#pragma once
#include <string>
struct Vector2 { float x, y; };

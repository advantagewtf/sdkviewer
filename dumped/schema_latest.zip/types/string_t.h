#pragma once
#include <cstdint>
using string_t = uintptr_t; // string_t placeholder

#pragma once
#include <string>
struct CUtlString { const char* str; std::string to_string() const { return str ? std::string(str) : std::string(); } };

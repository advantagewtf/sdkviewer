#pragma once
#include <string>
struct QAngle { float pitch, yaw, roll; };

#pragma once
#include <cstdint>
struct QAngle { float x, y, z; };

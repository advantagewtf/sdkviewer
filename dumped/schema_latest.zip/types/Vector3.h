#pragma once
#include <string>
struct Vector3 { float x, y, z; };

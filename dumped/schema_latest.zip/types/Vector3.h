#pragma once
#include <cstdint>
struct Vector3 { float x, y, z; };

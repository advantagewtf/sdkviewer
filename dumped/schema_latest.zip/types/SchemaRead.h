#pragma once
#include <cstdint>
template <typename t>
t t read(uintptr_t address) { return *(t*)address; }
#define SCHEMA_TYPE(type, add) read<type>(baseAddr + add)

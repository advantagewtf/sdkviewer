#pragma once
#include <string>
struct CUtlStringToken { uint32_t token; };

#pragma once
#include <cstdint>
template <typename T>
class CHandle { uintptr_t handle; };

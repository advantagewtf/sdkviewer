#pragma once
#include "../cstypes/uint16_t.h"
class C_EconItemView;

struct CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t  {
public:
    char PAD_0[0x10];
    uint16_t team;
    uint16_t slot;
};

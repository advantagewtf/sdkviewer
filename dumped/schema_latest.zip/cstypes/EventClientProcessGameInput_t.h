#pragma once
#include "../cstypes/EngineLoopState_t.h"

struct EventClientProcessGameInput_t  {
public:
    char PAD_0[0x20];
    float m_flRealTime;
    float m_flFrameTime;
};

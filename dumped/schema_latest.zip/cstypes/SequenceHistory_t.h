#pragma once
#include "../cstypes/AnimLoopMode_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"

struct SequenceHistory_t  {
public:
    char PAD_0[0x20];
    float m_flSeqFixedCycle;
    float m_flPlaybackRate;
    float m_flCyclesPerSecond;
};

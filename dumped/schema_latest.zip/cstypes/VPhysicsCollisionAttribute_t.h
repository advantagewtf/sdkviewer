#pragma once
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"

struct VPhysicsCollisionAttribute_t  {
public:
    char PAD_0[0x8];
    uint8_t m_nCollisionGroup;
    uint8_t m_nCollisionFunctionMask;
    char PAD_9[0x7];
    uint16_t m_nHierarchyId;
    char PAD_12[0xe];
    int m_nEntityId;
    int m_nOwnerId;
    char PAD_24[0x1c];
    uintptr_t m_nInteractsAs;
    uintptr_t m_nInteractsWith;
    uintptr_t m_nInteractsExclude;
};

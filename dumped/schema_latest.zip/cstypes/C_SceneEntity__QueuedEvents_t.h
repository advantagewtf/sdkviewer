#pragma once

struct C_SceneEntity__QueuedEvents_t  {
public:
    char PAD_0[0x20];
    float starttime;
};

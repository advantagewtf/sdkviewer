#pragma once

struct EventClientSceneSystemThreadStateChange_t  {
public:
};

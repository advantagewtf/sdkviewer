#pragma once
#include "../cstypes/uintptr_t.h"

struct EventProfileStorageAvailable_t  {
public:
};

#pragma once

struct CPulseCell_Outflow_CycleOrdered__InstanceState_t  {
public:
    char PAD_0[0x20];
    int m_nNextIndex;
};

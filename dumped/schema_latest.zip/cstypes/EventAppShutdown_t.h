#pragma once

struct EventAppShutdown_t  {
public:
    char PAD_0[0x20];
    int m_nDummy0;
};

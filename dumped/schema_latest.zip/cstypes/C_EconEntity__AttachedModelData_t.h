#pragma once

struct C_EconEntity__AttachedModelData_t  {
public:
    char PAD_0[0x20];
    int m_iModelDisplayFlags;
};

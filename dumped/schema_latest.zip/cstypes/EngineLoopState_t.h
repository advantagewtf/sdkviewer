#pragma once

struct EngineLoopState_t  {
public:
    char PAD_0[0x20];
    int m_nPlatWindowWidth;
    int m_nPlatWindowHeight;
    int m_nRenderWidth;
    int m_nRenderHeight;
};

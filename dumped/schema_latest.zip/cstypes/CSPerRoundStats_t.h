#pragma once

struct CSPerRoundStats_t  {
public:
    char PAD_0[0x20];
    int m_iKills;
    int m_iDeaths;
    int m_iAssists;
    int m_iDamage;
    int m_iEquipmentValue;
    int m_iMoneySaved;
    int m_iKillReward;
    int m_iLiveTime;
    int m_iHeadShotKills;
    int m_iObjective;
    int m_iCashEarned;
    int m_iUtilityDamage;
    int m_iEnemiesFlashed;
};

#pragma once

struct EventPostAdvanceTick_t  {
public:
    char PAD_0[0x20];
    int m_nCurrentTick;
    int m_nCurrentTickThisFrame;
    int m_nTotalTicksThisFrame;
    int m_nTotalTicks;
};

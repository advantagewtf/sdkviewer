#pragma once
#include "../cstypes/EngineLoopState_t.h"
#include "../cstypes/uintptr_t.h"

struct EventClientPreOutput_t  {
public:
    char PAD_0[0x20];
    float m_flRealTime;
    char PAD_24[0x1c];
    uintptr_t m_flRenderTime;
    uintptr_t m_flRenderFrameTime;
    uintptr_t m_flRenderFrameTimeUnbounded;
};

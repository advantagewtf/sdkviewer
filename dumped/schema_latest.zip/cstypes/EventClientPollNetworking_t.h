#pragma once

struct EventClientPollNetworking_t  {
public:
    char PAD_0[0x20];
    int m_nTickCount;
};

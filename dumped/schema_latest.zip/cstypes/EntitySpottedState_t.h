#pragma once

struct EntitySpottedState_t  {
public:
    char PAD_0[0x20];
    int m_bSpottedByMask;
};

#pragma once
#include "../cstypes/uintptr_t.h"
class C_FogController;

struct C_fogplayerparams_t  {
public:
    char PAD_0[0x20];
    float m_flTransitionTime;
    float m_flOldStart;
    float m_flOldEnd;
    float m_flOldMaxDensity;
    float m_flOldHDRColorScale;
    float m_flOldFarZ;
    float m_flNewStart;
    float m_flNewEnd;
    float m_flNewMaxDensity;
    float m_flNewHDRColorScale;
    float m_flNewFarZ;
};

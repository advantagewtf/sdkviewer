#pragma once
class CBaseAnimGraph;

struct CPulseCell_PlaySequence__CursorState_t  {
public:
};

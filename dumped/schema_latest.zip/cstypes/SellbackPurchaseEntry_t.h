#pragma once
#include "../cstypes/uint16_t.h"
#include "../cstypes/uintptr_t.h"

struct SellbackPurchaseEntry_t  {
public:
    char PAD_0[0x10];
    uint16_t m_unDefIdx;
    char PAD_12[0xe];
    int m_nCost;
    int m_nPrevArmor;
};

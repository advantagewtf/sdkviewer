#pragma once

struct CPulseCell_LimitCount__Criteria_t  {
public:
};

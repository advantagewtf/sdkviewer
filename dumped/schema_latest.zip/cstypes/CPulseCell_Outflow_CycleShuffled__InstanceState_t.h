#pragma once
#include "../cstypes/uint8_t.h"

struct CPulseCell_Outflow_CycleShuffled__InstanceState_t  {
public:
    char PAD_0[0x8];
    uint8_t m_Shuffle;
    char PAD_9[0x17];
    int m_nNextShuffle;
};

#pragma once
#include "../cstypes/uint16_t.h"

struct WeaponPurchaseCount_t  {
public:
    char PAD_0[0x10];
    uint16_t m_nItemDefIndex;
    uint16_t m_nCount;
};

#pragma once
#include "../cstypes/uintptr_t.h"
class CEntityComponentHelper;

struct EntComponentInfo_t  {
public:
    char PAD_0[0x20];
    int m_nRuntimeIndex;
    int m_nFlags;
};

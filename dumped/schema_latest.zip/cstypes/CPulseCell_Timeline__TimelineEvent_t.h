#pragma once
#include "../classes/CPulse_OutflowConnection.h"

struct CPulseCell_Timeline__TimelineEvent_t  {
public:
    char PAD_0[0x20];
    float m_flTimeFromPrevious;
};

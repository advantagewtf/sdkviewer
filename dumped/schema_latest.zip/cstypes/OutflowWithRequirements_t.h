#pragma once
#include "../classes/CPulse_OutflowConnection.h"
#include "../cstypes/PulseDocNodeID_t.h"
#include "../types/Vector3.h"

struct OutflowWithRequirements_t  {
public:
    char PAD_0[0x20];
    int m_nCursorStateBlockIndex;
};

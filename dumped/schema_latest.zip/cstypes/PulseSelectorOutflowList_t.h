#pragma once
#include "../types/Vector3.h"

struct PulseSelectorOutflowList_t  {
public:
};

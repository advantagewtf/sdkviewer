#pragma once

struct EventClientProcessNetworking_t  {
public:
    char PAD_0[0x20];
    int m_nTickCount;
};

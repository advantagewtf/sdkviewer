#pragma once
#include "../cstypes/ModelConfigHandle_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

struct ActiveModelConfig_t  {
public:
};

#pragma once
#include "../classes/CPulse_OutflowConnection.h"
#include "../cstypes/uintptr_t.h"

struct PulseNodeDynamicOutflows_t__DynamicOutflow_t  {
public:
};

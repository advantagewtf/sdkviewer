#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

struct EntityRenderAttribute_t  {
public:
    char PAD_0[0x4];
    Vector3 m_Values;
};

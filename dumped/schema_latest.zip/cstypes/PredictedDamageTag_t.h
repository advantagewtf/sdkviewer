#pragma once
#include "../cstypes/GameTick_t.h"

struct PredictedDamageTag_t  {
public:
    char PAD_0[0x20];
    float flFlinchModSmall;
    float flFlinchModLarge;
    float flFriendlyFireDamageReductionRatio;
};

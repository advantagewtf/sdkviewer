#pragma once

struct GameTime_t  {
public:
    char PAD_0[0x20];
    float m_Value;
};

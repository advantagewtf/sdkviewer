#pragma once

struct CSMatchStats_t  {
public:
    char PAD_0[0x20];
    int m_iEnemy5Ks;
    int m_iEnemy4Ks;
    int m_iEnemy3Ks;
    int m_iEnemyKnifeKills;
    int m_iEnemyTaserKills;
};

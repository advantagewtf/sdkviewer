#pragma once
#include "../cstypes/ShardSolid_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

struct shard_model_desc_t  {
public:
    char PAD_0[0x2];
    uintptr_t m_hMaterialBase;
    uintptr_t m_hMaterialDamageOverlay;
    Vector3 m_vecPanelSize;
    Vector3 m_vecStressPositionA;
    Vector3 m_vecStressPositionB;
    Vector3 m_vecPanelVertices;
    Vector3 m_vInitialPanelVertices;
    char PAD_8[0x18];
    int m_nModelID;
    float m_flGlassHalfThickness;
};

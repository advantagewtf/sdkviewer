#pragma once
#include "../cstypes/uintptr_t.h"

struct CAttributeManager__cached_attribute_float_t  {
public:
    char PAD_0[0x20];
    float flIn;
    float flOut;
};

#pragma once
#include "../cstypes/EngineLoopState_t.h"

struct EventSimulate_t  {
public:
};

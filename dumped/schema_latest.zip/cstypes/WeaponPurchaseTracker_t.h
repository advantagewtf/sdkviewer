#pragma once
#include "../types/Vector3.h"

struct WeaponPurchaseTracker_t  {
public:
};

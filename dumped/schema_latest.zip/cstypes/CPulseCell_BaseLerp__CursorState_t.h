#pragma once
#include "../cstypes/GameTime_t.h"

struct CPulseCell_BaseLerp__CursorState_t  {
public:
};

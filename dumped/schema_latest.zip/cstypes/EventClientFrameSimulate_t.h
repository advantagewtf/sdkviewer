#pragma once
#include "../cstypes/EngineLoopState_t.h"

struct EventClientFrameSimulate_t  {
public:
    char PAD_0[0x20];
    float m_flRealTime;
    float m_flFrameTime;
};

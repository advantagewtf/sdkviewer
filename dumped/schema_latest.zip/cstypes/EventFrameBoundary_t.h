#pragma once

struct EventFrameBoundary_t  {
public:
    char PAD_0[0x20];
    float m_flFrameTime;
};

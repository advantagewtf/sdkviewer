#pragma once
#include "../cstypes/PointCameraSettings_t.h"
class C_PointCamera;

struct CPulseCell_LerpCameraSettings__CursorState_t  {
public:
};

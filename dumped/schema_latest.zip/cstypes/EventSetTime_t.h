#pragma once
#include "../cstypes/EngineLoopState_t.h"
#include "../cstypes/uintptr_t.h"

struct EventSetTime_t  {
public:
    char PAD_0[0x20];
    int m_nClientOutputFrames;
    char PAD_24[0x1c];
    uintptr_t m_flRealTime;
    uintptr_t m_flRenderTime;
    uintptr_t m_flRenderFrameTime;
    uintptr_t m_flRenderFrameTimeUnbounded;
    uintptr_t m_flRenderFrameTimeUnscaled;
    uintptr_t m_flTickRemainder;
};

#pragma once
#include "../types/Vector3.h"

struct PulseNodeDynamicOutflows_t  {
public:
};

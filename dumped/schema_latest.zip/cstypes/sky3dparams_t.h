#pragma once
#include "../cstypes/WorldGroupId_t.h"
#include "../cstypes/fogparams_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

struct sky3dparams_t  {
public:
    char PAD_0[0x10];
    uintptr_t scale;
    char PAD_18[0x8];
    float flClip3DSkyBoxNearToWorldFarOffset;
};

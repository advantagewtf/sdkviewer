#pragma once

struct EventPostDataUpdate_t  {
public:
    char PAD_0[0x20];
    int m_nCount;
};

#pragma once
#include "../types/Vector3.h"
class C_BaseEntity;

struct PhysicsRagdollPose_t  {
public:
};

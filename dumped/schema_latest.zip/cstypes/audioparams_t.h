#pragma once
#include "../cstypes/uint8_t.h"
#include "../types/Vector3.h"

struct audioparams_t  {
public:
    char PAD_0[0x8];
    Vector3 localSound;
    uint8_t localBits;
    char PAD_9[0x17];
    int soundscapeIndex;
    int soundscapeEntityListIndex;
    int soundEventHash;
};

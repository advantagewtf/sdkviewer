#pragma once

struct CPulseCell_LimitCount__InstanceState_t  {
public:
    char PAD_0[0x20];
    int m_nCurrentCount;
};

#pragma once

struct CPulseCell_IsRequirementValid__Criteria_t  {
public:
};

#pragma once
#include "../cstypes/EngineLoopState_t.h"
#include "../cstypes/uintptr_t.h"

struct EventClientProcessInput_t  {
public:
    char PAD_0[0x20];
    float m_flRealTime;
    float m_flTickInterval;
    char PAD_24[0x1c];
    uintptr_t m_flTickStartTime;
};

#pragma once
#include "../classes/CPulse_OutflowConnection.h"
#include "../types/Vector3.h"

struct PulseObservableBoolExpression_t  {
public:
};

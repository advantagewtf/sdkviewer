#pragma once
#include "../cstypes/FixAngleSet_t.h"
#include "../types/QAngle.h"

struct ViewAngleServerChange_t  {
public:
    char PAD_0[0x20];
    int nIndex;
};

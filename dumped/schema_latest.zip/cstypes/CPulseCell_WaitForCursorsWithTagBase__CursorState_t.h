#pragma once
#include "../cstypes/PulseSymbol_t.h"

struct CPulseCell_WaitForCursorsWithTagBase__CursorState_t  {
public:
};

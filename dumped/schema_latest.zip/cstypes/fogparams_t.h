#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

struct fogparams_t  {
public:
    char PAD_0[0x20];
    float start;
    float end;
    float farz;
    float maxdensity;
    float exponent;
    float HDRColorScale;
    float skyboxFogFactor;
    float skyboxFogFactorLerpTo;
    float startLerpTo;
    float endLerpTo;
    float maxdensityLerpTo;
    float duration;
    float blendtobackground;
    float scattering;
    float locallightscale;
};

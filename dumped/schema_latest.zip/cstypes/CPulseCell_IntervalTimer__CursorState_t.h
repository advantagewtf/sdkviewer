#pragma once
#include "../cstypes/GameTime_t.h"

struct CPulseCell_IntervalTimer__CursorState_t  {
public:
    char PAD_0[0x20];
    float m_flWaitInterval;
    float m_flWaitIntervalHigh;
};

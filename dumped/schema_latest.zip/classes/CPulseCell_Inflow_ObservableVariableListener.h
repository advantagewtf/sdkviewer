#pragma once
#include "../cstypes/PulseRuntimeBlackboardReferenceIndex_t.h"

class CPulseCell_Inflow_ObservableVariableListener  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_ObservableVariableListener() : baseAddr(0) {}
    CPulseCell_Inflow_ObservableVariableListener(uintptr_t base) : baseAddr(base) {}

};

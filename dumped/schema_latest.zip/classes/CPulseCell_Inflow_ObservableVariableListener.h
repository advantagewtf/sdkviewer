#pragma once
#include <cstdint>
class CPulseCell_Inflow_ObservableVariableListener {
public:
    uintptr_t m_bSelfReference() { return SCHEMA_TYPE(uintptr_t, 0x82); }
    uintptr_t m_nBlackboardReference() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

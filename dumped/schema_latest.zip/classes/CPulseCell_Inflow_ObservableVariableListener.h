#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_ObservableVariableListener {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_ObservableVariableListener(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_ObservableVariableListener() : baseAddr(0) {}
    uintptr_t m_bSelfReference() { return SCHEMA_TYPE(uintptr_t, 0x82); }
    uintptr_t m_nBlackboardReference() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

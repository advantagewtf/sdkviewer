#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Inflow_Wait  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Wait() : baseAddr(0) {}
    CPulseCell_Inflow_Wait(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_Wait {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_Wait(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_Wait() : baseAddr(0) {}
    uintptr_t m_WakeResume() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include <cstdint>
class C_WorldModelGloves : public CBaseAnimGraph {
public:
};

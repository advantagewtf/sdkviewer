#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WorldModelGloves : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_WorldModelGloves(uintptr_t addr) : baseAddr(addr) {}
    C_WorldModelGloves() : baseAddr(0) {}
};

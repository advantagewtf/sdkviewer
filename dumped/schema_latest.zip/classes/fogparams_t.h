#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class fogparams_t {
public:
    uintptr_t /* float32 */ HDRColorScale() { return SCHEMA_TYPE(uintptr_t, 0x38); }
    bool blend() { return SCHEMA_TYPE(bool, 0x65); }
    uintptr_t /* float32 */ blendtobackground() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    uintptr_t /* Color */ colorPrimary() { return SCHEMA_TYPE(uintptr_t, 0x14); }
    uintptr_t /* Color */ colorPrimaryLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x1C); }
    uintptr_t /* Color */ colorSecondary() { return SCHEMA_TYPE(uintptr_t, 0x18); }
    uintptr_t /* Color */ colorSecondaryLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    Vector3 dirPrimary() { return SCHEMA_TYPE(Vector3, 0x8); }
    uintptr_t /* float32 */ duration() { return SCHEMA_TYPE(uintptr_t, 0x54); }
    bool enable() { return SCHEMA_TYPE(bool, 0x64); }
    uintptr_t /* float32 */ end() { return SCHEMA_TYPE(uintptr_t, 0x28); }
    uintptr_t /* float32 */ endLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t /* float32 */ exponent() { return SCHEMA_TYPE(uintptr_t, 0x34); }
    uintptr_t /* float32 */ farz() { return SCHEMA_TYPE(uintptr_t, 0x2C); }
    uintptr_t /* GameTime_t */ lerptime() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t /* float32 */ locallightscale() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    uintptr_t m_bPadding() { return SCHEMA_TYPE(uintptr_t, 0x67); }
    uintptr_t m_bPadding2() { return SCHEMA_TYPE(uintptr_t, 0x66); }
    uintptr_t /* float32 */ maxdensity() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t /* float32 */ maxdensityLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t /* float32 */ scattering() { return SCHEMA_TYPE(uintptr_t, 0x5C); }
    uintptr_t /* float32 */ skyboxFogFactor() { return SCHEMA_TYPE(uintptr_t, 0x3C); }
    uintptr_t /* float32 */ skyboxFogFactorLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* float32 */ start() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    uintptr_t /* float32 */ startLerpTo() { return SCHEMA_TYPE(uintptr_t, 0x44); }
};

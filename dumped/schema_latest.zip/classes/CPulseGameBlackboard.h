#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlString;
class CPulseGameBlackboard {
public:
    uintptr_t baseAddr;
    CPulseGameBlackboard(uintptr_t addr) : baseAddr(addr) {}
    CPulseGameBlackboard() : baseAddr(0) {}
    CUtlString m_strGraphName() { return SCHEMA_TYPE(CUtlString, 0x600); }
    CUtlString m_strStateBlob() { return SCHEMA_TYPE(CUtlString, 0x608); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseGameBlackboard  {
public:
    uintptr_t baseAddr;

    CPulseGameBlackboard() : baseAddr(0) {}
    CPulseGameBlackboard(uintptr_t base) : baseAddr(base) {}

};

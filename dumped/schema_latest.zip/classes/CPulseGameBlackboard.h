#pragma once
#include <cstdint>
class CPulseGameBlackboard {
public:
    uintptr_t /* CUtlString */ m_strGraphName() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t /* CUtlString */ m_strStateBlob() { return SCHEMA_TYPE(uintptr_t, 0x608); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CAttributeContainer;
class CCSPlayerPawn;
class C_Chicken {
public:
    uintptr_t baseAddr;
    C_Chicken(uintptr_t addr) : baseAddr(addr) {}
    C_Chicken() : baseAddr(0) {}
    CAttributeContainer m_AttributeManager() { return SCHEMA_TYPE(CAttributeContainer, 0x13B8); }
    uintptr_t m_bAttributesInitialized() { return SCHEMA_TYPE(uintptr_t, 0x1888); }
    uintptr_t m_bIsPreviewModel() { return SCHEMA_TYPE(uintptr_t, 0x1890); }
    uintptr_t m_hHolidayHatAddon() { return SCHEMA_TYPE(uintptr_t, 0x13A8); }
    uintptr_t m_hWaterWakeParticles() { return SCHEMA_TYPE(uintptr_t, 0x188C); }
    bool m_jumpedThisFrame() { return SCHEMA_TYPE(bool, 0x13AC); }
    CHandle<CCSPlayerPawn> m_leader() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x13B0); }
};

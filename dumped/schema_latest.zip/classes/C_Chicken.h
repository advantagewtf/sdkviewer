#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_Chicken {
public:
    uintptr_t /* CAttributeContainer */ m_AttributeManager() { return SCHEMA_TYPE(uintptr_t, 0x1438); }
    uintptr_t m_bAttributesInitialized() { return SCHEMA_TYPE(uintptr_t, 0x1910); }
    uintptr_t m_bIsPreviewModel() { return SCHEMA_TYPE(uintptr_t, 0x1918); }
    uintptr_t m_hHolidayHatAddon() { return SCHEMA_TYPE(uintptr_t, 0x1428); }
    uintptr_t m_hWaterWakeParticles() { return SCHEMA_TYPE(uintptr_t, 0x1914); }
    bool m_jumpedThisFrame() { return SCHEMA_TYPE(bool, 0x142C); }
    CHandle<CCSPlayerPawn> m_leader() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x1430); }
};

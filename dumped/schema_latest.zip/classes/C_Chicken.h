#pragma once
#include "../classes/C_AttributeContainer.h"
#include "../cstypes/ParticleIndex_t.h"
class CBaseAnimGraph;
class C_CSPlayerPawn;

class C_Chicken  {
public:
    uintptr_t baseAddr;

    C_Chicken() : baseAddr(0) {}
    C_Chicken(uintptr_t base) : baseAddr(base) {}

};

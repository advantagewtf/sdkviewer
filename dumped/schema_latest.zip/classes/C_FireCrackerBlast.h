#pragma once
#include <cstdint>
class C_FireCrackerBlast {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FireCrackerBlast {
public:
    uintptr_t baseAddr;
    C_FireCrackerBlast(uintptr_t addr) : baseAddr(addr) {}
    C_FireCrackerBlast() : baseAddr(0) {}
};

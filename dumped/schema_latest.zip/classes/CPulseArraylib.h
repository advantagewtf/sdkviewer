#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseArraylib {
public:
    uintptr_t baseAddr;
    CPulseArraylib(uintptr_t addr) : baseAddr(addr) {}
    CPulseArraylib() : baseAddr(0) {}
};

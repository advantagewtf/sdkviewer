#pragma once
#include <cstdint>
class CPulseArraylib {
public:
};

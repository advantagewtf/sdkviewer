#pragma once

class C_SpotlightEnd  {
public:
    uintptr_t baseAddr;

    C_SpotlightEnd() : baseAddr(0) {}
    C_SpotlightEnd(uintptr_t base) : baseAddr(base) {}

    float m_flLightScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_Radius() { return SCHEMA_TYPE(float, 0x20); }
};

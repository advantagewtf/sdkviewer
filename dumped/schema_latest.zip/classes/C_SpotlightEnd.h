#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class C_SpotlightEnd : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_SpotlightEnd(uintptr_t addr) : baseAddr(addr) {}
    C_SpotlightEnd() : baseAddr(0) {}
    float32 m_Radius() { return SCHEMA_TYPE(float32, 0xE8C); }
    float32 m_flLightScale() { return SCHEMA_TYPE(float32, 0xE88); }
};

#pragma once
#include <cstdint>
class C_SpotlightEnd : public C_BaseModelEntity {
public:
    uintptr_t /* float32 */ m_Radius() { return SCHEMA_TYPE(uintptr_t, 0xEB4); }
    uintptr_t /* float32 */ m_flLightScale() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

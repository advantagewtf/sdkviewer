#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_CSPlayerResource  {
public:
    uintptr_t baseAddr;

    C_CSPlayerResource() : baseAddr(0) {}
    C_CSPlayerResource(uintptr_t base) : baseAddr(base) {}

    bool m_bHostageAlive() { return SCHEMA_TYPE(bool, 0xc); }
    bool m_isHostageFollowingSomeone() { return SCHEMA_TYPE(bool, 0xc); }
    uintptr_t m_iHostageEntityIDs() { return SCHEMA_TYPE(uintptr_t, 0xc); }
    int m_hostageRescueX() { return SCHEMA_TYPE(int, 0x20); }
    int m_hostageRescueY() { return SCHEMA_TYPE(int, 0x20); }
    int m_hostageRescueZ() { return SCHEMA_TYPE(int, 0x20); }
};

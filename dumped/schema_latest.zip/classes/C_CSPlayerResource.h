#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CEntityIndex;
class C_CSPlayerResource : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSPlayerResource(uintptr_t addr) : baseAddr(addr) {}
    C_CSPlayerResource() : baseAddr(0) {}
    bool m_bEndMatchNextMapAllVoted() { return SCHEMA_TYPE(bool, 0x698); }
    bool m_bHostageAlive() { return SCHEMA_TYPE(bool, 0x608); }
    Vector3 m_bombsiteCenterA() { return SCHEMA_TYPE(Vector3, 0x650); }
    Vector3 m_bombsiteCenterB() { return SCHEMA_TYPE(Vector3, 0x65C); }
    uintptr_t m_foundGoalPositions() { return SCHEMA_TYPE(uintptr_t, 0x699); }
    int32_t m_hostageRescueX() { return SCHEMA_TYPE(int32_t, 0x668); }
    int32_t m_hostageRescueY() { return SCHEMA_TYPE(int32_t, 0x678); }
    int32_t m_hostageRescueZ() { return SCHEMA_TYPE(int32_t, 0x688); }
    CEntityIndex m_iHostageEntityIDs() { return SCHEMA_TYPE(CEntityIndex, 0x620); }
    bool m_isHostageFollowingSomeone() { return SCHEMA_TYPE(bool, 0x614); }
};

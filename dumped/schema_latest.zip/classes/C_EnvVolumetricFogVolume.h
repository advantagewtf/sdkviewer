#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class Color;
class C_EnvVolumetricFogVolume : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvVolumetricFogVolume(uintptr_t addr) : baseAddr(addr) {}
    C_EnvVolumetricFogVolume() : baseAddr(0) {}
    Color m_TintColor() { return SCHEMA_TYPE(Color, 0x638); }
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x5F8); }
    bool m_bIndirectUseLPVs() { return SCHEMA_TYPE(bool, 0x615); }
    bool m_bOverrideIndirectLightStrength() { return SCHEMA_TYPE(bool, 0x63D); }
    bool m_bOverrideNoiseStrength() { return SCHEMA_TYPE(bool, 0x63F); }
    bool m_bOverrideSunLightStrength() { return SCHEMA_TYPE(bool, 0x63E); }
    bool m_bOverrideTintColor() { return SCHEMA_TYPE(bool, 0x63C); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x614); }
    float m_fHeightFogEdgeWidth() { return SCHEMA_TYPE(float, 0x628); }
    float m_fIndirectLightStrength() { return SCHEMA_TYPE(float, 0x62C); }
    float m_fNoiseStrength() { return SCHEMA_TYPE(float, 0x634); }
    float m_fSunLightStrength() { return SCHEMA_TYPE(float, 0x630); }
    float m_flFalloffExponent() { return SCHEMA_TYPE(float, 0x620); }
    float m_flHeightFogDepth() { return SCHEMA_TYPE(float, 0x624); }
    float m_flStrength() { return SCHEMA_TYPE(float, 0x618); }
    int32_t m_nFalloffShape() { return SCHEMA_TYPE(int32_t, 0x61C); }
    Vector3 m_vBoxMaxs() { return SCHEMA_TYPE(Vector3, 0x608); }
    Vector3 m_vBoxMins() { return SCHEMA_TYPE(Vector3, 0x5FC); }
};

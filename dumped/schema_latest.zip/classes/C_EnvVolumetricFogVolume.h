#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_EnvVolumetricFogVolume  {
public:
    uintptr_t baseAddr;

    C_EnvVolumetricFogVolume() : baseAddr(0) {}
    C_EnvVolumetricFogVolume(uintptr_t base) : baseAddr(base) {}

    float m_flStrength() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFalloffShape() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFalloffExponent() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHeightFogDepth() { return SCHEMA_TYPE(float, 0x20); }
    float m_fHeightFogEdgeWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_fIndirectLightStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_fSunLightStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_fNoiseStrength() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class CPulseCell_Timeline__TimelineEvent_t {
public:
    uintptr_t m_EventOutflow() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_flTimeFromPrevious() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

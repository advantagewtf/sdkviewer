#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class Color;
class GameTime_t;
class HRenderTextureStrong;
class C_EnvVolumetricFogController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvVolumetricFogController(uintptr_t addr) : baseAddr(addr) {}
    C_EnvVolumetricFogController() : baseAddr(0) {}
    Color m_TintColor() { return SCHEMA_TYPE(Color, 0x5FC); }
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x644); }
    bool m_bEnableIndirect() { return SCHEMA_TYPE(bool, 0x66D); }
    uintptr_t m_bFirstTime() { return SCHEMA_TYPE(uintptr_t, 0x6A0); }
    bool m_bIsMaster() { return SCHEMA_TYPE(bool, 0x66E); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x66C); }
    float m_fFirstVolumeSliceThickness() { return SCHEMA_TYPE(float, 0x61C); }
    float m_fNoiseSpeed() { return SCHEMA_TYPE(float, 0x67C); }
    float m_fNoiseStrength() { return SCHEMA_TYPE(float, 0x680); }
    float m_fWindSpeed() { return SCHEMA_TYPE(float, 0x690); }
    float m_flAnisotropy() { return SCHEMA_TYPE(float, 0x600); }
    float m_flDefaultAnisotropy() { return SCHEMA_TYPE(float, 0x660); }
    float m_flDefaultDrawDistance() { return SCHEMA_TYPE(float, 0x668); }
    float m_flDefaultScattering() { return SCHEMA_TYPE(float, 0x664); }
    float m_flDrawDistance() { return SCHEMA_TYPE(float, 0x608); }
    float m_flFadeInEnd() { return SCHEMA_TYPE(float, 0x610); }
    float m_flFadeInStart() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flFadeSpeed() { return SCHEMA_TYPE(float, 0x604); }
    float m_flIndirectStrength() { return SCHEMA_TYPE(float, 0x614); }
    float m_flScattering() { return SCHEMA_TYPE(float, 0x5F8); }
    GameTime_t m_flStartAnisoTime() { return SCHEMA_TYPE(GameTime_t, 0x648); }
    float m_flStartAnisotropy() { return SCHEMA_TYPE(float, 0x654); }
    float m_flStartDrawDistance() { return SCHEMA_TYPE(float, 0x65C); }
    GameTime_t m_flStartDrawDistanceTime() { return SCHEMA_TYPE(GameTime_t, 0x650); }
    GameTime_t m_flStartScatterTime() { return SCHEMA_TYPE(GameTime_t, 0x64C); }
    float m_flStartScattering() { return SCHEMA_TYPE(float, 0x658); }
    HRenderTextureStrong m_hFogIndirectTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x670); }
    int32_t m_nForceRefreshCount() { return SCHEMA_TYPE(int32_t, 0x678); }
    int32_t m_nIndirectTextureDimX() { return SCHEMA_TYPE(int32_t, 0x620); }
    int32_t m_nIndirectTextureDimY() { return SCHEMA_TYPE(int32_t, 0x624); }
    int32_t m_nIndirectTextureDimZ() { return SCHEMA_TYPE(int32_t, 0x628); }
    int32_t m_nVolumeDepth() { return SCHEMA_TYPE(int32_t, 0x618); }
    Vector3 m_vBoxMaxs() { return SCHEMA_TYPE(Vector3, 0x638); }
    Vector3 m_vBoxMins() { return SCHEMA_TYPE(Vector3, 0x62C); }
    Vector3 m_vNoiseScale() { return SCHEMA_TYPE(Vector3, 0x684); }
    Vector3 m_vWindDirection() { return SCHEMA_TYPE(Vector3, 0x694); }
};

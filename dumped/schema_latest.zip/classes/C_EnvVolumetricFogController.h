#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_EnvVolumetricFogController  {
public:
    uintptr_t baseAddr;

    C_EnvVolumetricFogController() : baseAddr(0) {}
    C_EnvVolumetricFogController(uintptr_t base) : baseAddr(base) {}

    float m_flScattering() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAnisotropy() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDrawDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeInStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeInEnd() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIndirectStrength() { return SCHEMA_TYPE(float, 0x20); }
    int m_nVolumeDepth() { return SCHEMA_TYPE(int, 0x20); }
    float m_fFirstVolumeSliceThickness() { return SCHEMA_TYPE(float, 0x20); }
    int m_nIndirectTextureDimX() { return SCHEMA_TYPE(int, 0x20); }
    int m_nIndirectTextureDimY() { return SCHEMA_TYPE(int, 0x20); }
    int m_nIndirectTextureDimZ() { return SCHEMA_TYPE(int, 0x20); }
    float m_flStartAnisotropy() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartScattering() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartDrawDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefaultAnisotropy() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefaultScattering() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefaultDrawDistance() { return SCHEMA_TYPE(float, 0x20); }
    int m_nForceRefreshCount() { return SCHEMA_TYPE(int, 0x20); }
    float m_fNoiseSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_fNoiseStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_fWindSpeed() { return SCHEMA_TYPE(float, 0x20); }
};

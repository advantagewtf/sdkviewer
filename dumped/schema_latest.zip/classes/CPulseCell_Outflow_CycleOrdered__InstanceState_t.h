#pragma once
#include <cstdint>
class CPulseCell_Outflow_CycleOrdered__InstanceState_t {
public:
    uintptr_t m_nNextIndex() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

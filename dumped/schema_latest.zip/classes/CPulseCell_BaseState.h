#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseState {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseState(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseState() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPulseCell_BaseState {
public:
};

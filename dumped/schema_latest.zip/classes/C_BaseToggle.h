#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_BaseToggle : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_BaseToggle(uintptr_t addr) : baseAddr(addr) {}
    C_BaseToggle() : baseAddr(0) {}
};

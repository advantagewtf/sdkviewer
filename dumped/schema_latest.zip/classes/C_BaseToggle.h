#pragma once
#include <cstdint>
class C_BaseToggle : public C_BaseModelEntity {
public:
};

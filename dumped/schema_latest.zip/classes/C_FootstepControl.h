#pragma once
#include "../cstypes/uintptr_t.h"

class C_FootstepControl  {
public:
    uintptr_t baseAddr;

    C_FootstepControl() : baseAddr(0) {}
    C_FootstepControl(uintptr_t base) : baseAddr(base) {}

};

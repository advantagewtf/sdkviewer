#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_FootstepControl : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_FootstepControl(uintptr_t addr) : baseAddr(addr) {}
    C_FootstepControl() : baseAddr(0) {}
    string_t m_destination() { return SCHEMA_TYPE(string_t, 0xFF8); }
    string_t m_source() { return SCHEMA_TYPE(string_t, 0xFF0); }
};

#pragma once
#include <cstdint>
#include "../types/string_t.h"
class C_FootstepControl : public C_BaseTrigger {
public:
    string_t m_destination() { return SCHEMA_TYPE(string_t, 0xFF8); }
    string_t m_source() { return SCHEMA_TYPE(string_t, 0xFF0); }
};

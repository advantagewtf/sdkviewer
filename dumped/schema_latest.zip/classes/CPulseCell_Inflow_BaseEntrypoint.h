#pragma once
#include <cstdint>
class CPulseCell_Inflow_BaseEntrypoint {
public:
    uintptr_t m_EntryChunk() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_RegisterMap() { return SCHEMA_TYPE(uintptr_t, 0x50); }
};

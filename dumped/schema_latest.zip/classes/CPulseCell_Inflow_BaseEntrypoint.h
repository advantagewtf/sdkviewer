#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_BaseEntrypoint {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_BaseEntrypoint(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_BaseEntrypoint() : baseAddr(0) {}
    uintptr_t m_EntryChunk() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_RegisterMap() { return SCHEMA_TYPE(uintptr_t, 0x50); }
};

#pragma once
#include "../cstypes/PulseRegisterMap_t.h"
#include "../cstypes/PulseRuntimeChunkIndex_t.h"

class CPulseCell_Inflow_BaseEntrypoint  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_BaseEntrypoint() : baseAddr(0) {}
    CPulseCell_Inflow_BaseEntrypoint(uintptr_t base) : baseAddr(base) {}

};

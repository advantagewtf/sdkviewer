#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponAug : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponAug(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponAug() : baseAddr(0) {}
};

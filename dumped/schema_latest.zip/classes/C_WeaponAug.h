#pragma once
#include <cstdint>
class C_WeaponAug : public C_CSWeaponBaseGun {
public:
};

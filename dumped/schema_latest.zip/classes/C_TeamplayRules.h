#pragma once
#include <cstdint>
class C_TeamplayRules {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TeamplayRules {
public:
    uintptr_t baseAddr;
    C_TeamplayRules(uintptr_t addr) : baseAddr(addr) {}
    C_TeamplayRules() : baseAddr(0) {}
};

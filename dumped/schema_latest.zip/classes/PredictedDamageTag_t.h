#pragma once
#include <cstdint>
class PredictedDamageTag_t {
public:
    float flFlinchModLarge() { return SCHEMA_TYPE(float, 0x38); }
    float flFlinchModSmall() { return SCHEMA_TYPE(float, 0x34); }
    float flFriendlyFireDamageReductionRatio() { return SCHEMA_TYPE(float, 0x3C); }
    uintptr_t /* GameTick_t */ nTagTick() { return SCHEMA_TYPE(uintptr_t, 0x30); }
};

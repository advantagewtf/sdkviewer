#pragma once
#include <cstdint>
class CSPerRoundStats_t {
public:
    int32_t m_iAssists() { return SCHEMA_TYPE(int32_t, 0x38); }
    int32_t m_iCashEarned() { return SCHEMA_TYPE(int32_t, 0x58); }
    int32_t m_iDamage() { return SCHEMA_TYPE(int32_t, 0x3C); }
    int32_t m_iDeaths() { return SCHEMA_TYPE(int32_t, 0x34); }
    int32_t m_iEnemiesFlashed() { return SCHEMA_TYPE(int32_t, 0x60); }
    int32_t m_iEquipmentValue() { return SCHEMA_TYPE(int32_t, 0x40); }
    int32_t m_iHeadShotKills() { return SCHEMA_TYPE(int32_t, 0x50); }
    int32_t m_iKillReward() { return SCHEMA_TYPE(int32_t, 0x48); }
    int32_t m_iKills() { return SCHEMA_TYPE(int32_t, 0x30); }
    int32_t m_iLiveTime() { return SCHEMA_TYPE(int32_t, 0x4C); }
    int32_t m_iMoneySaved() { return SCHEMA_TYPE(int32_t, 0x44); }
    int32_t m_iObjective() { return SCHEMA_TYPE(int32_t, 0x54); }
    int32_t m_iUtilityDamage() { return SCHEMA_TYPE(int32_t, 0x5C); }
};

#pragma once
#include "../classes/C_EconItemView.h"
#include "../cstypes/uintptr_t.h"

class C_CSGO_TeamPreviewCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamPreviewCharacterPosition() : baseAddr(0) {}
    C_CSGO_TeamPreviewCharacterPosition(uintptr_t base) : baseAddr(base) {}

    int m_nVariant() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRandom() { return SCHEMA_TYPE(int, 0x20); }
    int m_nOrdinal() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_xuid() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

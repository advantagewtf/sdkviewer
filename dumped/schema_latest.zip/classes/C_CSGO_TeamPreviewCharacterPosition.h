#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEconItemView;
class CUtlString;
class XUID;
class C_CSGO_TeamPreviewCharacterPosition : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamPreviewCharacterPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamPreviewCharacterPosition() : baseAddr(0) {}
    CEconItemView m_agentItem() { return SCHEMA_TYPE(CEconItemView, 0x628); }
    CEconItemView m_glovesItem() { return SCHEMA_TYPE(CEconItemView, 0xA98); }
    int32_t m_nOrdinal() { return SCHEMA_TYPE(int32_t, 0x610); }
    int32_t m_nRandom() { return SCHEMA_TYPE(int32_t, 0x60C); }
    int32_t m_nVariant() { return SCHEMA_TYPE(int32_t, 0x608); }
    CUtlString m_sWeaponName() { return SCHEMA_TYPE(CUtlString, 0x618); }
    CEconItemView m_weaponItem() { return SCHEMA_TYPE(CEconItemView, 0xF08); }
    XUID m_xuid() { return SCHEMA_TYPE(XUID, 0x620); }
};

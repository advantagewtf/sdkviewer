#pragma once
#include <cstdint>
class C_CSGO_TeamPreviewCharacterPosition : public C_BaseEntity {
public:
    uintptr_t /* CEconItemView */ m_agentItem() { return SCHEMA_TYPE(uintptr_t, 0x618); }
    uintptr_t /* CEconItemView */ m_glovesItem() { return SCHEMA_TYPE(uintptr_t, 0xA90); }
    int32_t m_nOrdinal() { return SCHEMA_TYPE(int32_t, 0x600); }
    int32_t m_nRandom() { return SCHEMA_TYPE(int32_t, 0x5FC); }
    int32_t m_nVariant() { return SCHEMA_TYPE(int32_t, 0x5F8); }
    uintptr_t /* CUtlString */ m_sWeaponName() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t /* CEconItemView */ m_weaponItem() { return SCHEMA_TYPE(uintptr_t, 0xF08); }
    uintptr_t /* XUID */ m_xuid() { return SCHEMA_TYPE(uintptr_t, 0x610); }
};

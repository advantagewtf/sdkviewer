#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DynamicPropAlias_dynamic_prop : public C_DynamicProp {
public:
    uintptr_t baseAddr;
    C_DynamicPropAlias_dynamic_prop(uintptr_t addr) : baseAddr(addr) {}
    C_DynamicPropAlias_dynamic_prop() : baseAddr(0) {}
};

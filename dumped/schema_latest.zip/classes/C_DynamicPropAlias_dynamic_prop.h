#pragma once
#include "../memory.h"

class C_DynamicPropAlias_dynamic_prop {
public:
 uintptr_t baseAddr;
 C_DynamicPropAlias_dynamic_prop() : baseAddr(0){}
 C_DynamicPropAlias_dynamic_prop(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
class C_DynamicPropAlias_dynamic_prop : public C_DynamicProp {
public:
};

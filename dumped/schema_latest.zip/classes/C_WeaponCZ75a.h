#pragma once

class C_WeaponCZ75a  {
public:
    uintptr_t baseAddr;

    C_WeaponCZ75a() : baseAddr(0) {}
    C_WeaponCZ75a(uintptr_t base) : baseAddr(base) {}

};

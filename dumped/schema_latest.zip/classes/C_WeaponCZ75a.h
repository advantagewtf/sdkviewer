#pragma once
#include <cstdint>
class C_WeaponCZ75a : public C_CSWeaponBaseGun {
public:
    bool m_bMagazineRemoved() { return SCHEMA_TYPE(bool, 0x1FB0); }
};

#pragma once
#include "../memory.h"

class C_WeaponCZ75a {
public:
 uintptr_t baseAddr;
 C_WeaponCZ75a() : baseAddr(0){}
 C_WeaponCZ75a(uintptr_t b):baseAddr(b){}
 uintptr_t m_bMagazineRemoved(){return SCHEMA_TYPE(uintptr_t,0x1FB0);}
};

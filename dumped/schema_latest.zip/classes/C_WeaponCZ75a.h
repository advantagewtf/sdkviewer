#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponCZ75a : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponCZ75a(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponCZ75a() : baseAddr(0) {}
    bool m_bMagazineRemoved() { return SCHEMA_TYPE(bool, 0x1FB0); }
};

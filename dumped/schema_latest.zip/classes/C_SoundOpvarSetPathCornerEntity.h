#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetPathCornerEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetPathCornerEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetPathCornerEntity() : baseAddr(0) {}
};

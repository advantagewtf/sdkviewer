#pragma once
#include <cstdint>
class C_SoundOpvarSetPathCornerEntity {
public:
};

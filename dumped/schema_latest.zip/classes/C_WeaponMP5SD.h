#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponMP5SD : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponMP5SD(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponMP5SD() : baseAddr(0) {}
};

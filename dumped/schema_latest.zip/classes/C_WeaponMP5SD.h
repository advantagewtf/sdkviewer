#pragma once
#include <cstdint>
class C_WeaponMP5SD : public C_CSWeaponBaseGun {
public:
};

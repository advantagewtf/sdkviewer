#pragma once

class CHitboxComponent  {
public:
    uintptr_t baseAddr;

    CHitboxComponent() : baseAddr(0) {}
    CHitboxComponent(uintptr_t base) : baseAddr(base) {}

    float m_flBoundsExpandRadius() { return SCHEMA_TYPE(float, 0x20); }
};

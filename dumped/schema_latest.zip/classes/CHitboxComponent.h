#pragma once
#include <cstdint>
class CHitboxComponent : public CEntityComponent {
public:
    uintptr_t m_flBoundsExpandRadius() { return SCHEMA_TYPE(uintptr_t, 0x14); }
};

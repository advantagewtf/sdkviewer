#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CHitboxComponent : public CEntityComponent {
public:
    uintptr_t baseAddr;
    CHitboxComponent(uintptr_t addr) : baseAddr(addr) {}
    CHitboxComponent() : baseAddr(0) {}
    uintptr_t m_flBoundsExpandRadius() { return SCHEMA_TYPE(uintptr_t, 0x14); }
};

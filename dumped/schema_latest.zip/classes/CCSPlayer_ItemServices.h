#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_ItemServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_ItemServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_ItemServices() : baseAddr(0) {}
    bool m_bHasDefuser() { return SCHEMA_TYPE(bool, 0x48); }
    bool m_bHasHelmet() { return SCHEMA_TYPE(bool, 0x49); }
};

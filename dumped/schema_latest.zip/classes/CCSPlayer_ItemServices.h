#pragma once
#include <cstdint>
class CCSPlayer_ItemServices {
public:
    bool m_bHasDefuser() { return SCHEMA_TYPE(bool, 0x40); }
    bool m_bHasHelmet() { return SCHEMA_TYPE(bool, 0x41); }
};

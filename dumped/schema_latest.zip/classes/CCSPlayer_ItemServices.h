#pragma once

class CCSPlayer_ItemServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_ItemServices() : baseAddr(0) {}
    CCSPlayer_ItemServices(uintptr_t base) : baseAddr(base) {}

};

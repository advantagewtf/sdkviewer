#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBaseProp : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    CBaseProp(uintptr_t addr) : baseAddr(addr) {}
    CBaseProp() : baseAddr(0) {}
    uintptr_t m_bConformToCollisionBounds() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    uintptr_t m_bModelOverrodeBlockLOS() { return SCHEMA_TYPE(uintptr_t, 0x1168); }
    uintptr_t m_iShapeType() { return SCHEMA_TYPE(uintptr_t, 0x116C); }
    uintptr_t m_mPreferredCatchTransform() { return SCHEMA_TYPE(uintptr_t, 0x1180); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class CBaseProp  {
public:
    uintptr_t baseAddr;

    CBaseProp() : baseAddr(0) {}
    CBaseProp(uintptr_t base) : baseAddr(base) {}

    int m_iShapeType() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_InfoLadderDismount : public C_BaseEntity {
public:
};

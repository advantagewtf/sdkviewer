#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_InfoLadderDismount : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_InfoLadderDismount(uintptr_t addr) : baseAddr(addr) {}
    C_InfoLadderDismount() : baseAddr(0) {}
};

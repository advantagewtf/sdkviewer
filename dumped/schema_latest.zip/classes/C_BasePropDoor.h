#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class DoorState_t;
class QAngle;
class C_BasePropDoor {
public:
    uintptr_t baseAddr;
    C_BasePropDoor(uintptr_t addr) : baseAddr(addr) {}
    C_BasePropDoor() : baseAddr(0) {}
    bool m_bLocked() { return SCHEMA_TYPE(bool, 0x13B5); }
    bool m_bNoNPCs() { return SCHEMA_TYPE(bool, 0x13B6); }
    QAngle m_closedAngles() { return SCHEMA_TYPE(QAngle, 0x13C4); }
    Vector3 m_closedPosition() { return SCHEMA_TYPE(Vector3, 0x13B8); }
    DoorState_t m_eDoorState() { return SCHEMA_TYPE(DoorState_t, 0x13B0); }
    CHandle<C_BasePropDoor> m_hMaster() { return SCHEMA_TYPE(CHandle<C_BasePropDoor>, 0x13D0); }
    uintptr_t m_modelChanged() { return SCHEMA_TYPE(uintptr_t, 0x13B4); }
    uintptr_t m_vWhereToSetLightingOrigin() { return SCHEMA_TYPE(uintptr_t, 0x13D4); }
};

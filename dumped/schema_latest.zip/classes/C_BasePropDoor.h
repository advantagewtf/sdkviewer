#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/Vector3.h"
#include "C_BasePropDoor.h"
class C_BasePropDoor {
public:
    bool m_bLocked() { return SCHEMA_TYPE(bool, 0x1435); }
    bool m_bNoNPCs() { return SCHEMA_TYPE(bool, 0x1436); }
    uintptr_t /* QAngle */ m_closedAngles() { return SCHEMA_TYPE(uintptr_t, 0x1444); }
    Vector3 m_closedPosition() { return SCHEMA_TYPE(Vector3, 0x1438); }
    uintptr_t /* DoorState_t */ m_eDoorState() { return SCHEMA_TYPE(uintptr_t, 0x1430); }
    CHandle<C_BasePropDoor> m_hMaster() { return SCHEMA_TYPE(CHandle<C_BasePropDoor>, 0x1450); }
    uintptr_t m_modelChanged() { return SCHEMA_TYPE(uintptr_t, 0x1434); }
    uintptr_t m_vWhereToSetLightingOrigin() { return SCHEMA_TYPE(uintptr_t, 0x1454); }
};

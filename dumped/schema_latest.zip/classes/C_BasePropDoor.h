#pragma once
#include "../cstypes/DoorState_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_BasePropDoor  {
public:
    uintptr_t baseAddr;

    C_BasePropDoor() : baseAddr(0) {}
    C_BasePropDoor(uintptr_t base) : baseAddr(base) {}

};

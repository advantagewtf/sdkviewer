#pragma once
#include "../cstypes/filter_t.h"
#include "../cstypes/uintptr_t.h"
class C_BaseEntity;

class CFilterMultiple  {
public:
    uintptr_t baseAddr;

    CFilterMultiple() : baseAddr(0) {}
    CFilterMultiple(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iFilterName() { return SCHEMA_TYPE(uintptr_t, 0xa); }
    C_BaseEntity* m_hFilter() { return SCHEMA_TYPE(C_BaseEntity*, 0xa); }
};

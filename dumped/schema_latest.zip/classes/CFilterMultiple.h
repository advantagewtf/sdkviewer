#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterMultiple : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterMultiple(uintptr_t addr) : baseAddr(addr) {}
    CFilterMultiple() : baseAddr(0) {}
    uintptr_t m_hFilter() { return SCHEMA_TYPE(uintptr_t, 0x698); }
    uintptr_t m_iFilterName() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    uintptr_t m_nFilterType() { return SCHEMA_TYPE(uintptr_t, 0x640); }
};

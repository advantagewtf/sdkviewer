#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponSCAR20 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponSCAR20(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponSCAR20() : baseAddr(0) {}
};

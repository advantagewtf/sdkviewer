#pragma once
#include <cstdint>
class C_WeaponM4A1Silencer : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponM4A1Silencer : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponM4A1Silencer(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponM4A1Silencer() : baseAddr(0) {}
};

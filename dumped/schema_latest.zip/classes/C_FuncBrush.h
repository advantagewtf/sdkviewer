#pragma once
#include <cstdint>
class C_FuncBrush : public C_BaseModelEntity {
public:
};

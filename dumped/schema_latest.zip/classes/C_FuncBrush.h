#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FuncBrush : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncBrush(uintptr_t addr) : baseAddr(addr) {}
    C_FuncBrush() : baseAddr(0) {}
};

#pragma once
#include "../classes/CGameSceneNodeHandle.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CEntityInstance;

class CGameSceneNode  {
public:
    uintptr_t baseAddr;

    CGameSceneNode() : baseAddr(0) {}
    CGameSceneNode(uintptr_t base) : baseAddr(base) {}

    float m_flScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAbsScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flWrappedScale() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_nParentAttachmentOrBone() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_bDirtyHierarchy() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bDirtyBoneMergeInfo() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bNetworkedPositionChanged() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bNetworkedAnglesChanged() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bNetworkedScaleChanged() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bWillBeCallingPostDataUpdate() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bBoneMergeFlex() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_nLatchAbsOrigin() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    uintptr_t m_bDirtyBoneMergeBoneToRoot() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uint8_t m_nHierarchicalDepth() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nHierarchyType() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nDoNotSetAnimTimeInInvalidatePhysicsCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_flZOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flClientLocalScale() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
class C_PlayerPing;

class CCSPlayer_PingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_PingServices() : baseAddr(0) {}
    CCSPlayer_PingServices(uintptr_t base) : baseAddr(base) {}

};

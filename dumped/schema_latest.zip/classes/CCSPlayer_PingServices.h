#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CPlayerPing;
class CCSPlayer_PingServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_PingServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_PingServices() : baseAddr(0) {}
    CHandle<CPlayerPing> m_hPlayerPing() { return SCHEMA_TYPE(CHandle<CPlayerPing>, 0x40); }
};

#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CCSPlayer_PingServices {
public:
    CHandle<CPlayerPing> m_hPlayerPing() { return SCHEMA_TYPE(CHandle<CPlayerPing>, 0x40); }
};

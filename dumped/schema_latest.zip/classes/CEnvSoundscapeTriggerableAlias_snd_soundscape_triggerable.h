#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable : public CEnvSoundscapeTriggerable {
public:
    uintptr_t baseAddr;
    CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable(uintptr_t addr) : baseAddr(addr) {}
    CEnvSoundscapeTriggerableAlias_snd_soundscape_triggerable() : baseAddr(0) {}
};

#pragma once
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../types/Vector3.h"

class CAnimGraphNetworkedVariables  {
public:
    uintptr_t baseAddr;

    CAnimGraphNetworkedVariables() : baseAddr(0) {}
    CAnimGraphNetworkedVariables(uintptr_t base) : baseAddr(base) {}

    int m_PredNetBoolVariables() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_PredNetByteVariables() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint16_t m_PredNetUInt16Variables() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_PredNetIntVariables() { return SCHEMA_TYPE(int, 0x20); }
    int m_PredNetUInt32Variables() { return SCHEMA_TYPE(int, 0x20); }
    Vector3 m_PredNetUInt64Variables() { return SCHEMA_TYPE(Vector3, 0x40); }
    float m_PredNetFloatVariables() { return SCHEMA_TYPE(float, 0x20); }
    int m_OwnerOnlyPredNetBoolVariables() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_OwnerOnlyPredNetByteVariables() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint16_t m_OwnerOnlyPredNetUInt16Variables() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_OwnerOnlyPredNetIntVariables() { return SCHEMA_TYPE(int, 0x20); }
    int m_OwnerOnlyPredNetUInt32Variables() { return SCHEMA_TYPE(int, 0x20); }
    Vector3 m_OwnerOnlyPredNetUInt64Variables() { return SCHEMA_TYPE(Vector3, 0x40); }
    float m_OwnerOnlyPredNetFloatVariables() { return SCHEMA_TYPE(float, 0x20); }
    int m_nBoolVariablesCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nOwnerOnlyBoolVariablesCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRandomSeedOffset() { return SCHEMA_TYPE(int, 0x20); }
    float m_flLastTeleportTime() { return SCHEMA_TYPE(float, 0x20); }
};

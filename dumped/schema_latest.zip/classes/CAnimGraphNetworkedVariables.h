#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CGlobalSymbol;
class byte;
class CAnimGraphNetworkedVariables {
public:
    uintptr_t baseAddr;
    CAnimGraphNetworkedVariables(uintptr_t addr) : baseAddr(addr) {}
    CAnimGraphNetworkedVariables() : baseAddr(0) {}
    uint32_t m_OwnerOnlyPredNetBoolVariables() { return SCHEMA_TYPE(uint32_t, 0xF8); }
    byte m_OwnerOnlyPredNetByteVariables() { return SCHEMA_TYPE(byte, 0x110); }
    float m_OwnerOnlyPredNetFloatVariables() { return SCHEMA_TYPE(float, 0x188); }
    CGlobalSymbol m_OwnerOnlyPredNetGlobalSymbolVariables() { return SCHEMA_TYPE(CGlobalSymbol, 0x1D0); }
    int32_t m_OwnerOnlyPredNetIntVariables() { return SCHEMA_TYPE(int32_t, 0x140); }
    QAngle m_OwnerOnlyPredNetQuaternionVariables() { return SCHEMA_TYPE(QAngle, 0x1B8); }
    uint16_t m_OwnerOnlyPredNetUInt16Variables() { return SCHEMA_TYPE(uint16_t, 0x128); }
    uint32_t m_OwnerOnlyPredNetUInt32Variables() { return SCHEMA_TYPE(uint32_t, 0x158); }
    uint64_t m_OwnerOnlyPredNetUInt64Variables() { return SCHEMA_TYPE(uint64_t, 0x170); }
    Vector3 m_OwnerOnlyPredNetVectorVariables() { return SCHEMA_TYPE(Vector3, 0x1A0); }
    uint32_t m_PredNetBoolVariables() { return SCHEMA_TYPE(uint32_t, 0x8); }
    byte m_PredNetByteVariables() { return SCHEMA_TYPE(byte, 0x20); }
    float m_PredNetFloatVariables() { return SCHEMA_TYPE(float, 0x98); }
    CGlobalSymbol m_PredNetGlobalSymbolVariables() { return SCHEMA_TYPE(CGlobalSymbol, 0xE0); }
    int32_t m_PredNetIntVariables() { return SCHEMA_TYPE(int32_t, 0x50); }
    QAngle m_PredNetQuaternionVariables() { return SCHEMA_TYPE(QAngle, 0xC8); }
    uint16_t m_PredNetUInt16Variables() { return SCHEMA_TYPE(uint16_t, 0x38); }
    uint32_t m_PredNetUInt32Variables() { return SCHEMA_TYPE(uint32_t, 0x68); }
    uint64_t m_PredNetUInt64Variables() { return SCHEMA_TYPE(uint64_t, 0x80); }
    Vector3 m_PredNetVectorVariables() { return SCHEMA_TYPE(Vector3, 0xB0); }
    float m_flLastTeleportTime() { return SCHEMA_TYPE(float, 0x1F4); }
    int32_t m_nBoolVariablesCount() { return SCHEMA_TYPE(int32_t, 0x1E8); }
    int32_t m_nOwnerOnlyBoolVariablesCount() { return SCHEMA_TYPE(int32_t, 0x1EC); }
    int32_t m_nRandomSeedOffset() { return SCHEMA_TYPE(int32_t, 0x1F0); }
};

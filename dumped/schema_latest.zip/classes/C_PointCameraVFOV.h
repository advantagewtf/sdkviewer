#pragma once
#include <cstdint>
class C_PointCameraVFOV : public C_PointCamera {
public:
    uintptr_t m_flVerticalFOV() { return SCHEMA_TYPE(uintptr_t, 0x658); }
};

#pragma once

class C_PointCameraVFOV  {
public:
    uintptr_t baseAddr;

    C_PointCameraVFOV() : baseAddr(0) {}
    C_PointCameraVFOV(uintptr_t base) : baseAddr(base) {}

    float m_flVerticalFOV() { return SCHEMA_TYPE(float, 0x20); }
};

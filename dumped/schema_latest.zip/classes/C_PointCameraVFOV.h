#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PointCameraVFOV : public C_PointCamera {
public:
    uintptr_t baseAddr;
    C_PointCameraVFOV(uintptr_t addr) : baseAddr(addr) {}
    C_PointCameraVFOV() : baseAddr(0) {}
    uintptr_t m_flVerticalFOV() { return SCHEMA_TYPE(uintptr_t, 0x668); }
};

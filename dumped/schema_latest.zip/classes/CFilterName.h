#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterName : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterName(uintptr_t addr) : baseAddr(addr) {}
    CFilterName() : baseAddr(0) {}
    uintptr_t m_iFilterName() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class CFilterName  {
public:
    uintptr_t baseAddr;

    CFilterName() : baseAddr(0) {}
    CFilterName(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
class CFilterName : public CBaseFilter {
public:
    uintptr_t m_iFilterName() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

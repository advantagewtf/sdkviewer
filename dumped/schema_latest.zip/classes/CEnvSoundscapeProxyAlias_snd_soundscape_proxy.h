#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvSoundscapeProxyAlias_snd_soundscape_proxy : public CEnvSoundscapeProxy {
public:
    uintptr_t baseAddr;
    CEnvSoundscapeProxyAlias_snd_soundscape_proxy(uintptr_t addr) : baseAddr(addr) {}
    CEnvSoundscapeProxyAlias_snd_soundscape_proxy() : baseAddr(0) {}
};

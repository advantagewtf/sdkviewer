#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class shard_model_desc_t;
class C_ShatterGlassShardPhysics : public C_PhysicsProp {
public:
    uintptr_t baseAddr;
    C_ShatterGlassShardPhysics(uintptr_t addr) : baseAddr(addr) {}
    C_ShatterGlassShardPhysics() : baseAddr(0) {}
    shard_model_desc_t m_ShardDesc() { return SCHEMA_TYPE(shard_model_desc_t, 0x1318); }
};

#pragma once
#include <cstdint>
class C_ShatterGlassShardPhysics : public C_PhysicsProp {
public:
    uintptr_t /* shard_model_desc_t */ m_ShardDesc() { return SCHEMA_TYPE(uintptr_t, 0x1318); }
};

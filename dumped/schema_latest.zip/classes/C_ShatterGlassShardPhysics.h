#pragma once
#include "../cstypes/shard_model_desc_t.h"

class C_ShatterGlassShardPhysics  {
public:
    uintptr_t baseAddr;

    C_ShatterGlassShardPhysics() : baseAddr(0) {}
    C_ShatterGlassShardPhysics(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_LocalTempEntity  {
public:
    uintptr_t baseAddr;

    C_LocalTempEntity() : baseAddr(0) {}
    C_LocalTempEntity(uintptr_t base) : baseAddr(base) {}

    int flags() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFrameMax() { return SCHEMA_TYPE(float, 0x20); }
    float x() { return SCHEMA_TYPE(float, 0x20); }
    float y() { return SCHEMA_TYPE(float, 0x20); }
    float fadeSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float bounceFactor() { return SCHEMA_TYPE(float, 0x20); }
    int hitSound() { return SCHEMA_TYPE(int, 0x20); }
    int priority() { return SCHEMA_TYPE(int, 0x20); }
    int tempent_renderamt() { return SCHEMA_TYPE(int, 0x20); }
    float m_flSpriteScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFlickerFrame() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFrameRate() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFrame() { return SCHEMA_TYPE(float, 0x20); }
    int m_iLastCollisionFrame() { return SCHEMA_TYPE(int, 0x20); }
};

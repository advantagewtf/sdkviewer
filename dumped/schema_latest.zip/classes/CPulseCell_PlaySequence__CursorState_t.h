#pragma once
#include <cstdint>
class CPulseCell_PlaySequence__CursorState_t {
public:
    uintptr_t m_hTarget() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

#pragma once
#include <cstdint>
class CPulseCell_WaitForCursorsWithTagBase {
public:
    uintptr_t m_WaitComplete() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nCursorsAllowedToWait() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

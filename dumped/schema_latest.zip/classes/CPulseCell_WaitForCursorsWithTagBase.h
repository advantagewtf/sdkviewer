#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_WaitForCursorsWithTagBase  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTagBase() : baseAddr(0) {}
    CPulseCell_WaitForCursorsWithTagBase(uintptr_t base) : baseAddr(base) {}

    int m_nCursorsAllowedToWait() { return SCHEMA_TYPE(int, 0x20); }
};

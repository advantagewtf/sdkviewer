#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_WaitForCursorsWithTagBase {
public:
    uintptr_t baseAddr;
    CPulseCell_WaitForCursorsWithTagBase(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_WaitForCursorsWithTagBase() : baseAddr(0) {}
    uintptr_t m_WaitComplete() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nCursorsAllowedToWait() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

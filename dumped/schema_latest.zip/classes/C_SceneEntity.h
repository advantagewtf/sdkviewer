#pragma once
#include "../cstypes/uint16_t.h"
#include "../types/Vector3.h"
class C_BaseFlex;

class C_SceneEntity  {
public:
    uintptr_t baseAddr;

    C_SceneEntity() : baseAddr(0) {}
    C_SceneEntity(uintptr_t base) : baseAddr(base) {}

    float m_flForceClientTime() { return SCHEMA_TYPE(float, 0x20); }
    uint16_t m_nSceneStringIndex() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flCurrentTime() { return SCHEMA_TYPE(float, 0x20); }
};

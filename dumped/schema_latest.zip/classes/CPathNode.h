#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CUtlString;
class CPathNode {
public:
    uintptr_t baseAddr;
    CPathNode(uintptr_t addr) : baseAddr(addr) {}
    CPathNode() : baseAddr(0) {}
    uintptr_t m_hPath() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    CUtlString m_strParentPathUniqueID() { return SCHEMA_TYPE(CUtlString, 0x620); }
    CUtlString m_strPathNodeParameter() { return SCHEMA_TYPE(CUtlString, 0x628); }
    Vector3 m_vInTangentLocal() { return SCHEMA_TYPE(Vector3, 0x608); }
    Vector3 m_vOutTangentLocal() { return SCHEMA_TYPE(Vector3, 0x614); }
    uintptr_t m_xWSPrevParent() { return SCHEMA_TYPE(uintptr_t, 0x630); }
};

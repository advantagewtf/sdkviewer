#pragma once

class CBombTarget  {
public:
    uintptr_t baseAddr;

    CBombTarget() : baseAddr(0) {}
    CBombTarget(uintptr_t base) : baseAddr(base) {}

};

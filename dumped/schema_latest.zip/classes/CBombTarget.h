#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBombTarget {
public:
    uintptr_t baseAddr;
    CBombTarget(uintptr_t addr) : baseAddr(addr) {}
    CBombTarget() : baseAddr(0) {}
    bool m_bBombPlantedHere() { return SCHEMA_TYPE(bool, 0xF58); }
};

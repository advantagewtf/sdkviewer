#pragma once
#include <cstdint>
class CBombTarget {
public:
    bool m_bBombPlantedHere() { return SCHEMA_TYPE(bool, 0xFF0); }
};

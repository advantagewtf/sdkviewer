#pragma once
#include <cstdint>
class C_ModelPointEntity : public C_BaseModelEntity {
public:
};

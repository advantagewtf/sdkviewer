#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_ModelPointEntity : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_ModelPointEntity(uintptr_t addr) : baseAddr(addr) {}
    C_ModelPointEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PhysPropClientside : public C_BreakableProp {
public:
    uintptr_t baseAddr;
    C_PhysPropClientside(uintptr_t addr) : baseAddr(addr) {}
    C_PhysPropClientside() : baseAddr(0) {}
    uintptr_t m_fDeathTime() { return SCHEMA_TYPE(uintptr_t, 0x12D4); }
    uintptr_t m_flTouchDelta() { return SCHEMA_TYPE(uintptr_t, 0x12D0); }
    uintptr_t m_nDamageType() { return SCHEMA_TYPE(uintptr_t, 0x12F0); }
    uintptr_t m_vecDamageDirection() { return SCHEMA_TYPE(uintptr_t, 0x12E4); }
    uintptr_t m_vecDamagePosition() { return SCHEMA_TYPE(uintptr_t, 0x12D8); }
};

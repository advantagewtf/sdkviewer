#pragma once
#include "../cstypes/DamageTypes_t.h"
#include "../cstypes/GameTime_t.h"
#include "../types/Vector3.h"

class C_PhysPropClientside  {
public:
    uintptr_t baseAddr;

    C_PhysPropClientside() : baseAddr(0) {}
    C_PhysPropClientside(uintptr_t base) : baseAddr(base) {}

};

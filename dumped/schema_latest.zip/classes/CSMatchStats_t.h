#pragma once
#include <cstdint>
class CSMatchStats_t {
public:
    int32_t m_iEnemy3Ks() { return SCHEMA_TYPE(int32_t, 0x70); }
    int32_t m_iEnemy4Ks() { return SCHEMA_TYPE(int32_t, 0x6C); }
    int32_t m_iEnemy5Ks() { return SCHEMA_TYPE(int32_t, 0x68); }
    int32_t m_iEnemyKnifeKills() { return SCHEMA_TYPE(int32_t, 0x74); }
    int32_t m_iEnemyTaserKills() { return SCHEMA_TYPE(int32_t, 0x78); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_CSGO_PreviewPlayer  {
public:
    uintptr_t baseAddr;

    C_CSGO_PreviewPlayer() : baseAddr(0) {}
    C_CSGO_PreviewPlayer(uintptr_t base) : baseAddr(base) {}

    float m_flInitialModelScale() { return SCHEMA_TYPE(float, 0x20); }
};

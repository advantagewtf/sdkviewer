#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_PreviewPlayer {
public:
    uintptr_t baseAddr;
    C_CSGO_PreviewPlayer(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_PreviewPlayer() : baseAddr(0) {}
    uintptr_t m_animgraphCharacterModeString() { return SCHEMA_TYPE(uintptr_t, 0x3F10); }
    uintptr_t m_flInitialModelScale() { return SCHEMA_TYPE(uintptr_t, 0x3F18); }
};

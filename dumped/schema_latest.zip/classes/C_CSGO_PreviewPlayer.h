#pragma once
#include <cstdint>
class C_CSGO_PreviewPlayer {
public:
    uintptr_t m_animgraphCharacterModeString() { return SCHEMA_TYPE(uintptr_t, 0x3F10); }
    uintptr_t m_flInitialModelScale() { return SCHEMA_TYPE(uintptr_t, 0x3F18); }
};

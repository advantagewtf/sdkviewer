#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DEagle : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_DEagle(uintptr_t addr) : baseAddr(addr) {}
    C_DEagle() : baseAddr(0) {}
};

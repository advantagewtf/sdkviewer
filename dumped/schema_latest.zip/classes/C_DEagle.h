#pragma once
#include <cstdint>
class C_DEagle : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
class CPulseCell_Outflow_CycleRandom {
public:
    uintptr_t m_Outputs() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

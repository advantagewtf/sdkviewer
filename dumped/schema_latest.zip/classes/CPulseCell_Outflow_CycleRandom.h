#pragma once
#include "../types/Vector3.h"

class CPulseCell_Outflow_CycleRandom  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleRandom() : baseAddr(0) {}
    CPulseCell_Outflow_CycleRandom(uintptr_t base) : baseAddr(base) {}

};

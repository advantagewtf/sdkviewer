#pragma once
#include <cstdint>
class CLogicalEntity {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CLogicalEntity {
public:
    uintptr_t baseAddr;
    CLogicalEntity(uintptr_t addr) : baseAddr(addr) {}
    CLogicalEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CCSObserver_MovementServices {
public:
};

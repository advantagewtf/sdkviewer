#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSObserver_MovementServices {
public:
    uintptr_t baseAddr;
    CCSObserver_MovementServices(uintptr_t addr) : baseAddr(addr) {}
    CCSObserver_MovementServices() : baseAddr(0) {}
};

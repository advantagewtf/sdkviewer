#pragma once
#include "../cstypes/EngineLoopState_t.h"

class dump  {
public:
    uintptr_t baseAddr;

    dump() : baseAddr(0) {}
    dump(uintptr_t base) : baseAddr(base) {}

    float m_flRealTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFrameTime() { return SCHEMA_TYPE(float, 0x20); }
};

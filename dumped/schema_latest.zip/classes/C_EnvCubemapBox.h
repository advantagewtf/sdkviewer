#pragma once
#include <cstdint>
class C_EnvCubemapBox : public C_EnvCubemap {
public:
};

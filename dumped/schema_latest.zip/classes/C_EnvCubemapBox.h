#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_EnvCubemapBox : public C_EnvCubemap {
public:
    uintptr_t baseAddr;
    C_EnvCubemapBox(uintptr_t addr) : baseAddr(addr) {}
    C_EnvCubemapBox() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponM249 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponM249(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponM249() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_WeaponM249 : public C_CSWeaponBaseGun {
public:
};

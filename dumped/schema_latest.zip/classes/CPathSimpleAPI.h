#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPathSimpleAPI {
public:
    uintptr_t baseAddr;
    CPathSimpleAPI(uintptr_t addr) : baseAddr(addr) {}
    CPathSimpleAPI() : baseAddr(0) {}
};

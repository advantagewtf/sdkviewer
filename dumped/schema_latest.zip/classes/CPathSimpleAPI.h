#pragma once
#include <cstdint>
class CPathSimpleAPI {
public:
};

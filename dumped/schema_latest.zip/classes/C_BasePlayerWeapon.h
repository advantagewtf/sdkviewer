#pragma once
#include "../cstypes/GameTick_t.h"

class C_BasePlayerWeapon  {
public:
    uintptr_t baseAddr;

    C_BasePlayerWeapon() : baseAddr(0) {}
    C_BasePlayerWeapon(uintptr_t base) : baseAddr(base) {}

    float m_flNextPrimaryAttackTickRatio() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNextSecondaryAttackTickRatio() { return SCHEMA_TYPE(float, 0x20); }
    int m_iClip1() { return SCHEMA_TYPE(int, 0x20); }
    int m_iClip2() { return SCHEMA_TYPE(int, 0x20); }
    int m_pReserveAmmo() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_BasePlayerWeapon {
public:
    uintptr_t /* float32 */ m_flNextPrimaryAttackTickRatio() { return SCHEMA_TYPE(uintptr_t, 0x18E4); }
    uintptr_t /* float32 */ m_flNextSecondaryAttackTickRatio() { return SCHEMA_TYPE(uintptr_t, 0x18EC); }
    int32_t m_iClip1() { return SCHEMA_TYPE(int32_t, 0x18F0); }
    int32_t m_iClip2() { return SCHEMA_TYPE(int32_t, 0x18F4); }
    uintptr_t /* GameTick_t */ m_nNextPrimaryAttackTick() { return SCHEMA_TYPE(uintptr_t, 0x18E0); }
    uintptr_t /* GameTick_t */ m_nNextSecondaryAttackTick() { return SCHEMA_TYPE(uintptr_t, 0x18E8); }
    int32_t m_pReserveAmmo() { return SCHEMA_TYPE(int32_t, 0x18F8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTick_t;
class float32;
class C_BasePlayerWeapon {
public:
    uintptr_t baseAddr;
    C_BasePlayerWeapon(uintptr_t addr) : baseAddr(addr) {}
    C_BasePlayerWeapon() : baseAddr(0) {}
    float32 m_flNextPrimaryAttackTickRatio() { return SCHEMA_TYPE(float32, 0x18C4); }
    float32 m_flNextSecondaryAttackTickRatio() { return SCHEMA_TYPE(float32, 0x18CC); }
    int32_t m_iClip1() { return SCHEMA_TYPE(int32_t, 0x18D0); }
    int32_t m_iClip2() { return SCHEMA_TYPE(int32_t, 0x18D4); }
    GameTick_t m_nNextPrimaryAttackTick() { return SCHEMA_TYPE(GameTick_t, 0x18C0); }
    GameTick_t m_nNextSecondaryAttackTick() { return SCHEMA_TYPE(GameTick_t, 0x18C8); }
    int32_t m_pReserveAmmo() { return SCHEMA_TYPE(int32_t, 0x18D8); }
};

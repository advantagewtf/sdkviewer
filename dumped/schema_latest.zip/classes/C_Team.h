#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBasePlayerController;
class C_BasePlayerPawn;
class C_Team : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_Team(uintptr_t addr) : baseAddr(addr) {}
    C_Team() : baseAddr(0) {}
    CHandle<CBasePlayerController> m_aPlayerControllers() { return SCHEMA_TYPE(CHandle<CBasePlayerController>, 0x5F8); }
    CHandle<C_BasePlayerPawn> m_aPlayers() { return SCHEMA_TYPE(CHandle<C_BasePlayerPawn>, 0x610); }
    int32_t m_iScore() { return SCHEMA_TYPE(int32_t, 0x628); }
    char m_szTeamname() { return SCHEMA_TYPE(char, 0x62C); }
};

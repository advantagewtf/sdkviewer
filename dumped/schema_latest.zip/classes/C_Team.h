#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "CBasePlayerController.h"
#include "C_BasePlayerPawn.h"
class C_Team : public C_BaseEntity {
public:
    CHandle<CBasePlayerController> m_aPlayerControllers() { return SCHEMA_TYPE(CHandle<CBasePlayerController>, 0x5F8); }
    CHandle<C_BasePlayerPawn> m_aPlayers() { return SCHEMA_TYPE(CHandle<C_BasePlayerPawn>, 0x610); }
    int32_t m_iScore() { return SCHEMA_TYPE(int32_t, 0x628); }
    uintptr_t /* char */ m_szTeamname() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
};

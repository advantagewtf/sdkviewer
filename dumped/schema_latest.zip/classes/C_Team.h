#pragma once
#include "../types/Vector3.h"

class C_Team  {
public:
    uintptr_t baseAddr;

    C_Team() : baseAddr(0) {}
    C_Team(uintptr_t base) : baseAddr(base) {}

    int m_iScore() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szTeamname() { return SCHEMA_TYPE(char*, 0x81); }
};

#pragma once
#include <cstdint>
class IntervalTimer {
public:
    uintptr_t /* WorldGroupId_t */ m_nWorldGroupId() { return SCHEMA_TYPE(uintptr_t, 0xC); }
    uintptr_t /* GameTime_t */ m_timestamp() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

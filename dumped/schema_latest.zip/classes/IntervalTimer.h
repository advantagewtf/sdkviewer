#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTime_t;
class WorldGroupId_t;
class IntervalTimer {
public:
    uintptr_t baseAddr;
    IntervalTimer(uintptr_t addr) : baseAddr(addr) {}
    IntervalTimer() : baseAddr(0) {}
    WorldGroupId_t m_nWorldGroupId() { return SCHEMA_TYPE(WorldGroupId_t, 0xC); }
    GameTime_t m_timestamp() { return SCHEMA_TYPE(GameTime_t, 0x8); }
};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/WorldGroupId_t.h"

class IntervalTimer  {
public:
    uintptr_t baseAddr;

    IntervalTimer() : baseAddr(0) {}
    IntervalTimer(uintptr_t base) : baseAddr(base) {}

};

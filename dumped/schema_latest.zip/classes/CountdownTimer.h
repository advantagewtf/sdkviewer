#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTime_t;
class WorldGroupId_t;
class float32;
class CountdownTimer {
public:
    uintptr_t baseAddr;
    CountdownTimer(uintptr_t addr) : baseAddr(addr) {}
    CountdownTimer() : baseAddr(0) {}
    float32 m_duration() { return SCHEMA_TYPE(float32, 0x8); }
    WorldGroupId_t m_nWorldGroupId() { return SCHEMA_TYPE(WorldGroupId_t, 0x14); }
    float32 m_timescale() { return SCHEMA_TYPE(float32, 0x10); }
    GameTime_t m_timestamp() { return SCHEMA_TYPE(GameTime_t, 0xC); }
};

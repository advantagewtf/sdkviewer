#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PlayerVisibility : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PlayerVisibility(uintptr_t addr) : baseAddr(addr) {}
    C_PlayerVisibility() : baseAddr(0) {}
    bool m_bIsEnabled() { return SCHEMA_TYPE(bool, 0x619); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x618); }
    float m_flFadeTime() { return SCHEMA_TYPE(float, 0x614); }
    float m_flFogDistanceMultiplier() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flFogMaxDensityMultiplier() { return SCHEMA_TYPE(float, 0x610); }
    float m_flVisibilityStrength() { return SCHEMA_TYPE(float, 0x608); }
};

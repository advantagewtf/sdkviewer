#pragma once

class C_PlayerVisibility  {
public:
    uintptr_t baseAddr;

    C_PlayerVisibility() : baseAddr(0) {}
    C_PlayerVisibility(uintptr_t base) : baseAddr(base) {}

    float m_flVisibilityStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogDistanceMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxDensityMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeTime() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_PlayerVisibility : public C_BaseEntity {
public:
    bool m_bIsEnabled() { return SCHEMA_TYPE(bool, 0x609); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x608); }
    float m_flFadeTime() { return SCHEMA_TYPE(float, 0x604); }
    float m_flFogDistanceMultiplier() { return SCHEMA_TYPE(float, 0x5FC); }
    float m_flFogMaxDensityMultiplier() { return SCHEMA_TYPE(float, 0x600); }
    float m_flVisibilityStrength() { return SCHEMA_TYPE(float, 0x5F8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_UseServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_UseServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_UseServices() : baseAddr(0) {}
};

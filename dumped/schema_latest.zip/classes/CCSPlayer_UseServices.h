#pragma once
#include <cstdint>
class CCSPlayer_UseServices {
public:
};

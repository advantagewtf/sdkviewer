#pragma once
#include <cstdint>
class CPulse_ResumePoint {
public:
};

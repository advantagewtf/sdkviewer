#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulse_ResumePoint {
public:
    uintptr_t baseAddr;
    CPulse_ResumePoint(uintptr_t addr) : baseAddr(addr) {}
    CPulse_ResumePoint() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_IncendiaryGrenade {
public:
};

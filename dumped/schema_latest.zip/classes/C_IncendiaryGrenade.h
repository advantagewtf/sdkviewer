#pragma once
#include "../memory.h"

class C_IncendiaryGrenade {
public:
 uintptr_t baseAddr;
 C_IncendiaryGrenade() : baseAddr(0){}
 C_IncendiaryGrenade(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_IncendiaryGrenade {
public:
    uintptr_t baseAddr;
    C_IncendiaryGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_IncendiaryGrenade() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class VPhysicsCollisionAttribute_t {
public:
    uint8_t m_nCollisionFunctionMask() { return SCHEMA_TYPE(uint8_t, 0x2B); }
    uint8_t m_nCollisionGroup() { return SCHEMA_TYPE(uint8_t, 0x2A); }
    uint32_t m_nEntityId() { return SCHEMA_TYPE(uint32_t, 0x20); }
    uint16_t m_nHierarchyId() { return SCHEMA_TYPE(uint16_t, 0x28); }
    uint64_t m_nInteractsAs() { return SCHEMA_TYPE(uint64_t, 0x8); }
    uint64_t m_nInteractsExclude() { return SCHEMA_TYPE(uint64_t, 0x18); }
    uint64_t m_nInteractsWith() { return SCHEMA_TYPE(uint64_t, 0x10); }
    uint32_t m_nOwnerId() { return SCHEMA_TYPE(uint32_t, 0x24); }
};

#pragma once
#include "../cstypes/PulseCursorCancelPriority_t.h"

class CPulseCell_WaitForCursorsWithTag  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForCursorsWithTag() : baseAddr(0) {}
    CPulseCell_WaitForCursorsWithTag(uintptr_t base) : baseAddr(base) {}

};

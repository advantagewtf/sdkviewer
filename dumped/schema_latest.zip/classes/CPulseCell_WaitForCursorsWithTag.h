#pragma once
#include <cstdint>
class CPulseCell_WaitForCursorsWithTag {
public:
    uintptr_t m_bTagSelfWhenComplete() { return SCHEMA_TYPE(uintptr_t, 0x98); }
    uintptr_t m_nDesiredKillPriority() { return SCHEMA_TYPE(uintptr_t, 0x9C); }
};

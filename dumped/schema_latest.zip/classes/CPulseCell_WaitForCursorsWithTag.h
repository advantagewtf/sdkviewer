#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_WaitForCursorsWithTag {
public:
    uintptr_t baseAddr;
    CPulseCell_WaitForCursorsWithTag(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_WaitForCursorsWithTag() : baseAddr(0) {}
    uintptr_t m_bTagSelfWhenComplete() { return SCHEMA_TYPE(uintptr_t, 0x98); }
    uintptr_t m_nDesiredKillPriority() { return SCHEMA_TYPE(uintptr_t, 0x9C); }
};

#pragma once
#include <cstdint>
class CCSObserver_CameraServices {
public:
};

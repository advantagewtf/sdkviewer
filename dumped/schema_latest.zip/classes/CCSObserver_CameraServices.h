#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSObserver_CameraServices {
public:
    uintptr_t baseAddr;
    CCSObserver_CameraServices(uintptr_t addr) : baseAddr(addr) {}
    CCSObserver_CameraServices() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class C_BaseFlex : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_BaseFlex(uintptr_t addr) : baseAddr(addr) {}
    C_BaseFlex() : baseAddr(0) {}
    uintptr_t m_CachedViewTarget() { return SCHEMA_TYPE(uintptr_t, 0x1274); }
    uintptr_t m_PhonemeClasses() { return SCHEMA_TYPE(uintptr_t, 0x12F0); }
    uintptr_t m_bResetFlexWeightsOnModelChange() { return SCHEMA_TYPE(uintptr_t, 0x1286); }
    float32 m_flexWeight() { return SCHEMA_TYPE(float32, 0x1170); }
    uintptr_t m_iEyeAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1285); }
    uintptr_t m_iMouthAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1284); }
    uintptr_t m_mEyeOcclusionRendererCameraToBoneTransform() { return SCHEMA_TYPE(uintptr_t, 0x12A4); }
    uintptr_t m_nEyeOcclusionRendererBone() { return SCHEMA_TYPE(uintptr_t, 0x12A0); }
    uintptr_t m_nLastFlexUpdateFrameCount() { return SCHEMA_TYPE(uintptr_t, 0x1270); }
    uintptr_t m_nNextSceneEventId() { return SCHEMA_TYPE(uintptr_t, 0x1280); }
    uintptr_t m_vEyeOcclusionRendererHalfExtent() { return SCHEMA_TYPE(uintptr_t, 0x12D4); }
    uintptr_t m_vLookTargetPosition() { return SCHEMA_TYPE(uintptr_t, 0x1188); }
};

#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/SceneEventId_t.h"
#include "../cstypes/matrix3x4_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_BaseFlex  {
public:
    uintptr_t baseAddr;

    C_BaseFlex() : baseAddr(0) {}
    C_BaseFlex(uintptr_t base) : baseAddr(base) {}

    float m_flexWeight() { return SCHEMA_TYPE(float, 0x20); }
    int m_nLastFlexUpdateFrameCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_iBlink() { return SCHEMA_TYPE(int, 0x20); }
    float m_blinktime() { return SCHEMA_TYPE(float, 0x20); }
    int m_iJawOpen() { return SCHEMA_TYPE(int, 0x20); }
    float m_flJawOpenAmount() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBlinkAmount() { return SCHEMA_TYPE(float, 0x20); }
    int m_nEyeOcclusionRendererBone() { return SCHEMA_TYPE(int, 0x20); }
    matrix3x4_t m_mEyeOcclusionRendererCameraToBoneTransform() { return SCHEMA_TYPE(matrix3x4_t, 0x3); }
    uintptr_t m_PhonemeClasses() { return SCHEMA_TYPE(uintptr_t, 0x3); }
};

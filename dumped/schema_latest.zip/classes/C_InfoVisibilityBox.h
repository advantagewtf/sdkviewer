#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_InfoVisibilityBox : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_InfoVisibilityBox(uintptr_t addr) : baseAddr(addr) {}
    C_InfoVisibilityBox() : baseAddr(0) {}
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x60C); }
    int32_t m_nMode() { return SCHEMA_TYPE(int32_t, 0x5FC); }
    Vector3 m_vBoxSize() { return SCHEMA_TYPE(Vector3, 0x600); }
};

#pragma once
#include "../types/Vector3.h"

class C_InfoVisibilityBox  {
public:
    uintptr_t baseAddr;

    C_InfoVisibilityBox() : baseAddr(0) {}
    C_InfoVisibilityBox(uintptr_t base) : baseAddr(base) {}

    int m_nMode() { return SCHEMA_TYPE(int, 0x20); }
};

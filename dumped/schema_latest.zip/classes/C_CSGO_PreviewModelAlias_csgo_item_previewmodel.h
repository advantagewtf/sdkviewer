#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_PreviewModelAlias_csgo_item_previewmodel : public C_CSGO_PreviewModel {
public:
    uintptr_t baseAddr;
    C_CSGO_PreviewModelAlias_csgo_item_previewmodel(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_PreviewModelAlias_csgo_item_previewmodel() : baseAddr(0) {}
};

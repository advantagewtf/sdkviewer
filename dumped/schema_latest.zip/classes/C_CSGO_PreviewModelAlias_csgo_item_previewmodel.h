#pragma once
#include "../memory.h"

class C_CSGO_PreviewModelAlias_csgo_item_previewmodel {
public:
 uintptr_t baseAddr;
 C_CSGO_PreviewModelAlias_csgo_item_previewmodel() : baseAddr(0){}
 C_CSGO_PreviewModelAlias_csgo_item_previewmodel(uintptr_t b):baseAddr(b){}
};

#pragma once
#include "../memory.h"

class CInfoParticleTarget {
public:
 uintptr_t baseAddr;
 CInfoParticleTarget() : baseAddr(0){}
 CInfoParticleTarget(uintptr_t b):baseAddr(b){}
};

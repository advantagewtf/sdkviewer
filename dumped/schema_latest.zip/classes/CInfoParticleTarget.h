#pragma once
#include <cstdint>
class CInfoParticleTarget {
public:
};

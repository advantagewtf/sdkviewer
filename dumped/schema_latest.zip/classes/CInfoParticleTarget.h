#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CInfoParticleTarget {
public:
    uintptr_t baseAddr;
    CInfoParticleTarget(uintptr_t addr) : baseAddr(addr) {}
    CInfoParticleTarget() : baseAddr(0) {}
};

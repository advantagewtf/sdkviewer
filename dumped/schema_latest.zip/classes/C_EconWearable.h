#pragma once

class C_EconWearable  {
public:
    uintptr_t baseAddr;

    C_EconWearable() : baseAddr(0) {}
    C_EconWearable(uintptr_t base) : baseAddr(base) {}

    int m_nForceSkin() { return SCHEMA_TYPE(int, 0x20); }
};

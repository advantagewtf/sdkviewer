#pragma once
#include <cstdint>
class C_EconWearable : public C_EconEntity {
public:
    uintptr_t m_bAlwaysAllow() { return SCHEMA_TYPE(uintptr_t, 0x18E4); }
    uintptr_t m_nForceSkin() { return SCHEMA_TYPE(uintptr_t, 0x18E0); }
};

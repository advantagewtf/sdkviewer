#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_EconWearable : public C_EconEntity {
public:
    uintptr_t baseAddr;
    C_EconWearable(uintptr_t addr) : baseAddr(addr) {}
    C_EconWearable() : baseAddr(0) {}
    uintptr_t m_bAlwaysAllow() { return SCHEMA_TYPE(uintptr_t, 0x18E4); }
    uintptr_t m_nForceSkin() { return SCHEMA_TYPE(uintptr_t, 0x18E0); }
};

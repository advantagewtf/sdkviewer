#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CCSPlayerBase_CameraServices {
public:
    uintptr_t /* float32 */ m_flFOVRate() { return SCHEMA_TYPE(uintptr_t, 0x294); }
    uintptr_t /* GameTime_t */ m_flFOVTime() { return SCHEMA_TYPE(uintptr_t, 0x290); }
    uintptr_t m_flLastShotFOV() { return SCHEMA_TYPE(uintptr_t, 0x29C); }
    CHandle<CBaseEntity> m_hZoomOwner() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x298); }
    uint32_t m_iFOV() { return SCHEMA_TYPE(uint32_t, 0x288); }
    uint32_t m_iFOVStart() { return SCHEMA_TYPE(uint32_t, 0x28C); }
};

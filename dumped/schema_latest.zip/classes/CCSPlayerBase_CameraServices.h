#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class GameTime_t;
class float32;
class CCSPlayerBase_CameraServices {
public:
    uintptr_t baseAddr;
    CCSPlayerBase_CameraServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerBase_CameraServices() : baseAddr(0) {}
    float32 m_flFOVRate() { return SCHEMA_TYPE(float32, 0x294); }
    GameTime_t m_flFOVTime() { return SCHEMA_TYPE(GameTime_t, 0x290); }
    uintptr_t m_flLastShotFOV() { return SCHEMA_TYPE(uintptr_t, 0x29C); }
    CHandle<CBaseEntity> m_hZoomOwner() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x298); }
    uint32_t m_iFOV() { return SCHEMA_TYPE(uint32_t, 0x288); }
    uint32_t m_iFOVStart() { return SCHEMA_TYPE(uint32_t, 0x28C); }
};

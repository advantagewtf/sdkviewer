#pragma once
#include "../cstypes/GameTime_t.h"
class C_BaseEntity;

class CCSPlayerBase_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerBase_CameraServices() : baseAddr(0) {}
    CCSPlayerBase_CameraServices(uintptr_t base) : baseAddr(base) {}

    int m_iFOV() { return SCHEMA_TYPE(int, 0x20); }
    int m_iFOVStart() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFOVRate() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLastShotFOV() { return SCHEMA_TYPE(float, 0x20); }
};

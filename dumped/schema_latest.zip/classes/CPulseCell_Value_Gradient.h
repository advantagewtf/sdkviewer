#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Value_Gradient  {
public:
    uintptr_t baseAddr;

    CPulseCell_Value_Gradient() : baseAddr(0) {}
    CPulseCell_Value_Gradient(uintptr_t base) : baseAddr(base) {}

};

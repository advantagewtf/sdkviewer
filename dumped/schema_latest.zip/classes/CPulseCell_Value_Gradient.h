#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Value_Gradient {
public:
    uintptr_t baseAddr;
    CPulseCell_Value_Gradient(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Value_Gradient() : baseAddr(0) {}
    uintptr_t m_Gradient() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

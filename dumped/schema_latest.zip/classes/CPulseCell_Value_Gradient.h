#pragma once
#include <cstdint>
class CPulseCell_Value_Gradient {
public:
    uintptr_t m_Gradient() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

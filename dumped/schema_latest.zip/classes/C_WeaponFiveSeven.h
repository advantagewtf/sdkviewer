#pragma once
#include <cstdint>
class C_WeaponFiveSeven : public C_CSWeaponBaseGun {
public:
};

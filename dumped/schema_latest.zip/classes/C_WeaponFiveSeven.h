#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponFiveSeven : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponFiveSeven(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponFiveSeven() : baseAddr(0) {}
};

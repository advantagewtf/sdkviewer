#pragma once
#include "../cstypes/GameTick_t.h"
#include "../cstypes/GameTime_t.h"
class C_CSWeaponBase;

class C_BaseCSGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseCSGrenade() : baseAddr(0) {}
    C_BaseCSGrenade(uintptr_t base) : baseAddr(base) {}

    float m_flThrowStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNextHoldFrac() { return SCHEMA_TYPE(float, 0x20); }
};

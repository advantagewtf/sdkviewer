#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSWeaponBase;
class GameTick_t;
class GameTime_t;
class C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_BaseCSGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_BaseCSGrenade() : baseAddr(0) {}
    uintptr_t m_bClientPredictDelete() { return SCHEMA_TYPE(uintptr_t, 0x1F80); }
    bool m_bIsHeldByPlayer() { return SCHEMA_TYPE(bool, 0x1F82); }
    bool m_bJumpThrow() { return SCHEMA_TYPE(bool, 0x1F84); }
    bool m_bJustPulledPin() { return SCHEMA_TYPE(bool, 0x2010); }
    bool m_bPinPulled() { return SCHEMA_TYPE(bool, 0x1F83); }
    bool m_bRedraw() { return SCHEMA_TYPE(bool, 0x1F81); }
    bool m_bThrowAnimating() { return SCHEMA_TYPE(bool, 0x1F85); }
    GameTime_t m_fDropTime() { return SCHEMA_TYPE(GameTime_t, 0x2008); }
    GameTime_t m_fPinPullTime() { return SCHEMA_TYPE(GameTime_t, 0x200C); }
    GameTime_t m_fThrowTime() { return SCHEMA_TYPE(GameTime_t, 0x1F88); }
    float m_flNextHoldFrac() { return SCHEMA_TYPE(float, 0x2018); }
    uintptr_t m_flThrowStrength() { return SCHEMA_TYPE(uintptr_t, 0x1F90); }
    CHandle<CCSWeaponBase> m_hSwitchToWeaponAfterThrow() { return SCHEMA_TYPE(CHandle<CCSWeaponBase>, 0x201C); }
    GameTick_t m_nNextHoldTick() { return SCHEMA_TYPE(GameTick_t, 0x2014); }
};

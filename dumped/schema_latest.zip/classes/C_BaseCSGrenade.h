#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSWeaponBase;
class GameTick_t;
class GameTime_t;
class C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_BaseCSGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_BaseCSGrenade() : baseAddr(0) {}
    uintptr_t m_bClientPredictDelete() { return SCHEMA_TYPE(uintptr_t, 0x1F40); }
    bool m_bIsHeldByPlayer() { return SCHEMA_TYPE(bool, 0x1F42); }
    bool m_bJumpThrow() { return SCHEMA_TYPE(bool, 0x1F44); }
    bool m_bJustPulledPin() { return SCHEMA_TYPE(bool, 0x1FD0); }
    bool m_bPinPulled() { return SCHEMA_TYPE(bool, 0x1F43); }
    bool m_bRedraw() { return SCHEMA_TYPE(bool, 0x1F41); }
    bool m_bThrowAnimating() { return SCHEMA_TYPE(bool, 0x1F45); }
    GameTime_t m_fDropTime() { return SCHEMA_TYPE(GameTime_t, 0x1FC8); }
    GameTime_t m_fPinPullTime() { return SCHEMA_TYPE(GameTime_t, 0x1FCC); }
    GameTime_t m_fThrowTime() { return SCHEMA_TYPE(GameTime_t, 0x1F48); }
    float m_flNextHoldFrac() { return SCHEMA_TYPE(float, 0x1FD8); }
    uintptr_t m_flThrowStrength() { return SCHEMA_TYPE(uintptr_t, 0x1F50); }
    CHandle<CCSWeaponBase> m_hSwitchToWeaponAfterThrow() { return SCHEMA_TYPE(CHandle<CCSWeaponBase>, 0x1FDC); }
    GameTick_t m_nNextHoldTick() { return SCHEMA_TYPE(GameTick_t, 0x1FD4); }
};

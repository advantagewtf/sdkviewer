#pragma once
#include "../cstypes/uintptr_t.h"

class CFilterAttributeInt  {
public:
    uintptr_t baseAddr;

    CFilterAttributeInt() : baseAddr(0) {}
    CFilterAttributeInt(uintptr_t base) : baseAddr(base) {}

};

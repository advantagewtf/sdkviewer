#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterAttributeInt : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterAttributeInt(uintptr_t addr) : baseAddr(addr) {}
    CFilterAttributeInt() : baseAddr(0) {}
    uintptr_t m_sAttributeName() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

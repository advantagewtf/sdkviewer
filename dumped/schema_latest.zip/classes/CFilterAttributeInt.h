#pragma once
#include <cstdint>
class CFilterAttributeInt : public CBaseFilter {
public:
    uintptr_t m_sAttributeName() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

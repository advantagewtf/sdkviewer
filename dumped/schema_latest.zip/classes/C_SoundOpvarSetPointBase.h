#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_SoundOpvarSetPointBase : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetPointBase(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetPointBase() : baseAddr(0) {}
    bool m_bFastRefresh() { return SCHEMA_TYPE(bool, 0x625); }
    bool m_bUseAutoCompare() { return SCHEMA_TYPE(bool, 0x624); }
    int32_t m_iOpvarIndex() { return SCHEMA_TYPE(int32_t, 0x620); }
    string_t m_iszOperatorName() { return SCHEMA_TYPE(string_t, 0x610); }
    string_t m_iszOpvarName() { return SCHEMA_TYPE(string_t, 0x618); }
    string_t m_iszStackName() { return SCHEMA_TYPE(string_t, 0x608); }
};

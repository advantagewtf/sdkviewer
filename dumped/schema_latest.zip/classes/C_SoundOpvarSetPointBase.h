#pragma once
#include <cstdint>
#include "../types/string_t.h"
class C_SoundOpvarSetPointBase : public C_BaseEntity {
public:
    bool m_bUseAutoCompare() { return SCHEMA_TYPE(bool, 0x614); }
    int32_t m_iOpvarIndex() { return SCHEMA_TYPE(int32_t, 0x610); }
    string_t m_iszOperatorName() { return SCHEMA_TYPE(string_t, 0x600); }
    string_t m_iszOpvarName() { return SCHEMA_TYPE(string_t, 0x608); }
    string_t m_iszStackName() { return SCHEMA_TYPE(string_t, 0x5F8); }
};

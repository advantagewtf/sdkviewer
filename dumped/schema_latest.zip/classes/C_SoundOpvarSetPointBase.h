#pragma once
#include "../cstypes/uintptr_t.h"

class C_SoundOpvarSetPointBase  {
public:
    uintptr_t baseAddr;

    C_SoundOpvarSetPointBase() : baseAddr(0) {}
    C_SoundOpvarSetPointBase(uintptr_t base) : baseAddr(base) {}

    int m_iOpvarIndex() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include "../classes/C_EconItemView.h"
#include "../classes/CountdownTimer.h"
#include "../cstypes/CSPlayerBlockingUseAction_t.h"
#include "../cstypes/EntitySpottedState_t.h"
#include "../cstypes/GameTick_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/ParticleIndex_t.h"
#include "../cstypes/loadout_slot_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CCSPlayer_ActionTrackingServices;
class CCSPlayer_BulletServices;
class CCSPlayer_BuyServices;
class CCSPlayer_HostageServices;
class C_CSWeaponBase;

class C_CSPlayerPawn  {
public:
    uintptr_t baseAddr;

    C_CSPlayerPawn() : baseAddr(0) {}
    C_CSPlayerPawn(uintptr_t base) : baseAddr(base) {}

    float m_flLandingTimeSeconds() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOldFallVelocity() { return SCHEMA_TYPE(float, 0x20); }
    char* m_szLastPlaceName() { return SCHEMA_TYPE(char*, 0x12); }
    int m_nPrevArmorVal() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPrevGrenadeAmmoCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_unPreviousWeaponHash() { return SCHEMA_TYPE(int, 0x20); }
    int m_unWeaponHash() { return SCHEMA_TYPE(int, 0x20); }
    float m_aimPunchTickFraction() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLandingStartTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_iRetakesOffering() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRetakesOfferingCard() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRetakesMVPBoostItem() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nEconGlovesChanged() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nRagdollDamageBone() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szRagdollDamageWeaponName() { return SCHEMA_TYPE(char*, 0x40); }
    uintptr_t* m_hHudModelArms() { return SCHEMA_TYPE(uintptr_t*, 0x2); }
    float m_flViewmodelOffsetX() { return SCHEMA_TYPE(float, 0x20); }
    float m_flViewmodelOffsetY() { return SCHEMA_TYPE(float, 0x20); }
    float m_flViewmodelOffsetZ() { return SCHEMA_TYPE(float, 0x20); }
    float m_flViewmodelFOV() { return SCHEMA_TYPE(float, 0x20); }
    int m_vecPlayerPatchEconIndices() { return SCHEMA_TYPE(int, 0x20); }
    float m_flSlopeDropOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSlopeDropHeight() { return SCHEMA_TYPE(float, 0x20); }
    int m_nWhichBombZone() { return SCHEMA_TYPE(int, 0x20); }
    int m_iShotsFired() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFlinchStack() { return SCHEMA_TYPE(float, 0x20); }
    float m_flVelocityModifier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHitHeading() { return SCHEMA_TYPE(float, 0x20); }
    int m_nHitBodyPart() { return SCHEMA_TYPE(int, 0x20); }
    float m_ignoreLadderJumpTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_ArmorValue() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_unCurrentEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint16_t m_unRoundStartEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint16_t m_unFreezetimeEndEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flDeathInfoTime() { return SCHEMA_TYPE(float, 0x20); }
    QAngle m_angShootAngleHistory() { return SCHEMA_TYPE(QAngle, 0x2); }
    Vector3 m_vecThrowPositionHistory() { return SCHEMA_TYPE(Vector3, 0x2); }
    Vector3 m_vecVelocityHistory() { return SCHEMA_TYPE(Vector3, 0x2); }
    int m_nHighestAppliedDamageTagTick() { return SCHEMA_TYPE(int, 0x20); }
    float m_fMolotovDamageTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_fRenderingClipPlane() { return SCHEMA_TYPE(float, 0x20); }
    int m_nLastClipPlaneSetupFrame() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_arrOldEyeAnglesTimes() { return SCHEMA_TYPE(uintptr_t, 0x4); }
    QAngle m_arrOldEyeAngles() { return SCHEMA_TYPE(QAngle, 0x4); }
};

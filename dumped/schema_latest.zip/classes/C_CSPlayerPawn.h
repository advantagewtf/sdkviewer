#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CEconItemView;
class CEntityIndex;
class CSPlayerBlockingUseAction_t;
class Color;
class EntitySpottedState_t;
class GameTick_t;
class GameTime_t;
class PredictedDamageTag_t;
class QAngle;
class loadout_slot_t;
class C_CSPlayerPawn {
public:
    uintptr_t baseAddr;
    C_CSPlayerPawn(uintptr_t addr) : baseAddr(addr) {}
    C_CSPlayerPawn() : baseAddr(0) {}
    int32_t m_ArmorValue() { return SCHEMA_TYPE(int32_t, 0x272C); }
    CEconItemView m_EconGloves() { return SCHEMA_TYPE(CEconItemView, 0x1890); }
    Color m_GunGameImmunityColor() { return SCHEMA_TYPE(Color, 0x2460); }
    PredictedDamageTag_t m_PredictedDamageTags() { return SCHEMA_TYPE(PredictedDamageTag_t, 0x27C8); }
    loadout_slot_t m_RetakesMVPBoostExtraUtility() { return SCHEMA_TYPE(loadout_slot_t, 0x1888); }
    QAngle m_aimPunchAngle() { return SCHEMA_TYPE(QAngle, 0x16CC); }
    QAngle m_aimPunchAngleVel() { return SCHEMA_TYPE(QAngle, 0x16D8); }
    GameTick_t m_aimPunchTickBase() { return SCHEMA_TYPE(GameTick_t, 0x16E4); }
    float m_aimPunchTickFraction() { return SCHEMA_TYPE(float, 0x16E8); }
    uintptr_t m_angEyeAngles() { return SCHEMA_TYPE(uintptr_t, 0x3DD0); }
    uintptr_t m_angEyeAnglesVelocity() { return SCHEMA_TYPE(uintptr_t, 0x3EA0); }
    uintptr_t m_angShootAngleHistory() { return SCHEMA_TYPE(uintptr_t, 0x2780); }
    uintptr_t m_angStashedShootAngles() { return SCHEMA_TYPE(uintptr_t, 0x275C); }
    uintptr_t m_arrOldEyeAngles() { return SCHEMA_TYPE(uintptr_t, 0x3E70); }
    uintptr_t m_arrOldEyeAnglesTimes() { return SCHEMA_TYPE(uintptr_t, 0x3E60); }
    uintptr_t m_bCachedPlaneIsValid() { return SCHEMA_TYPE(uintptr_t, 0x3DBD); }
    uintptr_t m_bClipHitStaticWorld() { return SCHEMA_TYPE(uintptr_t, 0x3DBC); }
    uintptr_t m_bGrenadeParametersStashed() { return SCHEMA_TYPE(uintptr_t, 0x2758); }
    bool m_bGunGameImmunity() { return SCHEMA_TYPE(bool, 0x3D74); }
    uintptr_t m_bHasDeathInfo() { return SCHEMA_TYPE(uintptr_t, 0x273D); }
    bool m_bHasFemaleVoice() { return SCHEMA_TYPE(bool, 0x1698); }
    bool m_bInBombZone() { return SCHEMA_TYPE(bool, 0x1719); }
    bool m_bInBuyZone() { return SCHEMA_TYPE(bool, 0x16C8); }
    bool m_bInHostageRescueZone() { return SCHEMA_TYPE(bool, 0x1718); }
    uintptr_t m_bInLanding() { return SCHEMA_TYPE(uintptr_t, 0x1710); }
    bool m_bInNoDefuseArea() { return SCHEMA_TYPE(bool, 0x2704); }
    bool m_bIsBuyMenuOpen() { return SCHEMA_TYPE(bool, 0x171A); }
    bool m_bIsDefusing() { return SCHEMA_TYPE(bool, 0x26FA); }
    bool m_bIsGrabbingHostage() { return SCHEMA_TYPE(bool, 0x26FB); }
    bool m_bIsScoped() { return SCHEMA_TYPE(bool, 0x26F8); }
    bool m_bIsWalking() { return SCHEMA_TYPE(bool, 0x24C8); }
    bool m_bKilledByHeadshot() { return SCHEMA_TYPE(bool, 0x2729); }
    bool m_bLeftHanded() { return SCHEMA_TYPE(bool, 0x2411); }
    uintptr_t m_bMustSyncRagdollState() { return SCHEMA_TYPE(uintptr_t, 0x1D01); }
    uintptr_t m_bNeedToReApplyGloves() { return SCHEMA_TYPE(uintptr_t, 0x188D); }
    uintptr_t m_bOldIsScoped() { return SCHEMA_TYPE(uintptr_t, 0x273C); }
    uintptr_t m_bOnGroundLastTick() { return SCHEMA_TYPE(uintptr_t, 0x23E4); }
    uintptr_t m_bPrevDefuser() { return SCHEMA_TYPE(uintptr_t, 0x16B6); }
    uintptr_t m_bPrevHelmet() { return SCHEMA_TYPE(uintptr_t, 0x16B7); }
    uintptr_t m_bPreviouslyInBuyZone() { return SCHEMA_TYPE(uintptr_t, 0x16C9); }
    bool m_bRagdollDamageHeadshot() { return SCHEMA_TYPE(bool, 0x1D60); }
    bool m_bResumeZoom() { return SCHEMA_TYPE(bool, 0x26F9); }
    bool m_bRetakesHasDefuseKit() { return SCHEMA_TYPE(bool, 0x1880); }
    bool m_bRetakesMVPLastRound() { return SCHEMA_TYPE(bool, 0x1881); }
    uintptr_t m_bShouldAutobuyDMWeapons() { return SCHEMA_TYPE(uintptr_t, 0x3D6C); }
    uintptr_t m_bSkipOneHeadConstraintUpdate() { return SCHEMA_TYPE(uintptr_t, 0x2410); }
    bool m_bWaitForNoAttack() { return SCHEMA_TYPE(bool, 0x2720); }
    uintptr_t m_delayTargetIDTimer() { return SCHEMA_TYPE(uintptr_t, 0x3EB0); }
    EntitySpottedState_t m_entitySpottedState() { return SCHEMA_TYPE(EntitySpottedState_t, 0x26E0); }
    GameTime_t m_fImmuneToGunGameDamageTime() { return SCHEMA_TYPE(GameTime_t, 0x3D70); }
    uintptr_t m_fImmuneToGunGameDamageTimeLast() { return SCHEMA_TYPE(uintptr_t, 0x3D78); }
    float m_fMolotovDamageTime() { return SCHEMA_TYPE(float, 0x3D7C); }
    uintptr_t m_fRenderingClipPlane() { return SCHEMA_TYPE(uintptr_t, 0x3D90); }
    GameTime_t m_fSwitchedHandednessTime() { return SCHEMA_TYPE(GameTime_t, 0x2414); }
    uintptr_t m_flDeathInfoTime() { return SCHEMA_TYPE(uintptr_t, 0x2740); }
    GameTime_t m_flEmitSoundTime() { return SCHEMA_TYPE(GameTime_t, 0x2700); }
    float m_flFlinchStack() { return SCHEMA_TYPE(float, 0x2710); }
    GameTime_t m_flHealthShotBoostExpirationTime() { return SCHEMA_TYPE(GameTime_t, 0x1690); }
    float m_flHitHeading() { return SCHEMA_TYPE(float, 0x2718); }
    uintptr_t m_flLandingStartTime() { return SCHEMA_TYPE(uintptr_t, 0x1714); }
    uintptr_t m_flLandingTimeSeconds() { return SCHEMA_TYPE(uintptr_t, 0x169C); }
    uintptr_t m_flLastFiredWeaponTime() { return SCHEMA_TYPE(uintptr_t, 0x1694); }
    GameTime_t m_flNextSprayDecalTime() { return SCHEMA_TYPE(GameTime_t, 0x1720); }
    uintptr_t m_flOldFallVelocity() { return SCHEMA_TYPE(uintptr_t, 0x16A0); }
    uintptr_t m_flSlopeDropHeight() { return SCHEMA_TYPE(uintptr_t, 0x25D8); }
    uintptr_t m_flSlopeDropOffset() { return SCHEMA_TYPE(uintptr_t, 0x2560); }
    GameTime_t m_flTimeOfLastInjury() { return SCHEMA_TYPE(GameTime_t, 0x171C); }
    float m_flVelocityModifier() { return SCHEMA_TYPE(float, 0x2714); }
    float m_flViewmodelFOV() { return SCHEMA_TYPE(float, 0x2424); }
    float m_flViewmodelOffsetX() { return SCHEMA_TYPE(float, 0x2418); }
    float m_flViewmodelOffsetY() { return SCHEMA_TYPE(float, 0x241C); }
    float m_flViewmodelOffsetZ() { return SCHEMA_TYPE(float, 0x2420); }
    uintptr_t m_grenadeParameterStashTime() { return SCHEMA_TYPE(uintptr_t, 0x2754); }
    uintptr_t m_hHudModelArms() { return SCHEMA_TYPE(uintptr_t, 0x2400); }
    uintptr_t m_holdTargetIDTimer() { return SCHEMA_TYPE(uintptr_t, 0x3ED0); }
    CSPlayerBlockingUseAction_t m_iBlockingUseActionInProgress() { return SCHEMA_TYPE(CSPlayerBlockingUseAction_t, 0x26FC); }
    uintptr_t m_iIDEntIndex() { return SCHEMA_TYPE(uintptr_t, 0x3EAC); }
    uintptr_t m_iOldIDEntIndex() { return SCHEMA_TYPE(uintptr_t, 0x3ECC); }
    int32_t m_iRetakesMVPBoostItem() { return SCHEMA_TYPE(int32_t, 0x1884); }
    int32_t m_iRetakesOffering() { return SCHEMA_TYPE(int32_t, 0x1878); }
    int32_t m_iRetakesOfferingCard() { return SCHEMA_TYPE(int32_t, 0x187C); }
    int32_t m_iShotsFired() { return SCHEMA_TYPE(int32_t, 0x270C); }
    uintptr_t m_iTargetItemEntIdx() { return SCHEMA_TYPE(uintptr_t, 0x3EC8); }
    uintptr_t m_ignoreLadderJumpTime() { return SCHEMA_TYPE(uintptr_t, 0x2724); }
    uintptr_t m_lastLandTime() { return SCHEMA_TYPE(uintptr_t, 0x23E0); }
    uint8_t m_nEconGlovesChanged() { return SCHEMA_TYPE(uint8_t, 0x1D00); }
    uintptr_t m_nHighestAppliedDamageTagTick() { return SCHEMA_TYPE(uintptr_t, 0x2834); }
    int32_t m_nHitBodyPart() { return SCHEMA_TYPE(int32_t, 0x271C); }
    uintptr_t m_nLastClipPlaneSetupFrame() { return SCHEMA_TYPE(uintptr_t, 0x3DA0); }
    CEntityIndex m_nLastKillerIndex() { return SCHEMA_TYPE(CEntityIndex, 0x2738); }
    uintptr_t m_nPlayerInfernoBodyFx() { return SCHEMA_TYPE(uintptr_t, 0x3DC8); }
    uintptr_t m_nPrevArmorVal() { return SCHEMA_TYPE(uintptr_t, 0x16B8); }
    uintptr_t m_nPrevGrenadeAmmoCount() { return SCHEMA_TYPE(uintptr_t, 0x16BC); }
    uintptr_t m_nPrevHighestReceivedDamageTagTick() { return SCHEMA_TYPE(uintptr_t, 0x2830); }
    int32_t m_nRagdollDamageBone() { return SCHEMA_TYPE(int32_t, 0x1D04); }
    int32_t m_nWhichBombZone() { return SCHEMA_TYPE(int32_t, 0x2708); }
    CCSPlayer_ActionTrackingServices* m_pActionTrackingServices() { return SCHEMA_TYPE(CCSPlayer_ActionTrackingServices*, 0x1680); }
    CCSPlayer_BulletServices* m_pBulletServices() { return SCHEMA_TYPE(CCSPlayer_BulletServices*, 0x1660); }
    CCSPlayer_BuyServices* m_pBuyServices() { return SCHEMA_TYPE(CCSPlayer_BuyServices*, 0x1670); }
    uintptr_t m_pClippingWeapon() { return SCHEMA_TYPE(uintptr_t, 0x3DC0); }
    uintptr_t m_pDamageReactServices() { return SCHEMA_TYPE(uintptr_t, 0x1688); }
    CCSPlayer_GlowServices* m_pGlowServices() { return SCHEMA_TYPE(CCSPlayer_GlowServices*, 0x1678); }
    CCSPlayer_HostageServices* m_pHostageServices() { return SCHEMA_TYPE(CCSPlayer_HostageServices*, 0x1668); }
    QAngle m_qDeathEyeAngles() { return SCHEMA_TYPE(QAngle, 0x2404); }
    char m_szLastPlaceName() { return SCHEMA_TYPE(char, 0x16A4); }
    char m_szRagdollDamageWeaponName() { return SCHEMA_TYPE(char, 0x1D20); }
    uintptr_t m_thirdPersonHeading() { return SCHEMA_TYPE(uintptr_t, 0x24D0); }
    uint16_t m_unCurrentEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2730); }
    uint16_t m_unFreezetimeEndEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2734); }
    uintptr_t m_unPreviousWeaponHash() { return SCHEMA_TYPE(uintptr_t, 0x16C0); }
    uint16_t m_unRoundStartEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2732); }
    uintptr_t m_unWeaponHash() { return SCHEMA_TYPE(uintptr_t, 0x16C4); }
    uintptr_t m_vHeadConstraintOffset() { return SCHEMA_TYPE(uintptr_t, 0x2650); }
    Vector3 m_vRagdollDamageForce() { return SCHEMA_TYPE(Vector3, 0x1D08); }
    Vector3 m_vRagdollDamagePosition() { return SCHEMA_TYPE(Vector3, 0x1D14); }
    Vector3 m_vRagdollServerOrigin() { return SCHEMA_TYPE(Vector3, 0x1D64); }
    uintptr_t m_vecBulletHitModels() { return SCHEMA_TYPE(uintptr_t, 0x24B0); }
    uintptr_t m_vecDeathInfoOrigin() { return SCHEMA_TYPE(uintptr_t, 0x2744); }
    uintptr_t m_vecLastAliveLocalVelocity() { return SCHEMA_TYPE(uintptr_t, 0x3D84); }
    uintptr_t m_vecLastClipCameraForward() { return SCHEMA_TYPE(uintptr_t, 0x3DB0); }
    uintptr_t m_vecLastClipCameraPos() { return SCHEMA_TYPE(uintptr_t, 0x3DA4); }
    uint32_t m_vecPlayerPatchEconIndices() { return SCHEMA_TYPE(uint32_t, 0x2428); }
    uintptr_t m_vecStashedGrenadeThrowPosition() { return SCHEMA_TYPE(uintptr_t, 0x2768); }
    uintptr_t m_vecStashedVelocity() { return SCHEMA_TYPE(uintptr_t, 0x2774); }
    uintptr_t m_vecThrowPositionHistory() { return SCHEMA_TYPE(uintptr_t, 0x2798); }
    uintptr_t m_vecVelocityHistory() { return SCHEMA_TYPE(uintptr_t, 0x27B0); }
};

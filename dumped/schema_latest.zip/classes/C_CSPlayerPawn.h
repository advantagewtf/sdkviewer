#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CEconItemView;
class CEntityIndex;
class CSPlayerBlockingUseAction_t;
class Color;
class EntitySpottedState_t;
class GameTick_t;
class GameTime_t;
class PredictedDamageTag_t;
class QAngle;
class loadout_slot_t;
class C_CSPlayerPawn {
public:
    uintptr_t baseAddr;
    C_CSPlayerPawn(uintptr_t addr) : baseAddr(addr) {}
    C_CSPlayerPawn() : baseAddr(0) {}
    int32_t m_ArmorValue() { return SCHEMA_TYPE(int32_t, 0x274C); }
    CEconItemView m_EconGloves() { return SCHEMA_TYPE(CEconItemView, 0x18A8); }
    Color m_GunGameImmunityColor() { return SCHEMA_TYPE(Color, 0x2480); }
    PredictedDamageTag_t m_PredictedDamageTags() { return SCHEMA_TYPE(PredictedDamageTag_t, 0x27E8); }
    loadout_slot_t m_RetakesMVPBoostExtraUtility() { return SCHEMA_TYPE(loadout_slot_t, 0x18A0); }
    QAngle m_aimPunchAngle() { return SCHEMA_TYPE(QAngle, 0x16E4); }
    QAngle m_aimPunchAngleVel() { return SCHEMA_TYPE(QAngle, 0x16F0); }
    uintptr_t m_aimPunchCache() { return SCHEMA_TYPE(uintptr_t, 0x1708); }
    GameTick_t m_aimPunchTickBase() { return SCHEMA_TYPE(GameTick_t, 0x16FC); }
    float m_aimPunchTickFraction() { return SCHEMA_TYPE(float, 0x1700); }
    uintptr_t m_angEyeAngles() { return SCHEMA_TYPE(uintptr_t, 0x3DF0); }
    uintptr_t m_angEyeAnglesVelocity() { return SCHEMA_TYPE(uintptr_t, 0x3EC0); }
    uintptr_t m_angShootAngleHistory() { return SCHEMA_TYPE(uintptr_t, 0x27A0); }
    uintptr_t m_angStashedShootAngles() { return SCHEMA_TYPE(uintptr_t, 0x277C); }
    uintptr_t m_arrOldEyeAngles() { return SCHEMA_TYPE(uintptr_t, 0x3E90); }
    uintptr_t m_arrOldEyeAnglesTimes() { return SCHEMA_TYPE(uintptr_t, 0x3E80); }
    uintptr_t m_bCachedPlaneIsValid() { return SCHEMA_TYPE(uintptr_t, 0x3DDD); }
    uintptr_t m_bClipHitStaticWorld() { return SCHEMA_TYPE(uintptr_t, 0x3DDC); }
    uintptr_t m_bGrenadeParametersStashed() { return SCHEMA_TYPE(uintptr_t, 0x2778); }
    bool m_bGunGameImmunity() { return SCHEMA_TYPE(bool, 0x3D94); }
    uintptr_t m_bHasDeathInfo() { return SCHEMA_TYPE(uintptr_t, 0x275D); }
    bool m_bHasFemaleVoice() { return SCHEMA_TYPE(bool, 0x16B0); }
    bool m_bInBombZone() { return SCHEMA_TYPE(bool, 0x1731); }
    bool m_bInBuyZone() { return SCHEMA_TYPE(bool, 0x16E0); }
    bool m_bInHostageRescueZone() { return SCHEMA_TYPE(bool, 0x1730); }
    uintptr_t m_bInLanding() { return SCHEMA_TYPE(uintptr_t, 0x1728); }
    bool m_bInNoDefuseArea() { return SCHEMA_TYPE(bool, 0x2724); }
    bool m_bIsBuyMenuOpen() { return SCHEMA_TYPE(bool, 0x1732); }
    bool m_bIsDefusing() { return SCHEMA_TYPE(bool, 0x271A); }
    bool m_bIsGrabbingHostage() { return SCHEMA_TYPE(bool, 0x271B); }
    bool m_bIsScoped() { return SCHEMA_TYPE(bool, 0x2718); }
    bool m_bIsWalking() { return SCHEMA_TYPE(bool, 0x24E8); }
    bool m_bKilledByHeadshot() { return SCHEMA_TYPE(bool, 0x2749); }
    bool m_bLeftHanded() { return SCHEMA_TYPE(bool, 0x2431); }
    uintptr_t m_bMustSyncRagdollState() { return SCHEMA_TYPE(uintptr_t, 0x1D21); }
    uintptr_t m_bNeedToReApplyGloves() { return SCHEMA_TYPE(uintptr_t, 0x18A5); }
    uintptr_t m_bOldIsScoped() { return SCHEMA_TYPE(uintptr_t, 0x275C); }
    uintptr_t m_bOnGroundLastTick() { return SCHEMA_TYPE(uintptr_t, 0x2404); }
    uintptr_t m_bPrevDefuser() { return SCHEMA_TYPE(uintptr_t, 0x16CE); }
    uintptr_t m_bPrevHelmet() { return SCHEMA_TYPE(uintptr_t, 0x16CF); }
    uintptr_t m_bPreviouslyInBuyZone() { return SCHEMA_TYPE(uintptr_t, 0x16E1); }
    bool m_bRagdollDamageHeadshot() { return SCHEMA_TYPE(bool, 0x1D80); }
    bool m_bResumeZoom() { return SCHEMA_TYPE(bool, 0x2719); }
    bool m_bRetakesHasDefuseKit() { return SCHEMA_TYPE(bool, 0x1898); }
    bool m_bRetakesMVPLastRound() { return SCHEMA_TYPE(bool, 0x1899); }
    uintptr_t m_bShouldAutobuyDMWeapons() { return SCHEMA_TYPE(uintptr_t, 0x3D8C); }
    uintptr_t m_bSkipOneHeadConstraintUpdate() { return SCHEMA_TYPE(uintptr_t, 0x2430); }
    bool m_bWaitForNoAttack() { return SCHEMA_TYPE(bool, 0x2740); }
    uintptr_t m_delayTargetIDTimer() { return SCHEMA_TYPE(uintptr_t, 0x3ED0); }
    EntitySpottedState_t m_entitySpottedState() { return SCHEMA_TYPE(EntitySpottedState_t, 0x2700); }
    GameTime_t m_fImmuneToGunGameDamageTime() { return SCHEMA_TYPE(GameTime_t, 0x3D90); }
    uintptr_t m_fImmuneToGunGameDamageTimeLast() { return SCHEMA_TYPE(uintptr_t, 0x3D98); }
    float m_fMolotovDamageTime() { return SCHEMA_TYPE(float, 0x3D9C); }
    uintptr_t m_fRenderingClipPlane() { return SCHEMA_TYPE(uintptr_t, 0x3DB0); }
    GameTime_t m_fSwitchedHandednessTime() { return SCHEMA_TYPE(GameTime_t, 0x2434); }
    uintptr_t m_flDeathInfoTime() { return SCHEMA_TYPE(uintptr_t, 0x2760); }
    GameTime_t m_flEmitSoundTime() { return SCHEMA_TYPE(GameTime_t, 0x2720); }
    float m_flFlinchStack() { return SCHEMA_TYPE(float, 0x2730); }
    GameTime_t m_flHealthShotBoostExpirationTime() { return SCHEMA_TYPE(GameTime_t, 0x16A8); }
    float m_flHitHeading() { return SCHEMA_TYPE(float, 0x2738); }
    uintptr_t m_flLandingStartTime() { return SCHEMA_TYPE(uintptr_t, 0x172C); }
    uintptr_t m_flLandingTimeSeconds() { return SCHEMA_TYPE(uintptr_t, 0x16B4); }
    uintptr_t m_flLastFiredWeaponTime() { return SCHEMA_TYPE(uintptr_t, 0x16AC); }
    GameTime_t m_flNextSprayDecalTime() { return SCHEMA_TYPE(GameTime_t, 0x1738); }
    uintptr_t m_flOldFallVelocity() { return SCHEMA_TYPE(uintptr_t, 0x16B8); }
    uintptr_t m_flSlopeDropHeight() { return SCHEMA_TYPE(uintptr_t, 0x25F8); }
    uintptr_t m_flSlopeDropOffset() { return SCHEMA_TYPE(uintptr_t, 0x2580); }
    GameTime_t m_flTimeOfLastInjury() { return SCHEMA_TYPE(GameTime_t, 0x1734); }
    float m_flVelocityModifier() { return SCHEMA_TYPE(float, 0x2734); }
    float m_flViewmodelFOV() { return SCHEMA_TYPE(float, 0x2444); }
    float m_flViewmodelOffsetX() { return SCHEMA_TYPE(float, 0x2438); }
    float m_flViewmodelOffsetY() { return SCHEMA_TYPE(float, 0x243C); }
    float m_flViewmodelOffsetZ() { return SCHEMA_TYPE(float, 0x2440); }
    uintptr_t m_grenadeParameterStashTime() { return SCHEMA_TYPE(uintptr_t, 0x2774); }
    uintptr_t m_hHudModelArms() { return SCHEMA_TYPE(uintptr_t, 0x2420); }
    uintptr_t m_holdTargetIDTimer() { return SCHEMA_TYPE(uintptr_t, 0x3EF0); }
    CSPlayerBlockingUseAction_t m_iBlockingUseActionInProgress() { return SCHEMA_TYPE(CSPlayerBlockingUseAction_t, 0x271C); }
    uintptr_t m_iIDEntIndex() { return SCHEMA_TYPE(uintptr_t, 0x3ECC); }
    uintptr_t m_iOldIDEntIndex() { return SCHEMA_TYPE(uintptr_t, 0x3EEC); }
    int32_t m_iRetakesMVPBoostItem() { return SCHEMA_TYPE(int32_t, 0x189C); }
    int32_t m_iRetakesOffering() { return SCHEMA_TYPE(int32_t, 0x1890); }
    int32_t m_iRetakesOfferingCard() { return SCHEMA_TYPE(int32_t, 0x1894); }
    int32_t m_iShotsFired() { return SCHEMA_TYPE(int32_t, 0x272C); }
    uintptr_t m_iTargetItemEntIdx() { return SCHEMA_TYPE(uintptr_t, 0x3EE8); }
    uintptr_t m_ignoreLadderJumpTime() { return SCHEMA_TYPE(uintptr_t, 0x2744); }
    uintptr_t m_lastLandTime() { return SCHEMA_TYPE(uintptr_t, 0x2400); }
    uint8_t m_nEconGlovesChanged() { return SCHEMA_TYPE(uint8_t, 0x1D20); }
    uintptr_t m_nHighestAppliedDamageTagTick() { return SCHEMA_TYPE(uintptr_t, 0x2854); }
    int32_t m_nHitBodyPart() { return SCHEMA_TYPE(int32_t, 0x273C); }
    uintptr_t m_nLastClipPlaneSetupFrame() { return SCHEMA_TYPE(uintptr_t, 0x3DC0); }
    CEntityIndex m_nLastKillerIndex() { return SCHEMA_TYPE(CEntityIndex, 0x2758); }
    uintptr_t m_nPlayerInfernoBodyFx() { return SCHEMA_TYPE(uintptr_t, 0x3DE8); }
    uintptr_t m_nPrevArmorVal() { return SCHEMA_TYPE(uintptr_t, 0x16D0); }
    uintptr_t m_nPrevGrenadeAmmoCount() { return SCHEMA_TYPE(uintptr_t, 0x16D4); }
    uintptr_t m_nPrevHighestReceivedDamageTagTick() { return SCHEMA_TYPE(uintptr_t, 0x2850); }
    int32_t m_nRagdollDamageBone() { return SCHEMA_TYPE(int32_t, 0x1D24); }
    int32_t m_nWhichBombZone() { return SCHEMA_TYPE(int32_t, 0x2728); }
    CCSPlayer_ActionTrackingServices* m_pActionTrackingServices() { return SCHEMA_TYPE(CCSPlayer_ActionTrackingServices*, 0x1698); }
    CCSPlayer_BulletServices* m_pBulletServices() { return SCHEMA_TYPE(CCSPlayer_BulletServices*, 0x1678); }
    CCSPlayer_BuyServices* m_pBuyServices() { return SCHEMA_TYPE(CCSPlayer_BuyServices*, 0x1688); }
    uintptr_t m_pClippingWeapon() { return SCHEMA_TYPE(uintptr_t, 0x3DE0); }
    uintptr_t m_pDamageReactServices() { return SCHEMA_TYPE(uintptr_t, 0x16A0); }
    CCSPlayer_GlowServices* m_pGlowServices() { return SCHEMA_TYPE(CCSPlayer_GlowServices*, 0x1690); }
    CCSPlayer_HostageServices* m_pHostageServices() { return SCHEMA_TYPE(CCSPlayer_HostageServices*, 0x1680); }
    QAngle m_qDeathEyeAngles() { return SCHEMA_TYPE(QAngle, 0x2424); }
    char m_szLastPlaceName() { return SCHEMA_TYPE(char, 0x16BC); }
    char m_szRagdollDamageWeaponName() { return SCHEMA_TYPE(char, 0x1D40); }
    uintptr_t m_thirdPersonHeading() { return SCHEMA_TYPE(uintptr_t, 0x24F0); }
    uint16_t m_unCurrentEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2750); }
    uint16_t m_unFreezetimeEndEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2754); }
    uintptr_t m_unPreviousWeaponHash() { return SCHEMA_TYPE(uintptr_t, 0x16D8); }
    uint16_t m_unRoundStartEquipmentValue() { return SCHEMA_TYPE(uint16_t, 0x2752); }
    uintptr_t m_unWeaponHash() { return SCHEMA_TYPE(uintptr_t, 0x16DC); }
    uintptr_t m_vHeadConstraintOffset() { return SCHEMA_TYPE(uintptr_t, 0x2670); }
    Vector3 m_vRagdollDamageForce() { return SCHEMA_TYPE(Vector3, 0x1D28); }
    Vector3 m_vRagdollDamagePosition() { return SCHEMA_TYPE(Vector3, 0x1D34); }
    Vector3 m_vRagdollServerOrigin() { return SCHEMA_TYPE(Vector3, 0x1D84); }
    uintptr_t m_vecBulletHitModels() { return SCHEMA_TYPE(uintptr_t, 0x24D0); }
    uintptr_t m_vecDeathInfoOrigin() { return SCHEMA_TYPE(uintptr_t, 0x2764); }
    uintptr_t m_vecLastAliveLocalVelocity() { return SCHEMA_TYPE(uintptr_t, 0x3DA4); }
    uintptr_t m_vecLastClipCameraForward() { return SCHEMA_TYPE(uintptr_t, 0x3DD0); }
    uintptr_t m_vecLastClipCameraPos() { return SCHEMA_TYPE(uintptr_t, 0x3DC4); }
    uint32_t m_vecPlayerPatchEconIndices() { return SCHEMA_TYPE(uint32_t, 0x2448); }
    uintptr_t m_vecStashedGrenadeThrowPosition() { return SCHEMA_TYPE(uintptr_t, 0x2788); }
    uintptr_t m_vecStashedVelocity() { return SCHEMA_TYPE(uintptr_t, 0x2794); }
    uintptr_t m_vecThrowPositionHistory() { return SCHEMA_TYPE(uintptr_t, 0x27B8); }
    uintptr_t m_vecVelocityHistory() { return SCHEMA_TYPE(uintptr_t, 0x27D0); }
};

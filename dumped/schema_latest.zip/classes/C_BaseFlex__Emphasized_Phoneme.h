#pragma once
#include "../cstypes/uintptr_t.h"

class C_BaseFlex__Emphasized_Phoneme  {
public:
    uintptr_t baseAddr;

    C_BaseFlex__Emphasized_Phoneme() : baseAddr(0) {}
    C_BaseFlex__Emphasized_Phoneme(uintptr_t base) : baseAddr(base) {}

    float m_flAmount() { return SCHEMA_TYPE(float, 0x20); }
};

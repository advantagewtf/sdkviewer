#pragma once
#include <cstdint>
class C_BaseEntityAPI {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_BaseEntityAPI {
public:
    uintptr_t baseAddr;
    C_BaseEntityAPI(uintptr_t addr) : baseAddr(addr) {}
    C_BaseEntityAPI() : baseAddr(0) {}
};

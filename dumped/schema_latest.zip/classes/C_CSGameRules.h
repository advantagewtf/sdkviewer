#pragma once
#include "../classes/C_RetakeGameRules.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CCSGameModeRules;

class C_CSGameRules  {
public:
    uintptr_t baseAddr;

    C_CSGameRules() : baseAddr(0) {}
    C_CSGameRules(uintptr_t base) : baseAddr(base) {}

    float m_flTerroristTimeOutRemaining() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCTTimeOutRemaining() { return SCHEMA_TYPE(float, 0x20); }
    int m_nTerroristTimeOuts() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCTTimeOuts() { return SCHEMA_TYPE(int, 0x20); }
    int m_iFreezeTime() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundTime() { return SCHEMA_TYPE(int, 0x20); }
    float m_fMatchStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flGameStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_timeUntilNextPhaseStarts() { return SCHEMA_TYPE(float, 0x20); }
    int m_gamePhase() { return SCHEMA_TYPE(int, 0x20); }
    int m_totalRoundsPlayed() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRoundsPlayedThisPhase() { return SCHEMA_TYPE(int, 0x20); }
    int m_nOvertimePlaying() { return SCHEMA_TYPE(int, 0x20); }
    int m_iHostagesRemaining() { return SCHEMA_TYPE(int, 0x20); }
    int m_nQueuedMatchmakingMode() { return SCHEMA_TYPE(int, 0x20); }
    int m_iSpectatorSlotCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_MatchDevice() { return SCHEMA_TYPE(int, 0x20); }
    int m_nNextMapInMapgroup() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szTournamentEventName() { return SCHEMA_TYPE(char*, 0x200); }
    char* m_szTournamentEventStage() { return SCHEMA_TYPE(char*, 0x200); }
    char* m_szMatchStatTxt() { return SCHEMA_TYPE(char*, 0x200); }
    char* m_szTournamentPredictionsTxt() { return SCHEMA_TYPE(char*, 0x200); }
    int m_nTournamentPredictionsPct() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_arrProhibitedItemIndices() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_arrTournamentActiveCasterAccounts() { return SCHEMA_TYPE(int, 0x20); }
    int m_numBestOfMaps() { return SCHEMA_TYPE(int, 0x20); }
    int m_nHalloweenMaskListSeed() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundWinStatus() { return SCHEMA_TYPE(int, 0x20); }
    int m_eRoundWinReason() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMatchStats_RoundResults() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMatchStats_PlayersAlive_CT() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMatchStats_PlayersAlive_T() { return SCHEMA_TYPE(int, 0x20); }
    float m_TeamRespawnWaveTimes() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_flNextRespawnWave() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    float m_MinimapVerticalSectionHeights() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_ullLocalMatchID() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_nEndMatchMapGroupVoteTypes() { return SCHEMA_TYPE(int, 0x20); }
    int m_nEndMatchMapGroupVoteOptions() { return SCHEMA_TYPE(int, 0x20); }
    int m_nEndMatchMapVoteWinner() { return SCHEMA_TYPE(int, 0x20); }
    int m_iNumConsecutiveCTLoses() { return SCHEMA_TYPE(int, 0x20); }
    int m_iNumConsecutiveTerroristLoses() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMatchAbortedEarlyReason() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nMatchEndCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nTTeamIntroVariant() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCTTeamIntroVariant() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndWinnerTeam() { return SCHEMA_TYPE(int, 0x20); }
    int m_eRoundEndReason() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndTimerTime() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndFunFactData1() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndFunFactData2() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndFunFactData3() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndPlayerCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRoundEndLegacy() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nRoundEndCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_iRoundStartRoundNumber() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nRoundStartCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uintptr_t m_flLastPerfSampleTime() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

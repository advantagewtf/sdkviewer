#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CPlayerSlot;
class CRetakeGameRules;
class CUtlString;
class GameTime_t;
class C_CSGameRules {
public:
    uintptr_t baseAddr;
    C_CSGameRules(uintptr_t addr) : baseAddr(addr) {}
    C_CSGameRules() : baseAddr(0) {}
    int32_t m_MatchDevice() { return SCHEMA_TYPE(int32_t, 0xAC); }
    float m_MinimapVerticalSectionHeights() { return SCHEMA_TYPE(float, 0xC38); }
    CRetakeGameRules m_RetakeRules() { return SCHEMA_TYPE(CRetakeGameRules, 0xDA0); }
    float m_TeamRespawnWaveTimes() { return SCHEMA_TYPE(float, 0xB20); }
    uint16_t m_arrProhibitedItemIndices() { return SCHEMA_TYPE(uint16_t, 0x8C8); }
    uint32_t m_arrTournamentActiveCasterAccounts() { return SCHEMA_TYPE(uint32_t, 0x990); }
    bool m_bAnyHostageReached() { return SCHEMA_TYPE(bool, 0x98); }
    bool m_bBombDropped() { return SCHEMA_TYPE(bool, 0x9A8); }
    bool m_bBombPlanted() { return SCHEMA_TYPE(bool, 0x9A9); }
    bool m_bCTCantBuy() { return SCHEMA_TYPE(bool, 0x9B5); }
    bool m_bCTTimeOutActive() { return SCHEMA_TYPE(bool, 0x4D); }
    bool m_bFreezePeriod() { return SCHEMA_TYPE(bool, 0x40); }
    bool m_bGameRestart() { return SCHEMA_TYPE(bool, 0x78); }
    bool m_bHasMatchStarted() { return SCHEMA_TYPE(bool, 0xB0); }
    uintptr_t m_bHasTriggeredRoundStartMusic() { return SCHEMA_TYPE(uintptr_t, 0xD7C); }
    bool m_bIsDroppingItems() { return SCHEMA_TYPE(bool, 0x8C4); }
    bool m_bIsHltvActive() { return SCHEMA_TYPE(bool, 0x8C6); }
    bool m_bIsQuestEligible() { return SCHEMA_TYPE(bool, 0x8C5); }
    bool m_bIsQueuedMatchmaking() { return SCHEMA_TYPE(bool, 0x9C); }
    bool m_bIsValveDS() { return SCHEMA_TYPE(bool, 0xA4); }
    bool m_bLogoMap() { return SCHEMA_TYPE(bool, 0xA5); }
    bool m_bMapHasBombTarget() { return SCHEMA_TYPE(bool, 0x99); }
    bool m_bMapHasBuyZone() { return SCHEMA_TYPE(bool, 0x9B); }
    bool m_bMapHasRescueZone() { return SCHEMA_TYPE(bool, 0x9A); }
    bool m_bMatchWaitingForResume() { return SCHEMA_TYPE(bool, 0x61); }
    bool m_bPlayAllStepSoundsOnServer() { return SCHEMA_TYPE(bool, 0xA6); }
    bool m_bRoundEndNoMusic() { return SCHEMA_TYPE(bool, 0xF3C); }
    bool m_bRoundEndShowTimerDefend() { return SCHEMA_TYPE(bool, 0xF10); }
    uintptr_t m_bSwitchingTeamsAtRoundReset() { return SCHEMA_TYPE(uintptr_t, 0xD7D); }
    bool m_bTCantBuy() { return SCHEMA_TYPE(bool, 0x9B4); }
    bool m_bTeamIntroPeriod() { return SCHEMA_TYPE(bool, 0xF04); }
    bool m_bTechnicalTimeOut() { return SCHEMA_TYPE(bool, 0x60); }
    bool m_bTerroristTimeOutActive() { return SCHEMA_TYPE(bool, 0x4C); }
    bool m_bWarmupPeriod() { return SCHEMA_TYPE(bool, 0x41); }
    int32_t m_eRoundEndReason() { return SCHEMA_TYPE(int32_t, 0xF0C); }
    int32_t m_eRoundWinReason() { return SCHEMA_TYPE(int32_t, 0x9B0); }
    float m_fMatchStartTime() { return SCHEMA_TYPE(float, 0x6C); }
    GameTime_t m_fRoundStartTime() { return SCHEMA_TYPE(GameTime_t, 0x70); }
    GameTime_t m_fWarmupPeriodEnd() { return SCHEMA_TYPE(GameTime_t, 0x44); }
    GameTime_t m_fWarmupPeriodStart() { return SCHEMA_TYPE(GameTime_t, 0x48); }
    GameTime_t m_flCMMItemDropRevealEndTime() { return SCHEMA_TYPE(GameTime_t, 0x8C0); }
    GameTime_t m_flCMMItemDropRevealStartTime() { return SCHEMA_TYPE(GameTime_t, 0x8BC); }
    float m_flCTTimeOutRemaining() { return SCHEMA_TYPE(float, 0x54); }
    float m_flGameStartTime() { return SCHEMA_TYPE(float, 0x7C); }
    uintptr_t m_flLastPerfSampleTime() { return SCHEMA_TYPE(uintptr_t, 0x4F58); }
    GameTime_t m_flNextRespawnWave() { return SCHEMA_TYPE(GameTime_t, 0xBA0); }
    GameTime_t m_flRestartRoundTime() { return SCHEMA_TYPE(GameTime_t, 0x74); }
    float m_flTerroristTimeOutRemaining() { return SCHEMA_TYPE(float, 0x50); }
    int32_t m_gamePhase() { return SCHEMA_TYPE(int32_t, 0x84); }
    int32_t m_iFreezeTime() { return SCHEMA_TYPE(int32_t, 0x64); }
    int32_t m_iHostagesRemaining() { return SCHEMA_TYPE(int32_t, 0x94); }
    int32_t m_iMatchStats_PlayersAlive_CT() { return SCHEMA_TYPE(int32_t, 0xA30); }
    int32_t m_iMatchStats_PlayersAlive_T() { return SCHEMA_TYPE(int32_t, 0xAA8); }
    int32_t m_iMatchStats_RoundResults() { return SCHEMA_TYPE(int32_t, 0x9B8); }
    int32_t m_iNumConsecutiveCTLoses() { return SCHEMA_TYPE(int32_t, 0xCB4); }
    int32_t m_iNumConsecutiveTerroristLoses() { return SCHEMA_TYPE(int32_t, 0xCB8); }
    int32_t m_iRoundEndFunFactData1() { return SCHEMA_TYPE(int32_t, 0xF24); }
    int32_t m_iRoundEndFunFactData2() { return SCHEMA_TYPE(int32_t, 0xF28); }
    int32_t m_iRoundEndFunFactData3() { return SCHEMA_TYPE(int32_t, 0xF2C); }
    CPlayerSlot m_iRoundEndFunFactPlayerSlot() { return SCHEMA_TYPE(CPlayerSlot, 0xF20); }
    int32_t m_iRoundEndLegacy() { return SCHEMA_TYPE(int32_t, 0xF40); }
    int32_t m_iRoundEndPlayerCount() { return SCHEMA_TYPE(int32_t, 0xF38); }
    int32_t m_iRoundEndTimerTime() { return SCHEMA_TYPE(int32_t, 0xF14); }
    int32_t m_iRoundEndWinnerTeam() { return SCHEMA_TYPE(int32_t, 0xF08); }
    int32_t m_iRoundStartRoundNumber() { return SCHEMA_TYPE(int32_t, 0xF48); }
    int32_t m_iRoundTime() { return SCHEMA_TYPE(int32_t, 0x68); }
    int32_t m_iRoundWinStatus() { return SCHEMA_TYPE(int32_t, 0x9AC); }
    int32_t m_iSpectatorSlotCount() { return SCHEMA_TYPE(int32_t, 0xA8); }
    int32_t m_nCTTeamIntroVariant() { return SCHEMA_TYPE(int32_t, 0xF00); }
    int32_t m_nCTTimeOuts() { return SCHEMA_TYPE(int32_t, 0x5C); }
    int32_t m_nEndMatchMapGroupVoteOptions() { return SCHEMA_TYPE(int32_t, 0xC88); }
    int32_t m_nEndMatchMapGroupVoteTypes() { return SCHEMA_TYPE(int32_t, 0xC60); }
    int32_t m_nEndMatchMapVoteWinner() { return SCHEMA_TYPE(int32_t, 0xCB0); }
    int32_t m_nHalloweenMaskListSeed() { return SCHEMA_TYPE(int32_t, 0x9A4); }
    int32_t m_nMatchAbortedEarlyReason() { return SCHEMA_TYPE(int32_t, 0xD78); }
    uint8_t m_nMatchEndCount() { return SCHEMA_TYPE(uint8_t, 0xEF8); }
    int32_t m_nNextMapInMapgroup() { return SCHEMA_TYPE(int32_t, 0xB4); }
    int32_t m_nOvertimePlaying() { return SCHEMA_TYPE(int32_t, 0x90); }
    int32_t m_nQueuedMatchmakingMode() { return SCHEMA_TYPE(int32_t, 0xA0); }
    uint8_t m_nRoundEndCount() { return SCHEMA_TYPE(uint8_t, 0xF44); }
    uint8_t m_nRoundStartCount() { return SCHEMA_TYPE(uint8_t, 0xF4C); }
    int32_t m_nRoundsPlayedThisPhase() { return SCHEMA_TYPE(int32_t, 0x8C); }
    int32_t m_nTTeamIntroVariant() { return SCHEMA_TYPE(int32_t, 0xEFC); }
    int32_t m_nTerroristTimeOuts() { return SCHEMA_TYPE(int32_t, 0x58); }
    int32_t m_nTournamentPredictionsPct() { return SCHEMA_TYPE(int32_t, 0x8B8); }
    int32_t m_numBestOfMaps() { return SCHEMA_TYPE(int32_t, 0x9A0); }
    CCSGameModeRules* m_pGameModeRules() { return SCHEMA_TYPE(CCSGameModeRules*, 0xD98); }
    CUtlString m_sRoundEndFunFactToken() { return SCHEMA_TYPE(CUtlString, 0xF18); }
    CUtlString m_sRoundEndMessage() { return SCHEMA_TYPE(CUtlString, 0xF30); }
    char m_szMatchStatTxt() { return SCHEMA_TYPE(char, 0x4B8); }
    char m_szTournamentEventName() { return SCHEMA_TYPE(char, 0xB8); }
    char m_szTournamentEventStage() { return SCHEMA_TYPE(char, 0x2B8); }
    char m_szTournamentPredictionsTxt() { return SCHEMA_TYPE(char, 0x6B8); }
    float m_timeUntilNextPhaseStarts() { return SCHEMA_TYPE(float, 0x80); }
    int32_t m_totalRoundsPlayed() { return SCHEMA_TYPE(int32_t, 0x88); }
    uintptr_t m_ullLocalMatchID() { return SCHEMA_TYPE(uintptr_t, 0xC58); }
    Vector3 m_vMinimapMaxs() { return SCHEMA_TYPE(Vector3, 0xC2C); }
    Vector3 m_vMinimapMins() { return SCHEMA_TYPE(Vector3, 0xC20); }
};

#pragma once
#include "../cstypes/AmmoIndex_t.h"
#include "../cstypes/ItemFlagTypes_t.h"
#include "../cstypes/RumbleEffect_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"

class CBasePlayerWeaponVData  {
public:
    uintptr_t baseAddr;

    CBasePlayerWeaponVData() : baseAddr(0) {}
    CBasePlayerWeaponVData(uintptr_t base) : baseAddr(base) {}

    uint8_t m_nMuzzleSmokeShotThreshold() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_flMuzzleSmokeTimeout() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMuzzleSmokeDecrementRate() { return SCHEMA_TYPE(float, 0x20); }
    int m_iMaxClip1() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMaxClip2() { return SCHEMA_TYPE(int, 0x20); }
    int m_iDefaultClip1() { return SCHEMA_TYPE(int, 0x20); }
    int m_iDefaultClip2() { return SCHEMA_TYPE(int, 0x20); }
    int m_iWeight() { return SCHEMA_TYPE(int, 0x20); }
    float m_flDropSpeed() { return SCHEMA_TYPE(float, 0x20); }
    int m_iSlot() { return SCHEMA_TYPE(int, 0x20); }
    int m_iPosition() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBasePlayerWeaponVData {
public:
    uintptr_t baseAddr;
    CBasePlayerWeaponVData(uintptr_t addr) : baseAddr(addr) {}
    CBasePlayerWeaponVData() : baseAddr(0) {}
    uintptr_t m_aShootSounds() { return SCHEMA_TYPE(uintptr_t, 0x418); }
    uintptr_t m_bAllowFlipping() { return SCHEMA_TYPE(uintptr_t, 0x1E9); }
    uintptr_t m_bAutoSwitchFrom() { return SCHEMA_TYPE(uintptr_t, 0x3ED); }
    uintptr_t m_bAutoSwitchTo() { return SCHEMA_TYPE(uintptr_t, 0x3EC); }
    uintptr_t m_bBuiltRightHanded() { return SCHEMA_TYPE(uintptr_t, 0x1E8); }
    uintptr_t m_bGenerateMuzzleLight() { return SCHEMA_TYPE(uintptr_t, 0x3E4); }
    uintptr_t m_bKeepLoadedAmmo() { return SCHEMA_TYPE(uintptr_t, 0x402); }
    uintptr_t m_bLinkedCooldowns() { return SCHEMA_TYPE(uintptr_t, 0x3E5); }
    uintptr_t m_bReserveAmmoAsClips() { return SCHEMA_TYPE(uintptr_t, 0x400); }
    uintptr_t m_bTreatAsSingleClip() { return SCHEMA_TYPE(uintptr_t, 0x401); }
    uintptr_t m_flDropSpeed() { return SCHEMA_TYPE(uintptr_t, 0x408); }
    uintptr_t m_flMuzzleSmokeDecrementRate() { return SCHEMA_TYPE(uintptr_t, 0x3E0); }
    uintptr_t m_flMuzzleSmokeTimeout() { return SCHEMA_TYPE(uintptr_t, 0x3DC); }
    uintptr_t m_iDefaultClip1() { return SCHEMA_TYPE(uintptr_t, 0x3F8); }
    uintptr_t m_iDefaultClip2() { return SCHEMA_TYPE(uintptr_t, 0x3FC); }
    uintptr_t m_iFlags() { return SCHEMA_TYPE(uintptr_t, 0x3E6); }
    uintptr_t m_iMaxClip1() { return SCHEMA_TYPE(uintptr_t, 0x3F0); }
    uintptr_t m_iMaxClip2() { return SCHEMA_TYPE(uintptr_t, 0x3F4); }
    uintptr_t m_iPosition() { return SCHEMA_TYPE(uintptr_t, 0x410); }
    uintptr_t m_iRumbleEffect() { return SCHEMA_TYPE(uintptr_t, 0x404); }
    uintptr_t m_iSlot() { return SCHEMA_TYPE(uintptr_t, 0x40C); }
    uintptr_t m_iWeight() { return SCHEMA_TYPE(uintptr_t, 0x3E8); }
    uintptr_t m_nMuzzleSmokeShotThreshold() { return SCHEMA_TYPE(uintptr_t, 0x3D8); }
    uintptr_t m_nPrimaryAmmoType() { return SCHEMA_TYPE(uintptr_t, 0x3EE); }
    uintptr_t m_nSecondaryAmmoType() { return SCHEMA_TYPE(uintptr_t, 0x3EF); }
    uintptr_t m_sMuzzleAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1F0); }
    uintptr_t m_sToolsOnlyOwnerModelName() { return SCHEMA_TYPE(uintptr_t, 0x108); }
    uintptr_t m_szBarrelSmokeParticle() { return SCHEMA_TYPE(uintptr_t, 0x2F8); }
    uintptr_t m_szMuzzleFlashParticle() { return SCHEMA_TYPE(uintptr_t, 0x210); }
    uintptr_t m_szMuzzleFlashParticleConfig() { return SCHEMA_TYPE(uintptr_t, 0x2F0); }
    uintptr_t m_szWorldModel() { return SCHEMA_TYPE(uintptr_t, 0x28); }
};

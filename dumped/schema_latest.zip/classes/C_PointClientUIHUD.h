#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_PointClientUIHUD : public C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_PointClientUIHUD(uintptr_t addr) : baseAddr(addr) {}
    C_PointClientUIHUD() : baseAddr(0) {}
    bool m_bAllowInteractionFromAllSceneWorlds() { return SCHEMA_TYPE(bool, 0x1060); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    bool m_bIgnoreInput() { return SCHEMA_TYPE(bool, 0x1038); }
    float m_flDPI() { return SCHEMA_TYPE(float, 0x1044); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x104C); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x1040); }
    float m_flInteractDistance() { return SCHEMA_TYPE(float, 0x1048); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0x103C); }
    uint32_t m_unHorizontalAlign() { return SCHEMA_TYPE(uint32_t, 0x1054); }
    uint32_t m_unOrientation() { return SCHEMA_TYPE(uint32_t, 0x105C); }
    uint32_t m_unOwnerContext() { return SCHEMA_TYPE(uint32_t, 0x1050); }
    uint32_t m_unVerticalAlign() { return SCHEMA_TYPE(uint32_t, 0x1058); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x1068); }
};

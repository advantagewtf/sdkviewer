#pragma once
#include "../types/Vector3.h"

class C_PointClientUIHUD  {
public:
    uintptr_t baseAddr;

    C_PointClientUIHUD() : baseAddr(0) {}
    C_PointClientUIHUD(uintptr_t base) : baseAddr(base) {}

    float m_flWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDPI() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInteractDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x20); }
    int m_unOwnerContext() { return SCHEMA_TYPE(int, 0x20); }
    int m_unHorizontalAlign() { return SCHEMA_TYPE(int, 0x20); }
    int m_unVerticalAlign() { return SCHEMA_TYPE(int, 0x20); }
    int m_unOrientation() { return SCHEMA_TYPE(int, 0x20); }
};

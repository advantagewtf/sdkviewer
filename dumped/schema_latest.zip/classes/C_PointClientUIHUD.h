#pragma once
#include <cstdint>
#include "../types/string_t.h"
class C_PointClientUIHUD : public C_BaseClientUIEntity {
public:
    bool m_bAllowInteractionFromAllSceneWorlds() { return SCHEMA_TYPE(bool, 0x1088); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    bool m_bIgnoreInput() { return SCHEMA_TYPE(bool, 0x1060); }
    float m_flDPI() { return SCHEMA_TYPE(float, 0x106C); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x1074); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x1068); }
    float m_flInteractDistance() { return SCHEMA_TYPE(float, 0x1070); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0x1064); }
    uint32_t m_unHorizontalAlign() { return SCHEMA_TYPE(uint32_t, 0x107C); }
    uint32_t m_unOrientation() { return SCHEMA_TYPE(uint32_t, 0x1084); }
    uint32_t m_unOwnerContext() { return SCHEMA_TYPE(uint32_t, 0x1078); }
    uint32_t m_unVerticalAlign() { return SCHEMA_TYPE(uint32_t, 0x1080); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x1090); }
};

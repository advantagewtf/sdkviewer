#pragma once
#include <cstdint>
class WeaponPurchaseTracker_t {
public:
    uintptr_t /* WeaponPurchaseCount_t */ m_weaponPurchases() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

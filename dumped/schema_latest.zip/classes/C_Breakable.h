#pragma once
#include <cstdint>
class C_Breakable : public C_BaseModelEntity {
public:
};

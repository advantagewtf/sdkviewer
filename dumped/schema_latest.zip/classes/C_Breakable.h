#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Breakable : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_Breakable(uintptr_t addr) : baseAddr(addr) {}
    C_Breakable() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPulseCell_BaseValue {
public:
};

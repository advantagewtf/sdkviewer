#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseValue {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseValue(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseValue() : baseAddr(0) {}
};

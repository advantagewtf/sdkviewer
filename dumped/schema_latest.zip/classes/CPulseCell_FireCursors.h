#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPulseCell_FireCursors  {
public:
    uintptr_t baseAddr;

    CPulseCell_FireCursors() : baseAddr(0) {}
    CPulseCell_FireCursors(uintptr_t base) : baseAddr(base) {}

};

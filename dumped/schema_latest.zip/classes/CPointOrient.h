#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPointOrient {
public:
    uintptr_t baseAddr;
    CPointOrient(uintptr_t addr) : baseAddr(addr) {}
    CPointOrient() : baseAddr(0) {}
    uintptr_t m_bActive() { return SCHEMA_TYPE(uintptr_t, 0x614); }
    uintptr_t m_flLastGameTime() { return SCHEMA_TYPE(uintptr_t, 0x624); }
    uintptr_t m_flMaxTurnRate() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_hTarget() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_iszSpawnTargetName() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_nConstraint() { return SCHEMA_TYPE(uintptr_t, 0x61C); }
    uintptr_t m_nGoalDirection() { return SCHEMA_TYPE(uintptr_t, 0x618); }
};

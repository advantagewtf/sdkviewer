#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/PointOrientConstraint_t.h"
#include "../cstypes/PointOrientGoalDirectionType_t.h"
#include "../cstypes/uintptr_t.h"
class C_BaseEntity;

class CPointOrient  {
public:
    uintptr_t baseAddr;

    CPointOrient() : baseAddr(0) {}
    CPointOrient(uintptr_t base) : baseAddr(base) {}

    float m_flMaxTurnRate() { return SCHEMA_TYPE(float, 0x20); }
};

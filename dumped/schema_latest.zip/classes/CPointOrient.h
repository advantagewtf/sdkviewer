#pragma once
#include <cstdint>
class CPointOrient {
public:
    uintptr_t m_bActive() { return SCHEMA_TYPE(uintptr_t, 0x604); }
    uintptr_t m_flLastGameTime() { return SCHEMA_TYPE(uintptr_t, 0x614); }
    uintptr_t m_flMaxTurnRate() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_hTarget() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_iszSpawnTargetName() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_nConstraint() { return SCHEMA_TYPE(uintptr_t, 0x60C); }
    uintptr_t m_nGoalDirection() { return SCHEMA_TYPE(uintptr_t, 0x608); }
};

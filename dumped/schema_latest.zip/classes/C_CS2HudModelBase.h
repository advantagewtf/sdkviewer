#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CS2HudModelBase {
public:
    uintptr_t baseAddr;
    C_CS2HudModelBase(uintptr_t addr) : baseAddr(addr) {}
    C_CS2HudModelBase() : baseAddr(0) {}
};

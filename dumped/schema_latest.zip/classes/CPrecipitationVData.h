#pragma once
#include "../cstypes/ParticleAttachment_t.h"
#include "../cstypes/uintptr_t.h"

class CPrecipitationVData  {
public:
    uintptr_t baseAddr;

    CPrecipitationVData() : baseAddr(0) {}
    CPrecipitationVData(uintptr_t base) : baseAddr(base) {}

    float m_flInnerDistance() { return SCHEMA_TYPE(float, 0x20); }
    int m_nRTEnvCP() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRTEnvCPComponent() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class PhysicsRagdollPose_t {
public:
    uintptr_t /* CTransform */ m_Transforms() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_bSetFromDebugHistory() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    uintptr_t /* EHANDLE */ m_hOwner() { return SCHEMA_TYPE(uintptr_t, 0x20); }
};

#pragma once
#include <cstdint>
class CCSGameModeRules_ArmsRace {
public:
    uintptr_t /* CUtlString */ m_WeaponSequence() { return SCHEMA_TYPE(uintptr_t, 0x30); }
};

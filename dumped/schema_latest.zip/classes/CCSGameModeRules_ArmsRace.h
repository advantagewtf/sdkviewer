#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlString;
class CCSGameModeRules_ArmsRace {
public:
    uintptr_t baseAddr;
    CCSGameModeRules_ArmsRace(uintptr_t addr) : baseAddr(addr) {}
    CCSGameModeRules_ArmsRace() : baseAddr(0) {}
    CUtlString m_WeaponSequence() { return SCHEMA_TYPE(CUtlString, 0x30); }
};

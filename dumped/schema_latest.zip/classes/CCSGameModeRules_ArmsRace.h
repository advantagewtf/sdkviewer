#pragma once
#include "../types/Vector3.h"

class CCSGameModeRules_ArmsRace  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_ArmsRace() : baseAddr(0) {}
    CCSGameModeRules_ArmsRace(uintptr_t base) : baseAddr(base) {}

};

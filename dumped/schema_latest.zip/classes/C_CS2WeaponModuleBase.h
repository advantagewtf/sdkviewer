#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CS2WeaponModuleBase : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_CS2WeaponModuleBase(uintptr_t addr) : baseAddr(addr) {}
    C_CS2WeaponModuleBase() : baseAddr(0) {}
};

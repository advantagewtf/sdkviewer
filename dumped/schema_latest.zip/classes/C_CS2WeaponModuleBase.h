#pragma once
#include <cstdint>
class C_CS2WeaponModuleBase : public CBaseAnimGraph {
public:
};

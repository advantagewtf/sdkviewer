#pragma once
#include "../cstypes/PulseNodeDynamicOutflows_t.h"
#include "../cstypes/uintptr_t.h"

class CPulseCell_PlaySequence  {
public:
    uintptr_t baseAddr;

    CPulseCell_PlaySequence() : baseAddr(0) {}
    CPulseCell_PlaySequence(uintptr_t base) : baseAddr(base) {}

};

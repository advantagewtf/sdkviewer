#pragma once
#include <cstdint>
class CPulseCell_PlaySequence {
public:
    uintptr_t m_OnCanceled() { return SCHEMA_TYPE(uintptr_t, 0xB0); }
    uintptr_t m_OnFinished() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_PulseAnimEvents() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_SequenceName() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

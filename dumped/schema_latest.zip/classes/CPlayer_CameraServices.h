#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CPlayer_CameraServices {
public:
    uintptr_t m_CurrentFog() { return SCHEMA_TYPE(uintptr_t, 0x140); }
    uintptr_t m_OverrideFogColor() { return SCHEMA_TYPE(uintptr_t, 0x1B1); }
    uintptr_t /* fogplayerparams_t */ m_PlayerFog() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    CHandle<C_PostProcessingVolume> m_PostProcessingVolumes() { return SCHEMA_TYPE(CHandle<C_PostProcessingVolume>, 0x120); }
    uintptr_t m_angDemoViewAngles() { return SCHEMA_TYPE(uintptr_t, 0x1F8); }
    uintptr_t /* audioparams_t */ m_audio() { return SCHEMA_TYPE(uintptr_t, 0xA8); }
    uintptr_t m_bOverrideFogColor() { return SCHEMA_TYPE(uintptr_t, 0x1AC); }
    uintptr_t m_bOverrideFogStartEnd() { return SCHEMA_TYPE(uintptr_t, 0x1C5); }
    uintptr_t m_fOverrideFogEnd() { return SCHEMA_TYPE(uintptr_t, 0x1E0); }
    uintptr_t m_fOverrideFogStart() { return SCHEMA_TYPE(uintptr_t, 0x1CC); }
    uintptr_t /* float32 */ m_flCsViewPunchAngleTickRatio() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_flOldPlayerViewOffsetZ() { return SCHEMA_TYPE(uintptr_t, 0x13C); }
    uintptr_t m_flOldPlayerZ() { return SCHEMA_TYPE(uintptr_t, 0x138); }
    uintptr_t m_hActivePostProcessingVolume() { return SCHEMA_TYPE(uintptr_t, 0x1F4); }
    CHandle<CColorCorrection> m_hColorCorrectionCtrl() { return SCHEMA_TYPE(CHandle<CColorCorrection>, 0x98); }
    uintptr_t m_hOldFogController() { return SCHEMA_TYPE(uintptr_t, 0x1A8); }
    CHandle<CTonemapController2> m_hTonemapController() { return SCHEMA_TYPE(CHandle<CTonemapController2>, 0xA0); }
    CHandle<CBaseEntity> m_hViewEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x9C); }
    uintptr_t /* GameTick_t */ m_nCsViewPunchAngleTick() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t /* QAngle */ m_vecCsViewPunchAngle() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

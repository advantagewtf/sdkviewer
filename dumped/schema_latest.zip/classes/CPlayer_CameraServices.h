#pragma once
#include "../cstypes/C_fogplayerparams_t.h"
#include "../cstypes/GameTick_t.h"
#include "../cstypes/audioparams_t.h"
#include "../cstypes/fogparams_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class C_BaseEntity;
class C_ColorCorrection;
class C_FogController;
class C_PostProcessingVolume;
class C_TonemapController2;

class CPlayer_CameraServices  {
public:
    uintptr_t baseAddr;

    CPlayer_CameraServices() : baseAddr(0) {}
    CPlayer_CameraServices(uintptr_t base) : baseAddr(base) {}

    float m_flCsViewPunchAngleTickRatio() { return SCHEMA_TYPE(float, 0x20); }
    C_TonemapController2* m_hTonemapController() { return SCHEMA_TYPE(C_TonemapController2*, 0x2); }
    float m_flOldPlayerZ() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOldPlayerViewOffsetZ() { return SCHEMA_TYPE(float, 0x20); }
    bool m_bOverrideFogColor() { return SCHEMA_TYPE(bool, 0x5); }
    uintptr_t m_OverrideFogColor() { return SCHEMA_TYPE(uintptr_t, 0x5); }
    bool m_bOverrideFogStartEnd() { return SCHEMA_TYPE(bool, 0x5); }
    float m_fOverrideFogStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_fOverrideFogEnd() { return SCHEMA_TYPE(float, 0x20); }
};

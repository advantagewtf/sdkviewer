#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class CColorCorrection;
class CTonemapController2;
class C_PostProcessingVolume;
class GameTick_t;
class QAngle;
class audioparams_t;
class float32;
class fogplayerparams_t;
class CPlayer_CameraServices {
public:
    uintptr_t baseAddr;
    CPlayer_CameraServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_CameraServices() : baseAddr(0) {}
    uintptr_t m_CurrentFog() { return SCHEMA_TYPE(uintptr_t, 0x148); }
    uintptr_t m_OverrideFogColor() { return SCHEMA_TYPE(uintptr_t, 0x1B9); }
    fogplayerparams_t m_PlayerFog() { return SCHEMA_TYPE(fogplayerparams_t, 0x60); }
    CHandle<C_PostProcessingVolume> m_PostProcessingVolumes() { return SCHEMA_TYPE(CHandle<C_PostProcessingVolume>, 0x128); }
    uintptr_t m_angDemoViewAngles() { return SCHEMA_TYPE(uintptr_t, 0x200); }
    audioparams_t m_audio() { return SCHEMA_TYPE(audioparams_t, 0xB0); }
    uintptr_t m_bOverrideFogColor() { return SCHEMA_TYPE(uintptr_t, 0x1B4); }
    uintptr_t m_bOverrideFogStartEnd() { return SCHEMA_TYPE(uintptr_t, 0x1CD); }
    uintptr_t m_fOverrideFogEnd() { return SCHEMA_TYPE(uintptr_t, 0x1E8); }
    uintptr_t m_fOverrideFogStart() { return SCHEMA_TYPE(uintptr_t, 0x1D4); }
    float32 m_flCsViewPunchAngleTickRatio() { return SCHEMA_TYPE(float32, 0x58); }
    uintptr_t m_flOldPlayerViewOffsetZ() { return SCHEMA_TYPE(uintptr_t, 0x144); }
    uintptr_t m_flOldPlayerZ() { return SCHEMA_TYPE(uintptr_t, 0x140); }
    uintptr_t m_hActivePostProcessingVolume() { return SCHEMA_TYPE(uintptr_t, 0x1FC); }
    CHandle<CColorCorrection> m_hColorCorrectionCtrl() { return SCHEMA_TYPE(CHandle<CColorCorrection>, 0xA0); }
    uintptr_t m_hOldFogController() { return SCHEMA_TYPE(uintptr_t, 0x1B0); }
    CHandle<CTonemapController2> m_hTonemapController() { return SCHEMA_TYPE(CHandle<CTonemapController2>, 0xA8); }
    CHandle<CBaseEntity> m_hViewEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0xA4); }
    GameTick_t m_nCsViewPunchAngleTick() { return SCHEMA_TYPE(GameTick_t, 0x54); }
    QAngle m_vecCsViewPunchAngle() { return SCHEMA_TYPE(QAngle, 0x48); }
};

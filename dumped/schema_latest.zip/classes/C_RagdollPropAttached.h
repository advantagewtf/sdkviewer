#pragma once
#include "../types/Vector3.h"

class C_RagdollPropAttached  {
public:
    uintptr_t baseAddr;

    C_RagdollPropAttached() : baseAddr(0) {}
    C_RagdollPropAttached(uintptr_t base) : baseAddr(base) {}

    int m_boneIndexAttached() { return SCHEMA_TYPE(int, 0x20); }
    int m_ragdollAttachedObjectIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_parentTime() { return SCHEMA_TYPE(float, 0x20); }
};

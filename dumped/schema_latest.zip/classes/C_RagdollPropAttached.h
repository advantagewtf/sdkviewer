#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_RagdollPropAttached : public C_RagdollProp {
public:
    Vector3 m_attachmentPointBoneSpace() { return SCHEMA_TYPE(Vector3, 0x11F0); }
    Vector3 m_attachmentPointRagdollSpace() { return SCHEMA_TYPE(Vector3, 0x11FC); }
    uintptr_t m_bHasParent() { return SCHEMA_TYPE(uintptr_t, 0x1218); }
    uint32_t m_boneIndexAttached() { return SCHEMA_TYPE(uint32_t, 0x11E8); }
    uintptr_t m_parentTime() { return SCHEMA_TYPE(uintptr_t, 0x1214); }
    uint32_t m_ragdollAttachedObjectIndex() { return SCHEMA_TYPE(uint32_t, 0x11EC); }
    uintptr_t m_vecOffset() { return SCHEMA_TYPE(uintptr_t, 0x1208); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MultiplayRules {
public:
    uintptr_t baseAddr;
    C_MultiplayRules(uintptr_t addr) : baseAddr(addr) {}
    C_MultiplayRules() : baseAddr(0) {}
};

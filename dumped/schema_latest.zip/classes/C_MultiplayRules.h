#pragma once
#include <cstdint>
class C_MultiplayRules {
public:
};

#pragma once
#include <cstdint>
class C_WeaponHKP2000 : public C_CSWeaponBaseGun {
public:
};

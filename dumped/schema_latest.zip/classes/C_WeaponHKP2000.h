#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponHKP2000 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponHKP2000(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponHKP2000() : baseAddr(0) {}
};

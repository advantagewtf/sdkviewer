#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvWindShared;
class C_EnvWindController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvWindController(uintptr_t addr) : baseAddr(addr) {}
    C_EnvWindController() : baseAddr(0) {}
    CEnvWindShared m_EnvWindShared() { return SCHEMA_TYPE(CEnvWindShared, 0x608); }
    uintptr_t m_bFirstTime() { return SCHEMA_TYPE(uintptr_t, 0x721); }
    bool m_bIsMaster() { return SCHEMA_TYPE(bool, 0x720); }
    float m_fDirectionVariation() { return SCHEMA_TYPE(float, 0x700); }
    float m_fSpeedVariation() { return SCHEMA_TYPE(float, 0x704); }
    float m_fTurbulence() { return SCHEMA_TYPE(float, 0x708); }
    float m_fVolumeHalfExtentXY() { return SCHEMA_TYPE(float, 0x70C); }
    float m_fVolumeHalfExtentZ() { return SCHEMA_TYPE(float, 0x710); }
    int32_t m_nClipmapLevels() { return SCHEMA_TYPE(int32_t, 0x71C); }
    int32_t m_nVolumeResolutionXY() { return SCHEMA_TYPE(int32_t, 0x714); }
    int32_t m_nVolumeResolutionZ() { return SCHEMA_TYPE(int32_t, 0x718); }
};

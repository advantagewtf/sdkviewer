#pragma once
#include "../classes/C_EnvWindShared.h"

class C_EnvWindController  {
public:
    uintptr_t baseAddr;

    C_EnvWindController() : baseAddr(0) {}
    C_EnvWindController(uintptr_t base) : baseAddr(base) {}

    float m_fDirectionVariation() { return SCHEMA_TYPE(float, 0x20); }
    float m_fSpeedVariation() { return SCHEMA_TYPE(float, 0x20); }
    float m_fTurbulence() { return SCHEMA_TYPE(float, 0x20); }
    float m_fVolumeHalfExtentXY() { return SCHEMA_TYPE(float, 0x20); }
    float m_fVolumeHalfExtentZ() { return SCHEMA_TYPE(float, 0x20); }
    int m_nVolumeResolutionXY() { return SCHEMA_TYPE(int, 0x20); }
    int m_nVolumeResolutionZ() { return SCHEMA_TYPE(int, 0x20); }
    int m_nClipmapLevels() { return SCHEMA_TYPE(int, 0x20); }
};

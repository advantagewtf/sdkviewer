#pragma once
#include <cstdint>
class WeaponPurchaseCount_t {
public:
    uint16_t m_nCount() { return SCHEMA_TYPE(uint16_t, 0x32); }
    uint16_t m_nItemDefIndex() { return SCHEMA_TYPE(uint16_t, 0x30); }
};

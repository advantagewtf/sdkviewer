#pragma once
#include "../cstypes/uint8_t.h"

class C_DynamicLight  {
public:
    uintptr_t baseAddr;

    C_DynamicLight() : baseAddr(0) {}
    C_DynamicLight(uintptr_t base) : baseAddr(base) {}

    uint8_t m_Flags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_LightStyle() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_Radius() { return SCHEMA_TYPE(float, 0x20); }
    int m_Exponent() { return SCHEMA_TYPE(int, 0x20); }
    float m_InnerAngle() { return SCHEMA_TYPE(float, 0x20); }
    float m_OuterAngle() { return SCHEMA_TYPE(float, 0x20); }
    float m_SpotRadius() { return SCHEMA_TYPE(float, 0x20); }
};

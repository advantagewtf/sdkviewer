#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class C_DynamicLight : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_DynamicLight(uintptr_t addr) : baseAddr(addr) {}
    C_DynamicLight() : baseAddr(0) {}
    int32_t m_Exponent() { return SCHEMA_TYPE(int32_t, 0xEB8); }
    uint8_t m_Flags() { return SCHEMA_TYPE(uint8_t, 0xEB0); }
    float32 m_InnerAngle() { return SCHEMA_TYPE(float32, 0xEBC); }
    uint8_t m_LightStyle() { return SCHEMA_TYPE(uint8_t, 0xEB1); }
    float32 m_OuterAngle() { return SCHEMA_TYPE(float32, 0xEC0); }
    float32 m_Radius() { return SCHEMA_TYPE(float32, 0xEB4); }
    float32 m_SpotRadius() { return SCHEMA_TYPE(float32, 0xEC4); }
};

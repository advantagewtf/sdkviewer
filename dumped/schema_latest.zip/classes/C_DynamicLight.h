#pragma once
#include <cstdint>
class C_DynamicLight : public C_BaseModelEntity {
public:
    int32_t m_Exponent() { return SCHEMA_TYPE(int32_t, 0xEB8); }
    uint8_t m_Flags() { return SCHEMA_TYPE(uint8_t, 0xEB0); }
    uintptr_t /* float32 */ m_InnerAngle() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    uint8_t m_LightStyle() { return SCHEMA_TYPE(uint8_t, 0xEB1); }
    uintptr_t /* float32 */ m_OuterAngle() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t /* float32 */ m_Radius() { return SCHEMA_TYPE(uintptr_t, 0xEB4); }
    uintptr_t /* float32 */ m_SpotRadius() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
};

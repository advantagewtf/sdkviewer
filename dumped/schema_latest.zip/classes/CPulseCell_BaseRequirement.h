#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseRequirement {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseRequirement(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseRequirement() : baseAddr(0) {}
};

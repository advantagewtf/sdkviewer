#pragma once
#include <cstdint>
class CPulseCell_BaseRequirement {
public:
};

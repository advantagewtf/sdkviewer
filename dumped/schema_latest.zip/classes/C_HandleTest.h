#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_HandleTest : public C_BaseEntity {
public:
    CHandle<CBaseEntity> m_Handle() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x5F8); }
    bool m_bSendHandle() { return SCHEMA_TYPE(bool, 0x5FC); }
};

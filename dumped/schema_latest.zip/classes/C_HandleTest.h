#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class C_HandleTest : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_HandleTest(uintptr_t addr) : baseAddr(addr) {}
    C_HandleTest() : baseAddr(0) {}
    CHandle<CBaseEntity> m_Handle() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x608); }
    bool m_bSendHandle() { return SCHEMA_TYPE(bool, 0x60C); }
};

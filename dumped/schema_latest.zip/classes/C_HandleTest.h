#pragma once
class C_BaseEntity;

class C_HandleTest  {
public:
    uintptr_t baseAddr;

    C_HandleTest() : baseAddr(0) {}
    C_HandleTest(uintptr_t base) : baseAddr(base) {}

};

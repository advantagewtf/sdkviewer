#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CCSPlayer_HostageServices {
public:
    CHandle<CBaseEntity> m_hCarriedHostage() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x40); }
    CHandle<CBaseEntity> m_hCarriedHostageProp() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x44); }
};

#pragma once
class C_BaseEntity;

class CCSPlayer_HostageServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_HostageServices() : baseAddr(0) {}
    CCSPlayer_HostageServices(uintptr_t base) : baseAddr(base) {}

};

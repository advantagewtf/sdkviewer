#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class CCSPlayer_HostageServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_HostageServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_HostageServices() : baseAddr(0) {}
    CHandle<CBaseEntity> m_hCarriedHostage() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x40); }
    CHandle<CBaseEntity> m_hCarriedHostageProp() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x44); }
};

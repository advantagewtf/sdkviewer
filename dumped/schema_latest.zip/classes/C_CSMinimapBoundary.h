#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSMinimapBoundary : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSMinimapBoundary(uintptr_t addr) : baseAddr(addr) {}
    C_CSMinimapBoundary() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_CSMinimapBoundary : public C_BaseEntity {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_HostageCarriableProp : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_HostageCarriableProp(uintptr_t addr) : baseAddr(addr) {}
    C_HostageCarriableProp() : baseAddr(0) {}
};

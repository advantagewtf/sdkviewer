#pragma once
#include <cstdint>
class C_HostageCarriableProp : public CBaseAnimGraph {
public:
};

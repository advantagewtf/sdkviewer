#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MapPreviewParticleSystem {
public:
    uintptr_t baseAddr;
    C_MapPreviewParticleSystem(uintptr_t addr) : baseAddr(addr) {}
    C_MapPreviewParticleSystem() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_MapPreviewParticleSystem {
public:
};

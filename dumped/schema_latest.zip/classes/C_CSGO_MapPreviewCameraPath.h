#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_MapPreviewCameraPath : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSGO_MapPreviewCameraPath(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_MapPreviewCameraPath() : baseAddr(0) {}
    uintptr_t m_bConstantSpeed() { return SCHEMA_TYPE(uintptr_t, 0x612); }
    uintptr_t m_bDofEnabled() { return SCHEMA_TYPE(uintptr_t, 0x674); }
    uintptr_t m_bLoop() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_bVerticalFOV() { return SCHEMA_TYPE(uintptr_t, 0x611); }
    uintptr_t m_flDofFarBlurry() { return SCHEMA_TYPE(uintptr_t, 0x684); }
    uintptr_t m_flDofFarCrisp() { return SCHEMA_TYPE(uintptr_t, 0x680); }
    uintptr_t m_flDofNearBlurry() { return SCHEMA_TYPE(uintptr_t, 0x678); }
    uintptr_t m_flDofNearCrisp() { return SCHEMA_TYPE(uintptr_t, 0x67C); }
    uintptr_t m_flDofTiltToGround() { return SCHEMA_TYPE(uintptr_t, 0x688); }
    uintptr_t m_flDuration() { return SCHEMA_TYPE(uintptr_t, 0x614); }
    uintptr_t m_flPathDuration() { return SCHEMA_TYPE(uintptr_t, 0x65C); }
    uintptr_t m_flPathLength() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    uintptr_t m_flZFar() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_flZNear() { return SCHEMA_TYPE(uintptr_t, 0x60C); }
};

#pragma once

class C_CSGO_MapPreviewCameraPath  {
public:
    uintptr_t baseAddr;

    C_CSGO_MapPreviewCameraPath() : baseAddr(0) {}
    C_CSGO_MapPreviewCameraPath(uintptr_t base) : baseAddr(base) {}

    float m_flZFar() { return SCHEMA_TYPE(float, 0x20); }
    float m_flZNear() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPathLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPathDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofNearBlurry() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofNearCrisp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofFarCrisp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofFarBlurry() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofTiltToGround() { return SCHEMA_TYPE(float, 0x20); }
};

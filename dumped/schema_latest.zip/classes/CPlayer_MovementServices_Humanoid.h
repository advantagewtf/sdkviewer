#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class CPlayer_MovementServices_Humanoid : public CPlayer_MovementServices {
public:
    uintptr_t baseAddr;
    CPlayer_MovementServices_Humanoid(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_MovementServices_Humanoid() : baseAddr(0) {}
    float32 m_flFallVelocity() { return SCHEMA_TYPE(float32, 0x244); }
    uintptr_t m_flStepSoundTime() { return SCHEMA_TYPE(uintptr_t, 0x240); }
    uintptr_t m_flSurfaceFriction() { return SCHEMA_TYPE(uintptr_t, 0x254); }
    uintptr_t m_groundNormal() { return SCHEMA_TYPE(uintptr_t, 0x248); }
    uintptr_t m_nStepside() { return SCHEMA_TYPE(uintptr_t, 0x268); }
    uintptr_t m_surfaceProps() { return SCHEMA_TYPE(uintptr_t, 0x258); }
};

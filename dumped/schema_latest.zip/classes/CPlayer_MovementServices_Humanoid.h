#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPlayer_MovementServices_Humanoid  {
public:
    uintptr_t baseAddr;

    CPlayer_MovementServices_Humanoid() : baseAddr(0) {}
    CPlayer_MovementServices_Humanoid(uintptr_t base) : baseAddr(base) {}

    float m_flStepSoundTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFallVelocity() { return SCHEMA_TYPE(float, 0x20); }
    int m_nCrouchState() { return SCHEMA_TYPE(int, 0x20); }
    float m_flSurfaceFriction() { return SCHEMA_TYPE(float, 0x20); }
    int m_nStepside() { return SCHEMA_TYPE(int, 0x20); }
};

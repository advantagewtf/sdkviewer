#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTime_t;
class float32;
class CPlayer_MovementServices_Humanoid : public CPlayer_MovementServices {
public:
    uintptr_t baseAddr;
    CPlayer_MovementServices_Humanoid(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_MovementServices_Humanoid() : baseAddr(0) {}
    bool m_bDucked() { return SCHEMA_TYPE(bool, 0x24C); }
    bool m_bDucking() { return SCHEMA_TYPE(bool, 0x24D); }
    bool m_bInCrouch() { return SCHEMA_TYPE(bool, 0x240); }
    bool m_bInDuckJump() { return SCHEMA_TYPE(bool, 0x24E); }
    GameTime_t m_flCrouchTransitionStartTime() { return SCHEMA_TYPE(GameTime_t, 0x248); }
    float32 m_flFallVelocity() { return SCHEMA_TYPE(float32, 0x23C); }
    uintptr_t m_flStepSoundTime() { return SCHEMA_TYPE(uintptr_t, 0x238); }
    uintptr_t m_flSurfaceFriction() { return SCHEMA_TYPE(uintptr_t, 0x25C); }
    uintptr_t m_groundNormal() { return SCHEMA_TYPE(uintptr_t, 0x250); }
    uint32_t m_nCrouchState() { return SCHEMA_TYPE(uint32_t, 0x244); }
    uintptr_t m_nStepside() { return SCHEMA_TYPE(uintptr_t, 0x270); }
    uintptr_t m_surfaceProps() { return SCHEMA_TYPE(uintptr_t, 0x260); }
};

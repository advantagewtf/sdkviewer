#pragma once
#include "../cstypes/ParticleIndex_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_Inferno  {
public:
    uintptr_t baseAddr;

    C_Inferno() : baseAddr(0) {}
    C_Inferno(uintptr_t base) : baseAddr(base) {}

    Vector3 m_firePositions() { return SCHEMA_TYPE(Vector3, 0x40); }
    Vector3 m_fireParentPositions() { return SCHEMA_TYPE(Vector3, 0x40); }
    bool m_bFireIsBurning() { return SCHEMA_TYPE(bool, 0x40); }
    Vector3 m_BurnNormal() { return SCHEMA_TYPE(Vector3, 0x40); }
    int m_fireCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nInfernoType() { return SCHEMA_TYPE(int, 0x20); }
    float m_nFireLifetime() { return SCHEMA_TYPE(float, 0x20); }
    int m_lastFireCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nFireEffectTickBegin() { return SCHEMA_TYPE(int, 0x20); }
    int m_drawableCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nlosperiod() { return SCHEMA_TYPE(int, 0x20); }
    float m_maxFireHalfWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_maxFireHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLastGrassBurnThink() { return SCHEMA_TYPE(float, 0x20); }
};

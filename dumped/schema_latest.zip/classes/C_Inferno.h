#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_Inferno : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_Inferno(uintptr_t addr) : baseAddr(addr) {}
    C_Inferno() : baseAddr(0) {}
    Vector3 m_BurnNormal() { return SCHEMA_TYPE(Vector3, 0x1538); }
    bool m_bFireIsBurning() { return SCHEMA_TYPE(bool, 0x14F8); }
    bool m_bInPostEffectTime() { return SCHEMA_TYPE(bool, 0x1844); }
    uintptr_t m_blosCheck() { return SCHEMA_TYPE(uintptr_t, 0x8454); }
    uintptr_t m_drawableCount() { return SCHEMA_TYPE(uintptr_t, 0x8450); }
    int32_t m_fireCount() { return SCHEMA_TYPE(int32_t, 0x1838); }
    Vector3 m_fireParentPositions() { return SCHEMA_TYPE(Vector3, 0x11F8); }
    Vector3 m_firePositions() { return SCHEMA_TYPE(Vector3, 0xEF8); }
    uintptr_t m_flLastGrassBurnThink() { return SCHEMA_TYPE(uintptr_t, 0x847C); }
    uintptr_t m_hInfernoClimbingOutlinePointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    uintptr_t m_hInfernoDecalsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uintptr_t m_hInfernoFillerPointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    uintptr_t m_hInfernoOutlinePointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xEE0); }
    uintptr_t m_hInfernoPointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    uintptr_t m_lastFireCount() { return SCHEMA_TYPE(uintptr_t, 0x1848); }
    uintptr_t m_maxBounds() { return SCHEMA_TYPE(uintptr_t, 0x8470); }
    uintptr_t m_maxFireHalfWidth() { return SCHEMA_TYPE(uintptr_t, 0x845C); }
    uintptr_t m_maxFireHeight() { return SCHEMA_TYPE(uintptr_t, 0x8460); }
    uintptr_t m_minBounds() { return SCHEMA_TYPE(uintptr_t, 0x8464); }
    int32_t m_nFireEffectTickBegin() { return SCHEMA_TYPE(int32_t, 0x184C); }
    float m_nFireLifetime() { return SCHEMA_TYPE(float, 0x1840); }
    int32_t m_nInfernoType() { return SCHEMA_TYPE(int32_t, 0x183C); }
    uintptr_t m_nfxFireDamageEffect() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    uintptr_t m_nlosperiod() { return SCHEMA_TYPE(uintptr_t, 0x8458); }
};

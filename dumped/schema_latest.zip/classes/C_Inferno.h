#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_Inferno : public C_BaseModelEntity {
public:
    Vector3 m_BurnNormal() { return SCHEMA_TYPE(Vector3, 0x1560); }
    bool m_bFireIsBurning() { return SCHEMA_TYPE(bool, 0x1520); }
    bool m_bInPostEffectTime() { return SCHEMA_TYPE(bool, 0x186C); }
    uintptr_t m_blosCheck() { return SCHEMA_TYPE(uintptr_t, 0x8484); }
    uintptr_t m_drawableCount() { return SCHEMA_TYPE(uintptr_t, 0x8480); }
    int32_t m_fireCount() { return SCHEMA_TYPE(int32_t, 0x1860); }
    Vector3 m_fireParentPositions() { return SCHEMA_TYPE(Vector3, 0x1220); }
    Vector3 m_firePositions() { return SCHEMA_TYPE(Vector3, 0xF20); }
    uintptr_t m_flLastGrassBurnThink() { return SCHEMA_TYPE(uintptr_t, 0x84AC); }
    uintptr_t m_hInfernoClimbingOutlinePointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xF10); }
    uintptr_t m_hInfernoDecalsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xF18); }
    uintptr_t m_hInfernoFillerPointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xF00); }
    uintptr_t m_hInfernoOutlinePointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xF08); }
    uintptr_t m_hInfernoPointsSnapshot() { return SCHEMA_TYPE(uintptr_t, 0xEF8); }
    uintptr_t m_lastFireCount() { return SCHEMA_TYPE(uintptr_t, 0x1870); }
    uintptr_t m_maxBounds() { return SCHEMA_TYPE(uintptr_t, 0x84A0); }
    uintptr_t m_maxFireHalfWidth() { return SCHEMA_TYPE(uintptr_t, 0x848C); }
    uintptr_t m_maxFireHeight() { return SCHEMA_TYPE(uintptr_t, 0x8490); }
    uintptr_t m_minBounds() { return SCHEMA_TYPE(uintptr_t, 0x8494); }
    int32_t m_nFireEffectTickBegin() { return SCHEMA_TYPE(int32_t, 0x1874); }
    float m_nFireLifetime() { return SCHEMA_TYPE(float, 0x1868); }
    int32_t m_nInfernoType() { return SCHEMA_TYPE(int32_t, 0x1864); }
    uintptr_t m_nfxFireDamageEffect() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uintptr_t m_nlosperiod() { return SCHEMA_TYPE(uintptr_t, 0x8488); }
};

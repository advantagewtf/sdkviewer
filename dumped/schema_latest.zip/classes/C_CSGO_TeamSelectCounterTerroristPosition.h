#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamSelectCounterTerroristPosition : public C_CSGO_TeamSelectCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamSelectCounterTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamSelectCounterTerroristPosition() : baseAddr(0) {}
};

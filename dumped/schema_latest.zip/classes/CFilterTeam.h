#pragma once

class CFilterTeam  {
public:
    uintptr_t baseAddr;

    CFilterTeam() : baseAddr(0) {}
    CFilterTeam(uintptr_t base) : baseAddr(base) {}

    int m_iFilterTeam() { return SCHEMA_TYPE(int, 0x20); }
};

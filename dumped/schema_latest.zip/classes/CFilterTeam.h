#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterTeam : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterTeam(uintptr_t addr) : baseAddr(addr) {}
    CFilterTeam() : baseAddr(0) {}
    uintptr_t m_iFilterTeam() { return SCHEMA_TYPE(uintptr_t, 0x640); }
};

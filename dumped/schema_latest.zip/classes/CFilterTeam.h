#pragma once
#include <cstdint>
class CFilterTeam : public CBaseFilter {
public:
    uintptr_t m_iFilterTeam() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

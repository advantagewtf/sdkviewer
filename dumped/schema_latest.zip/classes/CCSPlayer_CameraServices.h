#pragma once
#include "../types/Vector3.h"

class CCSPlayer_CameraServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_CameraServices() : baseAddr(0) {}
    CCSPlayer_CameraServices(uintptr_t base) : baseAddr(base) {}

    float m_flDeathCamTilt() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_CameraServices : public CCSPlayerBase_CameraServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_CameraServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_CameraServices() : baseAddr(0) {}
    uintptr_t m_flDeathCamTilt() { return SCHEMA_TYPE(uintptr_t, 0x2A0); }
    uintptr_t m_vClientScopeInaccuracy() { return SCHEMA_TYPE(uintptr_t, 0x2A8); }
};

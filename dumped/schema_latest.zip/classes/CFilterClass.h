#pragma once
#include <cstdint>
class CFilterClass : public CBaseFilter {
public:
    uintptr_t m_iFilterClass() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

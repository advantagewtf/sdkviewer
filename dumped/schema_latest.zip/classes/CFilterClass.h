#pragma once
#include "../cstypes/uintptr_t.h"

class CFilterClass  {
public:
    uintptr_t baseAddr;

    CFilterClass() : baseAddr(0) {}
    CFilterClass(uintptr_t base) : baseAddr(base) {}

};

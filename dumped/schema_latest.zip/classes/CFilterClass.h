#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterClass : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterClass(uintptr_t addr) : baseAddr(addr) {}
    CFilterClass() : baseAddr(0) {}
    uintptr_t m_iFilterClass() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

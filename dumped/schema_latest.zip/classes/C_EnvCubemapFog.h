#pragma once
#include "../cstypes/uintptr_t.h"

class C_EnvCubemapFog  {
public:
    uintptr_t baseAddr;

    C_EnvCubemapFog() : baseAddr(0) {}
    C_EnvCubemapFog(uintptr_t base) : baseAddr(base) {}

    float m_flEndDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogFalloffExponent() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogHeightWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogHeightEnd() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogHeightStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogHeightExponent() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLODBias() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxOpacity() { return SCHEMA_TYPE(float, 0x20); }
    int m_nCubemapSourceType() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_hSkyMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
};

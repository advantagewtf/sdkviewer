#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class HMaterialStrong;
class HRenderTextureStrong;
class C_EnvCubemapFog : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvCubemapFog(uintptr_t addr) : baseAddr(addr) {}
    C_EnvCubemapFog() : baseAddr(0) {}
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x62C); }
    uintptr_t m_bFirstTime() { return SCHEMA_TYPE(uintptr_t, 0x651); }
    bool m_bHasHeightFogEnd() { return SCHEMA_TYPE(bool, 0x650); }
    bool m_bHeightFogEnabled() { return SCHEMA_TYPE(bool, 0x614); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x62D); }
    float m_flEndDistance() { return SCHEMA_TYPE(float, 0x608); }
    float m_flFogFalloffExponent() { return SCHEMA_TYPE(float, 0x610); }
    float m_flFogHeightEnd() { return SCHEMA_TYPE(float, 0x61C); }
    float m_flFogHeightExponent() { return SCHEMA_TYPE(float, 0x624); }
    float m_flFogHeightStart() { return SCHEMA_TYPE(float, 0x620); }
    float m_flFogHeightWidth() { return SCHEMA_TYPE(float, 0x618); }
    float m_flFogMaxOpacity() { return SCHEMA_TYPE(float, 0x630); }
    float m_flLODBias() { return SCHEMA_TYPE(float, 0x628); }
    float m_flStartDistance() { return SCHEMA_TYPE(float, 0x60C); }
    HRenderTextureStrong m_hFogCubemapTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x648); }
    HMaterialStrong m_hSkyMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0x638); }
    string_t m_iszSkyEntity() { return SCHEMA_TYPE(string_t, 0x640); }
    int32_t m_nCubemapSourceType() { return SCHEMA_TYPE(int32_t, 0x634); }
};

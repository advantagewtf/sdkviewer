#pragma once
#include <cstdint>
#include "../types/string_t.h"
class C_EnvCubemapFog : public C_BaseEntity {
public:
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x61C); }
    uintptr_t m_bFirstTime() { return SCHEMA_TYPE(uintptr_t, 0x641); }
    bool m_bHasHeightFogEnd() { return SCHEMA_TYPE(bool, 0x640); }
    bool m_bHeightFogEnabled() { return SCHEMA_TYPE(bool, 0x604); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x61D); }
    float m_flEndDistance() { return SCHEMA_TYPE(float, 0x5F8); }
    float m_flFogFalloffExponent() { return SCHEMA_TYPE(float, 0x600); }
    float m_flFogHeightEnd() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flFogHeightExponent() { return SCHEMA_TYPE(float, 0x614); }
    float m_flFogHeightStart() { return SCHEMA_TYPE(float, 0x610); }
    float m_flFogHeightWidth() { return SCHEMA_TYPE(float, 0x608); }
    float m_flFogMaxOpacity() { return SCHEMA_TYPE(float, 0x620); }
    float m_flLODBias() { return SCHEMA_TYPE(float, 0x618); }
    float m_flStartDistance() { return SCHEMA_TYPE(float, 0x5FC); }
    uintptr_t /* HRenderTextureStrong */ m_hFogCubemapTexture() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    uintptr_t /* HMaterialStrong */ m_hSkyMaterial() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    string_t m_iszSkyEntity() { return SCHEMA_TYPE(string_t, 0x630); }
    int32_t m_nCubemapSourceType() { return SCHEMA_TYPE(int32_t, 0x624); }
};

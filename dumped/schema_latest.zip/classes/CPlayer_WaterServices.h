#pragma once
#include <cstdint>
class CPlayer_WaterServices {
public:
};

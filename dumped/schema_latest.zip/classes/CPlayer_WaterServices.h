#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPlayer_WaterServices {
public:
    uintptr_t baseAddr;
    CPlayer_WaterServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_WaterServices() : baseAddr(0) {}
};

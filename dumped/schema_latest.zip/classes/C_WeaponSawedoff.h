#pragma once
#include <cstdint>
class C_WeaponSawedoff : public C_CSWeaponBaseShotgun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponSawedoff : public C_CSWeaponBaseShotgun {
public:
    uintptr_t baseAddr;
    C_WeaponSawedoff(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponSawedoff() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTime_t;
class CCSPlayer_WeaponServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_WeaponServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_WeaponServices() : baseAddr(0) {}
    bool m_bBlockInspectUntilNextGraphUpdate() { return SCHEMA_TYPE(bool, 0x18F8); }
    bool m_bIsHoldingLookAtWeapon() { return SCHEMA_TYPE(bool, 0xCD); }
    bool m_bIsLookingAtWeapon() { return SCHEMA_TYPE(bool, 0xCC); }
    GameTime_t m_flNextAttack() { return SCHEMA_TYPE(GameTime_t, 0xC8); }
    uintptr_t m_nOldTotalInputHistoryCount() { return SCHEMA_TYPE(uintptr_t, 0x368); }
    uintptr_t m_nOldTotalShootPositionHistoryCount() { return SCHEMA_TYPE(uintptr_t, 0xD0); }
    uint8_t m_networkAnimTiming() { return SCHEMA_TYPE(uint8_t, 0x18E0); }
};

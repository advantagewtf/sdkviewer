#pragma once
#include <cstdint>
class CCSPlayer_WeaponServices {
public:
    bool m_bBlockInspectUntilNextGraphUpdate() { return SCHEMA_TYPE(bool, 0x18F8); }
    bool m_bIsHoldingLookAtWeapon() { return SCHEMA_TYPE(bool, 0xCD); }
    bool m_bIsLookingAtWeapon() { return SCHEMA_TYPE(bool, 0xCC); }
    uintptr_t /* GameTime_t */ m_flNextAttack() { return SCHEMA_TYPE(uintptr_t, 0xC8); }
    uintptr_t m_nOldTotalInputHistoryCount() { return SCHEMA_TYPE(uintptr_t, 0x368); }
    uintptr_t m_nOldTotalShootPositionHistoryCount() { return SCHEMA_TYPE(uintptr_t, 0xD0); }
    uint8_t m_networkAnimTiming() { return SCHEMA_TYPE(uint8_t, 0x18E0); }
};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint8_t.h"

class CCSPlayer_WeaponServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_WeaponServices() : baseAddr(0) {}
    CCSPlayer_WeaponServices(uintptr_t base) : baseAddr(base) {}

    int m_nOldTotalShootPositionHistoryCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nOldTotalInputHistoryCount() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_networkAnimTiming() { return SCHEMA_TYPE(uint8_t, 0x8); }
};

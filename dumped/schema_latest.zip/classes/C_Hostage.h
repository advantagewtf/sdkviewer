#pragma once
#include "../classes/CountdownTimer.h"
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/EntitySpottedState_t.h"
#include "../cstypes/GameTime_t.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class C_BaseEntity;
class C_CSPlayerPawn;

class C_Hostage  {
public:
    uintptr_t baseAddr;

    C_Hostage() : baseAddr(0) {}
    C_Hostage(uintptr_t base) : baseAddr(base) {}

    int m_nHostageState() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class CBaseEntity;
class CCSPlayerPawn;
class CountdownTimer;
class EntitySpottedState_t;
class GameTime_t;
class C_Hostage : public C_BaseCombatCharacter {
public:
    uintptr_t baseAddr;
    C_Hostage(uintptr_t addr) : baseAddr(addr) {}
    C_Hostage() : baseAddr(0) {}
    bool m_bHandsHaveBeenCut() { return SCHEMA_TYPE(bool, 0x1424); }
    uintptr_t m_blinkTimer() { return SCHEMA_TYPE(uintptr_t, 0x1450); }
    uintptr_t m_chestAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1492); }
    EntitySpottedState_t m_entitySpottedState() { return SCHEMA_TYPE(EntitySpottedState_t, 0x13D8); }
    uintptr_t m_eyeAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1491); }
    uintptr_t m_fLastGrabTime() { return SCHEMA_TYPE(uintptr_t, 0x142C); }
    uintptr_t m_fNewestAlphaThinkTime() { return SCHEMA_TYPE(uintptr_t, 0x14A0); }
    uintptr_t m_flDeadOrRescuedTime() { return SCHEMA_TYPE(uintptr_t, 0x1448); }
    GameTime_t m_flDropStartTime() { return SCHEMA_TYPE(GameTime_t, 0x1444); }
    GameTime_t m_flGrabSuccessTime() { return SCHEMA_TYPE(GameTime_t, 0x1440); }
    GameTime_t m_flRescueStartTime() { return SCHEMA_TYPE(GameTime_t, 0x143C); }
    CHandle<CCSPlayerPawn> m_hHostageGrabber() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x1428); }
    uintptr_t m_isInit() { return SCHEMA_TYPE(uintptr_t, 0x1490); }
    bool m_isRescued() { return SCHEMA_TYPE(bool, 0x141C); }
    bool m_jumpedThisFrame() { return SCHEMA_TYPE(bool, 0x141D); }
    CHandle<CBaseEntity> m_leader() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x13F0); }
    uintptr_t m_lookAroundTimer() { return SCHEMA_TYPE(uintptr_t, 0x1478); }
    uintptr_t m_lookAt() { return SCHEMA_TYPE(uintptr_t, 0x1468); }
    int32_t m_nHostageState() { return SCHEMA_TYPE(int32_t, 0x1420); }
    uintptr_t m_pPredictionOwner() { return SCHEMA_TYPE(uintptr_t, 0x1498); }
    CountdownTimer m_reuseTimer() { return SCHEMA_TYPE(CountdownTimer, 0x13F8); }
    uintptr_t m_vecGrabbedPos() { return SCHEMA_TYPE(uintptr_t, 0x1430); }
    Vector3 m_vel() { return SCHEMA_TYPE(Vector3, 0x1410); }
};

#pragma once
#include <cstdint>
class CFilterProximity : public CBaseFilter {
public:
    uintptr_t m_flRadius() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterProximity : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterProximity(uintptr_t addr) : baseAddr(addr) {}
    CFilterProximity() : baseAddr(0) {}
    uintptr_t m_flRadius() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

#pragma once

class CFilterProximity  {
public:
    uintptr_t baseAddr;

    CFilterProximity() : baseAddr(0) {}
    CFilterProximity(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
};

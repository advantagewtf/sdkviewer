#pragma once
#include "../classes/CPulse_OutflowConnection.h"
#include "../cstypes/PulseObservableBoolExpression_t.h"

class CPulseCell_BooleanSwitchState  {
public:
    uintptr_t baseAddr;

    CPulseCell_BooleanSwitchState() : baseAddr(0) {}
    CPulseCell_BooleanSwitchState(uintptr_t base) : baseAddr(base) {}

};

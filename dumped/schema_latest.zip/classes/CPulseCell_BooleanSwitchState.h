#pragma once
#include <cstdint>
class CPulseCell_BooleanSwitchState {
public:
    uintptr_t m_Condition() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_SubGraph() { return SCHEMA_TYPE(uintptr_t, 0xC0); }
    uintptr_t m_WhenFalse() { return SCHEMA_TYPE(uintptr_t, 0x150); }
    uintptr_t m_WhenTrue() { return SCHEMA_TYPE(uintptr_t, 0x108); }
};

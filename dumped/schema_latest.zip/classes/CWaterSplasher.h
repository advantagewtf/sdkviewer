#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CWaterSplasher {
public:
    uintptr_t baseAddr;
    CWaterSplasher(uintptr_t addr) : baseAddr(addr) {}
    CWaterSplasher() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CWaterSplasher {
public:
};

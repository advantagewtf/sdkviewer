#pragma once

class C_MolotovProjectile  {
public:
    uintptr_t baseAddr;

    C_MolotovProjectile() : baseAddr(0) {}
    C_MolotovProjectile(uintptr_t base) : baseAddr(base) {}

};

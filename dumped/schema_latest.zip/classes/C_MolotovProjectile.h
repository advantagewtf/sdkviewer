#pragma once
#include <cstdint>
class C_MolotovProjectile : public C_BaseCSGrenadeProjectile {
public:
    bool m_bIsIncGrenade() { return SCHEMA_TYPE(bool, 0x1450); }
};

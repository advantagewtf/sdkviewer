#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MolotovProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_MolotovProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_MolotovProjectile() : baseAddr(0) {}
    bool m_bIsIncGrenade() { return SCHEMA_TYPE(bool, 0x1450); }
};

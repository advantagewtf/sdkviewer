#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSWeaponBaseGun : public C_CSWeaponBase {
public:
    uintptr_t baseAddr;
    C_CSWeaponBaseGun(uintptr_t addr) : baseAddr(addr) {}
    C_CSWeaponBaseGun() : baseAddr(0) {}
    bool m_bNeedsBoltAction() { return SCHEMA_TYPE(bool, 0x1F5D); }
    int32_t m_iBurstShotsRemaining() { return SCHEMA_TYPE(int32_t, 0x1F44); }
    uintptr_t m_iSilencerBodygroup() { return SCHEMA_TYPE(uintptr_t, 0x1F48); }
    uintptr_t m_inPrecache() { return SCHEMA_TYPE(uintptr_t, 0x1F5C); }
    int32_t m_nRevolverCylinderIdx() { return SCHEMA_TYPE(int32_t, 0x1F60); }
    uintptr_t m_silencedModelIndex() { return SCHEMA_TYPE(uintptr_t, 0x1F58); }
    int32_t m_zoomLevel() { return SCHEMA_TYPE(int32_t, 0x1F40); }
};

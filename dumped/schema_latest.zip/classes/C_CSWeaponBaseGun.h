#pragma once

class C_CSWeaponBaseGun  {
public:
    uintptr_t baseAddr;

    C_CSWeaponBaseGun() : baseAddr(0) {}
    C_CSWeaponBaseGun(uintptr_t base) : baseAddr(base) {}

    int m_zoomLevel() { return SCHEMA_TYPE(int, 0x20); }
    int m_iBurstShotsRemaining() { return SCHEMA_TYPE(int, 0x20); }
    int m_iSilencerBodygroup() { return SCHEMA_TYPE(int, 0x20); }
    int m_silencedModelIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRevolverCylinderIdx() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_CSWeaponBaseGun : public C_CSWeaponBase {
public:
    bool m_bNeedsBoltAction() { return SCHEMA_TYPE(bool, 0x1F9D); }
    int32_t m_iBurstShotsRemaining() { return SCHEMA_TYPE(int32_t, 0x1F84); }
    uintptr_t m_iSilencerBodygroup() { return SCHEMA_TYPE(uintptr_t, 0x1F88); }
    uintptr_t m_inPrecache() { return SCHEMA_TYPE(uintptr_t, 0x1F9C); }
    int32_t m_nRevolverCylinderIdx() { return SCHEMA_TYPE(int32_t, 0x1FA0); }
    uintptr_t m_silencedModelIndex() { return SCHEMA_TYPE(uintptr_t, 0x1F98); }
    int32_t m_zoomLevel() { return SCHEMA_TYPE(int32_t, 0x1F80); }
};

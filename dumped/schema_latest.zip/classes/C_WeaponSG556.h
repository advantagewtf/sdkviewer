#pragma once
#include <cstdint>
class C_WeaponSG556 : public C_CSWeaponBaseGun {
public:
};

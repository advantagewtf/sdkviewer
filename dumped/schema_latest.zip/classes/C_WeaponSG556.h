#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponSG556 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponSG556(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponSG556() : baseAddr(0) {}
};

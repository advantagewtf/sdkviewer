#pragma once
#include <cstdint>
class CBodyComponentSkeletonInstance : public CBodyComponent {
public:
    uintptr_t /* CSkeletonInstance */ m_skeletonInstance() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

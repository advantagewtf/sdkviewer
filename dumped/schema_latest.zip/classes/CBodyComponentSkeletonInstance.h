#pragma once
#include "../classes/CSkeletonInstance.h"

class CBodyComponentSkeletonInstance  {
public:
    uintptr_t baseAddr;

    CBodyComponentSkeletonInstance() : baseAddr(0) {}
    CBodyComponentSkeletonInstance(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CSkeletonInstance;
class CBodyComponentSkeletonInstance : public CBodyComponent {
public:
    uintptr_t baseAddr;
    CBodyComponentSkeletonInstance(uintptr_t addr) : baseAddr(addr) {}
    CBodyComponentSkeletonInstance() : baseAddr(0) {}
    CSkeletonInstance m_skeletonInstance() { return SCHEMA_TYPE(CSkeletonInstance, 0x80); }
};

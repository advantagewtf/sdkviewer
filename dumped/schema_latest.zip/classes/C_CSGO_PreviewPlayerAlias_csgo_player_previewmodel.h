#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel : public C_CSGO_PreviewPlayer {
public:
    uintptr_t baseAddr;
    C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_PreviewPlayerAlias_csgo_player_previewmodel() : baseAddr(0) {}
};

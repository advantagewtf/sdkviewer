#pragma once
#include "../classes/CAttributeList.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"

class C_EconItemView  {
public:
    uintptr_t baseAddr;

    C_EconItemView() : baseAddr(0) {}
    C_EconItemView(uintptr_t base) : baseAddr(base) {}

    int m_nInventoryImageRgbaWidth() { return SCHEMA_TYPE(int, 0x20); }
    int m_nInventoryImageRgbaHeight() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szCurrentLoadCachedFileName() { return SCHEMA_TYPE(char*, 0x104); }
    uint16_t m_iItemDefinitionIndex() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_iEntityQuality() { return SCHEMA_TYPE(int, 0x20); }
    int m_iEntityLevel() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_iItemID() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_iItemIDHigh() { return SCHEMA_TYPE(int, 0x20); }
    int m_iItemIDLow() { return SCHEMA_TYPE(int, 0x20); }
    int m_iAccountID() { return SCHEMA_TYPE(int, 0x20); }
    int m_iInventoryPosition() { return SCHEMA_TYPE(int, 0x20); }
    int m_iEntityQuantity() { return SCHEMA_TYPE(int, 0x20); }
    int m_iRarityOverride() { return SCHEMA_TYPE(int, 0x20); }
    int m_iQualityOverride() { return SCHEMA_TYPE(int, 0x20); }
    int m_iOriginOverride() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_ubStyleOverride() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_unClientFlags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    char* m_szCustomName() { return SCHEMA_TYPE(char*, 0xa1); }
    char* m_szCustomNameOverride() { return SCHEMA_TYPE(char*, 0xa1); }
};

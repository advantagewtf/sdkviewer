#pragma once
#include <cstdint>
class C_EconItemView {
public:
    uintptr_t /* CAttributeList */ m_AttributeList() { return SCHEMA_TYPE(uintptr_t, 0x210); }
    uintptr_t /* CAttributeList */ m_NetworkedDynamicAttributes() { return SCHEMA_TYPE(uintptr_t, 0x288); }
    uintptr_t m_bDisallowSOC() { return SCHEMA_TYPE(uintptr_t, 0x1E9); }
    bool m_bInitialized() { return SCHEMA_TYPE(bool, 0x1E8); }
    uintptr_t m_bInitializedTags() { return SCHEMA_TYPE(uintptr_t, 0x470); }
    uintptr_t m_bInventoryImageRgbaRequested() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    uintptr_t m_bInventoryImageTriedCache() { return SCHEMA_TYPE(uintptr_t, 0x61); }
    uintptr_t m_bIsStoreItem() { return SCHEMA_TYPE(uintptr_t, 0x1EA); }
    uintptr_t m_bIsTradeItem() { return SCHEMA_TYPE(uintptr_t, 0x1EB); }
    uintptr_t m_bRestoreCustomMaterialAfterPrecache() { return SCHEMA_TYPE(uintptr_t, 0x1B8); }
    uint32_t m_iAccountID() { return SCHEMA_TYPE(uint32_t, 0x1D8); }
    uint32_t m_iEntityLevel() { return SCHEMA_TYPE(uint32_t, 0x1C0); }
    int32_t m_iEntityQuality() { return SCHEMA_TYPE(int32_t, 0x1BC); }
    uintptr_t m_iEntityQuantity() { return SCHEMA_TYPE(uintptr_t, 0x1EC); }
    uint32_t m_iInventoryPosition() { return SCHEMA_TYPE(uint32_t, 0x1DC); }
    uintptr_t /* item_definition_index_t */ m_iItemDefinitionIndex() { return SCHEMA_TYPE(uintptr_t, 0x1BA); }
    uintptr_t m_iItemID() { return SCHEMA_TYPE(uintptr_t, 0x1C8); }
    uint32_t m_iItemIDHigh() { return SCHEMA_TYPE(uint32_t, 0x1D0); }
    uint32_t m_iItemIDLow() { return SCHEMA_TYPE(uint32_t, 0x1D4); }
    uintptr_t m_iOriginOverride() { return SCHEMA_TYPE(uintptr_t, 0x1F8); }
    uintptr_t m_iQualityOverride() { return SCHEMA_TYPE(uintptr_t, 0x1F4); }
    uintptr_t m_iRarityOverride() { return SCHEMA_TYPE(uintptr_t, 0x1F0); }
    uintptr_t m_nInventoryImageRgbaHeight() { return SCHEMA_TYPE(uintptr_t, 0x84); }
    uintptr_t m_nInventoryImageRgbaWidth() { return SCHEMA_TYPE(uintptr_t, 0x80); }
    uintptr_t m_szCurrentLoadCachedFileName() { return SCHEMA_TYPE(uintptr_t, 0x88); }
    uintptr_t /* char */ m_szCustomName() { return SCHEMA_TYPE(uintptr_t, 0x300); }
    uintptr_t m_szCustomNameOverride() { return SCHEMA_TYPE(uintptr_t, 0x3A1); }
    uintptr_t m_ubStyleOverride() { return SCHEMA_TYPE(uintptr_t, 0x1FC); }
    uintptr_t m_unClientFlags() { return SCHEMA_TYPE(uintptr_t, 0x1FD); }
};

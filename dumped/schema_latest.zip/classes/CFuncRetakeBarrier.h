#pragma once
#include <cstdint>
class CFuncRetakeBarrier {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFuncRetakeBarrier {
public:
    uintptr_t baseAddr;
    CFuncRetakeBarrier(uintptr_t addr) : baseAddr(addr) {}
    CFuncRetakeBarrier() : baseAddr(0) {}
};

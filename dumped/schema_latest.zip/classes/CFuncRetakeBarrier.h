#pragma once
#include "../memory.h"

class CFuncRetakeBarrier {
public:
 uintptr_t baseAddr;
 CFuncRetakeBarrier() : baseAddr(0){}
 CFuncRetakeBarrier(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_PlayerSprayDecal : public C_ModelPointEntity {
public:
    uintptr_t baseAddr;
    C_PlayerSprayDecal(uintptr_t addr) : baseAddr(addr) {}
    C_PlayerSprayDecal() : baseAddr(0) {}
    uintptr_t m_SprayRenderHelper() { return SCHEMA_TYPE(uintptr_t, 0xF90); }
    float m_flCreationTime() { return SCHEMA_TYPE(float, 0xEFC); }
    int32_t m_nEntity() { return SCHEMA_TYPE(int32_t, 0xEF4); }
    int32_t m_nHitbox() { return SCHEMA_TYPE(int32_t, 0xEF8); }
    int32_t m_nPlayer() { return SCHEMA_TYPE(int32_t, 0xEF0); }
    int32_t m_nTintID() { return SCHEMA_TYPE(int32_t, 0xF00); }
    int32_t m_nUniqueID() { return SCHEMA_TYPE(int32_t, 0xEB0); }
    uint8_t m_nVersion() { return SCHEMA_TYPE(uint8_t, 0xF04); }
    uint32_t m_rtGcTime() { return SCHEMA_TYPE(uint32_t, 0xEBC); }
    uint8_t m_ubSignature() { return SCHEMA_TYPE(uint8_t, 0xF05); }
    uint32_t m_unAccountID() { return SCHEMA_TYPE(uint32_t, 0xEB4); }
    uint32_t m_unTraceID() { return SCHEMA_TYPE(uint32_t, 0xEB8); }
    Vector3 m_vecEndPos() { return SCHEMA_TYPE(Vector3, 0xEC0); }
    Vector3 m_vecLeft() { return SCHEMA_TYPE(Vector3, 0xED8); }
    Vector3 m_vecNormal() { return SCHEMA_TYPE(Vector3, 0xEE4); }
    Vector3 m_vecStart() { return SCHEMA_TYPE(Vector3, 0xECC); }
};

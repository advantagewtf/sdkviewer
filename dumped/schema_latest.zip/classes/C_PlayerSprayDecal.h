#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_PlayerSprayDecal : public C_ModelPointEntity {
public:
    uintptr_t baseAddr;
    C_PlayerSprayDecal(uintptr_t addr) : baseAddr(addr) {}
    C_PlayerSprayDecal() : baseAddr(0) {}
    uintptr_t m_SprayRenderHelper() { return SCHEMA_TYPE(uintptr_t, 0xF68); }
    float m_flCreationTime() { return SCHEMA_TYPE(float, 0xED4); }
    int32_t m_nEntity() { return SCHEMA_TYPE(int32_t, 0xECC); }
    int32_t m_nHitbox() { return SCHEMA_TYPE(int32_t, 0xED0); }
    int32_t m_nPlayer() { return SCHEMA_TYPE(int32_t, 0xEC8); }
    int32_t m_nTintID() { return SCHEMA_TYPE(int32_t, 0xED8); }
    int32_t m_nUniqueID() { return SCHEMA_TYPE(int32_t, 0xE88); }
    uint8_t m_nVersion() { return SCHEMA_TYPE(uint8_t, 0xEDC); }
    uint32_t m_rtGcTime() { return SCHEMA_TYPE(uint32_t, 0xE94); }
    uint8_t m_ubSignature() { return SCHEMA_TYPE(uint8_t, 0xEDD); }
    uint32_t m_unAccountID() { return SCHEMA_TYPE(uint32_t, 0xE8C); }
    uint32_t m_unTraceID() { return SCHEMA_TYPE(uint32_t, 0xE90); }
    Vector3 m_vecEndPos() { return SCHEMA_TYPE(Vector3, 0xE98); }
    Vector3 m_vecLeft() { return SCHEMA_TYPE(Vector3, 0xEB0); }
    Vector3 m_vecNormal() { return SCHEMA_TYPE(Vector3, 0xEBC); }
    Vector3 m_vecStart() { return SCHEMA_TYPE(Vector3, 0xEA4); }
};

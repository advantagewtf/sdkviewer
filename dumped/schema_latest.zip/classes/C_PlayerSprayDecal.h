#pragma once
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_PlayerSprayDecal  {
public:
    uintptr_t baseAddr;

    C_PlayerSprayDecal() : baseAddr(0) {}
    C_PlayerSprayDecal(uintptr_t base) : baseAddr(base) {}

    int m_nUniqueID() { return SCHEMA_TYPE(int, 0x20); }
    int m_unAccountID() { return SCHEMA_TYPE(int, 0x20); }
    int m_unTraceID() { return SCHEMA_TYPE(int, 0x20); }
    int m_rtGcTime() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPlayer() { return SCHEMA_TYPE(int, 0x20); }
    int m_nEntity() { return SCHEMA_TYPE(int, 0x20); }
    int m_nHitbox() { return SCHEMA_TYPE(int, 0x20); }
    float m_flCreationTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_nTintID() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nVersion() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_ubSignature() { return SCHEMA_TYPE(uint8_t, 0x8); }
};

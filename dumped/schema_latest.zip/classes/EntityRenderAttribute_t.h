#pragma once
#include <cstdint>
class EntityRenderAttribute_t {
public:
    uintptr_t /* CUtlStringToken */ m_ID() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t /* Vector4D */ m_Values() { return SCHEMA_TYPE(uintptr_t, 0x34); }
};

#pragma once
class C_BaseEntity;

class C_PointClientUIDialog  {
public:
    uintptr_t baseAddr;

    C_PointClientUIDialog() : baseAddr(0) {}
    C_PointClientUIDialog(uintptr_t base) : baseAddr(base) {}

};

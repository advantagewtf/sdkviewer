#pragma once
#include <cstdint>
class C_PointClientUIDialog : public C_BaseClientUIEntity {
public:
    uintptr_t m_bStartEnabled() { return SCHEMA_TYPE(uintptr_t, 0xEE4); }
    uintptr_t /* EHANDLE */ m_hActivator() { return SCHEMA_TYPE(uintptr_t, 0xEE0); }
};

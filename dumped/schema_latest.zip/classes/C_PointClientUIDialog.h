#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class EHANDLE;
class C_PointClientUIDialog : public C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_PointClientUIDialog(uintptr_t addr) : baseAddr(addr) {}
    C_PointClientUIDialog() : baseAddr(0) {}
    uintptr_t m_bStartEnabled() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    EHANDLE m_hActivator() { return SCHEMA_TYPE(EHANDLE, 0xEB8); }
};

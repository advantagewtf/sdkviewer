#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundAreaEntitySphere : public C_SoundAreaEntityBase {
public:
    uintptr_t baseAddr;
    C_SoundAreaEntitySphere(uintptr_t addr) : baseAddr(addr) {}
    C_SoundAreaEntitySphere() : baseAddr(0) {}
    float m_flRadius() { return SCHEMA_TYPE(float, 0x620); }
};

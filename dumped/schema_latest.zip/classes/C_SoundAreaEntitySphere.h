#pragma once

class C_SoundAreaEntitySphere  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntitySphere() : baseAddr(0) {}
    C_SoundAreaEntitySphere(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
};

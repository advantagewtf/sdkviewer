#pragma once
#include <cstdint>
class C_SoundAreaEntitySphere : public C_SoundAreaEntityBase {
public:
    float m_flRadius() { return SCHEMA_TYPE(float, 0x620); }
};

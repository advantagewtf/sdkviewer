#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponMP7 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponMP7(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponMP7() : baseAddr(0) {}
};

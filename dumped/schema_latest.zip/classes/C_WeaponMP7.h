#pragma once
#include <cstdint>
class C_WeaponMP7 : public C_CSWeaponBaseGun {
public:
};

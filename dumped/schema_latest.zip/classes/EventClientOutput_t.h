#pragma once
#include "../memory.h"

class EventClientOutput_t {
public:
 uintptr_t baseAddr;
 EventClientOutput_t() : baseAddr(0){}
 EventClientOutput_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_LoopState(){return SCHEMA_TYPE(uintptr_t,0x0);}
 uintptr_t m_flRenderTime(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flRealTime(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_flRenderFrameTimeUnbounded(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_bRenderOnly(){return SCHEMA_TYPE(uintptr_t,0x34);}
};

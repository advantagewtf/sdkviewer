#pragma once
#include <cstdint>
class CBodyComponentBaseModelEntity {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBodyComponentBaseModelEntity {
public:
    uintptr_t baseAddr;
    CBodyComponentBaseModelEntity(uintptr_t addr) : baseAddr(addr) {}
    CBodyComponentBaseModelEntity() : baseAddr(0) {}
};

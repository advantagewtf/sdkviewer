#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CGameSceneNode;
class CBodyComponentPoint : public CBodyComponent {
public:
    uintptr_t baseAddr;
    CBodyComponentPoint(uintptr_t addr) : baseAddr(addr) {}
    CBodyComponentPoint() : baseAddr(0) {}
    CGameSceneNode m_sceneNode() { return SCHEMA_TYPE(CGameSceneNode, 0x80); }
};

#pragma once
#include "../classes/CGameSceneNode.h"

class CBodyComponentPoint  {
public:
    uintptr_t baseAddr;

    CBodyComponentPoint() : baseAddr(0) {}
    CBodyComponentPoint(uintptr_t base) : baseAddr(base) {}

};

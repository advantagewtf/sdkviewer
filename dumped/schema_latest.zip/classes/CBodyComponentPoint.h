#pragma once
#include <cstdint>
class CBodyComponentPoint : public CBodyComponent {
public:
    uintptr_t /* CGameSceneNode */ m_sceneNode() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

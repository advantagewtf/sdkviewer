#pragma once
#include "../types/Vector3.h"

class C_PhysMagnet  {
public:
    uintptr_t baseAddr;

    C_PhysMagnet() : baseAddr(0) {}
    C_PhysMagnet(uintptr_t base) : baseAddr(base) {}

    int m_aAttachedObjectsFromServer() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_PhysMagnet : public CBaseAnimGraph {
public:
    uintptr_t m_aAttachedObjects() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    uintptr_t m_aAttachedObjectsFromServer() { return SCHEMA_TYPE(uintptr_t, 0x1158); }
};

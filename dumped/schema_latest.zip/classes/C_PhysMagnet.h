#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PhysMagnet : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_PhysMagnet(uintptr_t addr) : baseAddr(addr) {}
    C_PhysMagnet() : baseAddr(0) {}
    uintptr_t m_aAttachedObjects() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    uintptr_t m_aAttachedObjectsFromServer() { return SCHEMA_TYPE(uintptr_t, 0x1158); }
};

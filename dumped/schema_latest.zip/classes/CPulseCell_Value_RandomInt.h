#pragma once
#include <cstdint>
class CPulseCell_Value_RandomInt {
public:
};

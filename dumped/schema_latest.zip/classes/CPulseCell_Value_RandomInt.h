#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Value_RandomInt {
public:
    uintptr_t baseAddr;
    CPulseCell_Value_RandomInt(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Value_RandomInt() : baseAddr(0) {}
};

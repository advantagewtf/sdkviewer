#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_Sprite : public C_BaseModelEntity {
public:
    bool m_bWorldSpaceScale() { return SCHEMA_TYPE(bool, 0xEE8); }
    uintptr_t /* float32 */ m_flBrightnessDuration() { return SCHEMA_TYPE(uintptr_t, 0xEDC); }
    uintptr_t m_flBrightnessTimeStart() { return SCHEMA_TYPE(uintptr_t, 0xF10); }
    uintptr_t m_flDestScale() { return SCHEMA_TYPE(uintptr_t, 0xF00); }
    uintptr_t m_flDieTime() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    uintptr_t /* float32 */ m_flFrame() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t /* float32 */ m_flGlowProxySize() { return SCHEMA_TYPE(uintptr_t, 0xEEC); }
    uintptr_t /* float32 */ m_flHDRColorScale() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uintptr_t m_flLastTime() { return SCHEMA_TYPE(uintptr_t, 0xEF4); }
    uintptr_t m_flMaxFrame() { return SCHEMA_TYPE(uintptr_t, 0xEF8); }
    uintptr_t /* float32 */ m_flScaleDuration() { return SCHEMA_TYPE(uintptr_t, 0xEE4); }
    uintptr_t m_flScaleTimeStart() { return SCHEMA_TYPE(uintptr_t, 0xF04); }
    uintptr_t /* float32 */ m_flSpriteFramerate() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t /* float32 */ m_flSpriteScale() { return SCHEMA_TYPE(uintptr_t, 0xEE0); }
    uintptr_t m_flStartScale() { return SCHEMA_TYPE(uintptr_t, 0xEFC); }
    CHandle<CBaseEntity> m_hAttachedToEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0xEB8); }
    uintptr_t /* HMaterialStrong */ m_hSpriteMaterial() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
    uintptr_t /* AttachmentHandle_t */ m_nAttachment() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    uint32_t m_nBrightness() { return SCHEMA_TYPE(uint32_t, 0xED8); }
    uintptr_t m_nDestBrightness() { return SCHEMA_TYPE(uintptr_t, 0xF0C); }
    uintptr_t m_nSpriteHeight() { return SCHEMA_TYPE(uintptr_t, 0xF24); }
    uintptr_t m_nSpriteWidth() { return SCHEMA_TYPE(uintptr_t, 0xF20); }
    uintptr_t m_nStartBrightness() { return SCHEMA_TYPE(uintptr_t, 0xF08); }
};

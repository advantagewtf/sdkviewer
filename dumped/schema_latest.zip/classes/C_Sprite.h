#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
class C_BaseEntity;

class C_Sprite  {
public:
    uintptr_t baseAddr;

    C_Sprite() : baseAddr(0) {}
    C_Sprite(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSpriteMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    float m_flSpriteFramerate() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFrame() { return SCHEMA_TYPE(float, 0x20); }
    int m_nBrightness() { return SCHEMA_TYPE(int, 0x20); }
    float m_flBrightnessDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSpriteScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flScaleDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flGlowProxySize() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHDRColorScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxFrame() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDestScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_nStartBrightness() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDestBrightness() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSpriteWidth() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSpriteHeight() { return SCHEMA_TYPE(int, 0x20); }
};

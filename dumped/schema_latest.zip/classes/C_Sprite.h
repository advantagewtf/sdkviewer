#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class AttachmentHandle_t;
class CBaseEntity;
class HMaterialStrong;
class float32;
class C_Sprite : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_Sprite(uintptr_t addr) : baseAddr(addr) {}
    C_Sprite() : baseAddr(0) {}
    bool m_bWorldSpaceScale() { return SCHEMA_TYPE(bool, 0xEC0); }
    float32 m_flBrightnessDuration() { return SCHEMA_TYPE(float32, 0xEB4); }
    uintptr_t m_flBrightnessTimeStart() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    uintptr_t m_flDestScale() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    uintptr_t m_flDieTime() { return SCHEMA_TYPE(uintptr_t, 0xEA0); }
    float32 m_flFrame() { return SCHEMA_TYPE(float32, 0xE9C); }
    float32 m_flGlowProxySize() { return SCHEMA_TYPE(float32, 0xEC4); }
    float32 m_flHDRColorScale() { return SCHEMA_TYPE(float32, 0xEC8); }
    uintptr_t m_flLastTime() { return SCHEMA_TYPE(uintptr_t, 0xECC); }
    uintptr_t m_flMaxFrame() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    float32 m_flScaleDuration() { return SCHEMA_TYPE(float32, 0xEBC); }
    uintptr_t m_flScaleTimeStart() { return SCHEMA_TYPE(uintptr_t, 0xEDC); }
    float32 m_flSpriteFramerate() { return SCHEMA_TYPE(float32, 0xE98); }
    float32 m_flSpriteScale() { return SCHEMA_TYPE(float32, 0xEB8); }
    uintptr_t m_flStartScale() { return SCHEMA_TYPE(uintptr_t, 0xED4); }
    CHandle<CBaseEntity> m_hAttachedToEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0xE90); }
    HMaterialStrong m_hSpriteMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0xE88); }
    AttachmentHandle_t m_nAttachment() { return SCHEMA_TYPE(AttachmentHandle_t, 0xE94); }
    uint32_t m_nBrightness() { return SCHEMA_TYPE(uint32_t, 0xEB0); }
    uintptr_t m_nDestBrightness() { return SCHEMA_TYPE(uintptr_t, 0xEE4); }
    uintptr_t m_nSpriteHeight() { return SCHEMA_TYPE(uintptr_t, 0xEFC); }
    uintptr_t m_nSpriteWidth() { return SCHEMA_TYPE(uintptr_t, 0xEF8); }
    uintptr_t m_nStartBrightness() { return SCHEMA_TYPE(uintptr_t, 0xEE0); }
};

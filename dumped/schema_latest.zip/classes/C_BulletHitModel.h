#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_BulletHitModel {
public:
    uintptr_t baseAddr;
    C_BulletHitModel(uintptr_t addr) : baseAddr(addr) {}
    C_BulletHitModel() : baseAddr(0) {}
    uintptr_t m_bIsHit() { return SCHEMA_TYPE(uintptr_t, 0x11A0); }
    uintptr_t m_flTimeCreated() { return SCHEMA_TYPE(uintptr_t, 0x11A4); }
    uintptr_t m_hPlayerParent() { return SCHEMA_TYPE(uintptr_t, 0x119C); }
    uintptr_t m_iBoneIndex() { return SCHEMA_TYPE(uintptr_t, 0x1198); }
    uintptr_t m_matLocal() { return SCHEMA_TYPE(uintptr_t, 0x1168); }
    uintptr_t m_vecStartPos() { return SCHEMA_TYPE(uintptr_t, 0x11A8); }
};

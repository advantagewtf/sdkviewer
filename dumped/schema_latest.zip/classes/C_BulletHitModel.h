#pragma once
#include "../cstypes/matrix3x4_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_BulletHitModel  {
public:
    uintptr_t baseAddr;

    C_BulletHitModel() : baseAddr(0) {}
    C_BulletHitModel(uintptr_t base) : baseAddr(base) {}

    matrix3x4_t m_matLocal() { return SCHEMA_TYPE(matrix3x4_t, 0x3); }
    int m_iBoneIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_flTimeCreated() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class CEnvSoundscapeAlias_snd_soundscape : public CEnvSoundscape {
public:
};

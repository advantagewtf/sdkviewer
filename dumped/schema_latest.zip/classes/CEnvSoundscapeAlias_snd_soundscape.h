#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvSoundscapeAlias_snd_soundscape : public CEnvSoundscape {
public:
    uintptr_t baseAddr;
    CEnvSoundscapeAlias_snd_soundscape(uintptr_t addr) : baseAddr(addr) {}
    CEnvSoundscapeAlias_snd_soundscape() : baseAddr(0) {}
};

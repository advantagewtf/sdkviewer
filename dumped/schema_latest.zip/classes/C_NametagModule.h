#pragma once
#include <cstdint>
class C_NametagModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t m_strNametagString() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_NametagModule  {
public:
    uintptr_t baseAddr;

    C_NametagModule() : baseAddr(0) {}
    C_NametagModule(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_NametagModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t baseAddr;
    C_NametagModule(uintptr_t addr) : baseAddr(addr) {}
    C_NametagModule() : baseAddr(0) {}
    uintptr_t m_strNametagString() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
};

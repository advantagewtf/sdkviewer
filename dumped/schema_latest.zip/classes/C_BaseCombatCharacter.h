#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/C_BaseCombatCharacter::WaterWakeMode_t.h"
#include "../types/Vector3.h"

class C_BaseCombatCharacter  {
public:
    uintptr_t baseAddr;

    C_BaseCombatCharacter() : baseAddr(0) {}
    C_BaseCombatCharacter(uintptr_t base) : baseAddr(base) {}

    float m_flWaterWorldZ() { return SCHEMA_TYPE(float, 0x20); }
    float m_flWaterNextTraceTime() { return SCHEMA_TYPE(float, 0x20); }
};

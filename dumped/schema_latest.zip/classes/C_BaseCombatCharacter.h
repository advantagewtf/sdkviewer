#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class C_EconWearable;
class C_BaseCombatCharacter {
public:
    uintptr_t baseAddr;
    C_BaseCombatCharacter(uintptr_t addr) : baseAddr(addr) {}
    C_BaseCombatCharacter() : baseAddr(0) {}
    uintptr_t m_flWaterNextTraceTime() { return SCHEMA_TYPE(uintptr_t, 0x1374); }
    uintptr_t m_flWaterWorldZ() { return SCHEMA_TYPE(uintptr_t, 0x1370); }
    CHandle<C_EconWearable> m_hMyWearables() { return SCHEMA_TYPE(CHandle<C_EconWearable>, 0x1350); }
    uintptr_t m_leftFootAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1368); }
    uintptr_t m_nWaterWakeMode() { return SCHEMA_TYPE(uintptr_t, 0x136C); }
    uintptr_t m_rightFootAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1369); }
};

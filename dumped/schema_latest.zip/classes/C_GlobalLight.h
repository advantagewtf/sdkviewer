#pragma once
#include <cstdint>
class C_GlobalLight : public C_BaseEntity {
public:
    uintptr_t m_WindClothForceHandle() { return SCHEMA_TYPE(uintptr_t, 0xAC0); }
};

#pragma once
#include "../cstypes/uint16_t.h"

class C_GlobalLight  {
public:
    uintptr_t baseAddr;

    C_GlobalLight() : baseAddr(0) {}
    C_GlobalLight(uintptr_t base) : baseAddr(base) {}

    uint16_t m_WindClothForceHandle() { return SCHEMA_TYPE(uint16_t, 0x10); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_GlobalLight : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_GlobalLight(uintptr_t addr) : baseAddr(addr) {}
    C_GlobalLight() : baseAddr(0) {}
    uintptr_t m_WindClothForceHandle() { return SCHEMA_TYPE(uintptr_t, 0xAC0); }
};

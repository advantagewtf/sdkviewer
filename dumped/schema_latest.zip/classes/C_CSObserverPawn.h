#pragma once
#include <cstdint>
class C_CSObserverPawn {
public:
    uintptr_t m_hDetectParentChange() { return SCHEMA_TYPE(uintptr_t, 0x1668); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSObserverPawn {
public:
    uintptr_t baseAddr;
    C_CSObserverPawn(uintptr_t addr) : baseAddr(addr) {}
    C_CSObserverPawn() : baseAddr(0) {}
    uintptr_t m_hDetectParentChange() { return SCHEMA_TYPE(uintptr_t, 0x1668); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_CSObserverPawn  {
public:
    uintptr_t baseAddr;

    C_CSObserverPawn() : baseAddr(0) {}
    C_CSObserverPawn(uintptr_t base) : baseAddr(base) {}

};

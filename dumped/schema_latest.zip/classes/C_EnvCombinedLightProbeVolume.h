#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class Color;
class HRenderTextureStrong;
class C_EnvCombinedLightProbeVolume : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvCombinedLightProbeVolume(uintptr_t addr) : baseAddr(addr) {}
    C_EnvCombinedLightProbeVolume() : baseAddr(0) {}
    Color m_Entity_Color() { return SCHEMA_TYPE(Color, 0x1680); }
    bool m_Entity_bCustomCubemapTexture() { return SCHEMA_TYPE(bool, 0x1690); }
    bool m_Entity_bEnabled() { return SCHEMA_TYPE(bool, 0x1749); }
    bool m_Entity_bMoveable() { return SCHEMA_TYPE(bool, 0x16F8); }
    bool m_Entity_bStartDisabled() { return SCHEMA_TYPE(bool, 0x1708); }
    float m_Entity_flBrightness() { return SCHEMA_TYPE(float, 0x1684); }
    float m_Entity_flEdgeFadeDist() { return SCHEMA_TYPE(float, 0x170C); }
    HRenderTextureStrong m_Entity_hCubemapTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1688); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightIndicesTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16C8); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightScalarsTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16D0); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightShadowsTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16D8); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_AmbientCube() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1698); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SDF() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16A0); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_B() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16C0); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_DC() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16A8); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_G() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16B8); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_R() { return SCHEMA_TYPE(HRenderTextureStrong, 0x16B0); }
    int32_t m_Entity_nEnvCubeMapArrayIndex() { return SCHEMA_TYPE(int32_t, 0x1700); }
    int32_t m_Entity_nHandshake() { return SCHEMA_TYPE(int32_t, 0x16FC); }
    int32_t m_Entity_nLightProbeAtlasX() { return SCHEMA_TYPE(int32_t, 0x1728); }
    int32_t m_Entity_nLightProbeAtlasY() { return SCHEMA_TYPE(int32_t, 0x172C); }
    int32_t m_Entity_nLightProbeAtlasZ() { return SCHEMA_TYPE(int32_t, 0x1730); }
    int32_t m_Entity_nLightProbeSizeX() { return SCHEMA_TYPE(int32_t, 0x171C); }
    int32_t m_Entity_nLightProbeSizeY() { return SCHEMA_TYPE(int32_t, 0x1720); }
    int32_t m_Entity_nLightProbeSizeZ() { return SCHEMA_TYPE(int32_t, 0x1724); }
    int32_t m_Entity_nPriority() { return SCHEMA_TYPE(int32_t, 0x1704); }
    Vector3 m_Entity_vBoxMaxs() { return SCHEMA_TYPE(Vector3, 0x16EC); }
    Vector3 m_Entity_vBoxMins() { return SCHEMA_TYPE(Vector3, 0x16E0); }
    Vector3 m_Entity_vEdgeFadeDists() { return SCHEMA_TYPE(Vector3, 0x1710); }
};

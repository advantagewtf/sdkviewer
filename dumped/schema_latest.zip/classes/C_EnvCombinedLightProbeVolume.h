#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_EnvCombinedLightProbeVolume  {
public:
    uintptr_t baseAddr;

    C_EnvCombinedLightProbeVolume() : baseAddr(0) {}
    C_EnvCombinedLightProbeVolume(uintptr_t base) : baseAddr(base) {}

    float m_Entity_flBrightness() { return SCHEMA_TYPE(float, 0x20); }
    int m_Entity_nHandshake() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nEnvCubeMapArrayIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nPriority() { return SCHEMA_TYPE(int, 0x20); }
    float m_Entity_flEdgeFadeDist() { return SCHEMA_TYPE(float, 0x20); }
    int m_Entity_nLightProbeSizeX() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nLightProbeSizeY() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nLightProbeSizeZ() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nLightProbeAtlasX() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nLightProbeAtlasY() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nLightProbeAtlasZ() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class CPulseCell_BaseLerp__CursorState_t {
public:
    uintptr_t m_EndTime() { return SCHEMA_TYPE(uintptr_t, 0x4); }
    uintptr_t m_StartTime() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CsmFovOverride : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CsmFovOverride(uintptr_t addr) : baseAddr(addr) {}
    C_CsmFovOverride() : baseAddr(0) {}
    uintptr_t m_cameraName() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_flCsmFovOverrideValue() { return SCHEMA_TYPE(uintptr_t, 0x610); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_CsmFovOverride  {
public:
    uintptr_t baseAddr;

    C_CsmFovOverride() : baseAddr(0) {}
    C_CsmFovOverride(uintptr_t base) : baseAddr(base) {}

    float m_flCsmFovOverrideValue() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_CsmFovOverride : public C_BaseEntity {
public:
    uintptr_t m_cameraName() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_flCsmFovOverrideValue() { return SCHEMA_TYPE(uintptr_t, 0x600); }
};

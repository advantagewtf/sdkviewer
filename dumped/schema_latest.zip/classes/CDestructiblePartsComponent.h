#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseModelEntity;
class CDestructiblePartsComponent {
public:
    uintptr_t baseAddr;
    CDestructiblePartsComponent(uintptr_t addr) : baseAddr(addr) {}
    CDestructiblePartsComponent() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    CHandle<CBaseModelEntity> m_hOwner() { return SCHEMA_TYPE(CHandle<CBaseModelEntity>, 0x60); }
    int32_t m_nLastHitDamageLevel() { return SCHEMA_TYPE(int32_t, 0x64); }
    uintptr_t m_vecDamageTakenByHitGroup() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

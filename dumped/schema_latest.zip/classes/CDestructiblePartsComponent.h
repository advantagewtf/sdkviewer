#pragma once
#include "../classes/CNetworkVarChainer.h"
#include "../cstypes/uint16_t.h"
class C_BaseModelEntity;

class CDestructiblePartsComponent  {
public:
    uintptr_t baseAddr;

    CDestructiblePartsComponent() : baseAddr(0) {}
    CDestructiblePartsComponent(uintptr_t base) : baseAddr(base) {}

    uint16_t m_vecDamageTakenByHitGroup() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_nLastHitDamageLevel() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class CPulseCell_LerpCameraSettings {
public:
    uintptr_t m_End() { return SCHEMA_TYPE(uintptr_t, 0xA4); }
    uintptr_t m_Start() { return SCHEMA_TYPE(uintptr_t, 0x94); }
    uintptr_t m_flSeconds() { return SCHEMA_TYPE(uintptr_t, 0x90); }
};

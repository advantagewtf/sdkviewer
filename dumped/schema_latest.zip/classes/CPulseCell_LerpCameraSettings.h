#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_LerpCameraSettings {
public:
    uintptr_t baseAddr;
    CPulseCell_LerpCameraSettings(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_LerpCameraSettings() : baseAddr(0) {}
    uintptr_t m_End() { return SCHEMA_TYPE(uintptr_t, 0xA4); }
    uintptr_t m_Start() { return SCHEMA_TYPE(uintptr_t, 0x94); }
    uintptr_t m_flSeconds() { return SCHEMA_TYPE(uintptr_t, 0x90); }
};

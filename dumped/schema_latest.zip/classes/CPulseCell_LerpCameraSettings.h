#pragma once
#include "../cstypes/PointCameraSettings_t.h"

class CPulseCell_LerpCameraSettings  {
public:
    uintptr_t baseAddr;

    CPulseCell_LerpCameraSettings() : baseAddr(0) {}
    CPulseCell_LerpCameraSettings(uintptr_t base) : baseAddr(base) {}

    float m_flSeconds() { return SCHEMA_TYPE(float, 0x20); }
};

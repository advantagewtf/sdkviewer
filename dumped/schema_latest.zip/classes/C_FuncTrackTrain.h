#pragma once

class C_FuncTrackTrain  {
public:
    uintptr_t baseAddr;

    C_FuncTrackTrain() : baseAddr(0) {}
    C_FuncTrackTrain(uintptr_t base) : baseAddr(base) {}

    int m_nLongAxis() { return SCHEMA_TYPE(int, 0x20); }
    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLineLength() { return SCHEMA_TYPE(float, 0x20); }
};

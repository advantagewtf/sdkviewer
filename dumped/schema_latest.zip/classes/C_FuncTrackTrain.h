#pragma once
#include <cstdint>
class C_FuncTrackTrain : public C_BaseModelEntity {
public:
    uintptr_t m_flLineLength() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t m_flRadius() { return SCHEMA_TYPE(uintptr_t, 0xEB4); }
    uintptr_t m_nLongAxis() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

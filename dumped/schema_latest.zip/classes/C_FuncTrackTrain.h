#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FuncTrackTrain : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncTrackTrain(uintptr_t addr) : baseAddr(addr) {}
    C_FuncTrackTrain() : baseAddr(0) {}
    uintptr_t m_flLineLength() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t m_flRadius() { return SCHEMA_TYPE(uintptr_t, 0xEB4); }
    uintptr_t m_nLongAxis() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

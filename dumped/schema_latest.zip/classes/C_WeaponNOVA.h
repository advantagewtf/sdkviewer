#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponNOVA : public C_CSWeaponBaseShotgun {
public:
    uintptr_t baseAddr;
    C_WeaponNOVA(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponNOVA() : baseAddr(0) {}
};

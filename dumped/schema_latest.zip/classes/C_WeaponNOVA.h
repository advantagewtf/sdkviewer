#pragma once
#include <cstdint>
class C_WeaponNOVA : public C_CSWeaponBaseShotgun {
public:
};

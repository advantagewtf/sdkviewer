#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class CUtlString;
class C_BaseModelEntity;
class Color;
class GameTime_t;
class HRenderTextureStrong;
class QAngle;
class C_BarnLight {
public:
    uintptr_t baseAddr;
    C_BarnLight(uintptr_t addr) : baseAddr(addr) {}
    C_BarnLight() : baseAddr(0) {}
    Color m_Color() { return SCHEMA_TYPE(Color, 0xE90); }
    CUtlString m_LightStyleEvents() { return SCHEMA_TYPE(CUtlString, 0xEE8); }
    CUtlString m_LightStyleString() { return SCHEMA_TYPE(CUtlString, 0xEC0); }
    CHandle<C_BaseModelEntity> m_LightStyleTargets() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0xF00); }
    CUtlString m_QueuedLightStyleStrings() { return SCHEMA_TYPE(CUtlString, 0xED0); }
    uintptr_t m_StyleEvent() { return SCHEMA_TYPE(uintptr_t, 0xF18); }
    uint16_t m_VisClusters() { return SCHEMA_TYPE(uint16_t, 0x1178); }
    bool m_bContactShadow() { return SCHEMA_TYPE(bool, 0xFCC); }
    bool m_bDynamicBounce() { return SCHEMA_TYPE(bool, 0xFD8); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xE88); }
    bool m_bFogMixedShadows() { return SCHEMA_TYPE(bool, 0x1000); }
    bool m_bForceShadowsEnabled() { return SCHEMA_TYPE(bool, 0xFCD); }
    uintptr_t m_bInitialBoneSetup() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    bool m_bPrecomputedFieldsValid() { return SCHEMA_TYPE(bool, 0x1014); }
    float m_fAlternateColorBrightness() { return SCHEMA_TYPE(float, 0xFEC); }
    float m_flBounceScale() { return SCHEMA_TYPE(float, 0xFD4); }
    float m_flBrightness() { return SCHEMA_TYPE(float, 0xE98); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0xE9C); }
    float m_flColorTemperature() { return SCHEMA_TYPE(float, 0xE94); }
    float m_flFadeSizeEnd() { return SCHEMA_TYPE(float, 0x1008); }
    float m_flFadeSizeStart() { return SCHEMA_TYPE(float, 0x1004); }
    float m_flFogScale() { return SCHEMA_TYPE(float, 0xFFC); }
    float m_flFogStrength() { return SCHEMA_TYPE(float, 0xFF4); }
    GameTime_t m_flLightStyleStartTime() { return SCHEMA_TYPE(GameTime_t, 0xEC8); }
    float m_flLuminaireAnisotropy() { return SCHEMA_TYPE(float, 0xEB8); }
    float m_flLuminaireSize() { return SCHEMA_TYPE(float, 0xEB4); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0xFDC); }
    float m_flRange() { return SCHEMA_TYPE(float, 0xFA0); }
    float m_flShadowFadeSizeEnd() { return SCHEMA_TYPE(float, 0x1010); }
    float m_flShadowFadeSizeStart() { return SCHEMA_TYPE(float, 0x100C); }
    float m_flShape() { return SCHEMA_TYPE(float, 0xF80); }
    float m_flSkirt() { return SCHEMA_TYPE(float, 0xF8C); }
    float m_flSkirtNear() { return SCHEMA_TYPE(float, 0xF90); }
    float m_flSoftX() { return SCHEMA_TYPE(float, 0xF84); }
    float m_flSoftY() { return SCHEMA_TYPE(float, 0xF88); }
    HRenderTextureStrong m_hLightCookie() { return SCHEMA_TYPE(HRenderTextureStrong, 0xF78); }
    int32_t m_nBakeSpecularToCubemaps() { return SCHEMA_TYPE(int32_t, 0xFB0); }
    int32_t m_nBakedShadowIndex() { return SCHEMA_TYPE(int32_t, 0xEA4); }
    int32_t m_nBounceLight() { return SCHEMA_TYPE(int32_t, 0xFD0); }
    int32_t m_nCastShadows() { return SCHEMA_TYPE(int32_t, 0xFC0); }
    int32_t m_nColorMode() { return SCHEMA_TYPE(int32_t, 0xE8C); }
    int32_t m_nDirectLight() { return SCHEMA_TYPE(int32_t, 0xEA0); }
    int32_t m_nFog() { return SCHEMA_TYPE(int32_t, 0xFF0); }
    int32_t m_nFogShadows() { return SCHEMA_TYPE(int32_t, 0xFF8); }
    int32_t m_nLightMapUniqueId() { return SCHEMA_TYPE(int32_t, 0xEAC); }
    int32_t m_nLightPathUniqueId() { return SCHEMA_TYPE(int32_t, 0xEA8); }
    int32_t m_nLuminaireShape() { return SCHEMA_TYPE(int32_t, 0xEB0); }
    int32_t m_nPrecomputedSubFrusta() { return SCHEMA_TYPE(int32_t, 0x1054); }
    int32_t m_nShadowMapSize() { return SCHEMA_TYPE(int32_t, 0xFC4); }
    int32_t m_nShadowPriority() { return SCHEMA_TYPE(int32_t, 0xFC8); }
    Vector3 m_vAlternateColor() { return SCHEMA_TYPE(Vector3, 0xFE0); }
    Vector3 m_vBakeSpecularToCubemapsSize() { return SCHEMA_TYPE(Vector3, 0xFB4); }
    Vector3 m_vPrecomputedBoundsMaxs() { return SCHEMA_TYPE(Vector3, 0x1024); }
    Vector3 m_vPrecomputedBoundsMins() { return SCHEMA_TYPE(Vector3, 0x1018); }
    QAngle m_vPrecomputedOBBAngles() { return SCHEMA_TYPE(QAngle, 0x103C); }
    QAngle m_vPrecomputedOBBAngles0() { return SCHEMA_TYPE(QAngle, 0x1064); }
    QAngle m_vPrecomputedOBBAngles1() { return SCHEMA_TYPE(QAngle, 0x1088); }
    QAngle m_vPrecomputedOBBAngles2() { return SCHEMA_TYPE(QAngle, 0x10AC); }
    QAngle m_vPrecomputedOBBAngles3() { return SCHEMA_TYPE(QAngle, 0x10D0); }
    QAngle m_vPrecomputedOBBAngles4() { return SCHEMA_TYPE(QAngle, 0x10F4); }
    QAngle m_vPrecomputedOBBAngles5() { return SCHEMA_TYPE(QAngle, 0x1118); }
    Vector3 m_vPrecomputedOBBExtent() { return SCHEMA_TYPE(Vector3, 0x1048); }
    Vector3 m_vPrecomputedOBBExtent0() { return SCHEMA_TYPE(Vector3, 0x1070); }
    Vector3 m_vPrecomputedOBBExtent1() { return SCHEMA_TYPE(Vector3, 0x1094); }
    Vector3 m_vPrecomputedOBBExtent2() { return SCHEMA_TYPE(Vector3, 0x10B8); }
    Vector3 m_vPrecomputedOBBExtent3() { return SCHEMA_TYPE(Vector3, 0x10DC); }
    Vector3 m_vPrecomputedOBBExtent4() { return SCHEMA_TYPE(Vector3, 0x1100); }
    Vector3 m_vPrecomputedOBBExtent5() { return SCHEMA_TYPE(Vector3, 0x1124); }
    Vector3 m_vPrecomputedOBBOrigin() { return SCHEMA_TYPE(Vector3, 0x1030); }
    Vector3 m_vPrecomputedOBBOrigin0() { return SCHEMA_TYPE(Vector3, 0x1058); }
    Vector3 m_vPrecomputedOBBOrigin1() { return SCHEMA_TYPE(Vector3, 0x107C); }
    Vector3 m_vPrecomputedOBBOrigin2() { return SCHEMA_TYPE(Vector3, 0x10A0); }
    Vector3 m_vPrecomputedOBBOrigin3() { return SCHEMA_TYPE(Vector3, 0x10C4); }
    Vector3 m_vPrecomputedOBBOrigin4() { return SCHEMA_TYPE(Vector3, 0x10E8); }
    Vector3 m_vPrecomputedOBBOrigin5() { return SCHEMA_TYPE(Vector3, 0x110C); }
    Vector3 m_vShear() { return SCHEMA_TYPE(Vector3, 0xFA4); }
    Vector3 m_vSizeParams() { return SCHEMA_TYPE(Vector3, 0xF94); }
};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_BarnLight  {
public:
    uintptr_t baseAddr;

    C_BarnLight() : baseAddr(0) {}
    C_BarnLight(uintptr_t base) : baseAddr(base) {}

    int m_nColorMode() { return SCHEMA_TYPE(int, 0x20); }
    float m_flColorTemperature() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBrightness() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_nDirectLight() { return SCHEMA_TYPE(int, 0x20); }
    int m_nBakedShadowIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLightPathUniqueId() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLightMapUniqueId() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLuminaireShape() { return SCHEMA_TYPE(int, 0x20); }
    float m_flLuminaireSize() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLuminaireAnisotropy() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_StyleEvent() { return SCHEMA_TYPE(uintptr_t, 0x4); }
    float m_flShape() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSoftX() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSoftY() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSkirt() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSkirtNear() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x20); }
    int m_nBakeSpecularToCubemaps() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCastShadows() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowMapSize() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowPriority() { return SCHEMA_TYPE(int, 0x20); }
    int m_nBounceLight() { return SCHEMA_TYPE(int, 0x20); }
    float m_flBounceScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0x20); }
    float m_fAlternateColorBrightness() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFog() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFogStrength() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFogShadows() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFogScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeSizeStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeSizeEnd() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowFadeSizeStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowFadeSizeEnd() { return SCHEMA_TYPE(float, 0x20); }
    int m_nPrecomputedSubFrusta() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_VisClusters() { return SCHEMA_TYPE(uint16_t, 0x10); }
};

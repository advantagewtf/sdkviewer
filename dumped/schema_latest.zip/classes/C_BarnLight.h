#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class C_BarnLight {
public:
    uintptr_t /* Color */ m_Color() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t /* CUtlString */ m_LightStyleEvents() { return SCHEMA_TYPE(uintptr_t, 0xF10); }
    uintptr_t /* CUtlString */ m_LightStyleString() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    CHandle<C_BaseModelEntity> m_LightStyleTargets() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0xF28); }
    uintptr_t /* CUtlString */ m_QueuedLightStyleStrings() { return SCHEMA_TYPE(uintptr_t, 0xEF8); }
    uintptr_t m_StyleEvent() { return SCHEMA_TYPE(uintptr_t, 0xF40); }
    uint16_t m_VisClusters() { return SCHEMA_TYPE(uint16_t, 0x11E0); }
    bool m_bContactShadow() { return SCHEMA_TYPE(bool, 0x1034); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEB0); }
    bool m_bFogMixedShadows() { return SCHEMA_TYPE(bool, 0x1064); }
    bool m_bForceShadowsEnabled() { return SCHEMA_TYPE(bool, 0x1035); }
    uintptr_t m_bInitialBoneSetup() { return SCHEMA_TYPE(uintptr_t, 0x11D8); }
    bool m_bPrecomputedFieldsValid() { return SCHEMA_TYPE(bool, 0x1078); }
    float m_fAlternateColorBrightness() { return SCHEMA_TYPE(float, 0x1050); }
    float m_flBounceScale() { return SCHEMA_TYPE(float, 0x103C); }
    float m_flBrightness() { return SCHEMA_TYPE(float, 0xEC0); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0xEC4); }
    float m_flColorTemperature() { return SCHEMA_TYPE(float, 0xEBC); }
    float m_flFadeSizeEnd() { return SCHEMA_TYPE(float, 0x106C); }
    float m_flFadeSizeStart() { return SCHEMA_TYPE(float, 0x1068); }
    float m_flFogScale() { return SCHEMA_TYPE(float, 0x1060); }
    float m_flFogStrength() { return SCHEMA_TYPE(float, 0x1058); }
    uintptr_t /* GameTime_t */ m_flLightStyleStartTime() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    float m_flLuminaireAnisotropy() { return SCHEMA_TYPE(float, 0xEE0); }
    float m_flLuminaireSize() { return SCHEMA_TYPE(float, 0xEDC); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0x1040); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x1008); }
    float m_flShadowFadeSizeEnd() { return SCHEMA_TYPE(float, 0x1074); }
    float m_flShadowFadeSizeStart() { return SCHEMA_TYPE(float, 0x1070); }
    float m_flShape() { return SCHEMA_TYPE(float, 0xFE8); }
    float m_flSkirt() { return SCHEMA_TYPE(float, 0xFF4); }
    float m_flSkirtNear() { return SCHEMA_TYPE(float, 0xFF8); }
    float m_flSoftX() { return SCHEMA_TYPE(float, 0xFEC); }
    float m_flSoftY() { return SCHEMA_TYPE(float, 0xFF0); }
    uintptr_t /* HRenderTextureStrong */ m_hLightCookie() { return SCHEMA_TYPE(uintptr_t, 0xFE0); }
    int32_t m_nBakeSpecularToCubemaps() { return SCHEMA_TYPE(int32_t, 0x1018); }
    int32_t m_nBakedShadowIndex() { return SCHEMA_TYPE(int32_t, 0xECC); }
    int32_t m_nBounceLight() { return SCHEMA_TYPE(int32_t, 0x1038); }
    int32_t m_nCastShadows() { return SCHEMA_TYPE(int32_t, 0x1028); }
    int32_t m_nColorMode() { return SCHEMA_TYPE(int32_t, 0xEB4); }
    int32_t m_nDirectLight() { return SCHEMA_TYPE(int32_t, 0xEC8); }
    int32_t m_nFog() { return SCHEMA_TYPE(int32_t, 0x1054); }
    int32_t m_nFogShadows() { return SCHEMA_TYPE(int32_t, 0x105C); }
    int32_t m_nLightMapUniqueId() { return SCHEMA_TYPE(int32_t, 0xED4); }
    int32_t m_nLightPathUniqueId() { return SCHEMA_TYPE(int32_t, 0xED0); }
    int32_t m_nLuminaireShape() { return SCHEMA_TYPE(int32_t, 0xED8); }
    int32_t m_nPrecomputedSubFrusta() { return SCHEMA_TYPE(int32_t, 0x10B8); }
    int32_t m_nShadowMapSize() { return SCHEMA_TYPE(int32_t, 0x102C); }
    int32_t m_nShadowPriority() { return SCHEMA_TYPE(int32_t, 0x1030); }
    Vector3 m_vAlternateColor() { return SCHEMA_TYPE(Vector3, 0x1044); }
    Vector3 m_vBakeSpecularToCubemapsSize() { return SCHEMA_TYPE(Vector3, 0x101C); }
    Vector3 m_vPrecomputedBoundsMaxs() { return SCHEMA_TYPE(Vector3, 0x1088); }
    Vector3 m_vPrecomputedBoundsMins() { return SCHEMA_TYPE(Vector3, 0x107C); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles() { return SCHEMA_TYPE(uintptr_t, 0x10A0); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles0() { return SCHEMA_TYPE(uintptr_t, 0x10C8); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles1() { return SCHEMA_TYPE(uintptr_t, 0x10EC); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles2() { return SCHEMA_TYPE(uintptr_t, 0x1110); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles3() { return SCHEMA_TYPE(uintptr_t, 0x1134); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles4() { return SCHEMA_TYPE(uintptr_t, 0x1158); }
    uintptr_t /* QAngle */ m_vPrecomputedOBBAngles5() { return SCHEMA_TYPE(uintptr_t, 0x117C); }
    Vector3 m_vPrecomputedOBBExtent() { return SCHEMA_TYPE(Vector3, 0x10AC); }
    Vector3 m_vPrecomputedOBBExtent0() { return SCHEMA_TYPE(Vector3, 0x10D4); }
    Vector3 m_vPrecomputedOBBExtent1() { return SCHEMA_TYPE(Vector3, 0x10F8); }
    Vector3 m_vPrecomputedOBBExtent2() { return SCHEMA_TYPE(Vector3, 0x111C); }
    Vector3 m_vPrecomputedOBBExtent3() { return SCHEMA_TYPE(Vector3, 0x1140); }
    Vector3 m_vPrecomputedOBBExtent4() { return SCHEMA_TYPE(Vector3, 0x1164); }
    Vector3 m_vPrecomputedOBBExtent5() { return SCHEMA_TYPE(Vector3, 0x1188); }
    Vector3 m_vPrecomputedOBBOrigin() { return SCHEMA_TYPE(Vector3, 0x1094); }
    Vector3 m_vPrecomputedOBBOrigin0() { return SCHEMA_TYPE(Vector3, 0x10BC); }
    Vector3 m_vPrecomputedOBBOrigin1() { return SCHEMA_TYPE(Vector3, 0x10E0); }
    Vector3 m_vPrecomputedOBBOrigin2() { return SCHEMA_TYPE(Vector3, 0x1104); }
    Vector3 m_vPrecomputedOBBOrigin3() { return SCHEMA_TYPE(Vector3, 0x1128); }
    Vector3 m_vPrecomputedOBBOrigin4() { return SCHEMA_TYPE(Vector3, 0x114C); }
    Vector3 m_vPrecomputedOBBOrigin5() { return SCHEMA_TYPE(Vector3, 0x1170); }
    Vector3 m_vShear() { return SCHEMA_TYPE(Vector3, 0x100C); }
    Vector3 m_vSizeParams() { return SCHEMA_TYPE(Vector3, 0xFFC); }
};

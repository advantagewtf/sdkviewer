#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CUtlString;
class Color;
class GameTime_t;
class HRenderTextureStrong;
class QAngle;
class CLightComponent : public CEntityComponent {
public:
    uintptr_t baseAddr;
    CLightComponent(uintptr_t addr) : baseAddr(addr) {}
    CLightComponent() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    Color m_Color() { return SCHEMA_TYPE(Color, 0x6D); }
    CUtlString m_Pattern() { return SCHEMA_TYPE(CUtlString, 0xD0); }
    Color m_SecondaryColor() { return SCHEMA_TYPE(Color, 0x71); }
    Color m_SkyAmbientBounce() { return SCHEMA_TYPE(Color, 0x18C); }
    Color m_SkyColor() { return SCHEMA_TYPE(Color, 0x184); }
    bool m_bAllowSSTGeneration() { return SCHEMA_TYPE(bool, 0x119); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x134); }
    bool m_bFlicker() { return SCHEMA_TYPE(bool, 0x135); }
    bool m_bMixedShadows() { return SCHEMA_TYPE(bool, 0x191); }
    bool m_bPrecomputedFieldsValid() { return SCHEMA_TYPE(bool, 0x136); }
    bool m_bRenderDiffuse() { return SCHEMA_TYPE(bool, 0xB8); }
    bool m_bRenderToCubemaps() { return SCHEMA_TYPE(bool, 0x118); }
    bool m_bRenderTransmissive() { return SCHEMA_TYPE(bool, 0xC0); }
    bool m_bUseSecondaryColor() { return SCHEMA_TYPE(bool, 0x190); }
    bool m_bUsesBakedShadowing() { return SCHEMA_TYPE(bool, 0x104); }
    float m_flAttenuation0() { return SCHEMA_TYPE(float, 0x8C); }
    float m_flAttenuation1() { return SCHEMA_TYPE(float, 0x90); }
    float m_flAttenuation2() { return SCHEMA_TYPE(float, 0x94); }
    float m_flBrightness() { return SCHEMA_TYPE(float, 0x78); }
    float m_flBrightnessMult() { return SCHEMA_TYPE(float, 0x80); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0x7C); }
    float m_flCapsuleLength() { return SCHEMA_TYPE(float, 0x198); }
    float m_flFadeMaxDist() { return SCHEMA_TYPE(float, 0x128); }
    float m_flFadeMinDist() { return SCHEMA_TYPE(float, 0x124); }
    float m_flFalloff() { return SCHEMA_TYPE(float, 0x88); }
    float m_flFogContributionStength() { return SCHEMA_TYPE(float, 0x17C); }
    GameTime_t m_flLightStyleStartTime() { return SCHEMA_TYPE(GameTime_t, 0x194); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0x19C); }
    float m_flNearClipPlane() { return SCHEMA_TYPE(float, 0x180); }
    float m_flOrthoLightHeight() { return SCHEMA_TYPE(float, 0xC8); }
    float m_flOrthoLightWidth() { return SCHEMA_TYPE(float, 0xC4); }
    float m_flPhi() { return SCHEMA_TYPE(float, 0x9C); }
    float m_flPrecomputedMaxRange() { return SCHEMA_TYPE(float, 0x174); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x84); }
    float m_flShadowCascadeCrossFade() { return SCHEMA_TYPE(float, 0xDC); }
    float m_flShadowCascadeDistance0() { return SCHEMA_TYPE(float, 0xE4); }
    float m_flShadowCascadeDistance1() { return SCHEMA_TYPE(float, 0xE8); }
    float m_flShadowCascadeDistance2() { return SCHEMA_TYPE(float, 0xEC); }
    float m_flShadowCascadeDistance3() { return SCHEMA_TYPE(float, 0xF0); }
    float m_flShadowCascadeDistanceFade() { return SCHEMA_TYPE(float, 0xE0); }
    float m_flShadowFadeMaxDist() { return SCHEMA_TYPE(float, 0x130); }
    float m_flShadowFadeMinDist() { return SCHEMA_TYPE(float, 0x12C); }
    float m_flSkyIntensity() { return SCHEMA_TYPE(float, 0x188); }
    float m_flTheta() { return SCHEMA_TYPE(float, 0x98); }
    HRenderTextureStrong m_hLightCookie() { return SCHEMA_TYPE(HRenderTextureStrong, 0xA0); }
    int32_t m_nBakedShadowIndex() { return SCHEMA_TYPE(int32_t, 0x10C); }
    int32_t m_nCascadeRenderStaticObjects() { return SCHEMA_TYPE(int32_t, 0xD8); }
    int32_t m_nCascades() { return SCHEMA_TYPE(int32_t, 0xA8); }
    int32_t m_nCastShadows() { return SCHEMA_TYPE(int32_t, 0xAC); }
    int32_t m_nDirectLight() { return SCHEMA_TYPE(int32_t, 0x11C); }
    int32_t m_nFogLightingMode() { return SCHEMA_TYPE(int32_t, 0x178); }
    int32_t m_nIndirectLight() { return SCHEMA_TYPE(int32_t, 0x120); }
    int32_t m_nLightMapUniqueId() { return SCHEMA_TYPE(int32_t, 0x114); }
    int32_t m_nLightPathUniqueId() { return SCHEMA_TYPE(int32_t, 0x110); }
    int32_t m_nRenderSpecular() { return SCHEMA_TYPE(int32_t, 0xBC); }
    int32_t m_nShadowCascadeResolution0() { return SCHEMA_TYPE(int32_t, 0xF4); }
    int32_t m_nShadowCascadeResolution1() { return SCHEMA_TYPE(int32_t, 0xF8); }
    int32_t m_nShadowCascadeResolution2() { return SCHEMA_TYPE(int32_t, 0xFC); }
    int32_t m_nShadowCascadeResolution3() { return SCHEMA_TYPE(int32_t, 0x100); }
    int32_t m_nShadowHeight() { return SCHEMA_TYPE(int32_t, 0xB4); }
    int32_t m_nShadowPriority() { return SCHEMA_TYPE(int32_t, 0x108); }
    int32_t m_nShadowWidth() { return SCHEMA_TYPE(int32_t, 0xB0); }
    int32_t m_nStyle() { return SCHEMA_TYPE(int32_t, 0xCC); }
    Vector3 m_vPrecomputedBoundsMaxs() { return SCHEMA_TYPE(Vector3, 0x144); }
    Vector3 m_vPrecomputedBoundsMins() { return SCHEMA_TYPE(Vector3, 0x138); }
    QAngle m_vPrecomputedOBBAngles() { return SCHEMA_TYPE(QAngle, 0x15C); }
    Vector3 m_vPrecomputedOBBExtent() { return SCHEMA_TYPE(Vector3, 0x168); }
    Vector3 m_vPrecomputedOBBOrigin() { return SCHEMA_TYPE(Vector3, 0x150); }
};

#pragma once
#include "../classes/CNetworkVarChainer.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CLightComponent  {
public:
    uintptr_t baseAddr;

    CLightComponent() : baseAddr(0) {}
    CLightComponent(uintptr_t base) : baseAddr(base) {}

    float m_flBrightness() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBrightnessMult() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFalloff() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAttenuation0() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAttenuation1() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAttenuation2() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTheta() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPhi() { return SCHEMA_TYPE(float, 0x20); }
    int m_nCascades() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCastShadows() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowWidth() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowHeight() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRenderSpecular() { return SCHEMA_TYPE(int, 0x20); }
    float m_flOrthoLightWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOrthoLightHeight() { return SCHEMA_TYPE(float, 0x20); }
    int m_nStyle() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCascadeRenderStaticObjects() { return SCHEMA_TYPE(int, 0x20); }
    float m_flShadowCascadeCrossFade() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowCascadeDistanceFade() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowCascadeDistance0() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowCascadeDistance1() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowCascadeDistance2() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowCascadeDistance3() { return SCHEMA_TYPE(float, 0x20); }
    int m_nShadowCascadeResolution0() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowCascadeResolution1() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowCascadeResolution2() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowCascadeResolution3() { return SCHEMA_TYPE(int, 0x20); }
    int m_nShadowPriority() { return SCHEMA_TYPE(int, 0x20); }
    int m_nBakedShadowIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLightPathUniqueId() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLightMapUniqueId() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDirectLight() { return SCHEMA_TYPE(int, 0x20); }
    int m_nIndirectLight() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFadeMinDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeMaxDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowFadeMinDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowFadeMaxDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPrecomputedMaxRange() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFogLightingMode() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFogContributionStength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNearClipPlane() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSkyIntensity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCapsuleLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0x20); }
};

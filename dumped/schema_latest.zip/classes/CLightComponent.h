#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class CUtlString;
class Color;
class GameTime_t;
class HRenderTextureStrong;
class QAngle;
class CLightComponent : public CEntityComponent {
public:
    uintptr_t baseAddr;
    CLightComponent(uintptr_t addr) : baseAddr(addr) {}
    CLightComponent() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x38); }
    Color m_Color() { return SCHEMA_TYPE(Color, 0x75); }
    CUtlString m_Pattern() { return SCHEMA_TYPE(CUtlString, 0xD8); }
    Color m_SecondaryColor() { return SCHEMA_TYPE(Color, 0x79); }
    Color m_SkyAmbientBounce() { return SCHEMA_TYPE(Color, 0x198); }
    Color m_SkyColor() { return SCHEMA_TYPE(Color, 0x190); }
    bool m_bAllowSSTGeneration() { return SCHEMA_TYPE(bool, 0x121); }
    bool m_bDynamicBounce() { return SCHEMA_TYPE(bool, 0x12C); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x140); }
    bool m_bFlicker() { return SCHEMA_TYPE(bool, 0x141); }
    bool m_bMixedShadows() { return SCHEMA_TYPE(bool, 0x19D); }
    bool m_bPrecomputedFieldsValid() { return SCHEMA_TYPE(bool, 0x142); }
    bool m_bRenderDiffuse() { return SCHEMA_TYPE(bool, 0xC0); }
    bool m_bRenderToCubemaps() { return SCHEMA_TYPE(bool, 0x120); }
    bool m_bRenderTransmissive() { return SCHEMA_TYPE(bool, 0xC8); }
    bool m_bUseSecondaryColor() { return SCHEMA_TYPE(bool, 0x19C); }
    bool m_bUsesBakedShadowing() { return SCHEMA_TYPE(bool, 0x10C); }
    float m_flAttenuation0() { return SCHEMA_TYPE(float, 0x94); }
    float m_flAttenuation1() { return SCHEMA_TYPE(float, 0x98); }
    float m_flAttenuation2() { return SCHEMA_TYPE(float, 0x9C); }
    float m_flBrightness() { return SCHEMA_TYPE(float, 0x80); }
    float m_flBrightnessMult() { return SCHEMA_TYPE(float, 0x88); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0x84); }
    float m_flCapsuleLength() { return SCHEMA_TYPE(float, 0x1A4); }
    float m_flFadeMaxDist() { return SCHEMA_TYPE(float, 0x134); }
    float m_flFadeMinDist() { return SCHEMA_TYPE(float, 0x130); }
    float m_flFalloff() { return SCHEMA_TYPE(float, 0x90); }
    float m_flFogContributionStength() { return SCHEMA_TYPE(float, 0x188); }
    GameTime_t m_flLightStyleStartTime() { return SCHEMA_TYPE(GameTime_t, 0x1A0); }
    float m_flMinRoughness() { return SCHEMA_TYPE(float, 0x1A8); }
    float m_flNearClipPlane() { return SCHEMA_TYPE(float, 0x18C); }
    float m_flOrthoLightHeight() { return SCHEMA_TYPE(float, 0xD0); }
    float m_flOrthoLightWidth() { return SCHEMA_TYPE(float, 0xCC); }
    float m_flPhi() { return SCHEMA_TYPE(float, 0xA4); }
    float m_flPrecomputedMaxRange() { return SCHEMA_TYPE(float, 0x180); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x8C); }
    float m_flShadowCascadeCrossFade() { return SCHEMA_TYPE(float, 0xE4); }
    float m_flShadowCascadeDistance0() { return SCHEMA_TYPE(float, 0xEC); }
    float m_flShadowCascadeDistance1() { return SCHEMA_TYPE(float, 0xF0); }
    float m_flShadowCascadeDistance2() { return SCHEMA_TYPE(float, 0xF4); }
    float m_flShadowCascadeDistance3() { return SCHEMA_TYPE(float, 0xF8); }
    float m_flShadowCascadeDistanceFade() { return SCHEMA_TYPE(float, 0xE8); }
    float m_flShadowFadeMaxDist() { return SCHEMA_TYPE(float, 0x13C); }
    float m_flShadowFadeMinDist() { return SCHEMA_TYPE(float, 0x138); }
    float m_flSkyIntensity() { return SCHEMA_TYPE(float, 0x194); }
    float m_flTheta() { return SCHEMA_TYPE(float, 0xA0); }
    HRenderTextureStrong m_hLightCookie() { return SCHEMA_TYPE(HRenderTextureStrong, 0xA8); }
    int32_t m_nBakedShadowIndex() { return SCHEMA_TYPE(int32_t, 0x114); }
    int32_t m_nCascadeRenderStaticObjects() { return SCHEMA_TYPE(int32_t, 0xE0); }
    int32_t m_nCascades() { return SCHEMA_TYPE(int32_t, 0xB0); }
    int32_t m_nCastShadows() { return SCHEMA_TYPE(int32_t, 0xB4); }
    int32_t m_nDirectLight() { return SCHEMA_TYPE(int32_t, 0x124); }
    int32_t m_nFogLightingMode() { return SCHEMA_TYPE(int32_t, 0x184); }
    int32_t m_nIndirectLight() { return SCHEMA_TYPE(int32_t, 0x128); }
    int32_t m_nLightMapUniqueId() { return SCHEMA_TYPE(int32_t, 0x11C); }
    int32_t m_nLightPathUniqueId() { return SCHEMA_TYPE(int32_t, 0x118); }
    int32_t m_nRenderSpecular() { return SCHEMA_TYPE(int32_t, 0xC4); }
    int32_t m_nShadowCascadeResolution0() { return SCHEMA_TYPE(int32_t, 0xFC); }
    int32_t m_nShadowCascadeResolution1() { return SCHEMA_TYPE(int32_t, 0x100); }
    int32_t m_nShadowCascadeResolution2() { return SCHEMA_TYPE(int32_t, 0x104); }
    int32_t m_nShadowCascadeResolution3() { return SCHEMA_TYPE(int32_t, 0x108); }
    int32_t m_nShadowHeight() { return SCHEMA_TYPE(int32_t, 0xBC); }
    int32_t m_nShadowPriority() { return SCHEMA_TYPE(int32_t, 0x110); }
    int32_t m_nShadowWidth() { return SCHEMA_TYPE(int32_t, 0xB8); }
    int32_t m_nStyle() { return SCHEMA_TYPE(int32_t, 0xD4); }
    Vector3 m_vPrecomputedBoundsMaxs() { return SCHEMA_TYPE(Vector3, 0x150); }
    Vector3 m_vPrecomputedBoundsMins() { return SCHEMA_TYPE(Vector3, 0x144); }
    QAngle m_vPrecomputedOBBAngles() { return SCHEMA_TYPE(QAngle, 0x168); }
    Vector3 m_vPrecomputedOBBExtent() { return SCHEMA_TYPE(Vector3, 0x174); }
    Vector3 m_vPrecomputedOBBOrigin() { return SCHEMA_TYPE(Vector3, 0x15C); }
};

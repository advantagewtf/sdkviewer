#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PortraitWorldCallbackHandler : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PortraitWorldCallbackHandler(uintptr_t addr) : baseAddr(addr) {}
    C_PortraitWorldCallbackHandler() : baseAddr(0) {}
};

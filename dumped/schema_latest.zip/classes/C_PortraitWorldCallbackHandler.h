#pragma once
#include <cstdint>
class C_PortraitWorldCallbackHandler : public C_BaseEntity {
public:
};

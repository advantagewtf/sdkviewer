#pragma once
#include "../memory.h"

class CPulseCell_PickBestOutflowSelector {
public:
 uintptr_t baseAddr;
 CPulseCell_PickBestOutflowSelector() : baseAddr(0){}
 CPulseCell_PickBestOutflowSelector(uintptr_t b):baseAddr(b){}
 uintptr_t m_nCheckType(){return SCHEMA_TYPE(uintptr_t,0x48);}
 uintptr_t m_OutflowList(){return SCHEMA_TYPE(uintptr_t,0x50);}
};

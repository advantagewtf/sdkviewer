#pragma once
#include <cstdint>
class CPulseCell_PickBestOutflowSelector {
public:
    uintptr_t m_OutflowList() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nCheckType() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include "../cstypes/PulseBestOutflowRules_t.h"
#include "../cstypes/PulseSelectorOutflowList_t.h"

class CPulseCell_PickBestOutflowSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_PickBestOutflowSelector() : baseAddr(0) {}
    CPulseCell_PickBestOutflowSelector(uintptr_t base) : baseAddr(base) {}

};

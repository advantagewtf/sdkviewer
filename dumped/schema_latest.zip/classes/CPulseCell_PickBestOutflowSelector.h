#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_PickBestOutflowSelector {
public:
    uintptr_t baseAddr;
    CPulseCell_PickBestOutflowSelector(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_PickBestOutflowSelector() : baseAddr(0) {}
    uintptr_t m_OutflowList() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nCheckType() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

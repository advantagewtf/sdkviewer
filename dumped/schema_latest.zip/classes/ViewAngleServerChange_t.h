#pragma once
#include <cstdint>
class ViewAngleServerChange_t {
public:
    uint32_t nIndex() { return SCHEMA_TYPE(uint32_t, 0x40); }
    uintptr_t /* FixAngleSet_t */ nType() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t /* QAngle */ qAngle() { return SCHEMA_TYPE(uintptr_t, 0x34); }
};

#pragma once
#include <cstdint>
class CPulseCell_LimitCount {
public:
    uintptr_t m_nLimitCount() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once

class CPulseCell_LimitCount  {
public:
    uintptr_t baseAddr;

    CPulseCell_LimitCount() : baseAddr(0) {}
    CPulseCell_LimitCount(uintptr_t base) : baseAddr(base) {}

    int m_nLimitCount() { return SCHEMA_TYPE(int, 0x20); }
};

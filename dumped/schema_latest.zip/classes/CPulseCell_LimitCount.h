#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_LimitCount {
public:
    uintptr_t baseAddr;
    CPulseCell_LimitCount(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_LimitCount() : baseAddr(0) {}
    uintptr_t m_nLimitCount() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

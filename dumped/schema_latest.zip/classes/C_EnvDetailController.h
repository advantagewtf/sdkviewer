#pragma once
#include <cstdint>
class C_EnvDetailController : public C_BaseEntity {
public:
    uintptr_t /* float32 */ m_flFadeEndDist() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t /* float32 */ m_flFadeStartDist() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

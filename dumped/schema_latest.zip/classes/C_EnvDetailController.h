#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class C_EnvDetailController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvDetailController(uintptr_t addr) : baseAddr(addr) {}
    C_EnvDetailController() : baseAddr(0) {}
    float32 m_flFadeEndDist() { return SCHEMA_TYPE(float32, 0x60C); }
    float32 m_flFadeStartDist() { return SCHEMA_TYPE(float32, 0x608); }
};

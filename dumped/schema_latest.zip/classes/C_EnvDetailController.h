#pragma once

class C_EnvDetailController  {
public:
    uintptr_t baseAddr;

    C_EnvDetailController() : baseAddr(0) {}
    C_EnvDetailController(uintptr_t base) : baseAddr(base) {}

    float m_flFadeStartDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeEndDist() { return SCHEMA_TYPE(float, 0x20); }
};

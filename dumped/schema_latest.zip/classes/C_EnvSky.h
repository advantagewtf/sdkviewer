#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class HMaterialStrong;
class C_EnvSky : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_EnvSky(uintptr_t addr) : baseAddr(addr) {}
    C_EnvSky() : baseAddr(0) {}
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEE4); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0xEC0); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0xECC); }
    float m_flFogMaxEnd() { return SCHEMA_TYPE(float, 0xEE0); }
    float m_flFogMaxStart() { return SCHEMA_TYPE(float, 0xEDC); }
    float m_flFogMinEnd() { return SCHEMA_TYPE(float, 0xED8); }
    float m_flFogMinStart() { return SCHEMA_TYPE(float, 0xED4); }
    HMaterialStrong m_hSkyMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0xEB0); }
    HMaterialStrong m_hSkyMaterialLightingOnly() { return SCHEMA_TYPE(HMaterialStrong, 0xEB8); }
    int32_t m_nFogType() { return SCHEMA_TYPE(int32_t, 0xED0); }
    Color m_vTintColor() { return SCHEMA_TYPE(Color, 0xEC1); }
    Color m_vTintColorLightingOnly() { return SCHEMA_TYPE(Color, 0xEC5); }
};

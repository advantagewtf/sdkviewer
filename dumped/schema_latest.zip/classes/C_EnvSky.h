#pragma once
#include "../cstypes/uintptr_t.h"

class C_EnvSky  {
public:
    uintptr_t baseAddr;

    C_EnvSky() : baseAddr(0) {}
    C_EnvSky(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hSkyMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    uintptr_t m_hSkyMaterialLightingOnly() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFogType() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFogMinStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMinEnd() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxEnd() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_EnvSky : public C_BaseModelEntity {
public:
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEE4); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0xEC0); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0xECC); }
    float m_flFogMaxEnd() { return SCHEMA_TYPE(float, 0xEE0); }
    float m_flFogMaxStart() { return SCHEMA_TYPE(float, 0xEDC); }
    float m_flFogMinEnd() { return SCHEMA_TYPE(float, 0xED8); }
    float m_flFogMinStart() { return SCHEMA_TYPE(float, 0xED4); }
    uintptr_t /* HMaterialStrong */ m_hSkyMaterial() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
    uintptr_t /* HMaterialStrong */ m_hSkyMaterialLightingOnly() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    int32_t m_nFogType() { return SCHEMA_TYPE(int32_t, 0xED0); }
    uintptr_t /* Color */ m_vTintColor() { return SCHEMA_TYPE(uintptr_t, 0xEC1); }
    uintptr_t /* Color */ m_vTintColorLightingOnly() { return SCHEMA_TYPE(uintptr_t, 0xEC5); }
};

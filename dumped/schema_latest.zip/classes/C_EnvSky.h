#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class HMaterialStrong;
class C_EnvSky : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_EnvSky(uintptr_t addr) : baseAddr(addr) {}
    C_EnvSky() : baseAddr(0) {}
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEBC); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0xE98); }
    float m_flBrightnessScale() { return SCHEMA_TYPE(float, 0xEA4); }
    float m_flFogMaxEnd() { return SCHEMA_TYPE(float, 0xEB8); }
    float m_flFogMaxStart() { return SCHEMA_TYPE(float, 0xEB4); }
    float m_flFogMinEnd() { return SCHEMA_TYPE(float, 0xEB0); }
    float m_flFogMinStart() { return SCHEMA_TYPE(float, 0xEAC); }
    HMaterialStrong m_hSkyMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0xE88); }
    HMaterialStrong m_hSkyMaterialLightingOnly() { return SCHEMA_TYPE(HMaterialStrong, 0xE90); }
    int32_t m_nFogType() { return SCHEMA_TYPE(int32_t, 0xEA8); }
    Color m_vTintColor() { return SCHEMA_TYPE(Color, 0xE99); }
    Color m_vTintColorLightingOnly() { return SCHEMA_TYPE(Color, 0xE9D); }
};

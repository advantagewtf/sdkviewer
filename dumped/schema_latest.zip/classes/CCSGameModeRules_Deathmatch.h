#pragma once
#include <cstdint>
class CCSGameModeRules_Deathmatch {
public:
    uintptr_t /* GameTime_t */ m_flDMBonusStartTime() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    float m_flDMBonusTimeLength() { return SCHEMA_TYPE(float, 0x34); }
    uintptr_t /* CUtlString */ m_sDMBonusWeapon() { return SCHEMA_TYPE(uintptr_t, 0x38); }
};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"

class CCSGameModeRules_Deathmatch  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_Deathmatch() : baseAddr(0) {}
    CCSGameModeRules_Deathmatch(uintptr_t base) : baseAddr(base) {}

    float m_flDMBonusTimeLength() { return SCHEMA_TYPE(float, 0x20); }
};

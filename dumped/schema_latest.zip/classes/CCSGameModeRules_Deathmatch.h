#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlString;
class GameTime_t;
class CCSGameModeRules_Deathmatch {
public:
    uintptr_t baseAddr;
    CCSGameModeRules_Deathmatch(uintptr_t addr) : baseAddr(addr) {}
    CCSGameModeRules_Deathmatch() : baseAddr(0) {}
    GameTime_t m_flDMBonusStartTime() { return SCHEMA_TYPE(GameTime_t, 0x30); }
    float m_flDMBonusTimeLength() { return SCHEMA_TYPE(float, 0x34); }
    CUtlString m_sDMBonusWeapon() { return SCHEMA_TYPE(CUtlString, 0x38); }
};

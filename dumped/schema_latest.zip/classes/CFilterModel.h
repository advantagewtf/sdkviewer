#pragma once
#include <cstdint>
class CFilterModel : public CBaseFilter {
public:
    uintptr_t m_iFilterModel() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

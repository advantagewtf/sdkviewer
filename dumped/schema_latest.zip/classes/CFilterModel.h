#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterModel : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterModel(uintptr_t addr) : baseAddr(addr) {}
    CFilterModel() : baseAddr(0) {}
    uintptr_t m_iFilterModel() { return SCHEMA_TYPE(uintptr_t, 0x640); }
};

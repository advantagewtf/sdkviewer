#pragma once
#include "../cstypes/uintptr_t.h"

class CFilterModel  {
public:
    uintptr_t baseAddr;

    CFilterModel() : baseAddr(0) {}
    CFilterModel(uintptr_t base) : baseAddr(base) {}

};

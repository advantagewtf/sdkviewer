#pragma once
#include <cstdint>
class CPulseCell_LerpCameraSettings__CursorState_t {
public:
    uintptr_t m_OverlaidEnd() { return SCHEMA_TYPE(uintptr_t, 0x1C); }
    uintptr_t m_OverlaidStart() { return SCHEMA_TYPE(uintptr_t, 0xC); }
    uintptr_t m_hCamera() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

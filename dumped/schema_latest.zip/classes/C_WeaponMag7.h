#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponMag7 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponMag7(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponMag7() : baseAddr(0) {}
};

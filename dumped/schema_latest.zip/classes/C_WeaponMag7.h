#pragma once
#include <cstdint>
class C_WeaponMag7 : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
class OutflowWithRequirements_t {
public:
    uintptr_t m_Connection() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_DestinationFlowNodeID() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_RequirementNodeIDs() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nCursorStateBlockIndex() { return SCHEMA_TYPE(uintptr_t, 0x68); }
};

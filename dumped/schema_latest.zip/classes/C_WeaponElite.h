#pragma once
#include <cstdint>
class C_WeaponElite : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponElite : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponElite(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponElite() : baseAddr(0) {}
};

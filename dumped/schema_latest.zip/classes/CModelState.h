#pragma once
#include "../cstypes/uintptr_t.h"

class CModelState  {
public:
    uintptr_t baseAddr;

    CModelState() : baseAddr(0) {}
    CModelState(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_MeshGroupMask() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_nBodyGroupChoices() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_nIdealMotionType() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_nForceLOD() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_nClothUpdateFlags() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

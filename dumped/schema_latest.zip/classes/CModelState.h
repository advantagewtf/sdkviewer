#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class HModelStrong;
class MeshGroupMask_t;
class int8;
class CModelState {
public:
    uintptr_t baseAddr;
    CModelState(uintptr_t addr) : baseAddr(addr) {}
    CModelState() : baseAddr(0) {}
    MeshGroupMask_t m_MeshGroupMask() { return SCHEMA_TYPE(MeshGroupMask_t, 0x250); }
    uintptr_t m_ModelName() { return SCHEMA_TYPE(uintptr_t, 0xD8); }
    bool m_bClientClothCreationSuppressed() { return SCHEMA_TYPE(bool, 0x1A9); }
    HModelStrong m_hModel() { return SCHEMA_TYPE(HModelStrong, 0xD0); }
    int32_t m_nBodyGroupChoices() { return SCHEMA_TYPE(int32_t, 0x2A0); }
    uintptr_t m_nClothUpdateFlags() { return SCHEMA_TYPE(uintptr_t, 0x2EC); }
    uintptr_t m_nForceLOD() { return SCHEMA_TYPE(uintptr_t, 0x2EB); }
    int8 m_nIdealMotionType() { return SCHEMA_TYPE(int8, 0x2EA); }
};

#pragma once
#include <cstdint>
class CModelState {
public:
    uintptr_t /* MeshGroupMask_t */ m_MeshGroupMask() { return SCHEMA_TYPE(uintptr_t, 0x250); }
    uintptr_t m_ModelName() { return SCHEMA_TYPE(uintptr_t, 0xD8); }
    bool m_bClientClothCreationSuppressed() { return SCHEMA_TYPE(bool, 0x1A9); }
    uintptr_t /* HModelStrong */ m_hModel() { return SCHEMA_TYPE(uintptr_t, 0xD0); }
    int32_t m_nBodyGroupChoices() { return SCHEMA_TYPE(int32_t, 0x2A0); }
    uintptr_t m_nClothUpdateFlags() { return SCHEMA_TYPE(uintptr_t, 0x2EC); }
    uintptr_t m_nForceLOD() { return SCHEMA_TYPE(uintptr_t, 0x2EB); }
    uintptr_t /* int8 */ m_nIdealMotionType() { return SCHEMA_TYPE(uintptr_t, 0x2EA); }
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class CCollisionProperty {
public:
    uint8_t m_CollisionGroup() { return SCHEMA_TYPE(uint8_t, 0x5E); }
    uintptr_t /* VPhysicsCollisionAttribute_t */ m_collisionAttribute() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_flBoundingRadius() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    float m_flCapsuleRadius() { return SCHEMA_TYPE(float, 0xAC); }
    uint8_t m_nEnablePhysics() { return SCHEMA_TYPE(uint8_t, 0x5F); }
    uintptr_t /* SolidType_t */ m_nSolidType() { return SCHEMA_TYPE(uintptr_t, 0x5B); }
    uintptr_t /* SurroundingBoundsType_t */ m_nSurroundType() { return SCHEMA_TYPE(uintptr_t, 0x5D); }
    uint8_t m_triggerBloat() { return SCHEMA_TYPE(uint8_t, 0x5C); }
    uint8_t m_usSolidFlags() { return SCHEMA_TYPE(uint8_t, 0x5A); }
    Vector3 m_vCapsuleCenter1() { return SCHEMA_TYPE(Vector3, 0x94); }
    Vector3 m_vCapsuleCenter2() { return SCHEMA_TYPE(Vector3, 0xA0); }
    Vector3 m_vecMaxs() { return SCHEMA_TYPE(Vector3, 0x4C); }
    Vector3 m_vecMins() { return SCHEMA_TYPE(Vector3, 0x40); }
    Vector3 m_vecSpecifiedSurroundingMaxs() { return SCHEMA_TYPE(Vector3, 0x70); }
    Vector3 m_vecSpecifiedSurroundingMins() { return SCHEMA_TYPE(Vector3, 0x64); }
    uintptr_t m_vecSurroundingMaxs() { return SCHEMA_TYPE(uintptr_t, 0x7C); }
    uintptr_t m_vecSurroundingMins() { return SCHEMA_TYPE(uintptr_t, 0x88); }
};

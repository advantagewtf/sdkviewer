#pragma once
#include "../cstypes/SolidType_t.h"
#include "../cstypes/SurroundingBoundsType_t.h"
#include "../cstypes/VPhysicsCollisionAttribute_t.h"
#include "../cstypes/uint8_t.h"
#include "../types/Vector3.h"

class CCollisionProperty  {
public:
    uintptr_t baseAddr;

    CCollisionProperty() : baseAddr(0) {}
    CCollisionProperty(uintptr_t base) : baseAddr(base) {}

    uint8_t m_usSolidFlags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_triggerBloat() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_CollisionGroup() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nEnablePhysics() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_flBoundingRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCapsuleRadius() { return SCHEMA_TYPE(float, 0x20); }
};

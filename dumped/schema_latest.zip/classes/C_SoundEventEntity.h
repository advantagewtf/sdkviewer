#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundEventEntity : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventEntity() : baseAddr(0) {}
    uintptr_t m_bClientSideOnly() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bSaveRestore() { return SCHEMA_TYPE(uintptr_t, 0x60B); }
    uintptr_t m_bSavedIsPlaying() { return SCHEMA_TYPE(uintptr_t, 0x60C); }
    uintptr_t m_bStartOnSpawn() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_bStopOnNew() { return SCHEMA_TYPE(uintptr_t, 0x60A); }
    uintptr_t m_bToLocalPlayer() { return SCHEMA_TYPE(uintptr_t, 0x609); }
    uintptr_t m_flClientCullRadius() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    uintptr_t m_flSavedElapsedTime() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_hSource() { return SCHEMA_TYPE(uintptr_t, 0x6AC); }
    uintptr_t m_iszAttachmentName() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_iszSoundName() { return SCHEMA_TYPE(uintptr_t, 0x690); }
    uintptr_t m_iszSourceEntityName() { return SCHEMA_TYPE(uintptr_t, 0x618); }
    uintptr_t m_nEntityIndexSelection() { return SCHEMA_TYPE(uintptr_t, 0x6B0); }
    uintptr_t m_onGUIDChanged() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    uintptr_t m_onSoundFinished() { return SCHEMA_TYPE(uintptr_t, 0x648); }
};

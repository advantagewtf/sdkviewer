#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/uintptr_t.h"

class C_SoundEventEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventEntity() : baseAddr(0) {}
    C_SoundEventEntity(uintptr_t base) : baseAddr(base) {}

    float m_flSavedElapsedTime() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_onGUIDChanged() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    float m_flClientCullRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_nEntityIndexSelection() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_bClientSideOnly() { return SCHEMA_TYPE(uintptr_t, 0x1); }
};

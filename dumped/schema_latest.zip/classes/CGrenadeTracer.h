#pragma once
#include "../cstypes/GrenadeType_t.h"

class CGrenadeTracer  {
public:
    uintptr_t baseAddr;

    CGrenadeTracer() : baseAddr(0) {}
    CGrenadeTracer(uintptr_t base) : baseAddr(base) {}

    float m_flTracerDuration() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CGrenadeTracer {
public:
    uintptr_t baseAddr;
    CGrenadeTracer(uintptr_t addr) : baseAddr(addr) {}
    CGrenadeTracer() : baseAddr(0) {}
    uintptr_t m_flTracerDuration() { return SCHEMA_TYPE(uintptr_t, 0xEA0); }
    uintptr_t m_nType() { return SCHEMA_TYPE(uintptr_t, 0xEA4); }
};

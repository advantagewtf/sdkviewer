#pragma once
#include <cstdint>
class CGrenadeTracer {
public:
    uintptr_t m_flTracerDuration() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    uintptr_t m_nType() { return SCHEMA_TYPE(uintptr_t, 0xECC); }
};

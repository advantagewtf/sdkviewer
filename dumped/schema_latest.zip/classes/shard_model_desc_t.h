#pragma once
#include <cstdint>
class shard_model_desc_t {
public:
    uintptr_t /* CUtlStringToken */ m_SurfacePropStringToken() { return SCHEMA_TYPE(uintptr_t, 0x78); }
    bool m_bHasParent() { return SCHEMA_TYPE(bool, 0x74); }
    bool m_bParentFrozen() { return SCHEMA_TYPE(bool, 0x75); }
    float m_flGlassHalfThickness() { return SCHEMA_TYPE(float, 0x70); }
    uintptr_t /* HMaterialStrong */ m_hMaterialBase() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t /* HMaterialStrong */ m_hMaterialDamageOverlay() { return SCHEMA_TYPE(uintptr_t, 0x18); }
    int32_t m_nModelID() { return SCHEMA_TYPE(int32_t, 0x8); }
    uintptr_t /* ShardSolid_t */ m_solid() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    uintptr_t /* Vector4D */ m_vInitialPanelVertices() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    uintptr_t /* Vector2D */ m_vecPanelSize() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    uintptr_t /* Vector2D */ m_vecPanelVertices() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* Vector2D */ m_vecStressPositionA() { return SCHEMA_TYPE(uintptr_t, 0x2C); }
    uintptr_t /* Vector2D */ m_vecStressPositionB() { return SCHEMA_TYPE(uintptr_t, 0x34); }
};

#pragma once
#include <cstdint>
class CPointChildModifier {
public:
    uintptr_t m_bOrphanInsteadOfDeletingChildrenOnRemove() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPointChildModifier {
public:
    uintptr_t baseAddr;
    CPointChildModifier(uintptr_t addr) : baseAddr(addr) {}
    CPointChildModifier() : baseAddr(0) {}
    uintptr_t m_bOrphanInsteadOfDeletingChildrenOnRemove() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

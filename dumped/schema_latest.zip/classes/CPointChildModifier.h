#pragma once

class CPointChildModifier  {
public:
    uintptr_t baseAddr;

    CPointChildModifier() : baseAddr(0) {}
    CPointChildModifier(uintptr_t base) : baseAddr(base) {}

};

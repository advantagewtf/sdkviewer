#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TriggerMultiple : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_TriggerMultiple(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerMultiple() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_TriggerMultiple : public C_BaseTrigger {
public:
};

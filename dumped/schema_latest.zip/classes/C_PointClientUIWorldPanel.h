#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_PointClientUIWorldPanel : public C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_PointClientUIWorldPanel(uintptr_t addr) : baseAddr(addr) {}
    C_PointClientUIWorldPanel() : baseAddr(0) {}
    uintptr_t m_anchorDeltaTransform() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    bool m_bAllowInteractionFromAllSceneWorlds() { return SCHEMA_TYPE(bool, 0x10B0); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0xEC2); }
    bool m_bDisableMipGen() { return SCHEMA_TYPE(bool, 0x10D8); }
    bool m_bExcludeFromSaveGames() { return SCHEMA_TYPE(bool, 0x10D5); }
    bool m_bFollowPlayerAcrossTeleport() { return SCHEMA_TYPE(bool, 0x108A); }
    uintptr_t m_bForceRecreateNextUpdate() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    bool m_bGrabbable() { return SCHEMA_TYPE(bool, 0x10D6); }
    bool m_bIgnoreInput() { return SCHEMA_TYPE(bool, 0x1088); }
    bool m_bLit() { return SCHEMA_TYPE(bool, 0x1089); }
    uintptr_t m_bMoveViewToPlayerNextThink() { return SCHEMA_TYPE(uintptr_t, 0xEC1); }
    bool m_bNoDepth() { return SCHEMA_TYPE(bool, 0x10D1); }
    bool m_bOnlyRenderToTexture() { return SCHEMA_TYPE(bool, 0x10D7); }
    bool m_bOpaque() { return SCHEMA_TYPE(bool, 0x10D0); }
    bool m_bRenderBackface() { return SCHEMA_TYPE(bool, 0x10D3); }
    bool m_bUseOffScreenIndicator() { return SCHEMA_TYPE(bool, 0x10D4); }
    bool m_bVisibleWhenParentNoDraw() { return SCHEMA_TYPE(bool, 0x10D2); }
    float m_flDPI() { return SCHEMA_TYPE(float, 0x1094); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x109C); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x1090); }
    float m_flInteractDistance() { return SCHEMA_TYPE(float, 0x1098); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0x108C); }
    int32_t m_nExplicitImageLayout() { return SCHEMA_TYPE(int32_t, 0x10DC); }
    uintptr_t m_pOffScreenIndicator() { return SCHEMA_TYPE(uintptr_t, 0x1060); }
    uint32_t m_unHorizontalAlign() { return SCHEMA_TYPE(uint32_t, 0x10A4); }
    uint32_t m_unOrientation() { return SCHEMA_TYPE(uint32_t, 0x10AC); }
    uint32_t m_unOwnerContext() { return SCHEMA_TYPE(uint32_t, 0x10A0); }
    uint32_t m_unVerticalAlign() { return SCHEMA_TYPE(uint32_t, 0x10A8); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x10B8); }
};

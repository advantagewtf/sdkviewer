#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_PointClientUIWorldPanel : public C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_PointClientUIWorldPanel(uintptr_t addr) : baseAddr(addr) {}
    C_PointClientUIWorldPanel() : baseAddr(0) {}
    uintptr_t m_anchorDeltaTransform() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    bool m_bAllowInteractionFromAllSceneWorlds() { return SCHEMA_TYPE(bool, 0x10D0); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0xEEA); }
    bool m_bDisableMipGen() { return SCHEMA_TYPE(bool, 0x10F8); }
    bool m_bExcludeFromSaveGames() { return SCHEMA_TYPE(bool, 0x10F5); }
    bool m_bFollowPlayerAcrossTeleport() { return SCHEMA_TYPE(bool, 0x10AA); }
    uintptr_t m_bForceRecreateNextUpdate() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    bool m_bGrabbable() { return SCHEMA_TYPE(bool, 0x10F6); }
    bool m_bIgnoreInput() { return SCHEMA_TYPE(bool, 0x10A8); }
    bool m_bLit() { return SCHEMA_TYPE(bool, 0x10A9); }
    uintptr_t m_bMoveViewToPlayerNextThink() { return SCHEMA_TYPE(uintptr_t, 0xEE9); }
    bool m_bNoDepth() { return SCHEMA_TYPE(bool, 0x10F1); }
    bool m_bOnlyRenderToTexture() { return SCHEMA_TYPE(bool, 0x10F7); }
    bool m_bOpaque() { return SCHEMA_TYPE(bool, 0x10F0); }
    bool m_bRenderBackface() { return SCHEMA_TYPE(bool, 0x10F3); }
    bool m_bUseOffScreenIndicator() { return SCHEMA_TYPE(bool, 0x10F4); }
    bool m_bVisibleWhenParentNoDraw() { return SCHEMA_TYPE(bool, 0x10F2); }
    float m_flDPI() { return SCHEMA_TYPE(float, 0x10B4); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x10BC); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x10B0); }
    float m_flInteractDistance() { return SCHEMA_TYPE(float, 0x10B8); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0x10AC); }
    int32_t m_nExplicitImageLayout() { return SCHEMA_TYPE(int32_t, 0x10FC); }
    uintptr_t m_pOffScreenIndicator() { return SCHEMA_TYPE(uintptr_t, 0x1080); }
    uint32_t m_unHorizontalAlign() { return SCHEMA_TYPE(uint32_t, 0x10C4); }
    uint32_t m_unOrientation() { return SCHEMA_TYPE(uint32_t, 0x10CC); }
    uint32_t m_unOwnerContext() { return SCHEMA_TYPE(uint32_t, 0x10C0); }
    uint32_t m_unVerticalAlign() { return SCHEMA_TYPE(uint32_t, 0x10C8); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x10D8); }
};

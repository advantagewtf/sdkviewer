#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPointTemplateAPI {
public:
    uintptr_t baseAddr;
    CPointTemplateAPI(uintptr_t addr) : baseAddr(addr) {}
    CPointTemplateAPI() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPointTemplateAPI {
public:
};

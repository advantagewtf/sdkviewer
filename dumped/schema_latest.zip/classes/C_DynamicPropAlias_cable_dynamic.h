#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DynamicPropAlias_cable_dynamic : public C_DynamicProp {
public:
    uintptr_t baseAddr;
    C_DynamicPropAlias_cable_dynamic(uintptr_t addr) : baseAddr(addr) {}
    C_DynamicPropAlias_cable_dynamic() : baseAddr(0) {}
};

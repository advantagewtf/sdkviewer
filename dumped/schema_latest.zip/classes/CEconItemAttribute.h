#pragma once
#include "../cstypes/uint16_t.h"

class CEconItemAttribute  {
public:
    uintptr_t baseAddr;

    CEconItemAttribute() : baseAddr(0) {}
    CEconItemAttribute(uintptr_t base) : baseAddr(base) {}

    uint16_t m_iAttributeDefinitionIndex() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flValue() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInitialValue() { return SCHEMA_TYPE(float, 0x20); }
    int m_nRefundableCurrency() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class CEconItemAttribute {
public:
    bool m_bSetBonus() { return SCHEMA_TYPE(bool, 0x40); }
    float m_flInitialValue() { return SCHEMA_TYPE(float, 0x38); }
    float m_flValue() { return SCHEMA_TYPE(float, 0x34); }
    uintptr_t /* attrib_definition_index_t */ m_iAttributeDefinitionIndex() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    int32_t m_nRefundableCurrency() { return SCHEMA_TYPE(int32_t, 0x3C); }
};

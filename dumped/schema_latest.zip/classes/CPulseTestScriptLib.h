#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseTestScriptLib {
public:
    uintptr_t baseAddr;
    CPulseTestScriptLib(uintptr_t addr) : baseAddr(addr) {}
    CPulseTestScriptLib() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class ButtonBitMask_t;
class float32;
class CPlayer_MovementServices {
public:
    uintptr_t baseAddr;
    CPlayer_MovementServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_MovementServices() : baseAddr(0) {}
    float32 m_arrForceSubtickMoveWhen() { return SCHEMA_TYPE(float32, 0x1A4); }
    uintptr_t m_flForwardMove() { return SCHEMA_TYPE(uintptr_t, 0x1B4); }
    uintptr_t m_flLeftMove() { return SCHEMA_TYPE(uintptr_t, 0x1B8); }
    float32 m_flMaxspeed() { return SCHEMA_TYPE(float32, 0x1A0); }
    uintptr_t m_flUpMove() { return SCHEMA_TYPE(uintptr_t, 0x1BC); }
    uintptr_t m_nButtonDoublePressed() { return SCHEMA_TYPE(uintptr_t, 0x80); }
    uintptr_t m_nButtons() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nImpulse() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_nLastCommandNumberProcessed() { return SCHEMA_TYPE(uintptr_t, 0x188); }
    uintptr_t m_nQueuedButtonChangeMask() { return SCHEMA_TYPE(uintptr_t, 0x78); }
    uintptr_t m_nQueuedButtonDownMask() { return SCHEMA_TYPE(uintptr_t, 0x70); }
    ButtonBitMask_t m_nToggleButtonDownMask() { return SCHEMA_TYPE(ButtonBitMask_t, 0x190); }
    uintptr_t m_pButtonPressedCmdNumber() { return SCHEMA_TYPE(uintptr_t, 0x88); }
    uintptr_t m_vecLastMovementImpulses() { return SCHEMA_TYPE(uintptr_t, 0x1C0); }
    uintptr_t m_vecOldViewAngles() { return SCHEMA_TYPE(uintptr_t, 0x228); }
};

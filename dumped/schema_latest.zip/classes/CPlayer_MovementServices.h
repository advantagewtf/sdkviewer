#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CPlayer_MovementServices  {
public:
    uintptr_t baseAddr;

    CPlayer_MovementServices() : baseAddr(0) {}
    CPlayer_MovementServices(uintptr_t base) : baseAddr(base) {}

    int m_nImpulse() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_nQueuedButtonDownMask() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_nQueuedButtonChangeMask() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_nButtonDoublePressed() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_pButtonPressedCmdNumber() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLastCommandNumberProcessed() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_nToggleButtonDownMask() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    float m_flMaxspeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_arrForceSubtickMoveWhen() { return SCHEMA_TYPE(float, 0x20); }
    float m_flForwardMove() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLeftMove() { return SCHEMA_TYPE(float, 0x20); }
    float m_flUpMove() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_SingleplayRules {
public:
};

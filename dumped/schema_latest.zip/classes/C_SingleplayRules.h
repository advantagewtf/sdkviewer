#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SingleplayRules {
public:
    uintptr_t baseAddr;
    C_SingleplayRules(uintptr_t addr) : baseAddr(addr) {}
    C_SingleplayRules() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPulseCell_Inflow_GraphHook {
public:
    uintptr_t m_HookName() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

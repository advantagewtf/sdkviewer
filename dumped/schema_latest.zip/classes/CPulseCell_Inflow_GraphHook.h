#pragma once
#include "../cstypes/PulseSymbol_t.h"

class CPulseCell_Inflow_GraphHook  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_GraphHook() : baseAddr(0) {}
    CPulseCell_Inflow_GraphHook(uintptr_t base) : baseAddr(base) {}

};

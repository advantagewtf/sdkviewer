#pragma once
#include "../memory.h"

class CPulseCell_Inflow_GraphHook {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_GraphHook() : baseAddr(0){}
 CPulseCell_Inflow_GraphHook(uintptr_t b):baseAddr(b){}
 uintptr_t m_HookName(){return SCHEMA_TYPE(uintptr_t,0x80);}
};

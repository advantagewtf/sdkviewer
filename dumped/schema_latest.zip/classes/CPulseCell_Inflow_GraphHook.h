#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_GraphHook {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_GraphHook(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_GraphHook() : baseAddr(0) {}
    uintptr_t m_HookName() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PathParticleRopeAlias_path_particle_rope_clientside : public C_PathParticleRope {
public:
    uintptr_t baseAddr;
    C_PathParticleRopeAlias_path_particle_rope_clientside(uintptr_t addr) : baseAddr(addr) {}
    C_PathParticleRopeAlias_path_particle_rope_clientside() : baseAddr(0) {}
};

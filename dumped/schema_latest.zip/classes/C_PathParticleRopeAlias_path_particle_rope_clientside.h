#pragma once
#include <cstdint>
class C_PathParticleRopeAlias_path_particle_rope_clientside : public C_PathParticleRope {
public:
};

#pragma once
#include <cstdint>
class C_Precipitation : public C_BaseTrigger {
public:
    uintptr_t m_bActiveParticlePrecipEmitter() { return SCHEMA_TYPE(uintptr_t, 0x1038); }
    uintptr_t m_bHasSimulatedSinceLastSceneObjectUpdate() { return SCHEMA_TYPE(uintptr_t, 0x103A); }
    uintptr_t m_bParticlePrecipInitialized() { return SCHEMA_TYPE(uintptr_t, 0x1039); }
    uintptr_t m_flDensity() { return SCHEMA_TYPE(uintptr_t, 0xFF0); }
    uintptr_t m_flParticleInnerDist() { return SCHEMA_TYPE(uintptr_t, 0x1000); }
    uintptr_t m_nAvailableSheetSequencesMaxIndex() { return SCHEMA_TYPE(uintptr_t, 0x103C); }
    uintptr_t m_pParticleDef() { return SCHEMA_TYPE(uintptr_t, 0x1008); }
    uintptr_t m_tParticlePrecipTraceTimer() { return SCHEMA_TYPE(uintptr_t, 0x1030); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_Precipitation  {
public:
    uintptr_t baseAddr;

    C_Precipitation() : baseAddr(0) {}
    C_Precipitation(uintptr_t base) : baseAddr(base) {}

    float m_flDensity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flParticleInnerDist() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_tParticlePrecipTraceTimer() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    bool m_bActiveParticlePrecipEmitter() { return SCHEMA_TYPE(bool, 0x1); }
    int m_nAvailableSheetSequencesMaxIndex() { return SCHEMA_TYPE(int, 0x20); }
};

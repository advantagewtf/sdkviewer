#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Precipitation : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_Precipitation(uintptr_t addr) : baseAddr(addr) {}
    C_Precipitation() : baseAddr(0) {}
    uintptr_t m_bActiveParticlePrecipEmitter() { return SCHEMA_TYPE(uintptr_t, 0xFA0); }
    uintptr_t m_bHasSimulatedSinceLastSceneObjectUpdate() { return SCHEMA_TYPE(uintptr_t, 0xFA2); }
    uintptr_t m_bParticlePrecipInitialized() { return SCHEMA_TYPE(uintptr_t, 0xFA1); }
    uintptr_t m_flDensity() { return SCHEMA_TYPE(uintptr_t, 0xF58); }
    uintptr_t m_flParticleInnerDist() { return SCHEMA_TYPE(uintptr_t, 0xF68); }
    uintptr_t m_nAvailableSheetSequencesMaxIndex() { return SCHEMA_TYPE(uintptr_t, 0xFA4); }
    uintptr_t m_pParticleDef() { return SCHEMA_TYPE(uintptr_t, 0xF70); }
    uintptr_t m_tParticlePrecipTraceTimer() { return SCHEMA_TYPE(uintptr_t, 0xF98); }
};

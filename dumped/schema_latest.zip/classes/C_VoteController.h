#pragma once

class C_VoteController  {
public:
    uintptr_t baseAddr;

    C_VoteController() : baseAddr(0) {}
    C_VoteController(uintptr_t base) : baseAddr(base) {}

    int m_iActiveIssueIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_iOnlyTeamToVote() { return SCHEMA_TYPE(int, 0x20); }
    int m_nVoteOptionCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPotentialVotes() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_VoteController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_VoteController(uintptr_t addr) : baseAddr(addr) {}
    C_VoteController() : baseAddr(0) {}
    bool m_bIsYesNoVote() { return SCHEMA_TYPE(bool, 0x63A); }
    uintptr_t m_bTypeDirty() { return SCHEMA_TYPE(uintptr_t, 0x639); }
    uintptr_t m_bVotesDirty() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    int32_t m_iActiveIssueIndex() { return SCHEMA_TYPE(int32_t, 0x618); }
    int32_t m_iOnlyTeamToVote() { return SCHEMA_TYPE(int32_t, 0x61C); }
    int32_t m_nPotentialVotes() { return SCHEMA_TYPE(int32_t, 0x634); }
    int32_t m_nVoteOptionCount() { return SCHEMA_TYPE(int32_t, 0x620); }
};

#pragma once
#include <cstdint>
class CGlowProperty {
public:
    bool m_bEligibleForScreenHighlight() { return SCHEMA_TYPE(bool, 0x50); }
    bool m_bFlashing() { return SCHEMA_TYPE(bool, 0x44); }
    uintptr_t m_bGlowing() { return SCHEMA_TYPE(uintptr_t, 0x51); }
    uintptr_t m_fGlowColor() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    float m_flGlowStartTime() { return SCHEMA_TYPE(float, 0x4C); }
    float m_flGlowTime() { return SCHEMA_TYPE(float, 0x48); }
    uintptr_t /* Color */ m_glowColorOverride() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int32_t m_iGlowTeam() { return SCHEMA_TYPE(int32_t, 0x34); }
    int32_t m_iGlowType() { return SCHEMA_TYPE(int32_t, 0x30); }
    int32_t m_nGlowRange() { return SCHEMA_TYPE(int32_t, 0x38); }
    int32_t m_nGlowRangeMin() { return SCHEMA_TYPE(int32_t, 0x3C); }
};

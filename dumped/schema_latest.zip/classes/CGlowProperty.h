#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CGlowProperty  {
public:
    uintptr_t baseAddr;

    CGlowProperty() : baseAddr(0) {}
    CGlowProperty(uintptr_t base) : baseAddr(base) {}

    int m_iGlowType() { return SCHEMA_TYPE(int, 0x20); }
    int m_iGlowTeam() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGlowRange() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGlowRangeMin() { return SCHEMA_TYPE(int, 0x20); }
    float m_flGlowTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flGlowStartTime() { return SCHEMA_TYPE(float, 0x20); }
};

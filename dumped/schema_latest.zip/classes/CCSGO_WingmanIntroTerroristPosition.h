#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSGO_WingmanIntroTerroristPosition : public CCSGO_WingmanIntroCharacterPosition {
public:
    uintptr_t baseAddr;
    CCSGO_WingmanIntroTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    CCSGO_WingmanIntroTerroristPosition() : baseAddr(0) {}
};

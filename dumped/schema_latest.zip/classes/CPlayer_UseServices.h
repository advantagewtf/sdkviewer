#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPlayer_UseServices {
public:
    uintptr_t baseAddr;
    CPlayer_UseServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_UseServices() : baseAddr(0) {}
};

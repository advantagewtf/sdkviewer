#pragma once
#include <cstdint>
class CPlayer_UseServices {
public:
};

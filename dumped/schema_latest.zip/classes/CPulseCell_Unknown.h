#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Unknown  {
public:
    uintptr_t baseAddr;

    CPulseCell_Unknown() : baseAddr(0) {}
    CPulseCell_Unknown(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_UnknownKeys() { return SCHEMA_TYPE(uintptr_t, 0x3); }
};

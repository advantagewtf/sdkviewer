#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Unknown {
public:
    uintptr_t baseAddr;
    CPulseCell_Unknown(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Unknown() : baseAddr(0) {}
    uintptr_t m_UnknownKeys() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

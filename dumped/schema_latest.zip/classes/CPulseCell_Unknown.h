#pragma once
#include <cstdint>
class CPulseCell_Unknown {
public:
    uintptr_t m_UnknownKeys() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

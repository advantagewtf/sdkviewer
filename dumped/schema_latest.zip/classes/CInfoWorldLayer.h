#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/uintptr_t.h"

class CInfoWorldLayer  {
public:
    uintptr_t baseAddr;

    CInfoWorldLayer() : baseAddr(0) {}
    CInfoWorldLayer(uintptr_t base) : baseAddr(base) {}

    int m_hLayerSpawnGroup() { return SCHEMA_TYPE(int, 0x20); }
};

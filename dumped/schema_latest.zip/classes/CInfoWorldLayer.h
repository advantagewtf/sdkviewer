#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class CInfoWorldLayer {
public:
    uintptr_t baseAddr;
    CInfoWorldLayer(uintptr_t addr) : baseAddr(addr) {}
    CInfoWorldLayer() : baseAddr(0) {}
    uintptr_t m_bCreateAsChildSpawnGroup() { return SCHEMA_TYPE(uintptr_t, 0x632); }
    bool m_bEntitiesSpawned() { return SCHEMA_TYPE(bool, 0x631); }
    uintptr_t m_bWorldLayerActuallyVisible() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    bool m_bWorldLayerVisible() { return SCHEMA_TYPE(bool, 0x630); }
    uintptr_t m_hLayerSpawnGroup() { return SCHEMA_TYPE(uintptr_t, 0x634); }
    string_t m_layerName() { return SCHEMA_TYPE(string_t, 0x628); }
    uintptr_t m_pOutputOnEntitiesSpawned() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    string_t m_worldName() { return SCHEMA_TYPE(string_t, 0x620); }
};

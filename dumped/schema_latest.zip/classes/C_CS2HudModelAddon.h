#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CS2HudModelAddon {
public:
    uintptr_t baseAddr;
    C_CS2HudModelAddon(uintptr_t addr) : baseAddr(addr) {}
    C_CS2HudModelAddon() : baseAddr(0) {}
};

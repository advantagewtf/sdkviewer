#pragma once
#include <cstdint>
class C_CS2HudModelAddon {
public:
};

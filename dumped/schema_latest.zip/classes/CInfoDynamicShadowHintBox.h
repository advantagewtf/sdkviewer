#pragma once
#include "../types/Vector3.h"

class CInfoDynamicShadowHintBox  {
public:
    uintptr_t baseAddr;

    CInfoDynamicShadowHintBox() : baseAddr(0) {}
    CInfoDynamicShadowHintBox(uintptr_t base) : baseAddr(base) {}

};

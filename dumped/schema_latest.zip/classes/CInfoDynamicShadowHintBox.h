#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CInfoDynamicShadowHintBox : public CInfoDynamicShadowHint {
public:
    uintptr_t baseAddr;
    CInfoDynamicShadowHintBox(uintptr_t addr) : baseAddr(addr) {}
    CInfoDynamicShadowHintBox() : baseAddr(0) {}
    uintptr_t m_vBoxMaxs() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
    uintptr_t m_vBoxMins() { return SCHEMA_TYPE(uintptr_t, 0x620); }
};

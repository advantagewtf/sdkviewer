#pragma once
#include <cstdint>
class CInfoDynamicShadowHintBox : public CInfoDynamicShadowHint {
public:
    uintptr_t m_vBoxMaxs() { return SCHEMA_TYPE(uintptr_t, 0x61C); }
    uintptr_t m_vBoxMins() { return SCHEMA_TYPE(uintptr_t, 0x610); }
};

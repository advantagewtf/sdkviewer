#pragma once
#include <cstdint>
class C_TriggerBuoyancy : public C_BaseTrigger {
public:
    uintptr_t m_BuoyancyHelper() { return SCHEMA_TYPE(uintptr_t, 0xFF0); }
    float m_flFluidDensity() { return SCHEMA_TYPE(float, 0x1108); }
};

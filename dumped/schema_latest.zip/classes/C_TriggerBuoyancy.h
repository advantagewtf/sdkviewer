#pragma once
#include "../classes/CBuoyancyHelper.h"

class C_TriggerBuoyancy  {
public:
    uintptr_t baseAddr;

    C_TriggerBuoyancy() : baseAddr(0) {}
    C_TriggerBuoyancy(uintptr_t base) : baseAddr(base) {}

    float m_flFluidDensity() { return SCHEMA_TYPE(float, 0x20); }
};

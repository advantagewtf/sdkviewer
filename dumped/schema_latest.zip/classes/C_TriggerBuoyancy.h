#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TriggerBuoyancy : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_TriggerBuoyancy(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerBuoyancy() : baseAddr(0) {}
    uintptr_t m_BuoyancyHelper() { return SCHEMA_TYPE(uintptr_t, 0xF58); }
    float m_flFluidDensity() { return SCHEMA_TYPE(float, 0x1070); }
};

#pragma once
#include <cstdint>
class C_TonemapController2 : public C_BaseEntity {
public:
    float m_flAutoExposureMax() { return SCHEMA_TYPE(float, 0x5FC); }
    float m_flAutoExposureMin() { return SCHEMA_TYPE(float, 0x5F8); }
    float m_flExposureAdaptationSpeedDown() { return SCHEMA_TYPE(float, 0x604); }
    float m_flExposureAdaptationSpeedUp() { return SCHEMA_TYPE(float, 0x600); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0x608); }
};

#pragma once

class C_TonemapController2  {
public:
    uintptr_t baseAddr;

    C_TonemapController2() : baseAddr(0) {}
    C_TonemapController2(uintptr_t base) : baseAddr(base) {}

    float m_flAutoExposureMin() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAutoExposureMax() { return SCHEMA_TYPE(float, 0x20); }
    float m_flExposureAdaptationSpeedUp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flExposureAdaptationSpeedDown() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TonemapController2 : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_TonemapController2(uintptr_t addr) : baseAddr(addr) {}
    C_TonemapController2() : baseAddr(0) {}
    float m_flAutoExposureMax() { return SCHEMA_TYPE(float, 0x5FC); }
    float m_flAutoExposureMin() { return SCHEMA_TYPE(float, 0x5F8); }
    float m_flExposureAdaptationSpeedDown() { return SCHEMA_TYPE(float, 0x604); }
    float m_flExposureAdaptationSpeedUp() { return SCHEMA_TYPE(float, 0x600); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0x608); }
};

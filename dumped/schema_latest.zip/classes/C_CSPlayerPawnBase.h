#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CCSPlayerController;
class CCSPlayer_PingServices;

class C_CSPlayerPawnBase  {
public:
    uintptr_t baseAddr;

    C_CSPlayerPawnBase() : baseAddr(0) {}
    C_CSPlayerPawnBase(uintptr_t base) : baseAddr(base) {}

    int m_iProgressBarDuration() { return SCHEMA_TYPE(int, 0x20); }
    float m_flProgressBarStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlashBangTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlashScreenshotAlpha() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlashOverlayAlpha() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlashMaxAlpha() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlashDuration() { return SCHEMA_TYPE(float, 0x20); }
    int m_nClientHealthFadeParityValue() { return SCHEMA_TYPE(int, 0x20); }
    float m_fNextThinkPushAway() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurrentMusicStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMusicRoundStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLastSmokeOverlayAlpha() { return SCHEMA_TYPE(float, 0x20); }
    float m_flLastSmokeAge() { return SCHEMA_TYPE(float, 0x20); }
};

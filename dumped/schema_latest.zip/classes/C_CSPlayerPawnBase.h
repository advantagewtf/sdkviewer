#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSPlayerController;
class CSPlayerState;
class C_CSPlayerPawnBase : public C_BasePlayerPawn {
public:
    uintptr_t baseAddr;
    C_CSPlayerPawnBase(uintptr_t addr) : baseAddr(addr) {}
    C_CSPlayerPawnBase() : baseAddr(0) {}
    uintptr_t m_bDeferStartMusicOnWarmup() { return SCHEMA_TYPE(uintptr_t, 0x1614); }
    uintptr_t m_bFlashBuildUp() { return SCHEMA_TYPE(uintptr_t, 0x15F0); }
    uintptr_t m_bFlashDspHasBeenCleared() { return SCHEMA_TYPE(uintptr_t, 0x15F1); }
    uintptr_t m_bFlashScreenshotHasBeenGrabbed() { return SCHEMA_TYPE(uintptr_t, 0x15F2); }
    bool m_bHasMovedSinceSpawn() { return SCHEMA_TYPE(bool, 0x15D0); }
    uintptr_t m_fNextThinkPushAway() { return SCHEMA_TYPE(uintptr_t, 0x1604); }
    uintptr_t m_flClientDeathTime() { return SCHEMA_TYPE(uintptr_t, 0x15E0); }
    uintptr_t m_flClientHealthFadeChangeTimestamp() { return SCHEMA_TYPE(uintptr_t, 0x15FC); }
    uintptr_t m_flCurrentMusicStartTime() { return SCHEMA_TYPE(uintptr_t, 0x160C); }
    uintptr_t m_flFlashBangTime() { return SCHEMA_TYPE(uintptr_t, 0x15E4); }
    float m_flFlashDuration() { return SCHEMA_TYPE(float, 0x15F8); }
    float m_flFlashMaxAlpha() { return SCHEMA_TYPE(float, 0x15F4); }
    uintptr_t m_flFlashOverlayAlpha() { return SCHEMA_TYPE(uintptr_t, 0x15EC); }
    uintptr_t m_flFlashScreenshotAlpha() { return SCHEMA_TYPE(uintptr_t, 0x15E8); }
    uintptr_t m_flLastSmokeAge() { return SCHEMA_TYPE(uintptr_t, 0x161C); }
    uintptr_t m_flLastSmokeOverlayAlpha() { return SCHEMA_TYPE(uintptr_t, 0x1618); }
    uintptr_t m_flLastSpawnTimeIndex() { return SCHEMA_TYPE(uintptr_t, 0x15D4); }
    uintptr_t m_flMusicRoundStartTime() { return SCHEMA_TYPE(uintptr_t, 0x1610); }
    float m_flProgressBarStartTime() { return SCHEMA_TYPE(float, 0x15DC); }
    CHandle<CCSPlayerController> m_hOriginalController() { return SCHEMA_TYPE(CHandle<CCSPlayerController>, 0x1648); }
    CSPlayerState m_iPlayerState() { return SCHEMA_TYPE(CSPlayerState, 0x15CC); }
    int32_t m_iProgressBarDuration() { return SCHEMA_TYPE(int32_t, 0x15D8); }
    uintptr_t m_nClientHealthFadeParityValue() { return SCHEMA_TYPE(uintptr_t, 0x1600); }
    CCSPlayer_PingServices* m_pPingServices() { return SCHEMA_TYPE(CCSPlayer_PingServices*, 0x15C0); }
    uintptr_t m_previousPlayerState() { return SCHEMA_TYPE(uintptr_t, 0x15C8); }
    uintptr_t m_vLastSmokeOverlayColor() { return SCHEMA_TYPE(uintptr_t, 0x1620); }
};

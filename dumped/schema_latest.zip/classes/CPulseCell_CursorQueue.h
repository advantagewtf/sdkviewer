#pragma once
#include <cstdint>
class CPulseCell_CursorQueue {
public:
    uintptr_t m_nCursorsAllowedToRunParallel() { return SCHEMA_TYPE(uintptr_t, 0x98); }
};

#pragma once

class CPulseCell_CursorQueue  {
public:
    uintptr_t baseAddr;

    CPulseCell_CursorQueue() : baseAddr(0) {}
    CPulseCell_CursorQueue(uintptr_t base) : baseAddr(base) {}

    int m_nCursorsAllowedToRunParallel() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_CursorQueue {
public:
    uintptr_t baseAddr;
    CPulseCell_CursorQueue(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_CursorQueue() : baseAddr(0) {}
    uintptr_t m_nCursorsAllowedToRunParallel() { return SCHEMA_TYPE(uintptr_t, 0x98); }
};

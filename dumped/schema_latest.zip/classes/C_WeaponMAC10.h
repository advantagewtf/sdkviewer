#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponMAC10 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponMAC10(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponMAC10() : baseAddr(0) {}
};

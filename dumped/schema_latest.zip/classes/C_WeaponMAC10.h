#pragma once
#include "../memory.h"

class C_WeaponMAC10 {
public:
 uintptr_t baseAddr;
 C_WeaponMAC10() : baseAddr(0){}
 C_WeaponMAC10(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
class C_WeaponMAC10 : public C_CSWeaponBaseGun {
public:
};

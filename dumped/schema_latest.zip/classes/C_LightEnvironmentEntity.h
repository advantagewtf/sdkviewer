#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_LightEnvironmentEntity : public C_LightDirectionalEntity {
public:
    uintptr_t baseAddr;
    C_LightEnvironmentEntity(uintptr_t addr) : baseAddr(addr) {}
    C_LightEnvironmentEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_LightEnvironmentEntity : public C_LightDirectionalEntity {
public:
};

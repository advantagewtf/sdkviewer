#pragma once
#include <cstdint>
class C_AK47 {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_AK47 {
public:
    uintptr_t baseAddr;
    C_AK47(uintptr_t addr) : baseAddr(addr) {}
    C_AK47() : baseAddr(0) {}
};

#pragma once

class CMapInfo  {
public:
    uintptr_t baseAddr;

    CMapInfo() : baseAddr(0) {}
    CMapInfo(uintptr_t base) : baseAddr(base) {}

    int m_iBuyingStatus() { return SCHEMA_TYPE(int, 0x20); }
    float m_flBombRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_iPetPopulation() { return SCHEMA_TYPE(int, 0x20); }
    float m_flBotMaxVisionDistance() { return SCHEMA_TYPE(float, 0x20); }
    int m_iHostageCount() { return SCHEMA_TYPE(int, 0x20); }
    float m_flEnvRainStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEnvPuddleRippleStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEnvPuddleRippleDirection() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEnvWetnessCoverage() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEnvWetnessDryingAmount() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include "../memory.h"

class C_TriggerPhysics {
public:
 uintptr_t baseAddr;
 C_TriggerPhysics() : baseAddr(0){}
 C_TriggerPhysics(uintptr_t b):baseAddr(b){}
 uintptr_t m_gravityScale(){return SCHEMA_TYPE(uintptr_t,0xFF0);}
 uintptr_t m_linearLimit(){return SCHEMA_TYPE(uintptr_t,0xFF4);}
 uintptr_t m_linearDamping(){return SCHEMA_TYPE(uintptr_t,0xFF8);}
 uintptr_t m_angularLimit(){return SCHEMA_TYPE(uintptr_t,0xFFC);}
 uintptr_t m_angularDamping(){return SCHEMA_TYPE(uintptr_t,0x1000);}
 uintptr_t m_linearForce(){return SCHEMA_TYPE(uintptr_t,0x1004);}
 uintptr_t m_flFrequency(){return SCHEMA_TYPE(uintptr_t,0x1008);}
 uintptr_t m_flDampingRatio(){return SCHEMA_TYPE(uintptr_t,0x100C);}
 uintptr_t m_vecLinearForcePointAt(){return SCHEMA_TYPE(uintptr_t,0x1010);}
 uintptr_t m_bCollapseToForcePoint(){return SCHEMA_TYPE(uintptr_t,0x101C);}
 uintptr_t m_vecLinearForcePointAtWorld(){return SCHEMA_TYPE(uintptr_t,0x1020);}
 uintptr_t m_vecLinearForceDirection(){return SCHEMA_TYPE(uintptr_t,0x102C);}
 uintptr_t m_bConvertToDebrisWhenPossible(){return SCHEMA_TYPE(uintptr_t,0x1038);}
};

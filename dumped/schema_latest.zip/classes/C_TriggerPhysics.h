#pragma once
#include "../types/Vector3.h"

class C_TriggerPhysics  {
public:
    uintptr_t baseAddr;

    C_TriggerPhysics() : baseAddr(0) {}
    C_TriggerPhysics(uintptr_t base) : baseAddr(base) {}

    float m_gravityScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_linearLimit() { return SCHEMA_TYPE(float, 0x20); }
    float m_linearDamping() { return SCHEMA_TYPE(float, 0x20); }
    float m_angularLimit() { return SCHEMA_TYPE(float, 0x20); }
    float m_angularDamping() { return SCHEMA_TYPE(float, 0x20); }
    float m_linearForce() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFrequency() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDampingRatio() { return SCHEMA_TYPE(float, 0x20); }
};

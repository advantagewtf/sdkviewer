#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_TriggerPhysics : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_TriggerPhysics(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerPhysics() : baseAddr(0) {}
    float m_angularDamping() { return SCHEMA_TYPE(float, 0x1000); }
    float m_angularLimit() { return SCHEMA_TYPE(float, 0xFFC); }
    bool m_bCollapseToForcePoint() { return SCHEMA_TYPE(bool, 0x101C); }
    bool m_bConvertToDebrisWhenPossible() { return SCHEMA_TYPE(bool, 0x1038); }
    float m_flDampingRatio() { return SCHEMA_TYPE(float, 0x100C); }
    float m_flFrequency() { return SCHEMA_TYPE(float, 0x1008); }
    float m_gravityScale() { return SCHEMA_TYPE(float, 0xFF0); }
    float m_linearDamping() { return SCHEMA_TYPE(float, 0xFF8); }
    float m_linearForce() { return SCHEMA_TYPE(float, 0x1004); }
    float m_linearLimit() { return SCHEMA_TYPE(float, 0xFF4); }
    Vector3 m_vecLinearForceDirection() { return SCHEMA_TYPE(Vector3, 0x102C); }
    Vector3 m_vecLinearForcePointAt() { return SCHEMA_TYPE(Vector3, 0x1010); }
    Vector3 m_vecLinearForcePointAtWorld() { return SCHEMA_TYPE(Vector3, 0x1020); }
};

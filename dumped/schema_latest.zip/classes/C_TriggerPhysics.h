#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_TriggerPhysics : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_TriggerPhysics(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerPhysics() : baseAddr(0) {}
    float m_angularDamping() { return SCHEMA_TYPE(float, 0xF68); }
    float m_angularLimit() { return SCHEMA_TYPE(float, 0xF64); }
    bool m_bCollapseToForcePoint() { return SCHEMA_TYPE(bool, 0xF84); }
    bool m_bConvertToDebrisWhenPossible() { return SCHEMA_TYPE(bool, 0xFA0); }
    float m_flDampingRatio() { return SCHEMA_TYPE(float, 0xF74); }
    float m_flFrequency() { return SCHEMA_TYPE(float, 0xF70); }
    float m_gravityScale() { return SCHEMA_TYPE(float, 0xF58); }
    float m_linearDamping() { return SCHEMA_TYPE(float, 0xF60); }
    float m_linearForce() { return SCHEMA_TYPE(float, 0xF6C); }
    float m_linearLimit() { return SCHEMA_TYPE(float, 0xF5C); }
    Vector3 m_vecLinearForceDirection() { return SCHEMA_TYPE(Vector3, 0xF94); }
    Vector3 m_vecLinearForcePointAt() { return SCHEMA_TYPE(Vector3, 0xF78); }
    Vector3 m_vecLinearForcePointAtWorld() { return SCHEMA_TYPE(Vector3, 0xF88); }
};

#pragma once

class C_WeaponBaseItem  {
public:
    uintptr_t baseAddr;

    C_WeaponBaseItem() : baseAddr(0) {}
    C_WeaponBaseItem(uintptr_t base) : baseAddr(base) {}

};

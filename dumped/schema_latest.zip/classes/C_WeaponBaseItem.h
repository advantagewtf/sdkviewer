#pragma once
#include <cstdint>
class C_WeaponBaseItem : public C_CSWeaponBase {
public:
    bool m_bRedraw() { return SCHEMA_TYPE(bool, 0x1F81); }
    bool m_bSequenceInProgress() { return SCHEMA_TYPE(bool, 0x1F80); }
};

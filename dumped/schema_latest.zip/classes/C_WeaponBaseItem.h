#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponBaseItem : public C_CSWeaponBase {
public:
    uintptr_t baseAddr;
    C_WeaponBaseItem(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponBaseItem() : baseAddr(0) {}
    bool m_bRedraw() { return SCHEMA_TYPE(bool, 0x1F41); }
    bool m_bSequenceInProgress() { return SCHEMA_TYPE(bool, 0x1F40); }
};

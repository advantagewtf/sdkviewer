#pragma once
#include <cstdint>
class CPulseCell_IsRequirementValid__Criteria_t {
public:
    uintptr_t m_bIsValid() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

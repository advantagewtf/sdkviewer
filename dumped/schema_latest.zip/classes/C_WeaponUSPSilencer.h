#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponUSPSilencer : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponUSPSilencer(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponUSPSilencer() : baseAddr(0) {}
};

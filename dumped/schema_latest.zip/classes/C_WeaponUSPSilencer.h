#pragma once
#include <cstdint>
class C_WeaponUSPSilencer : public C_CSWeaponBaseGun {
public:
};

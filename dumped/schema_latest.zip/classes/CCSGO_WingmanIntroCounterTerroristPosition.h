#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSGO_WingmanIntroCounterTerroristPosition : public CCSGO_WingmanIntroCharacterPosition {
public:
    uintptr_t baseAddr;
    CCSGO_WingmanIntroCounterTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    CCSGO_WingmanIntroCounterTerroristPosition() : baseAddr(0) {}
};

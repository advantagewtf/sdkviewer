#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPathQueryComponent : public CEntityComponent {
public:
    uintptr_t baseAddr;
    CPathQueryComponent(uintptr_t addr) : baseAddr(addr) {}
    CPathQueryComponent() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPathQueryComponent : public CEntityComponent {
public:
};

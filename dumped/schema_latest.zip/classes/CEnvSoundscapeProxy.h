#pragma once
#include "../cstypes/uintptr_t.h"

class CEnvSoundscapeProxy  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeProxy() : baseAddr(0) {}
    CEnvSoundscapeProxy(uintptr_t base) : baseAddr(base) {}

};

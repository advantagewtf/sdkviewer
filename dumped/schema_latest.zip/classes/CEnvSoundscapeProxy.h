#pragma once
#include <cstdint>
class CEnvSoundscapeProxy : public CEnvSoundscape {
public:
    uintptr_t m_MainSoundscapeName() { return SCHEMA_TYPE(uintptr_t, 0x698); }
};

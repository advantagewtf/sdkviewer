#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvSoundscapeProxy : public CEnvSoundscape {
public:
    uintptr_t baseAddr;
    CEnvSoundscapeProxy(uintptr_t addr) : baseAddr(addr) {}
    CEnvSoundscapeProxy() : baseAddr(0) {}
    uintptr_t m_MainSoundscapeName() { return SCHEMA_TYPE(uintptr_t, 0x698); }
};

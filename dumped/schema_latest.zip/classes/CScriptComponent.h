#pragma once
#include "../cstypes/uintptr_t.h"

class CScriptComponent  {
public:
    uintptr_t baseAddr;

    CScriptComponent() : baseAddr(0) {}
    CScriptComponent(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CScriptComponent : public CEntityComponent {
public:
    uintptr_t baseAddr;
    CScriptComponent(uintptr_t addr) : baseAddr(addr) {}
    CScriptComponent() : baseAddr(0) {}
    uintptr_t m_scriptClassName() { return SCHEMA_TYPE(uintptr_t, 0x30); }
};

#pragma once
#include <cstdint>
class CScriptComponent : public CEntityComponent {
public:
    uintptr_t m_scriptClassName() { return SCHEMA_TYPE(uintptr_t, 0x30); }
};

#pragma once
#include <cstdint>
class CCSGO_WingmanIntroCharacterPosition {
public:
};

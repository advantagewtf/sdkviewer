#pragma once
#include "../memory.h"

class CCSGO_WingmanIntroCharacterPosition {
public:
 uintptr_t baseAddr;
 CCSGO_WingmanIntroCharacterPosition() : baseAddr(0){}
 CCSGO_WingmanIntroCharacterPosition(uintptr_t b):baseAddr(b){}
};

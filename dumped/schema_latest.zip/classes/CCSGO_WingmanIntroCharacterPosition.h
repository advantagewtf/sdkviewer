#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSGO_WingmanIntroCharacterPosition {
public:
    uintptr_t baseAddr;
    CCSGO_WingmanIntroCharacterPosition(uintptr_t addr) : baseAddr(addr) {}
    CCSGO_WingmanIntroCharacterPosition() : baseAddr(0) {}
};

#pragma once
#include "../cstypes/PulseRegisterMap_t.h"
#include "../cstypes/PulseRuntimeChunkIndex_t.h"
#include "../cstypes/PulseSymbol_t.h"

class CPulse_OutflowConnection  {
public:
    uintptr_t baseAddr;

    CPulse_OutflowConnection() : baseAddr(0) {}
    CPulse_OutflowConnection(uintptr_t base) : baseAddr(base) {}

    int m_nInstruction() { return SCHEMA_TYPE(int, 0x20); }
};

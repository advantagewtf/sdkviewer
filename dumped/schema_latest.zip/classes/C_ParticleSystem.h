#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_ParticleSystem  {
public:
    uintptr_t baseAddr;

    C_ParticleSystem() : baseAddr(0) {}
    C_ParticleSystem(uintptr_t base) : baseAddr(base) {}

    char* m_szSnapshotFileName() { return SCHEMA_TYPE(char*, 0x200); }
    float m_flFreezeTransitionDuration() { return SCHEMA_TYPE(float, 0x20); }
    int m_nStopType() { return SCHEMA_TYPE(int, 0x20); }
    float m_flPreSimTime() { return SCHEMA_TYPE(float, 0x20); }
    Vector3 m_vServerControlPoints() { return SCHEMA_TYPE(Vector3, 0x4); }
    uint8_t m_iServerControlPointAssignments() { return SCHEMA_TYPE(uint8_t, 0x8); }
    C_BaseEntity* m_hControlPointEnts() { return SCHEMA_TYPE(C_BaseEntity*, 0x40); }
    uintptr_t m_iszControlPointNames() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_nDataCP() { return SCHEMA_TYPE(int, 0x20); }
    int m_nTintCP() { return SCHEMA_TYPE(int, 0x20); }
};

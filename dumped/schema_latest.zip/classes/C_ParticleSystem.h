#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class CBaseEntity;
class GameTime_t;
class HParticleSystemDefinitionStrong;
class float32;
class C_ParticleSystem : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_ParticleSystem(uintptr_t addr) : baseAddr(addr) {}
    C_ParticleSystem() : baseAddr(0) {}
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x10B0); }
    bool m_bAnimateDuringGameplayPause() { return SCHEMA_TYPE(bool, 0x10BC); }
    bool m_bFrozen() { return SCHEMA_TYPE(bool, 0x10B1); }
    bool m_bNoFreeze() { return SCHEMA_TYPE(bool, 0x1205); }
    bool m_bNoRamp() { return SCHEMA_TYPE(bool, 0x1206); }
    bool m_bNoSave() { return SCHEMA_TYPE(bool, 0x1204); }
    uintptr_t m_bOldActive() { return SCHEMA_TYPE(uintptr_t, 0x1448); }
    uintptr_t m_bOldFrozen() { return SCHEMA_TYPE(uintptr_t, 0x1449); }
    uintptr_t m_bStartActive() { return SCHEMA_TYPE(uintptr_t, 0x1207); }
    uintptr_t m_clrTint() { return SCHEMA_TYPE(uintptr_t, 0x1424); }
    float m_flFreezeTransitionDuration() { return SCHEMA_TYPE(float, 0x10B4); }
    float32 m_flPreSimTime() { return SCHEMA_TYPE(float32, 0x10CC); }
    GameTime_t m_flStartTime() { return SCHEMA_TYPE(GameTime_t, 0x10C8); }
    CHandle<CBaseEntity> m_hControlPointEnts() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x1104); }
    HParticleSystemDefinitionStrong m_iEffectIndex() { return SCHEMA_TYPE(HParticleSystemDefinitionStrong, 0x10C0); }
    uint8_t m_iServerControlPointAssignments() { return SCHEMA_TYPE(uint8_t, 0x1100); }
    uintptr_t m_iszControlPointNames() { return SCHEMA_TYPE(uintptr_t, 0x1210); }
    uintptr_t m_iszEffectName() { return SCHEMA_TYPE(uintptr_t, 0x1208); }
    uintptr_t m_nDataCP() { return SCHEMA_TYPE(uintptr_t, 0x1410); }
    int32_t m_nStopType() { return SCHEMA_TYPE(int32_t, 0x10B8); }
    uintptr_t m_nTintCP() { return SCHEMA_TYPE(uintptr_t, 0x1420); }
    char m_szSnapshotFileName() { return SCHEMA_TYPE(char, 0xEB0); }
    Vector3 m_vServerControlPoints() { return SCHEMA_TYPE(Vector3, 0x10D0); }
    uintptr_t m_vecDataCPValue() { return SCHEMA_TYPE(uintptr_t, 0x1414); }
};

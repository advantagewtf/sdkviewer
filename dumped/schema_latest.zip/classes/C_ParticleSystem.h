#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class CBaseEntity;
class GameTime_t;
class HParticleSystemDefinitionStrong;
class float32;
class C_ParticleSystem : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_ParticleSystem(uintptr_t addr) : baseAddr(addr) {}
    C_ParticleSystem() : baseAddr(0) {}
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x1088); }
    bool m_bAnimateDuringGameplayPause() { return SCHEMA_TYPE(bool, 0x1094); }
    bool m_bFrozen() { return SCHEMA_TYPE(bool, 0x1089); }
    bool m_bNoFreeze() { return SCHEMA_TYPE(bool, 0x11DD); }
    bool m_bNoRamp() { return SCHEMA_TYPE(bool, 0x11DE); }
    bool m_bNoSave() { return SCHEMA_TYPE(bool, 0x11DC); }
    uintptr_t m_bOldActive() { return SCHEMA_TYPE(uintptr_t, 0x1420); }
    uintptr_t m_bOldFrozen() { return SCHEMA_TYPE(uintptr_t, 0x1421); }
    uintptr_t m_bStartActive() { return SCHEMA_TYPE(uintptr_t, 0x11DF); }
    uintptr_t m_clrTint() { return SCHEMA_TYPE(uintptr_t, 0x13FC); }
    float m_flFreezeTransitionDuration() { return SCHEMA_TYPE(float, 0x108C); }
    float32 m_flPreSimTime() { return SCHEMA_TYPE(float32, 0x10A4); }
    GameTime_t m_flStartTime() { return SCHEMA_TYPE(GameTime_t, 0x10A0); }
    CHandle<CBaseEntity> m_hControlPointEnts() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x10DC); }
    HParticleSystemDefinitionStrong m_iEffectIndex() { return SCHEMA_TYPE(HParticleSystemDefinitionStrong, 0x1098); }
    uint8_t m_iServerControlPointAssignments() { return SCHEMA_TYPE(uint8_t, 0x10D8); }
    uintptr_t m_iszControlPointNames() { return SCHEMA_TYPE(uintptr_t, 0x11E8); }
    uintptr_t m_iszEffectName() { return SCHEMA_TYPE(uintptr_t, 0x11E0); }
    uintptr_t m_nDataCP() { return SCHEMA_TYPE(uintptr_t, 0x13E8); }
    int32_t m_nStopType() { return SCHEMA_TYPE(int32_t, 0x1090); }
    uintptr_t m_nTintCP() { return SCHEMA_TYPE(uintptr_t, 0x13F8); }
    char m_szSnapshotFileName() { return SCHEMA_TYPE(char, 0xE88); }
    Vector3 m_vServerControlPoints() { return SCHEMA_TYPE(Vector3, 0x10A8); }
    uintptr_t m_vecDataCPValue() { return SCHEMA_TYPE(uintptr_t, 0x13EC); }
};

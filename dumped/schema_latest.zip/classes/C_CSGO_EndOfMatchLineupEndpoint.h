#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_EndOfMatchLineupEndpoint : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSGO_EndOfMatchLineupEndpoint(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_EndOfMatchLineupEndpoint() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_CSGO_EndOfMatchLineupEndpoint : public C_BaseEntity {
public:
};

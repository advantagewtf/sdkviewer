#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class EHANDLE;
class QAngle;
class float32;
class C_RagdollProp : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_RagdollProp(uintptr_t addr) : baseAddr(addr) {}
    C_RagdollProp() : baseAddr(0) {}
    float32 m_flBlendWeight() { return SCHEMA_TYPE(float32, 0x11B8); }
    uintptr_t m_flBlendWeightCurrent() { return SCHEMA_TYPE(uintptr_t, 0x11C4); }
    EHANDLE m_hRagdollSource() { return SCHEMA_TYPE(EHANDLE, 0x11BC); }
    uintptr_t m_iEyeAttachment() { return SCHEMA_TYPE(uintptr_t, 0x11C0); }
    uintptr_t m_parentPhysicsBoneIndices() { return SCHEMA_TYPE(uintptr_t, 0x11C8); }
    QAngle m_ragAngles() { return SCHEMA_TYPE(QAngle, 0x11A0); }
    bool m_ragEnabled() { return SCHEMA_TYPE(bool, 0x1170); }
    Vector3 m_ragPos() { return SCHEMA_TYPE(Vector3, 0x1188); }
    uintptr_t m_worldSpaceBoneComputationOrder() { return SCHEMA_TYPE(uintptr_t, 0x11E0); }
};

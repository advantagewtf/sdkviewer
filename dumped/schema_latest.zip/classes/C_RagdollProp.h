#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_RagdollProp : public CBaseAnimGraph {
public:
    uintptr_t /* float32 */ m_flBlendWeight() { return SCHEMA_TYPE(uintptr_t, 0x11A8); }
    uintptr_t m_flBlendWeightCurrent() { return SCHEMA_TYPE(uintptr_t, 0x11B4); }
    uintptr_t /* EHANDLE */ m_hRagdollSource() { return SCHEMA_TYPE(uintptr_t, 0x11AC); }
    uintptr_t m_iEyeAttachment() { return SCHEMA_TYPE(uintptr_t, 0x11B0); }
    uintptr_t m_parentPhysicsBoneIndices() { return SCHEMA_TYPE(uintptr_t, 0x11B8); }
    uintptr_t /* QAngle */ m_ragAngles() { return SCHEMA_TYPE(uintptr_t, 0x1190); }
    bool m_ragEnabled() { return SCHEMA_TYPE(bool, 0x1160); }
    Vector3 m_ragPos() { return SCHEMA_TYPE(Vector3, 0x1178); }
    uintptr_t m_worldSpaceBoneComputationOrder() { return SCHEMA_TYPE(uintptr_t, 0x11D0); }
};

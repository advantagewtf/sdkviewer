#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_RagdollProp  {
public:
    uintptr_t baseAddr;

    C_RagdollProp() : baseAddr(0) {}
    C_RagdollProp(uintptr_t base) : baseAddr(base) {}

    float m_flBlendWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBlendWeightCurrent() { return SCHEMA_TYPE(float, 0x20); }
    int m_parentPhysicsBoneIndices() { return SCHEMA_TYPE(int, 0x20); }
    int m_worldSpaceBoneComputationOrder() { return SCHEMA_TYPE(int, 0x20); }
};

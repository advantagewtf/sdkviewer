#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/uintptr_t.h"

class CEnvSoundscape  {
public:
    uintptr_t baseAddr;

    CEnvSoundscape() : baseAddr(0) {}
    CEnvSoundscape(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_soundscapeIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_soundscapeEntityListId() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_positionNames() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    int m_soundEventHash() { return SCHEMA_TYPE(int, 0x20); }
};

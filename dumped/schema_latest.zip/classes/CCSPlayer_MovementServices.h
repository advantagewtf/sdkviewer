#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CCSPlayer_MovementServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_MovementServices() : baseAddr(0) {}
    CCSPlayer_MovementServices(uintptr_t base) : baseAddr(base) {}

    int m_nLadderSurfacePropIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_flDuckAmount() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDuckSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDuckOffset() { return SCHEMA_TYPE(float, 0x20); }
    int m_nDuckTimeMsecs() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDuckJumpTimeMsecs() { return SCHEMA_TYPE(int, 0x20); }
    int m_nJumpTimeMsecs() { return SCHEMA_TYPE(int, 0x20); }
    float m_flLastDuckTime() { return SCHEMA_TYPE(float, 0x20); }
    Vector3 m_vecLastPositionAtFullCrouchSpeed() { return SCHEMA_TYPE(Vector3, 0x2); }
    int m_nTraceCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_StuckLast() { return SCHEMA_TYPE(int, 0x20); }
    int m_nOldWaterLevel() { return SCHEMA_TYPE(int, 0x20); }
    float m_flWaterEntryTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_nGameCodeHasMovedPlayerAfterCommand() { return SCHEMA_TYPE(int, 0x20); }
    float m_flJumpPressedTime() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_nButtonDownMaskPrev() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    float m_flOffsetTickCompleteTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOffsetTickStashedSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStamina() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHeightAtJumpStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxJumpHeightThisJump() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxJumpHeightLastJump() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStaminaAtJumpStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAccumulatedJumpError() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTicksSinceLastSurfingDetected() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class ButtonBitMask_t;
class GameTime_t;
class CCSPlayer_MovementServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_MovementServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_MovementServices() : baseAddr(0) {}
    uintptr_t m_StuckLast() { return SCHEMA_TYPE(uintptr_t, 0x4CC); }
    bool m_bDesiresDuck() { return SCHEMA_TYPE(bool, 0x291); }
    bool m_bDuckOverride() { return SCHEMA_TYPE(bool, 0x290); }
    uintptr_t m_bHasWalkMovedSinceLastJump() { return SCHEMA_TYPE(uintptr_t, 0x2B9); }
    uintptr_t m_bInStuckTest() { return SCHEMA_TYPE(uintptr_t, 0x2BA); }
    bool m_bJumpApexPending() { return SCHEMA_TYPE(bool, 0xDF8); }
    bool m_bOldJumpPressed() { return SCHEMA_TYPE(bool, 0x504); }
    uintptr_t m_bSpeedCropped() { return SCHEMA_TYPE(uintptr_t, 0x4D0); }
    bool m_bWasSurfing() { return SCHEMA_TYPE(bool, 0x53C); }
    uintptr_t m_duckUntilOnGround() { return SCHEMA_TYPE(uintptr_t, 0x2B8); }
    GameTime_t m_fStashGrenadeParameterWhen() { return SCHEMA_TYPE(GameTime_t, 0x50C); }
    uintptr_t m_flAccumulatedJumpError() { return SCHEMA_TYPE(uintptr_t, 0x534); }
    float m_flDuckAmount() { return SCHEMA_TYPE(float, 0x288); }
    float m_flDuckOffset() { return SCHEMA_TYPE(float, 0x294); }
    float m_flDuckSpeed() { return SCHEMA_TYPE(float, 0x28C); }
    uintptr_t m_flHeightAtJumpStart() { return SCHEMA_TYPE(uintptr_t, 0x524); }
    uintptr_t m_flJumpPressedTime() { return SCHEMA_TYPE(uintptr_t, 0x508); }
    float m_flLastDuckTime() { return SCHEMA_TYPE(float, 0x2A4); }
    uintptr_t m_flMaxJumpHeightLastJump() { return SCHEMA_TYPE(uintptr_t, 0x52C); }
    uintptr_t m_flMaxJumpHeightThisJump() { return SCHEMA_TYPE(uintptr_t, 0x528); }
    float m_flOffsetTickCompleteTime() { return SCHEMA_TYPE(float, 0x518); }
    float m_flOffsetTickStashedSpeed() { return SCHEMA_TYPE(float, 0x51C); }
    float m_flStamina() { return SCHEMA_TYPE(float, 0x520); }
    uintptr_t m_flStaminaAtJumpStart() { return SCHEMA_TYPE(uintptr_t, 0x530); }
    uintptr_t m_flTicksSinceLastSurfingDetected() { return SCHEMA_TYPE(uintptr_t, 0x538); }
    uintptr_t m_flWaterEntryTime() { return SCHEMA_TYPE(uintptr_t, 0x4D8); }
    ButtonBitMask_t m_nButtonDownMaskPrev() { return SCHEMA_TYPE(ButtonBitMask_t, 0x510); }
    uint32_t m_nDuckJumpTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x29C); }
    uint32_t m_nDuckTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x298); }
    int32_t m_nGameCodeHasMovedPlayerAfterCommand() { return SCHEMA_TYPE(int32_t, 0x500); }
    uint32_t m_nJumpTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x2A0); }
    int32_t m_nLadderSurfacePropIndex() { return SCHEMA_TYPE(int32_t, 0x284); }
    uintptr_t m_nOldWaterLevel() { return SCHEMA_TYPE(uintptr_t, 0x4D4); }
    uintptr_t m_nTraceCount() { return SCHEMA_TYPE(uintptr_t, 0x4C8); }
    uintptr_t m_vecForward() { return SCHEMA_TYPE(uintptr_t, 0x4DC); }
    uintptr_t m_vecInputRotated() { return SCHEMA_TYPE(uintptr_t, 0x5CC); }
    Vector3 m_vecLadderNormal() { return SCHEMA_TYPE(Vector3, 0x278); }
    uintptr_t m_vecLastPositionAtFullCrouchSpeed() { return SCHEMA_TYPE(uintptr_t, 0x2B0); }
    uintptr_t m_vecLeft() { return SCHEMA_TYPE(uintptr_t, 0x4E8); }
    uintptr_t m_vecUp() { return SCHEMA_TYPE(uintptr_t, 0x4F4); }
};

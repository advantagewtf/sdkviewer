#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class ButtonBitMask_t;
class CCSPlayerLegacyJump;
class CCSPlayerModernJump;
class GameTick_t;
class GameTime_t;
class CCSPlayer_MovementServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_MovementServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_MovementServices() : baseAddr(0) {}
    CCSPlayerLegacyJump m_LegacyJump() { return SCHEMA_TYPE(CCSPlayerLegacyJump, 0x538); }
    CCSPlayerModernJump m_ModernJump() { return SCHEMA_TYPE(CCSPlayerModernJump, 0x550); }
    uintptr_t m_StuckLast() { return SCHEMA_TYPE(uintptr_t, 0x4CC); }
    bool m_bDesiresDuck() { return SCHEMA_TYPE(bool, 0x28D); }
    bool m_bDuckOverride() { return SCHEMA_TYPE(bool, 0x28C); }
    bool m_bDucked() { return SCHEMA_TYPE(bool, 0x280); }
    bool m_bDucking() { return SCHEMA_TYPE(bool, 0x28E); }
    uintptr_t m_bHasWalkMovedSinceLastJump() { return SCHEMA_TYPE(uintptr_t, 0x2B9); }
    uintptr_t m_bInStuckTest() { return SCHEMA_TYPE(uintptr_t, 0x2BA); }
    bool m_bJumpApexPending() { return SCHEMA_TYPE(bool, 0x594); }
    uintptr_t m_bSpeedCropped() { return SCHEMA_TYPE(uintptr_t, 0x4D0); }
    bool m_bWasSurfing() { return SCHEMA_TYPE(bool, 0x59C); }
    uintptr_t m_duckUntilOnGround() { return SCHEMA_TYPE(uintptr_t, 0x2B8); }
    GameTime_t m_fStashGrenadeParameterWhen() { return SCHEMA_TYPE(GameTime_t, 0x504); }
    uintptr_t m_flAccumulatedJumpError() { return SCHEMA_TYPE(uintptr_t, 0x530); }
    float m_flDuckAmount() { return SCHEMA_TYPE(float, 0x284); }
    float m_flDuckOffset() { return SCHEMA_TYPE(float, 0x290); }
    float m_flDuckSpeed() { return SCHEMA_TYPE(float, 0x288); }
    uintptr_t m_flHeightAtJumpStart() { return SCHEMA_TYPE(uintptr_t, 0x51C); }
    float m_flLastDuckTime() { return SCHEMA_TYPE(float, 0x2A0); }
    float m_flLastJumpFrac() { return SCHEMA_TYPE(float, 0x58C); }
    float m_flLastJumpVelocityZ() { return SCHEMA_TYPE(float, 0x590); }
    uintptr_t m_flMaxJumpHeightLastJump() { return SCHEMA_TYPE(uintptr_t, 0x524); }
    uintptr_t m_flMaxJumpHeightThisJump() { return SCHEMA_TYPE(uintptr_t, 0x520); }
    float m_flOffsetTickCompleteTime() { return SCHEMA_TYPE(float, 0x510); }
    float m_flOffsetTickStashedSpeed() { return SCHEMA_TYPE(float, 0x514); }
    float m_flStamina() { return SCHEMA_TYPE(float, 0x518); }
    uintptr_t m_flStaminaAtJumpStart() { return SCHEMA_TYPE(uintptr_t, 0x528); }
    uintptr_t m_flTicksSinceLastSurfingDetected() { return SCHEMA_TYPE(uintptr_t, 0x598); }
    uintptr_t m_flVelMulAtJumpStart() { return SCHEMA_TYPE(uintptr_t, 0x52C); }
    uintptr_t m_flWaterEntryTime() { return SCHEMA_TYPE(uintptr_t, 0x4D8); }
    ButtonBitMask_t m_nButtonDownMaskPrev() { return SCHEMA_TYPE(ButtonBitMask_t, 0x508); }
    uint32_t m_nDuckJumpTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x298); }
    uint32_t m_nDuckTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x294); }
    int32_t m_nGameCodeHasMovedPlayerAfterCommand() { return SCHEMA_TYPE(int32_t, 0x500); }
    uint32_t m_nJumpTimeMsecs() { return SCHEMA_TYPE(uint32_t, 0x29C); }
    int32_t m_nLadderSurfacePropIndex() { return SCHEMA_TYPE(int32_t, 0x27C); }
    GameTick_t m_nLastJumpTick() { return SCHEMA_TYPE(GameTick_t, 0x588); }
    uintptr_t m_nOldWaterLevel() { return SCHEMA_TYPE(uintptr_t, 0x4D4); }
    uintptr_t m_nTraceCount() { return SCHEMA_TYPE(uintptr_t, 0x4C8); }
    uintptr_t m_vecForward() { return SCHEMA_TYPE(uintptr_t, 0x4DC); }
    uintptr_t m_vecInputRotated() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
    uintptr_t m_vecLadderNormal() { return SCHEMA_TYPE(uintptr_t, 0x270); }
    uintptr_t m_vecLastPositionAtFullCrouchSpeed() { return SCHEMA_TYPE(uintptr_t, 0x2B0); }
    uintptr_t m_vecLeft() { return SCHEMA_TYPE(uintptr_t, 0x4E8); }
    uintptr_t m_vecUp() { return SCHEMA_TYPE(uintptr_t, 0x4F4); }
};

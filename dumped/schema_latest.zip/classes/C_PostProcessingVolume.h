#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class HPostProcessingStrong;
class C_PostProcessingVolume : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_PostProcessingVolume(uintptr_t addr) : baseAddr(addr) {}
    C_PostProcessingVolume() : baseAddr(0) {}
    bool m_bExposureControl() { return SCHEMA_TYPE(bool, 0xF95); }
    bool m_bMaster() { return SCHEMA_TYPE(bool, 0xF94); }
    float m_flExposureCompensation() { return SCHEMA_TYPE(float, 0xF84); }
    float m_flExposureFadeSpeedDown() { return SCHEMA_TYPE(float, 0xF8C); }
    float m_flExposureFadeSpeedUp() { return SCHEMA_TYPE(float, 0xF88); }
    float m_flFadeDuration() { return SCHEMA_TYPE(float, 0xF70); }
    float m_flMaxExposure() { return SCHEMA_TYPE(float, 0xF80); }
    float m_flMaxLogExposure() { return SCHEMA_TYPE(float, 0xF78); }
    float m_flMinExposure() { return SCHEMA_TYPE(float, 0xF7C); }
    float m_flMinLogExposure() { return SCHEMA_TYPE(float, 0xF74); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0xF90); }
    HPostProcessingStrong m_hPostSettings() { return SCHEMA_TYPE(HPostProcessingStrong, 0xF68); }
};

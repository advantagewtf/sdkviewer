#pragma once
#include "../cstypes/uintptr_t.h"

class C_PostProcessingVolume  {
public:
    uintptr_t baseAddr;

    C_PostProcessingVolume() : baseAddr(0) {}
    C_PostProcessingVolume(uintptr_t base) : baseAddr(base) {}

    float m_flFadeDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMinLogExposure() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxLogExposure() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMinExposure() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxExposure() { return SCHEMA_TYPE(float, 0x20); }
    float m_flExposureCompensation() { return SCHEMA_TYPE(float, 0x20); }
    float m_flExposureFadeSpeedUp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flExposureFadeSpeedDown() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_PostProcessingVolume : public C_BaseTrigger {
public:
    bool m_bExposureControl() { return SCHEMA_TYPE(bool, 0x102D); }
    bool m_bMaster() { return SCHEMA_TYPE(bool, 0x102C); }
    float m_flExposureCompensation() { return SCHEMA_TYPE(float, 0x101C); }
    float m_flExposureFadeSpeedDown() { return SCHEMA_TYPE(float, 0x1024); }
    float m_flExposureFadeSpeedUp() { return SCHEMA_TYPE(float, 0x1020); }
    float m_flFadeDuration() { return SCHEMA_TYPE(float, 0x1008); }
    float m_flMaxExposure() { return SCHEMA_TYPE(float, 0x1018); }
    float m_flMaxLogExposure() { return SCHEMA_TYPE(float, 0x1010); }
    float m_flMinExposure() { return SCHEMA_TYPE(float, 0x1014); }
    float m_flMinLogExposure() { return SCHEMA_TYPE(float, 0x100C); }
    float m_flTonemapEVSmoothingRange() { return SCHEMA_TYPE(float, 0x1028); }
    uintptr_t /* HPostProcessingStrong */ m_hPostSettings() { return SCHEMA_TYPE(uintptr_t, 0x1000); }
};

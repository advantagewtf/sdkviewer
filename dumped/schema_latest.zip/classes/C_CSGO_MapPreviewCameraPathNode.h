#pragma once
#include <cstdint>
class C_CSGO_MapPreviewCameraPathNode : public C_BaseEntity {
public:
    uintptr_t m_flCameraSpeed() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_flEaseIn() { return SCHEMA_TYPE(uintptr_t, 0x624); }
    uintptr_t m_flEaseOut() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    uintptr_t m_flFOV() { return SCHEMA_TYPE(uintptr_t, 0x61C); }
    uintptr_t m_nPathIndex() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_szParentPathUniqueID() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_vInTangentLocal() { return SCHEMA_TYPE(uintptr_t, 0x604); }
    uintptr_t m_vInTangentWorld() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
    uintptr_t m_vOutTangentLocal() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_vOutTangentWorld() { return SCHEMA_TYPE(uintptr_t, 0x638); }
};

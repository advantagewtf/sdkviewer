#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_CSGO_MapPreviewCameraPathNode  {
public:
    uintptr_t baseAddr;

    C_CSGO_MapPreviewCameraPathNode() : baseAddr(0) {}
    C_CSGO_MapPreviewCameraPathNode(uintptr_t base) : baseAddr(base) {}

    int m_nPathIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFOV() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCameraSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEaseIn() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEaseOut() { return SCHEMA_TYPE(float, 0x20); }
};

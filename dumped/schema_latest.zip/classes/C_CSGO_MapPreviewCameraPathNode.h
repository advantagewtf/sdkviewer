#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_MapPreviewCameraPathNode : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSGO_MapPreviewCameraPathNode(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_MapPreviewCameraPathNode() : baseAddr(0) {}
    uintptr_t m_flCameraSpeed() { return SCHEMA_TYPE(uintptr_t, 0x630); }
    uintptr_t m_flEaseIn() { return SCHEMA_TYPE(uintptr_t, 0x634); }
    uintptr_t m_flEaseOut() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    uintptr_t m_flFOV() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
    uintptr_t m_nPathIndex() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_szParentPathUniqueID() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_vInTangentLocal() { return SCHEMA_TYPE(uintptr_t, 0x614); }
    uintptr_t m_vInTangentWorld() { return SCHEMA_TYPE(uintptr_t, 0x63C); }
    uintptr_t m_vOutTangentLocal() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_vOutTangentWorld() { return SCHEMA_TYPE(uintptr_t, 0x648); }
};

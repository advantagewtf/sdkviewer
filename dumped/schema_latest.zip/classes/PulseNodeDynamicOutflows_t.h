#pragma once
#include <cstdint>
class PulseNodeDynamicOutflows_t {
public:
    uintptr_t m_Outflows() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

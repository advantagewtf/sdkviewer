#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGameRulesProxy {
public:
    uintptr_t baseAddr;
    C_CSGameRulesProxy(uintptr_t addr) : baseAddr(addr) {}
    C_CSGameRulesProxy() : baseAddr(0) {}
    C_CSGameRules* m_pGameRules() { return SCHEMA_TYPE(C_CSGameRules*, 0x5F8); }
};

#pragma once
class C_CSGameRules;

class C_CSGameRulesProxy  {
public:
    uintptr_t baseAddr;

    C_CSGameRulesProxy() : baseAddr(0) {}
    C_CSGameRulesProxy(uintptr_t base) : baseAddr(base) {}

};

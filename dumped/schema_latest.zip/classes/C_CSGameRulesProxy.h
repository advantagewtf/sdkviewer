#pragma once
#include <cstdint>
class C_CSGameRulesProxy {
public:
    uintptr_t /* C_CSGameRules* */ m_pGameRules() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

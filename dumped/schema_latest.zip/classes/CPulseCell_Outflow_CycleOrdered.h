#pragma once
#include "../types/Vector3.h"

class CPulseCell_Outflow_CycleOrdered  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleOrdered() : baseAddr(0) {}
    CPulseCell_Outflow_CycleOrdered(uintptr_t base) : baseAddr(base) {}

};

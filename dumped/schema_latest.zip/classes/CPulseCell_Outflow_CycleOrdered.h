#pragma once
#include "../memory.h"

class CPulseCell_Outflow_CycleOrdered {
public:
 uintptr_t baseAddr;
 CPulseCell_Outflow_CycleOrdered() : baseAddr(0){}
 CPulseCell_Outflow_CycleOrdered(uintptr_t b):baseAddr(b){}
 uintptr_t m_Outputs(){return SCHEMA_TYPE(uintptr_t,0x48);}
};

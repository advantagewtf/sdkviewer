#pragma once
#include <cstdint>
class CPulseCell_Outflow_CycleOrdered {
public:
    uintptr_t m_Outputs() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Outflow_CycleOrdered {
public:
    uintptr_t baseAddr;
    CPulseCell_Outflow_CycleOrdered(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Outflow_CycleOrdered() : baseAddr(0) {}
    uintptr_t m_Outputs() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

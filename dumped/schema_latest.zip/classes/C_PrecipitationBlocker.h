#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PrecipitationBlocker : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_PrecipitationBlocker(uintptr_t addr) : baseAddr(addr) {}
    C_PrecipitationBlocker() : baseAddr(0) {}
};

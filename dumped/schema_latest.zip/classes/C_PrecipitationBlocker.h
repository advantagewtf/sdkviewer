#pragma once
#include "../memory.h"

class C_PrecipitationBlocker {
public:
 uintptr_t baseAddr;
 C_PrecipitationBlocker() : baseAddr(0){}
 C_PrecipitationBlocker(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
class C_PrecipitationBlocker : public C_BaseModelEntity {
public:
};

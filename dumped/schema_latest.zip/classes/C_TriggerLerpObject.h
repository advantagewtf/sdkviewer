#pragma once
#include <cstdint>
class C_TriggerLerpObject : public C_BaseTrigger {
public:
};

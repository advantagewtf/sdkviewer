#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TriggerLerpObject : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_TriggerLerpObject(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerLerpObject() : baseAddr(0) {}
};

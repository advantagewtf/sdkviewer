#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_SoundEventOBBEntity : public C_SoundEventEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventOBBEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventOBBEntity() : baseAddr(0) {}
    Vector3 m_vMaxs() { return SCHEMA_TYPE(Vector3, 0x6C4); }
    Vector3 m_vMins() { return SCHEMA_TYPE(Vector3, 0x6B8); }
};

#pragma once
#include "../types/Vector3.h"

class C_SoundEventOBBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventOBBEntity() : baseAddr(0) {}
    C_SoundEventOBBEntity(uintptr_t base) : baseAddr(base) {}

};

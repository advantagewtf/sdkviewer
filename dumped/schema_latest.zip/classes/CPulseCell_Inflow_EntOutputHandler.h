#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_EntOutputHandler {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_EntOutputHandler(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_EntOutputHandler() : baseAddr(0) {}
    uintptr_t m_ExpectedParamType() { return SCHEMA_TYPE(uintptr_t, 0xA0); }
    uintptr_t m_SourceEntity() { return SCHEMA_TYPE(uintptr_t, 0x80); }
    uintptr_t m_SourceOutput() { return SCHEMA_TYPE(uintptr_t, 0x90); }
};

#pragma once
#include "../cstypes/PulseSymbol_t.h"
#include "../cstypes/uintptr_t.h"

class CPulseCell_Inflow_EntOutputHandler  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_EntOutputHandler() : baseAddr(0) {}
    CPulseCell_Inflow_EntOutputHandler(uintptr_t base) : baseAddr(base) {}

};

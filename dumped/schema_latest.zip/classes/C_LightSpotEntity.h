#pragma once
#include <cstdint>
class C_LightSpotEntity : public C_LightEntity {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_LightSpotEntity : public C_LightEntity {
public:
    uintptr_t baseAddr;
    C_LightSpotEntity(uintptr_t addr) : baseAddr(addr) {}
    C_LightSpotEntity() : baseAddr(0) {}
};

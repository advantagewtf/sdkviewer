#pragma once
#include "../cstypes/EntComponentInfo_t.h"

class CEntityComponentHelper  {
public:
    uintptr_t baseAddr;

    CEntityComponentHelper() : baseAddr(0) {}
    CEntityComponentHelper(uintptr_t base) : baseAddr(base) {}

    int m_flags() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPriority() { return SCHEMA_TYPE(int, 0x20); }
};

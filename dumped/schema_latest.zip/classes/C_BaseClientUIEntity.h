#pragma once
#include "../cstypes/uintptr_t.h"

class C_BaseClientUIEntity  {
public:
    uintptr_t baseAddr;

    C_BaseClientUIEntity() : baseAddr(0) {}
    C_BaseClientUIEntity(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_BaseClientUIEntity(uintptr_t addr) : baseAddr(addr) {}
    C_BaseClientUIEntity() : baseAddr(0) {}
    string_t m_DialogXMLName() { return SCHEMA_TYPE(string_t, 0xEC0); }
    string_t m_PanelClassName() { return SCHEMA_TYPE(string_t, 0xEC8); }
    string_t m_PanelID() { return SCHEMA_TYPE(string_t, 0xED0); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEB8); }
};

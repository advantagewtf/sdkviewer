#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_BaseClientUIEntity {
public:
    uintptr_t baseAddr;
    C_BaseClientUIEntity(uintptr_t addr) : baseAddr(addr) {}
    C_BaseClientUIEntity() : baseAddr(0) {}
    string_t m_DialogXMLName() { return SCHEMA_TYPE(string_t, 0xE98); }
    string_t m_PanelClassName() { return SCHEMA_TYPE(string_t, 0xEA0); }
    string_t m_PanelID() { return SCHEMA_TYPE(string_t, 0xEA8); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xE90); }
};

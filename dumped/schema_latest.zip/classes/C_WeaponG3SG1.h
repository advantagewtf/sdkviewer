#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponG3SG1 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponG3SG1(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponG3SG1() : baseAddr(0) {}
};

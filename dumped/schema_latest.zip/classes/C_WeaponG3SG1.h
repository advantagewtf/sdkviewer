#pragma once
#include <cstdint>
class C_WeaponG3SG1 : public C_CSWeaponBaseGun {
public:
};

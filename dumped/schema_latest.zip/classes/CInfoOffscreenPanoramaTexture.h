#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/string_t.h"
class CInfoOffscreenPanoramaTexture {
public:
    string_t m_RenderAttrName() { return SCHEMA_TYPE(string_t, 0x610); }
    CHandle<C_BaseModelEntity> m_TargetEntities() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0x618); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0x7B0); }
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0x5F8); }
    int32_t m_nResolutionX() { return SCHEMA_TYPE(int32_t, 0x5FC); }
    int32_t m_nResolutionY() { return SCHEMA_TYPE(int32_t, 0x600); }
    int32_t m_nTargetChangeCount() { return SCHEMA_TYPE(int32_t, 0x630); }
    string_t m_szLayoutFileName() { return SCHEMA_TYPE(string_t, 0x608); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x638); }
};

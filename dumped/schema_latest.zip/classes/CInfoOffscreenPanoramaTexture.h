#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/string_t.h"
class C_BaseModelEntity;
class CInfoOffscreenPanoramaTexture {
public:
    uintptr_t baseAddr;
    CInfoOffscreenPanoramaTexture(uintptr_t addr) : baseAddr(addr) {}
    CInfoOffscreenPanoramaTexture() : baseAddr(0) {}
    uintptr_t m_AdditionalTargetEntities() { return SCHEMA_TYPE(uintptr_t, 0x670); }
    string_t m_RenderAttrName() { return SCHEMA_TYPE(string_t, 0x628); }
    CHandle<C_BaseModelEntity> m_TargetEntities() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0x630); }
    uintptr_t m_bCheckCSSClasses() { return SCHEMA_TYPE(uintptr_t, 0x7E8); }
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0x608); }
    int32_t m_nResolutionX() { return SCHEMA_TYPE(int32_t, 0x60C); }
    int32_t m_nResolutionY() { return SCHEMA_TYPE(int32_t, 0x610); }
    int32_t m_nTargetChangeCount() { return SCHEMA_TYPE(int32_t, 0x648); }
    string_t m_szLayoutFileName() { return SCHEMA_TYPE(string_t, 0x620); }
    string_t m_szPanelType() { return SCHEMA_TYPE(string_t, 0x618); }
    uintptr_t m_szTargetsName() { return SCHEMA_TYPE(uintptr_t, 0x668); }
    string_t m_vecCSSClasses() { return SCHEMA_TYPE(string_t, 0x650); }
};

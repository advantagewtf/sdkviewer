#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CInfoOffscreenPanoramaTexture  {
public:
    uintptr_t baseAddr;

    CInfoOffscreenPanoramaTexture() : baseAddr(0) {}
    CInfoOffscreenPanoramaTexture(uintptr_t base) : baseAddr(base) {}

    int m_nResolutionX() { return SCHEMA_TYPE(int, 0x20); }
    int m_nResolutionY() { return SCHEMA_TYPE(int, 0x20); }
    int m_nTargetChangeCount() { return SCHEMA_TYPE(int, 0x20); }
};

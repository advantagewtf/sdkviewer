#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DecoyGrenade : public C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_DecoyGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_DecoyGrenade() : baseAddr(0) {}
};

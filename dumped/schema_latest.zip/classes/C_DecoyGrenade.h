#pragma once
#include <cstdint>
class C_DecoyGrenade : public C_BaseCSGrenade {
public:
};

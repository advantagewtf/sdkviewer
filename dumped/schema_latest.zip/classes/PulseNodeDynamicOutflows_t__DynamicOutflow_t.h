#pragma once
#include <cstdint>
class PulseNodeDynamicOutflows_t__DynamicOutflow_t {
public:
    uintptr_t m_Connection() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_OutflowID() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

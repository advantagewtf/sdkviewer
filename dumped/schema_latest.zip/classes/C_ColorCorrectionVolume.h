#pragma once
#include <cstdint>
class C_ColorCorrectionVolume : public C_BaseTrigger {
public:
    float m_FadeDuration() { return SCHEMA_TYPE(float, 0x1008); }
    uintptr_t m_LastEnterTime() { return SCHEMA_TYPE(uintptr_t, 0xFF4); }
    uintptr_t m_LastEnterWeight() { return SCHEMA_TYPE(uintptr_t, 0xFF0); }
    uintptr_t m_LastExitTime() { return SCHEMA_TYPE(uintptr_t, 0xFFC); }
    uintptr_t m_LastExitWeight() { return SCHEMA_TYPE(uintptr_t, 0xFF8); }
    float m_MaxWeight() { return SCHEMA_TYPE(float, 0x1004); }
    float m_Weight() { return SCHEMA_TYPE(float, 0x100C); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x1000); }
    uintptr_t /* char */ m_lookupFilename() { return SCHEMA_TYPE(uintptr_t, 0x1010); }
};

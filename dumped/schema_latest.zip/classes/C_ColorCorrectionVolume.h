#pragma once
#include "../cstypes/GameTime_t.h"

class C_ColorCorrectionVolume  {
public:
    uintptr_t baseAddr;

    C_ColorCorrectionVolume() : baseAddr(0) {}
    C_ColorCorrectionVolume(uintptr_t base) : baseAddr(base) {}

    float m_LastEnterWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_LastExitWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_MaxWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_FadeDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_Weight() { return SCHEMA_TYPE(float, 0x20); }
    char* m_lookupFilename() { return SCHEMA_TYPE(char*, 0x200); }
};

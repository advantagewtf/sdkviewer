#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_ColorCorrectionVolume : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_ColorCorrectionVolume(uintptr_t addr) : baseAddr(addr) {}
    C_ColorCorrectionVolume() : baseAddr(0) {}
    float m_FadeDuration() { return SCHEMA_TYPE(float, 0x1008); }
    uintptr_t m_LastEnterTime() { return SCHEMA_TYPE(uintptr_t, 0xFF4); }
    uintptr_t m_LastEnterWeight() { return SCHEMA_TYPE(uintptr_t, 0xFF0); }
    uintptr_t m_LastExitTime() { return SCHEMA_TYPE(uintptr_t, 0xFFC); }
    uintptr_t m_LastExitWeight() { return SCHEMA_TYPE(uintptr_t, 0xFF8); }
    float m_MaxWeight() { return SCHEMA_TYPE(float, 0x1004); }
    float m_Weight() { return SCHEMA_TYPE(float, 0x100C); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x1000); }
    char m_lookupFilename() { return SCHEMA_TYPE(char, 0x1010); }
};

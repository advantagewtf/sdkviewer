#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_ColorCorrectionVolume : public C_BaseTrigger {
public:
    uintptr_t baseAddr;
    C_ColorCorrectionVolume(uintptr_t addr) : baseAddr(addr) {}
    C_ColorCorrectionVolume() : baseAddr(0) {}
    float m_FadeDuration() { return SCHEMA_TYPE(float, 0xF70); }
    uintptr_t m_LastEnterTime() { return SCHEMA_TYPE(uintptr_t, 0xF5C); }
    uintptr_t m_LastEnterWeight() { return SCHEMA_TYPE(uintptr_t, 0xF58); }
    uintptr_t m_LastExitTime() { return SCHEMA_TYPE(uintptr_t, 0xF64); }
    uintptr_t m_LastExitWeight() { return SCHEMA_TYPE(uintptr_t, 0xF60); }
    float m_MaxWeight() { return SCHEMA_TYPE(float, 0xF6C); }
    float m_Weight() { return SCHEMA_TYPE(float, 0xF74); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xF68); }
    char m_lookupFilename() { return SCHEMA_TYPE(char, 0xF78); }
};

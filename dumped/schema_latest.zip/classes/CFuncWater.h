#pragma once
#include <cstdint>
class CFuncWater {
public:
    uintptr_t m_BuoyancyHelper() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

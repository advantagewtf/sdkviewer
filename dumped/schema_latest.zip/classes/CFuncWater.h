#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFuncWater {
public:
    uintptr_t baseAddr;
    CFuncWater(uintptr_t addr) : baseAddr(addr) {}
    CFuncWater() : baseAddr(0) {}
    uintptr_t m_BuoyancyHelper() { return SCHEMA_TYPE(uintptr_t, 0xE88); }
};

#pragma once
#include "../classes/CBuoyancyHelper.h"

class CFuncWater  {
public:
    uintptr_t baseAddr;

    CFuncWater() : baseAddr(0) {}
    CFuncWater(uintptr_t base) : baseAddr(base) {}

};

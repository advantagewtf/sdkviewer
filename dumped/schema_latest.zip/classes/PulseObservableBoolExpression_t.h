#pragma once
#include <cstdint>
class PulseObservableBoolExpression_t {
public:
    uintptr_t m_DependentObservableBlackboardReferences() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    uintptr_t m_DependentObservableVars() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_EvaluateConnection() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponMP9 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponMP9(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponMP9() : baseAddr(0) {}
};

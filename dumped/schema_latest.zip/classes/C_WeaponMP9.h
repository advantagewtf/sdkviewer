#pragma once
#include <cstdint>
class C_WeaponMP9 : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Item_Healthshot {
public:
    uintptr_t baseAddr;
    C_Item_Healthshot(uintptr_t addr) : baseAddr(addr) {}
    C_Item_Healthshot() : baseAddr(0) {}
};

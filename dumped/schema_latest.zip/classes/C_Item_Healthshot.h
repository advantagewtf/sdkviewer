#pragma once
#include <cstdint>
class C_Item_Healthshot {
public:
};

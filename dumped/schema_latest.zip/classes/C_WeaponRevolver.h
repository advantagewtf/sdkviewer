#pragma once
#include <cstdint>
class C_WeaponRevolver : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponRevolver : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponRevolver(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponRevolver() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CInfoFan;
class CountdownTimer;
class CTriggerFan {
public:
    uintptr_t baseAddr;
    CTriggerFan(uintptr_t addr) : baseAddr(addr) {}
    CTriggerFan() : baseAddr(0) {}
    CountdownTimer m_RampTimer() { return SCHEMA_TYPE(CountdownTimer, 0xFA0); }
    bool m_bFalloff() { return SCHEMA_TYPE(bool, 0xF98); }
    bool m_bPushAwayFromInfoTarget() { return SCHEMA_TYPE(bool, 0xF71); }
    bool m_bPushTowardsInfoTarget() { return SCHEMA_TYPE(bool, 0xF70); }
    float m_flForce() { return SCHEMA_TYPE(float, 0xF94); }
    CHandle<CInfoFan> m_hInfoFan() { return SCHEMA_TYPE(CHandle<CInfoFan>, 0xF90); }
    QAngle m_qNoiseDelta() { return SCHEMA_TYPE(QAngle, 0xF80); }
    Vector3 m_vDirection() { return SCHEMA_TYPE(Vector3, 0xF64); }
    Vector3 m_vFanOriginOffset() { return SCHEMA_TYPE(Vector3, 0xF58); }
};

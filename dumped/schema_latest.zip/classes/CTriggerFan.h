#pragma once
#include "../classes/CountdownTimer.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CInfoFan;

class CTriggerFan  {
public:
    uintptr_t baseAddr;

    CTriggerFan() : baseAddr(0) {}
    CTriggerFan(uintptr_t base) : baseAddr(base) {}

    float m_flForce() { return SCHEMA_TYPE(float, 0x20); }
};

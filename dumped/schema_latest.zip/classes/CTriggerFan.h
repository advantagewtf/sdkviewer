#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CInfoFan;
class CountdownTimer;
class CTriggerFan {
public:
    uintptr_t baseAddr;
    CTriggerFan(uintptr_t addr) : baseAddr(addr) {}
    CTriggerFan() : baseAddr(0) {}
    CountdownTimer m_RampTimer() { return SCHEMA_TYPE(CountdownTimer, 0x1030); }
    bool m_bFalloff() { return SCHEMA_TYPE(bool, 0x1028); }
    bool m_bPushAwayFromInfoTarget() { return SCHEMA_TYPE(bool, 0x1009); }
    bool m_bPushTowardsInfoTarget() { return SCHEMA_TYPE(bool, 0x1008); }
    float m_flForce() { return SCHEMA_TYPE(float, 0x1024); }
    CHandle<CInfoFan> m_hInfoFan() { return SCHEMA_TYPE(CHandle<CInfoFan>, 0x1020); }
    QAngle m_qNoiseDelta() { return SCHEMA_TYPE(QAngle, 0x1010); }
    Vector3 m_vDirection() { return SCHEMA_TYPE(Vector3, 0xFFC); }
    Vector3 m_vFanOriginOffset() { return SCHEMA_TYPE(Vector3, 0xFF0); }
};

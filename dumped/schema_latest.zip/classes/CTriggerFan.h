#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
#include "CInfoFan.h"
class CTriggerFan {
public:
    uintptr_t /* CountdownTimer */ m_RampTimer() { return SCHEMA_TYPE(uintptr_t, 0x1030); }
    bool m_bFalloff() { return SCHEMA_TYPE(bool, 0x1028); }
    bool m_bPushAwayFromInfoTarget() { return SCHEMA_TYPE(bool, 0x1009); }
    bool m_bPushTowardsInfoTarget() { return SCHEMA_TYPE(bool, 0x1008); }
    float m_flForce() { return SCHEMA_TYPE(float, 0x1024); }
    CHandle<CInfoFan> m_hInfoFan() { return SCHEMA_TYPE(CHandle<CInfoFan>, 0x1020); }
    QAngle m_qNoiseDelta() { return SCHEMA_TYPE(QAngle, 0x1010); }
    Vector3 m_vDirection() { return SCHEMA_TYPE(Vector3, 0xFFC); }
    Vector3 m_vFanOriginOffset() { return SCHEMA_TYPE(Vector3, 0xFF0); }
};

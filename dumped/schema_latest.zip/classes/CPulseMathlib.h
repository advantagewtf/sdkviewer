#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseMathlib {
public:
    uintptr_t baseAddr;
    CPulseMathlib(uintptr_t addr) : baseAddr(addr) {}
    CPulseMathlib() : baseAddr(0) {}
};

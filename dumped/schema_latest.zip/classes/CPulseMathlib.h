#pragma once
#include <cstdint>
class CPulseMathlib {
public:
};

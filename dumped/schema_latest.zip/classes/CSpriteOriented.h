#pragma once
#include <cstdint>
class CSpriteOriented {
public:
};

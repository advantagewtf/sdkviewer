#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CSpriteOriented {
public:
    uintptr_t baseAddr;
    CSpriteOriented(uintptr_t addr) : baseAddr(addr) {}
    CSpriteOriented() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CHostageRescueZone {
public:
    uintptr_t baseAddr;
    CHostageRescueZone(uintptr_t addr) : baseAddr(addr) {}
    CHostageRescueZone() : baseAddr(0) {}
};

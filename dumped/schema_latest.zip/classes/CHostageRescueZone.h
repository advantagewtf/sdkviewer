#pragma once
#include <cstdint>
class CHostageRescueZone {
public:
};

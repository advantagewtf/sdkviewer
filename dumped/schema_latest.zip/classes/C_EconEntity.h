#pragma once
#include "../classes/C_AttributeContainer.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CBaseAnimGraph;
class C_BaseEntity;

class C_EconEntity  {
public:
    uintptr_t baseAddr;

    C_EconEntity() : baseAddr(0) {}
    C_EconEntity(uintptr_t base) : baseAddr(base) {}

    float m_flFlexDelayTime() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t* m_flFlexDelayedWeight() { return SCHEMA_TYPE(uintptr_t*, 0x20); }
    int m_OriginalOwnerXuidLow() { return SCHEMA_TYPE(int, 0x20); }
    int m_OriginalOwnerXuidHigh() { return SCHEMA_TYPE(int, 0x20); }
    int m_nFallbackPaintKit() { return SCHEMA_TYPE(int, 0x20); }
    int m_nFallbackSeed() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFallbackWear() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFallbackStatTrak() { return SCHEMA_TYPE(int, 0x20); }
    int m_vecAttachedParticles() { return SCHEMA_TYPE(int, 0x20); }
    int m_iOldTeam() { return SCHEMA_TYPE(int, 0x20); }
    int m_nUnloadedModelIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_iNumOwnerValidationRetries() { return SCHEMA_TYPE(int, 0x20); }
};

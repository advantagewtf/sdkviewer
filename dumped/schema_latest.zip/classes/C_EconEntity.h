#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CAttributeContainer;
class C_EconEntity : public C_BaseFlex {
public:
    uintptr_t baseAddr;
    C_EconEntity(uintptr_t addr) : baseAddr(addr) {}
    C_EconEntity() : baseAddr(0) {}
    CAttributeContainer m_AttributeManager() { return SCHEMA_TYPE(CAttributeContainer, 0x1378); }
    uint32_t m_OriginalOwnerXuidHigh() { return SCHEMA_TYPE(uint32_t, 0x184C); }
    uint32_t m_OriginalOwnerXuidLow() { return SCHEMA_TYPE(uint32_t, 0x1848); }
    uintptr_t m_bAttachmentDirty() { return SCHEMA_TYPE(uintptr_t, 0x1888); }
    uintptr_t m_bAttributesInitialized() { return SCHEMA_TYPE(uintptr_t, 0x1370); }
    uintptr_t m_bClientside() { return SCHEMA_TYPE(uintptr_t, 0x1860); }
    uintptr_t m_bParticleSystemsCreated() { return SCHEMA_TYPE(uintptr_t, 0x1861); }
    float m_flFallbackWear() { return SCHEMA_TYPE(float, 0x1858); }
    uintptr_t m_flFlexDelayTime() { return SCHEMA_TYPE(uintptr_t, 0x1360); }
    uintptr_t m_flFlexDelayedWeight() { return SCHEMA_TYPE(uintptr_t, 0x1368); }
    uintptr_t m_hOldProvidee() { return SCHEMA_TYPE(uintptr_t, 0x18A0); }
    uintptr_t m_hViewmodelAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1880); }
    uintptr_t m_iNumOwnerValidationRetries() { return SCHEMA_TYPE(uintptr_t, 0x1890); }
    uintptr_t m_iOldTeam() { return SCHEMA_TYPE(uintptr_t, 0x1884); }
    int32_t m_nFallbackPaintKit() { return SCHEMA_TYPE(int32_t, 0x1850); }
    int32_t m_nFallbackSeed() { return SCHEMA_TYPE(int32_t, 0x1854); }
    int32_t m_nFallbackStatTrak() { return SCHEMA_TYPE(int32_t, 0x185C); }
    uintptr_t m_nUnloadedModelIndex() { return SCHEMA_TYPE(uintptr_t, 0x188C); }
    uintptr_t m_vecAttachedModels() { return SCHEMA_TYPE(uintptr_t, 0x18A8); }
    uintptr_t m_vecAttachedParticles() { return SCHEMA_TYPE(uintptr_t, 0x1868); }
};

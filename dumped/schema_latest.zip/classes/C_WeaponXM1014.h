#pragma once
#include <cstdint>
class C_WeaponXM1014 : public C_CSWeaponBaseShotgun {
public:
};

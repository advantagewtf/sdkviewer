#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponXM1014 : public C_CSWeaponBaseShotgun {
public:
    uintptr_t baseAddr;
    C_WeaponXM1014(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponXM1014() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Item : public C_EconEntity {
public:
    uintptr_t baseAddr;
    C_Item(uintptr_t addr) : baseAddr(addr) {}
    C_Item() : baseAddr(0) {}
    uintptr_t m_pReticleHintTextName() { return SCHEMA_TYPE(uintptr_t, 0x18E0); }
};

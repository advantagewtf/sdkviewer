#pragma once
#include <cstdint>
class C_Item : public C_EconEntity {
public:
    uintptr_t m_pReticleHintTextName() { return SCHEMA_TYPE(uintptr_t, 0x18E0); }
};

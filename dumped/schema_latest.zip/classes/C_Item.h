#pragma once

class C_Item  {
public:
    uintptr_t baseAddr;

    C_Item() : baseAddr(0) {}
    C_Item(uintptr_t base) : baseAddr(base) {}

    char* m_pReticleHintTextName() { return SCHEMA_TYPE(char*, 0x100); }
};

#pragma once
#include <cstdint>
class CCSPlayer_ActionTrackingServices {
public:
    bool m_bIsRescuing() { return SCHEMA_TYPE(bool, 0x44); }
    uintptr_t m_hLastWeaponBeforeC4AutoSwitch() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* WeaponPurchaseTracker_t */ m_weaponPurchasesThisMatch() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t /* WeaponPurchaseTracker_t */ m_weaponPurchasesThisRound() { return SCHEMA_TYPE(uintptr_t, 0xB8); }
};

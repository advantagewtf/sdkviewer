#pragma once
#include "../cstypes/WeaponPurchaseTracker_t.h"
class C_BasePlayerWeapon;

class CCSPlayer_ActionTrackingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_ActionTrackingServices() : baseAddr(0) {}
    CCSPlayer_ActionTrackingServices(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class WeaponPurchaseTracker_t;
class CCSPlayer_ActionTrackingServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_ActionTrackingServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_ActionTrackingServices() : baseAddr(0) {}
    bool m_bIsRescuing() { return SCHEMA_TYPE(bool, 0x4C); }
    uintptr_t m_hLastWeaponBeforeC4AutoSwitch() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    WeaponPurchaseTracker_t m_weaponPurchasesThisMatch() { return SCHEMA_TYPE(WeaponPurchaseTracker_t, 0x50); }
    WeaponPurchaseTracker_t m_weaponPurchasesThisRound() { return SCHEMA_TYPE(WeaponPurchaseTracker_t, 0xC0); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CInfoInteraction {
public:
    uintptr_t baseAddr;
    CInfoInteraction(uintptr_t addr) : baseAddr(addr) {}
    CInfoInteraction() : baseAddr(0) {}
    uintptr_t m_flInteractRadius() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    uintptr_t m_strInteractVData() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    uintptr_t m_strSlotEntityName() { return SCHEMA_TYPE(uintptr_t, 0x608); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponFamas : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponFamas(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponFamas() : baseAddr(0) {}
};

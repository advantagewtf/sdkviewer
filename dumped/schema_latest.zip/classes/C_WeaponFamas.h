#pragma once
#include <cstdint>
class C_WeaponFamas : public C_CSWeaponBaseGun {
public:
};

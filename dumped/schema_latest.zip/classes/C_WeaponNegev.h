#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponNegev : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponNegev(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponNegev() : baseAddr(0) {}
};

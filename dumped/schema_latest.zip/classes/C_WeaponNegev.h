#pragma once
#include <cstdint>
class C_WeaponNegev : public C_CSWeaponBaseGun {
public:
};

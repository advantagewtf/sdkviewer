#pragma once
#include "../memory.h"

class C_WeaponNegev {
public:
 uintptr_t baseAddr;
 C_WeaponNegev() : baseAddr(0){}
 C_WeaponNegev(uintptr_t b):baseAddr(b){}
};

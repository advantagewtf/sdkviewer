#pragma once
#include <cstdint>
class C_SoundEventPathCornerEntity : public C_SoundEventEntity {
public:
    uintptr_t /* SoundeventPathCornerPairNetworked_t */ m_vecCornerPairsNetworked() { return SCHEMA_TYPE(uintptr_t, 0x6C0); }
};

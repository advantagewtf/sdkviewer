#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class SoundeventPathCornerPairNetworked_t;
class C_SoundEventPathCornerEntity : public C_SoundEventEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventPathCornerEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventPathCornerEntity() : baseAddr(0) {}
    SoundeventPathCornerPairNetworked_t m_vecCornerPairsNetworked() { return SCHEMA_TYPE(SoundeventPathCornerPairNetworked_t, 0x6C0); }
};

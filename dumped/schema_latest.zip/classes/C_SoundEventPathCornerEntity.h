#pragma once
#include "../types/Vector3.h"

class C_SoundEventPathCornerEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventPathCornerEntity() : baseAddr(0) {}
    C_SoundEventPathCornerEntity(uintptr_t base) : baseAddr(base) {}

};

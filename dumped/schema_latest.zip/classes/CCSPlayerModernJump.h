#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTick_t;
class CCSPlayerModernJump {
public:
    uintptr_t baseAddr;
    CCSPlayerModernJump(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerModernJump() : baseAddr(0) {}
    float m_flLastActualJumpPressFrac() { return SCHEMA_TYPE(float, 0x14); }
    float m_flLastLandedFrac() { return SCHEMA_TYPE(float, 0x24); }
    float m_flLastLandedVelocityX() { return SCHEMA_TYPE(float, 0x28); }
    float m_flLastLandedVelocityY() { return SCHEMA_TYPE(float, 0x2C); }
    float m_flLastLandedVelocityZ() { return SCHEMA_TYPE(float, 0x30); }
    float m_flLastUsableJumpPressFrac() { return SCHEMA_TYPE(float, 0x1C); }
    GameTick_t m_nLastActualJumpPressTick() { return SCHEMA_TYPE(GameTick_t, 0x10); }
    GameTick_t m_nLastLandedTick() { return SCHEMA_TYPE(GameTick_t, 0x20); }
    GameTick_t m_nLastUsableJumpPressTick() { return SCHEMA_TYPE(GameTick_t, 0x18); }
};

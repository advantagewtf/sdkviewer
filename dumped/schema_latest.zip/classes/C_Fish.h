#pragma once
#include "../classes/CountdownTimer.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class C_Fish  {
public:
    uintptr_t baseAddr;

    C_Fish() : baseAddr(0) {}
    C_Fish(uintptr_t base) : baseAddr(base) {}

    int m_localLifeState() { return SCHEMA_TYPE(int, 0x20); }
    float m_deathDepth() { return SCHEMA_TYPE(float, 0x20); }
    float m_deathAngle() { return SCHEMA_TYPE(float, 0x20); }
    float m_buoyancy() { return SCHEMA_TYPE(float, 0x20); }
    float m_wigglePhase() { return SCHEMA_TYPE(float, 0x20); }
    float m_wiggleRate() { return SCHEMA_TYPE(float, 0x20); }
    float m_waterLevel() { return SCHEMA_TYPE(float, 0x20); }
    float m_x() { return SCHEMA_TYPE(float, 0x20); }
    float m_y() { return SCHEMA_TYPE(float, 0x20); }
    float m_z() { return SCHEMA_TYPE(float, 0x20); }
    float m_angle() { return SCHEMA_TYPE(float, 0x20); }
    float m_errorHistory() { return SCHEMA_TYPE(float, 0x20); }
    int m_errorHistoryIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_errorHistoryCount() { return SCHEMA_TYPE(int, 0x20); }
    float m_averageError() { return SCHEMA_TYPE(float, 0x20); }
};

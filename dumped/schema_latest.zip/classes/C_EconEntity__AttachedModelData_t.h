#pragma once
#include <cstdint>
class C_EconEntity__AttachedModelData_t {
public:
    uintptr_t m_iModelDisplayFlags() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

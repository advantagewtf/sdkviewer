#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_DamageReactServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_DamageReactServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_DamageReactServices() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CCSPlayer_DamageReactServices {
public:
};

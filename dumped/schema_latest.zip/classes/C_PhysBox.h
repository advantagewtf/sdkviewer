#pragma once
#include <cstdint>
class C_PhysBox : public C_Breakable {
public:
};

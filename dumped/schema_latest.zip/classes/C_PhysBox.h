#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PhysBox : public C_Breakable {
public:
    uintptr_t baseAddr;
    C_PhysBox(uintptr_t addr) : baseAddr(addr) {}
    C_PhysBox() : baseAddr(0) {}
};

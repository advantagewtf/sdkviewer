#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundEventEntityAlias_snd_event_point : public C_SoundEventEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventEntityAlias_snd_event_point(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventEntityAlias_snd_event_point() : baseAddr(0) {}
};

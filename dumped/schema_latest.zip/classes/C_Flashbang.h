#pragma once
#include <cstdint>
class C_Flashbang : public C_BaseCSGrenade {
public:
};

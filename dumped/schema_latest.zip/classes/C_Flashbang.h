#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Flashbang : public C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_Flashbang(uintptr_t addr) : baseAddr(addr) {}
    C_Flashbang() : baseAddr(0) {}
};

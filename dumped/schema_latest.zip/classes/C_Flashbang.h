#pragma once
#include "../memory.h"

class C_Flashbang {
public:
 uintptr_t baseAddr;
 C_Flashbang() : baseAddr(0){}
 C_Flashbang(uintptr_t b):baseAddr(b){}
};

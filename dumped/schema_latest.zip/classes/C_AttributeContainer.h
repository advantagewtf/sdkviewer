#pragma once
#include "../classes/C_EconItemView.h"
#include "../cstypes/uintptr_t.h"

class C_AttributeContainer  {
public:
    uintptr_t baseAddr;

    C_AttributeContainer() : baseAddr(0) {}
    C_AttributeContainer(uintptr_t base) : baseAddr(base) {}

    int m_iExternalItemProviderRegisteredToken() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_ullRegisteredAsItemID() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEconItemView;
class C_AttributeContainer : public CAttributeManager {
public:
    uintptr_t baseAddr;
    C_AttributeContainer(uintptr_t addr) : baseAddr(addr) {}
    C_AttributeContainer() : baseAddr(0) {}
    CEconItemView m_Item() { return SCHEMA_TYPE(CEconItemView, 0x50); }
    uintptr_t m_iExternalItemProviderRegisteredToken() { return SCHEMA_TYPE(uintptr_t, 0x4C8); }
    uintptr_t m_ullRegisteredAsItemID() { return SCHEMA_TYPE(uintptr_t, 0x4D0); }
};

#pragma once
#include <cstdint>
class C_AttributeContainer : public CAttributeManager {
public:
    uintptr_t /* CEconItemView */ m_Item() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_iExternalItemProviderRegisteredToken() { return SCHEMA_TYPE(uintptr_t, 0x4C8); }
    uintptr_t m_ullRegisteredAsItemID() { return SCHEMA_TYPE(uintptr_t, 0x4D0); }
};

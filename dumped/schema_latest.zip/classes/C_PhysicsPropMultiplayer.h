#pragma once
#include <cstdint>
class C_PhysicsPropMultiplayer : public C_PhysicsProp {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PhysicsPropMultiplayer : public C_PhysicsProp {
public:
    uintptr_t baseAddr;
    C_PhysicsPropMultiplayer(uintptr_t addr) : baseAddr(addr) {}
    C_PhysicsPropMultiplayer() : baseAddr(0) {}
};

#pragma once
#include "../types/Vector3.h"

class C_ColorCorrection  {
public:
    uintptr_t baseAddr;

    C_ColorCorrection() : baseAddr(0) {}
    C_ColorCorrection(uintptr_t base) : baseAddr(base) {}

    float m_MinFalloff() { return SCHEMA_TYPE(float, 0x20); }
    float m_MaxFalloff() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeInDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeOutDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurWeight() { return SCHEMA_TYPE(float, 0x20); }
    char* m_netlookupFilename() { return SCHEMA_TYPE(char*, 0x200); }
    bool m_bEnabledOnClient() { return SCHEMA_TYPE(bool, 0x1); }
    float m_flCurWeightOnClient() { return SCHEMA_TYPE(float, 0x20); }
    bool m_bFadingIn() { return SCHEMA_TYPE(bool, 0x1); }
    float m_flFadeStartWeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeDuration() { return SCHEMA_TYPE(float, 0x20); }
};

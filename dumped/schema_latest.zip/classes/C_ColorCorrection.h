#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class C_ColorCorrection : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_ColorCorrection(uintptr_t addr) : baseAddr(addr) {}
    C_ColorCorrection() : baseAddr(0) {}
    float32 m_MaxFalloff() { return SCHEMA_TYPE(float32, 0x608); }
    float32 m_MinFalloff() { return SCHEMA_TYPE(float32, 0x604); }
    bool m_bClientSide() { return SCHEMA_TYPE(bool, 0x81E); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x81C); }
    uintptr_t m_bEnabledOnClient() { return SCHEMA_TYPE(uintptr_t, 0x820); }
    bool m_bExclusive() { return SCHEMA_TYPE(bool, 0x81F); }
    uintptr_t m_bFadingIn() { return SCHEMA_TYPE(uintptr_t, 0x828); }
    bool m_bMaster() { return SCHEMA_TYPE(bool, 0x81D); }
    float32 m_flCurWeight() { return SCHEMA_TYPE(float32, 0x618); }
    uintptr_t m_flCurWeightOnClient() { return SCHEMA_TYPE(uintptr_t, 0x824); }
    uintptr_t m_flFadeDuration() { return SCHEMA_TYPE(uintptr_t, 0x834); }
    float32 m_flFadeInDuration() { return SCHEMA_TYPE(float32, 0x60C); }
    float32 m_flFadeOutDuration() { return SCHEMA_TYPE(float32, 0x610); }
    uintptr_t m_flFadeStartTime() { return SCHEMA_TYPE(uintptr_t, 0x830); }
    uintptr_t m_flFadeStartWeight() { return SCHEMA_TYPE(uintptr_t, 0x82C); }
    float32 m_flMaxWeight() { return SCHEMA_TYPE(float32, 0x614); }
    char m_netlookupFilename() { return SCHEMA_TYPE(char, 0x61C); }
    uintptr_t m_vecOrigin() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

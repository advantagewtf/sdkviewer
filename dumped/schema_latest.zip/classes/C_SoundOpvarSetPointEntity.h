#pragma once
#include <cstdint>
class C_SoundOpvarSetPointEntity : public C_SoundOpvarSetPointBase {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetPointEntity : public C_SoundOpvarSetPointBase {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetPointEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetPointEntity() : baseAddr(0) {}
};

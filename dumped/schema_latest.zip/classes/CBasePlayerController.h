#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBasePlayerPawn;
class PlayerConnectedState;
class CBasePlayerController {
public:
    uintptr_t baseAddr;
    CBasePlayerController(uintptr_t addr) : baseAddr(addr) {}
    CBasePlayerController() : baseAddr(0) {}
    uintptr_t m_CommandContext() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_bIsHLTV() { return SCHEMA_TYPE(uintptr_t, 0x6F0); }
    uintptr_t m_bIsLocalPlayerController() { return SCHEMA_TYPE(uintptr_t, 0x788); }
    bool m_bKnownTeamMismatch() { return SCHEMA_TYPE(bool, 0x6C8); }
    bool m_bNoClipEnabled() { return SCHEMA_TYPE(bool, 0x789); }
    CHandle<CBasePlayerPawn> m_hPawn() { return SCHEMA_TYPE(CHandle<CBasePlayerPawn>, 0x6C4); }
    uintptr_t m_hPredictedPawn() { return SCHEMA_TYPE(uintptr_t, 0x6CC); }
    uintptr_t m_hSplitOwner() { return SCHEMA_TYPE(uintptr_t, 0x6D4); }
    uintptr_t m_hSplitScreenPlayers() { return SCHEMA_TYPE(uintptr_t, 0x6D8); }
    PlayerConnectedState m_iConnected() { return SCHEMA_TYPE(PlayerConnectedState, 0x6F4); }
    uint32_t m_iDesiredFOV() { return SCHEMA_TYPE(uint32_t, 0x78C); }
    char m_iszPlayerName() { return SCHEMA_TYPE(char, 0x6F8); }
    uintptr_t m_nInButtonsWhichAreToggles() { return SCHEMA_TYPE(uintptr_t, 0x6B8); }
    uintptr_t m_nSplitScreenSlot() { return SCHEMA_TYPE(uintptr_t, 0x6D0); }
    uint32_t m_nTickBase() { return SCHEMA_TYPE(uint32_t, 0x6C0); }
    uint64_t m_steamID() { return SCHEMA_TYPE(uint64_t, 0x780); }
};

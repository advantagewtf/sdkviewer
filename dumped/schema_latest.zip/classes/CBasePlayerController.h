#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class C_BasePlayerPawn;

class CBasePlayerController  {
public:
    uintptr_t baseAddr;

    CBasePlayerController() : baseAddr(0) {}
    CBasePlayerController(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nInButtonsWhichAreToggles() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_nTickBase() { return SCHEMA_TYPE(int, 0x20); }
    char* m_iszPlayerName() { return SCHEMA_TYPE(char*, 0x80); }
    uintptr_t m_steamID() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_iDesiredFOV() { return SCHEMA_TYPE(int, 0x20); }
};

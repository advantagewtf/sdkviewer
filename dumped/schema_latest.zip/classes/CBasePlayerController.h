#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CBasePlayerController {
public:
    uintptr_t m_CommandContext() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_bIsHLTV() { return SCHEMA_TYPE(uintptr_t, 0x6E0); }
    uintptr_t m_bIsLocalPlayerController() { return SCHEMA_TYPE(uintptr_t, 0x778); }
    bool m_bKnownTeamMismatch() { return SCHEMA_TYPE(bool, 0x6B8); }
    bool m_bNoClipEnabled() { return SCHEMA_TYPE(bool, 0x779); }
    CHandle<CBasePlayerPawn> m_hPawn() { return SCHEMA_TYPE(CHandle<CBasePlayerPawn>, 0x6B4); }
    uintptr_t m_hPredictedPawn() { return SCHEMA_TYPE(uintptr_t, 0x6BC); }
    uintptr_t m_hSplitOwner() { return SCHEMA_TYPE(uintptr_t, 0x6C4); }
    uintptr_t m_hSplitScreenPlayers() { return SCHEMA_TYPE(uintptr_t, 0x6C8); }
    uintptr_t /* PlayerConnectedState */ m_iConnected() { return SCHEMA_TYPE(uintptr_t, 0x6E4); }
    uint32_t m_iDesiredFOV() { return SCHEMA_TYPE(uint32_t, 0x77C); }
    uintptr_t /* char */ m_iszPlayerName() { return SCHEMA_TYPE(uintptr_t, 0x6E8); }
    uintptr_t m_nInButtonsWhichAreToggles() { return SCHEMA_TYPE(uintptr_t, 0x6A8); }
    uintptr_t m_nSplitScreenSlot() { return SCHEMA_TYPE(uintptr_t, 0x6C0); }
    uint32_t m_nTickBase() { return SCHEMA_TYPE(uint32_t, 0x6B0); }
    uint64_t m_steamID() { return SCHEMA_TYPE(uint64_t, 0x770); }
};

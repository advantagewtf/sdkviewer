#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
class CCSPlayerController_ActionTrackingServices;
class CCSPlayerController_DamageServices;
class CCSPlayerController_InGameMoneyServices;
class CCSPlayerController_InventoryServices;
class C_CSObserverPawn;
class C_CSPlayerPawn;

class CCSPlayerController  {
public:
    uintptr_t baseAddr;

    CCSPlayerController() : baseAddr(0) {}
    CCSPlayerController(uintptr_t base) : baseAddr(base) {}

    int m_iPing() { return SCHEMA_TYPE(int, 0x20); }
    int m_uiCommunicationMuteFlags() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_iPendingTeamNum() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_iCompTeammateColor() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCoachingTeam() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_nPlayerDominated() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_nPlayerDominatingMe() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int m_iCompetitiveRanking() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCompetitiveWins() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_iCompetitiveRankType() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    int m_iCompetitiveRankingPredicted_Win() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCompetitiveRankingPredicted_Loss() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCompetitiveRankingPredicted_Tie() { return SCHEMA_TYPE(int, 0x20); }
    int m_nEndMatchNextMapVote() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_unActiveQuestId() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_rtActiveMissionPeriod() { return SCHEMA_TYPE(int, 0x20); }
    int m_unPlayerTvControlFlags() { return SCHEMA_TYPE(int, 0x20); }
    int m_iDraftIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_msQueuedModeDisconnectionTimestamp() { return SCHEMA_TYPE(int, 0x20); }
    int m_uiAbandonRecordedReason() { return SCHEMA_TYPE(int, 0x20); }
    int m_eNetworkDisconnectionReason() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDisconnectionTick() { return SCHEMA_TYPE(int, 0x20); }
    int m_nBotsControlledThisRound() { return SCHEMA_TYPE(int, 0x20); }
    int m_iPawnHealth() { return SCHEMA_TYPE(int, 0x20); }
    int m_iPawnArmor() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_nPawnCharacterDefIndex() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_iPawnLifetimeStart() { return SCHEMA_TYPE(int, 0x20); }
    int m_iPawnLifetimeEnd() { return SCHEMA_TYPE(int, 0x20); }
    int m_iPawnBotDifficulty() { return SCHEMA_TYPE(int, 0x20); }
    int m_iScore() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_recentKillQueue() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nFirstKill() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nKillCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_eMvpReason() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMusicKitID() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMusicKitMVPs() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMVPs() { return SCHEMA_TYPE(int, 0x20); }
};

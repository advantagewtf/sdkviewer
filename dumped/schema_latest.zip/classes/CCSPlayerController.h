#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/string_t.h"
#include "CCSPlayerController.h"
class CCSPlayerController : public CBasePlayerController {
public:
    uintptr_t m_bAbandonAllowsSurrender() { return SCHEMA_TYPE(uintptr_t, 0x8DA); }
    uintptr_t m_bAbandonOffersInstantSurrender() { return SCHEMA_TYPE(uintptr_t, 0x8DB); }
    bool m_bCanControlObservedBot() { return SCHEMA_TYPE(bool, 0x8F8); }
    uintptr_t m_bCannotBeKicked() { return SCHEMA_TYPE(uintptr_t, 0x8D8); }
    bool m_bControllingBot() { return SCHEMA_TYPE(bool, 0x8F0); }
    uintptr_t m_bDisconnection1MinWarningPrinted() { return SCHEMA_TYPE(uintptr_t, 0x8DC); }
    uintptr_t m_bEverFullyConnected() { return SCHEMA_TYPE(uintptr_t, 0x8D9); }
    bool m_bEverPlayedOnTeam() { return SCHEMA_TYPE(bool, 0x83C); }
    bool m_bFireBulletsSeedSynchronized() { return SCHEMA_TYPE(bool, 0x945); }
    uintptr_t m_bHasBeenControlledByPlayerThisRound() { return SCHEMA_TYPE(uintptr_t, 0x8F2); }
    bool m_bHasCommunicationAbuseMute() { return SCHEMA_TYPE(bool, 0x81C); }
    bool m_bHasControlledBotThisRound() { return SCHEMA_TYPE(bool, 0x8F1); }
    uintptr_t m_bIsPlayerNameDirty() { return SCHEMA_TYPE(uintptr_t, 0x944); }
    bool m_bMvpNoMusic() { return SCHEMA_TYPE(bool, 0x932); }
    bool m_bPawnHasDefuser() { return SCHEMA_TYPE(bool, 0x910); }
    bool m_bPawnHasHelmet() { return SCHEMA_TYPE(bool, 0x911); }
    bool m_bPawnIsAlive() { return SCHEMA_TYPE(bool, 0x904); }
    uintptr_t m_bScoreReported() { return SCHEMA_TYPE(uintptr_t, 0x8DD); }
    int32_t m_eMvpReason() { return SCHEMA_TYPE(int32_t, 0x934); }
    uintptr_t m_eNetworkDisconnectionReason() { return SCHEMA_TYPE(uintptr_t, 0x8D4); }
    uintptr_t /* GameTime_t */ m_flForceTeamTime() { return SCHEMA_TYPE(uintptr_t, 0x834); }
    uintptr_t m_flPreviousForceJoinTeamTime() { return SCHEMA_TYPE(uintptr_t, 0x840); }
    CHandle<CCSObserverPawn> m_hObserverPawn() { return SCHEMA_TYPE(CHandle<CCSObserverPawn>, 0x900); }
    CHandle<CCSPlayerController> m_hOriginalControllerOfCurrentPawn() { return SCHEMA_TYPE(CHandle<CCSPlayerController>, 0x920); }
    CHandle<CCSPlayerPawn> m_hPlayerPawn() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x8FC); }
    int32_t m_iCoachingTeam() { return SCHEMA_TYPE(int32_t, 0x858); }
    int32_t m_iCompTeammateColor() { return SCHEMA_TYPE(int32_t, 0x838); }
    uintptr_t /* int8 */ m_iCompetitiveRankType() { return SCHEMA_TYPE(uintptr_t, 0x878); }
    int32_t m_iCompetitiveRanking() { return SCHEMA_TYPE(int32_t, 0x870); }
    int32_t m_iCompetitiveRankingPredicted_Loss() { return SCHEMA_TYPE(int32_t, 0x880); }
    int32_t m_iCompetitiveRankingPredicted_Tie() { return SCHEMA_TYPE(int32_t, 0x884); }
    int32_t m_iCompetitiveRankingPredicted_Win() { return SCHEMA_TYPE(int32_t, 0x87C); }
    int32_t m_iCompetitiveWins() { return SCHEMA_TYPE(int32_t, 0x874); }
    uintptr_t m_iDraftIndex() { return SCHEMA_TYPE(uintptr_t, 0x8C8); }
    int32_t m_iMVPs() { return SCHEMA_TYPE(int32_t, 0x940); }
    int32_t m_iMusicKitID() { return SCHEMA_TYPE(int32_t, 0x938); }
    int32_t m_iMusicKitMVPs() { return SCHEMA_TYPE(int32_t, 0x93C); }
    int32_t m_iPawnArmor() { return SCHEMA_TYPE(int32_t, 0x90C); }
    int32_t m_iPawnBotDifficulty() { return SCHEMA_TYPE(int32_t, 0x91C); }
    uint32_t m_iPawnHealth() { return SCHEMA_TYPE(uint32_t, 0x908); }
    int32_t m_iPawnLifetimeEnd() { return SCHEMA_TYPE(int32_t, 0x918); }
    int32_t m_iPawnLifetimeStart() { return SCHEMA_TYPE(int32_t, 0x914); }
    uint8_t m_iPendingTeamNum() { return SCHEMA_TYPE(uint8_t, 0x830); }
    uint32_t m_iPing() { return SCHEMA_TYPE(uint32_t, 0x818); }
    int32_t m_iScore() { return SCHEMA_TYPE(int32_t, 0x924); }
    uintptr_t m_msQueuedModeDisconnectionTimestamp() { return SCHEMA_TYPE(uintptr_t, 0x8CC); }
    uintptr_t m_nBotsControlledThisRound() { return SCHEMA_TYPE(uintptr_t, 0x8F4); }
    int32_t m_nDisconnectionTick() { return SCHEMA_TYPE(int32_t, 0x8E0); }
    int32_t m_nEndMatchNextMapVote() { return SCHEMA_TYPE(int32_t, 0x888); }
    uint8_t m_nFirstKill() { return SCHEMA_TYPE(uint8_t, 0x930); }
    uint8_t m_nKillCount() { return SCHEMA_TYPE(uint8_t, 0x931); }
    uintptr_t /* item_definition_index_t */ m_nPawnCharacterDefIndex() { return SCHEMA_TYPE(uintptr_t, 0x912); }
    uint64_t m_nPlayerDominated() { return SCHEMA_TYPE(uint64_t, 0x860); }
    uint64_t m_nPlayerDominatingMe() { return SCHEMA_TYPE(uint64_t, 0x868); }
    uintptr_t /* QuestProgress::Reason */ m_nQuestProgressReason() { return SCHEMA_TYPE(uintptr_t, 0x894); }
    uintptr_t /* CCSPlayerController_ActionTrackingServices* */ m_pActionTrackingServices() { return SCHEMA_TYPE(uintptr_t, 0x808); }
    uintptr_t /* CCSPlayerController_DamageServices* */ m_pDamageServices() { return SCHEMA_TYPE(uintptr_t, 0x810); }
    uintptr_t /* CCSPlayerController_InGameMoneyServices* */ m_pInGameMoneyServices() { return SCHEMA_TYPE(uintptr_t, 0x7F8); }
    uintptr_t /* CCSPlayerController_InventoryServices* */ m_pInventoryServices() { return SCHEMA_TYPE(uintptr_t, 0x800); }
    uint8_t m_recentKillQueue() { return SCHEMA_TYPE(uint8_t, 0x928); }
    uintptr_t /* RTime32 */ m_rtActiveMissionPeriod() { return SCHEMA_TYPE(uintptr_t, 0x890); }
    uintptr_t m_sSanitizedPlayerName() { return SCHEMA_TYPE(uintptr_t, 0x850); }
    string_t m_szClan() { return SCHEMA_TYPE(string_t, 0x848); }
    string_t m_szCrosshairCodes() { return SCHEMA_TYPE(string_t, 0x828); }
    uintptr_t m_uiAbandonRecordedReason() { return SCHEMA_TYPE(uintptr_t, 0x8D0); }
    uint32_t m_uiCommunicationMuteFlags() { return SCHEMA_TYPE(uint32_t, 0x820); }
    uint16_t m_unActiveQuestId() { return SCHEMA_TYPE(uint16_t, 0x88C); }
    uint32_t m_unPlayerTvControlFlags() { return SCHEMA_TYPE(uint32_t, 0x898); }
};

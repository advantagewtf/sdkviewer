#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/string_t.h"
class CCSObserverPawn;
class CCSPlayerPawn;
class GameTime_t;
class QuestProgress__Reason;
class RTime32;
class int8;
class item_definition_index_t;
class CCSPlayerController : public CBasePlayerController {
public:
    uintptr_t baseAddr;
    CCSPlayerController(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerController() : baseAddr(0) {}
    uintptr_t m_bAbandonAllowsSurrender() { return SCHEMA_TYPE(uintptr_t, 0x8EA); }
    uintptr_t m_bAbandonOffersInstantSurrender() { return SCHEMA_TYPE(uintptr_t, 0x8EB); }
    bool m_bCanControlObservedBot() { return SCHEMA_TYPE(bool, 0x908); }
    uintptr_t m_bCannotBeKicked() { return SCHEMA_TYPE(uintptr_t, 0x8E8); }
    bool m_bControllingBot() { return SCHEMA_TYPE(bool, 0x900); }
    uintptr_t m_bDisconnection1MinWarningPrinted() { return SCHEMA_TYPE(uintptr_t, 0x8EC); }
    uintptr_t m_bEverFullyConnected() { return SCHEMA_TYPE(uintptr_t, 0x8E9); }
    bool m_bEverPlayedOnTeam() { return SCHEMA_TYPE(bool, 0x84C); }
    bool m_bFireBulletsSeedSynchronized() { return SCHEMA_TYPE(bool, 0x955); }
    uintptr_t m_bHasBeenControlledByPlayerThisRound() { return SCHEMA_TYPE(uintptr_t, 0x902); }
    bool m_bHasCommunicationAbuseMute() { return SCHEMA_TYPE(bool, 0x82C); }
    bool m_bHasControlledBotThisRound() { return SCHEMA_TYPE(bool, 0x901); }
    uintptr_t m_bIsPlayerNameDirty() { return SCHEMA_TYPE(uintptr_t, 0x954); }
    bool m_bMvpNoMusic() { return SCHEMA_TYPE(bool, 0x942); }
    bool m_bPawnHasDefuser() { return SCHEMA_TYPE(bool, 0x920); }
    bool m_bPawnHasHelmet() { return SCHEMA_TYPE(bool, 0x921); }
    bool m_bPawnIsAlive() { return SCHEMA_TYPE(bool, 0x914); }
    uintptr_t m_bScoreReported() { return SCHEMA_TYPE(uintptr_t, 0x8ED); }
    int32_t m_eMvpReason() { return SCHEMA_TYPE(int32_t, 0x944); }
    uintptr_t m_eNetworkDisconnectionReason() { return SCHEMA_TYPE(uintptr_t, 0x8E4); }
    GameTime_t m_flForceTeamTime() { return SCHEMA_TYPE(GameTime_t, 0x844); }
    uintptr_t m_flPreviousForceJoinTeamTime() { return SCHEMA_TYPE(uintptr_t, 0x850); }
    CHandle<CCSObserverPawn> m_hObserverPawn() { return SCHEMA_TYPE(CHandle<CCSObserverPawn>, 0x910); }
    CHandle<CCSPlayerController> m_hOriginalControllerOfCurrentPawn() { return SCHEMA_TYPE(CHandle<CCSPlayerController>, 0x930); }
    CHandle<CCSPlayerPawn> m_hPlayerPawn() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x90C); }
    int32_t m_iCoachingTeam() { return SCHEMA_TYPE(int32_t, 0x868); }
    int32_t m_iCompTeammateColor() { return SCHEMA_TYPE(int32_t, 0x848); }
    int8 m_iCompetitiveRankType() { return SCHEMA_TYPE(int8, 0x888); }
    int32_t m_iCompetitiveRanking() { return SCHEMA_TYPE(int32_t, 0x880); }
    int32_t m_iCompetitiveRankingPredicted_Loss() { return SCHEMA_TYPE(int32_t, 0x890); }
    int32_t m_iCompetitiveRankingPredicted_Tie() { return SCHEMA_TYPE(int32_t, 0x894); }
    int32_t m_iCompetitiveRankingPredicted_Win() { return SCHEMA_TYPE(int32_t, 0x88C); }
    int32_t m_iCompetitiveWins() { return SCHEMA_TYPE(int32_t, 0x884); }
    uintptr_t m_iDraftIndex() { return SCHEMA_TYPE(uintptr_t, 0x8D8); }
    int32_t m_iMVPs() { return SCHEMA_TYPE(int32_t, 0x950); }
    int32_t m_iMusicKitID() { return SCHEMA_TYPE(int32_t, 0x948); }
    int32_t m_iMusicKitMVPs() { return SCHEMA_TYPE(int32_t, 0x94C); }
    int32_t m_iPawnArmor() { return SCHEMA_TYPE(int32_t, 0x91C); }
    int32_t m_iPawnBotDifficulty() { return SCHEMA_TYPE(int32_t, 0x92C); }
    uint32_t m_iPawnHealth() { return SCHEMA_TYPE(uint32_t, 0x918); }
    int32_t m_iPawnLifetimeEnd() { return SCHEMA_TYPE(int32_t, 0x928); }
    int32_t m_iPawnLifetimeStart() { return SCHEMA_TYPE(int32_t, 0x924); }
    uint8_t m_iPendingTeamNum() { return SCHEMA_TYPE(uint8_t, 0x840); }
    uint32_t m_iPing() { return SCHEMA_TYPE(uint32_t, 0x828); }
    int32_t m_iScore() { return SCHEMA_TYPE(int32_t, 0x934); }
    uintptr_t m_msQueuedModeDisconnectionTimestamp() { return SCHEMA_TYPE(uintptr_t, 0x8DC); }
    uintptr_t m_nBotsControlledThisRound() { return SCHEMA_TYPE(uintptr_t, 0x904); }
    int32_t m_nDisconnectionTick() { return SCHEMA_TYPE(int32_t, 0x8F0); }
    int32_t m_nEndMatchNextMapVote() { return SCHEMA_TYPE(int32_t, 0x898); }
    uint8_t m_nFirstKill() { return SCHEMA_TYPE(uint8_t, 0x940); }
    uint8_t m_nKillCount() { return SCHEMA_TYPE(uint8_t, 0x941); }
    item_definition_index_t m_nPawnCharacterDefIndex() { return SCHEMA_TYPE(item_definition_index_t, 0x922); }
    uint64_t m_nPlayerDominated() { return SCHEMA_TYPE(uint64_t, 0x870); }
    uint64_t m_nPlayerDominatingMe() { return SCHEMA_TYPE(uint64_t, 0x878); }
    QuestProgress__Reason m_nQuestProgressReason() { return SCHEMA_TYPE(QuestProgress__Reason, 0x8A4); }
    CCSPlayerController_ActionTrackingServices* m_pActionTrackingServices() { return SCHEMA_TYPE(CCSPlayerController_ActionTrackingServices*, 0x818); }
    CCSPlayerController_DamageServices* m_pDamageServices() { return SCHEMA_TYPE(CCSPlayerController_DamageServices*, 0x820); }
    CCSPlayerController_InGameMoneyServices* m_pInGameMoneyServices() { return SCHEMA_TYPE(CCSPlayerController_InGameMoneyServices*, 0x808); }
    CCSPlayerController_InventoryServices* m_pInventoryServices() { return SCHEMA_TYPE(CCSPlayerController_InventoryServices*, 0x810); }
    uint8_t m_recentKillQueue() { return SCHEMA_TYPE(uint8_t, 0x938); }
    RTime32 m_rtActiveMissionPeriod() { return SCHEMA_TYPE(RTime32, 0x8A0); }
    uintptr_t m_sSanitizedPlayerName() { return SCHEMA_TYPE(uintptr_t, 0x860); }
    string_t m_szClan() { return SCHEMA_TYPE(string_t, 0x858); }
    string_t m_szCrosshairCodes() { return SCHEMA_TYPE(string_t, 0x838); }
    uintptr_t m_uiAbandonRecordedReason() { return SCHEMA_TYPE(uintptr_t, 0x8E0); }
    uint32_t m_uiCommunicationMuteFlags() { return SCHEMA_TYPE(uint32_t, 0x830); }
    uint16_t m_unActiveQuestId() { return SCHEMA_TYPE(uint16_t, 0x89C); }
    uint32_t m_unPlayerTvControlFlags() { return SCHEMA_TYPE(uint32_t, 0x8A8); }
};

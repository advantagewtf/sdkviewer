#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class audioparams_t {
public:
    uint8_t localBits() { return SCHEMA_TYPE(uint8_t, 0x6C); }
    Vector3 localSound() { return SCHEMA_TYPE(Vector3, 0x8); }
    uint32_t soundEventHash() { return SCHEMA_TYPE(uint32_t, 0x74); }
    int32_t soundscapeEntityListIndex() { return SCHEMA_TYPE(int32_t, 0x70); }
    int32_t soundscapeIndex() { return SCHEMA_TYPE(int32_t, 0x68); }
};

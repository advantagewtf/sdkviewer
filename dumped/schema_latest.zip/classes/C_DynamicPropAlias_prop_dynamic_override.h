#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DynamicPropAlias_prop_dynamic_override : public C_DynamicProp {
public:
    uintptr_t baseAddr;
    C_DynamicPropAlias_prop_dynamic_override(uintptr_t addr) : baseAddr(addr) {}
    C_DynamicPropAlias_prop_dynamic_override() : baseAddr(0) {}
};

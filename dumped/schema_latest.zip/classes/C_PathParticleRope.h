#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class Color;
class HParticleSystemDefinitionStrong;
class C_PathParticleRope : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PathParticleRope(uintptr_t addr) : baseAddr(addr) {}
    C_PathParticleRope() : baseAddr(0) {}
    Color m_ColorTint() { return SCHEMA_TYPE(Color, 0x634); }
    Vector3 m_PathNodes_Color() { return SCHEMA_TYPE(Vector3, 0x690); }
    uintptr_t m_PathNodes_Name() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    bool m_PathNodes_PinEnabled() { return SCHEMA_TYPE(bool, 0x6A8); }
    Vector3 m_PathNodes_Position() { return SCHEMA_TYPE(Vector3, 0x648); }
    float m_PathNodes_RadiusScale() { return SCHEMA_TYPE(float, 0x6C0); }
    Vector3 m_PathNodes_TangentIn() { return SCHEMA_TYPE(Vector3, 0x660); }
    Vector3 m_PathNodes_TangentOut() { return SCHEMA_TYPE(Vector3, 0x678); }
    uintptr_t m_bStartActive() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_flMaxSimulationTime() { return SCHEMA_TYPE(uintptr_t, 0x604); }
    float m_flParticleSpacing() { return SCHEMA_TYPE(float, 0x628); }
    float m_flRadius() { return SCHEMA_TYPE(float, 0x630); }
    float m_flSlack() { return SCHEMA_TYPE(float, 0x62C); }
    HParticleSystemDefinitionStrong m_iEffectIndex() { return SCHEMA_TYPE(HParticleSystemDefinitionStrong, 0x640); }
    uintptr_t m_iszEffectName() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    int32_t m_nEffectState() { return SCHEMA_TYPE(int32_t, 0x638); }
};

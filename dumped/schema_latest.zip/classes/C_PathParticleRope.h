#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_PathParticleRope  {
public:
    uintptr_t baseAddr;

    C_PathParticleRope() : baseAddr(0) {}
    C_PathParticleRope(uintptr_t base) : baseAddr(base) {}

    float m_flMaxSimulationTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flParticleSpacing() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSlack() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_nEffectState() { return SCHEMA_TYPE(int, 0x20); }
    float m_PathNodes_RadiusScale() { return SCHEMA_TYPE(float, 0x20); }
};

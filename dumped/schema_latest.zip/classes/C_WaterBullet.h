#pragma once
#include <cstdint>
class C_WaterBullet : public CBaseAnimGraph {
public:
};

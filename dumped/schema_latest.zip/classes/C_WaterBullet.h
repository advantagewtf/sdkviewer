#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WaterBullet : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_WaterBullet(uintptr_t addr) : baseAddr(addr) {}
    C_WaterBullet() : baseAddr(0) {}
};

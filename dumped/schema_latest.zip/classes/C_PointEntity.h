#pragma once
#include <cstdint>
class C_PointEntity : public C_BaseEntity {
public:
};

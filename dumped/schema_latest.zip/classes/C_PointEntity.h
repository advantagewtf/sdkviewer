#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PointEntity : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PointEntity(uintptr_t addr) : baseAddr(addr) {}
    C_PointEntity() : baseAddr(0) {}
};

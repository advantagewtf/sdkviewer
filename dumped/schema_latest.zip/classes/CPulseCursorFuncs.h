#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCursorFuncs {
public:
    uintptr_t baseAddr;
    CPulseCursorFuncs(uintptr_t addr) : baseAddr(addr) {}
    CPulseCursorFuncs() : baseAddr(0) {}
};

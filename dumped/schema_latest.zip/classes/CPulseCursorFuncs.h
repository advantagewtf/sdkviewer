#pragma once
#include <cstdint>
class CPulseCursorFuncs {
public:
};

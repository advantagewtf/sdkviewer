#pragma once
#include "../classes/CBaseAnimGraphController.h"

class CBodyComponentBaseAnimGraph  {
public:
    uintptr_t baseAddr;

    CBodyComponentBaseAnimGraph() : baseAddr(0) {}
    CBodyComponentBaseAnimGraph(uintptr_t base) : baseAddr(base) {}

};

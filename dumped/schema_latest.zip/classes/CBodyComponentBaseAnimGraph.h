#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBaseAnimGraphController;
class CBodyComponentBaseAnimGraph {
public:
    uintptr_t baseAddr;
    CBodyComponentBaseAnimGraph(uintptr_t addr) : baseAddr(addr) {}
    CBodyComponentBaseAnimGraph() : baseAddr(0) {}
    CBaseAnimGraphController m_animationController() { return SCHEMA_TYPE(CBaseAnimGraphController, 0x5B0); }
};

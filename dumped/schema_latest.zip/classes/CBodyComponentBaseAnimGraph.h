#pragma once
#include <cstdint>
class CBodyComponentBaseAnimGraph {
public:
    uintptr_t /* CBaseAnimGraphController */ m_animationController() { return SCHEMA_TYPE(uintptr_t, 0x5B0); }
};

#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_RopeKeyframe  {
public:
    uintptr_t baseAddr;

    C_RopeKeyframe() : baseAddr(0) {}
    C_RopeKeyframe(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_LinksTouchingSomething() { return SCHEMA_TYPE(uintptr_t, 0xa); }
    int m_nLinksTouchingSomething() { return SCHEMA_TYPE(int, 0x20); }
    int m_fPrevLockedPoints() { return SCHEMA_TYPE(int, 0x20); }
    int m_iForcePointMoveCounter() { return SCHEMA_TYPE(int, 0x20); }
    bool m_bPrevEndPointPos() { return SCHEMA_TYPE(bool, 0x2); }
    Vector3 m_vPrevEndPointPos() { return SCHEMA_TYPE(Vector3, 0x2); }
    float m_flCurScroll() { return SCHEMA_TYPE(float, 0x20); }
    float m_flScrollSpeed() { return SCHEMA_TYPE(float, 0x20); }
    uint16_t m_RopeFlags() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uintptr_t m_iRopeMaterialModelIndex() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    uint8_t m_nSegments() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_Subdiv() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uintptr_t m_RopeLength() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_Slack() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    float m_TextureScale() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_fLockedPoints() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_nChangeCount() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_Width() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_hMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    int m_TextureHeight() { return SCHEMA_TYPE(int, 0x20); }
    float m_flCurrentGustTimer() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurrentGustLifetime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTimeToNextGust() { return SCHEMA_TYPE(float, 0x20); }
    Vector3 m_vCachedEndPointAttachmentPos() { return SCHEMA_TYPE(Vector3, 0x2); }
    QAngle m_vCachedEndPointAttachmentAngle() { return SCHEMA_TYPE(QAngle, 0x2); }
    uintptr_t m_bEndPointAttachmentPositionsDirty() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bEndPointAttachmentAnglesDirty() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bNewDataThisFrame() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bPhysicsInitted() { return SCHEMA_TYPE(uintptr_t, 0x1); }
};

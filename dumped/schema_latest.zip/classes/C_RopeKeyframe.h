#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class AttachmentHandle_t;
class C_BaseEntity;
class HMaterialStrong;
class float32;
class int16;
class C_RopeKeyframe : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_RopeKeyframe(uintptr_t addr) : baseAddr(addr) {}
    C_RopeKeyframe() : baseAddr(0) {}
    uintptr_t m_LinksTouchingSomething() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t m_PhysicsDelegate() { return SCHEMA_TYPE(uintptr_t, 0x1190); }
    uint16_t m_RopeFlags() { return SCHEMA_TYPE(uint16_t, 0xEF0); }
    int16 m_RopeLength() { return SCHEMA_TYPE(int16, 0x1180); }
    int16 m_Slack() { return SCHEMA_TYPE(int16, 0x1182); }
    uint8_t m_Subdiv() { return SCHEMA_TYPE(uint8_t, 0x117E); }
    uintptr_t m_TextureHeight() { return SCHEMA_TYPE(uintptr_t, 0x11A8); }
    float32 m_TextureScale() { return SCHEMA_TYPE(float32, 0x1184); }
    float32 m_Width() { return SCHEMA_TYPE(float32, 0x118C); }
    uintptr_t m_bApplyWind() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    bool m_bConstrainBetweenEndpoints() { return SCHEMA_TYPE(bool, 0x1218); }
    uintptr_t m_bEndPointAttachmentAnglesDirty() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bEndPointAttachmentPositionsDirty() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bNewDataThisFrame() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bPhysicsInitted() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bPrevEndPointPos() { return SCHEMA_TYPE(uintptr_t, 0xECC); }
    uint8_t m_fLockedPoints() { return SCHEMA_TYPE(uint8_t, 0x1188); }
    uintptr_t m_fPrevLockedPoints() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t m_flCurScroll() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    uintptr_t m_flCurrentGustLifetime() { return SCHEMA_TYPE(uintptr_t, 0x11C8); }
    uintptr_t m_flCurrentGustTimer() { return SCHEMA_TYPE(uintptr_t, 0x11C4); }
    float32 m_flScrollSpeed() { return SCHEMA_TYPE(float32, 0xEEC); }
    uintptr_t m_flTimeToNextGust() { return SCHEMA_TYPE(uintptr_t, 0x11CC); }
    CHandle<C_BaseEntity> m_hEndPoint() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x1178); }
    uintptr_t m_hMaterial() { return SCHEMA_TYPE(uintptr_t, 0x11A0); }
    CHandle<C_BaseEntity> m_hStartPoint() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x1174); }
    AttachmentHandle_t m_iEndAttachment() { return SCHEMA_TYPE(AttachmentHandle_t, 0x117D); }
    uintptr_t m_iForcePointMoveCounter() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    HMaterialStrong m_iRopeMaterialModelIndex() { return SCHEMA_TYPE(HMaterialStrong, 0xEF8); }
    AttachmentHandle_t m_iStartAttachment() { return SCHEMA_TYPE(AttachmentHandle_t, 0x117C); }
    uint8_t m_nChangeCount() { return SCHEMA_TYPE(uint8_t, 0x1189); }
    uintptr_t m_nLinksTouchingSomething() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    uint8_t m_nSegments() { return SCHEMA_TYPE(uint8_t, 0x1170); }
    uintptr_t m_vCachedEndPointAttachmentAngle() { return SCHEMA_TYPE(uintptr_t, 0x1200); }
    uintptr_t m_vCachedEndPointAttachmentPos() { return SCHEMA_TYPE(uintptr_t, 0x11E8); }
    uintptr_t m_vColorMod() { return SCHEMA_TYPE(uintptr_t, 0x11DC); }
    uintptr_t m_vPrevEndPointPos() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    uintptr_t m_vWindDir() { return SCHEMA_TYPE(uintptr_t, 0x11D0); }
    uintptr_t m_vecImpulse() { return SCHEMA_TYPE(uintptr_t, 0x11AC); }
    uintptr_t m_vecPreviousImpulse() { return SCHEMA_TYPE(uintptr_t, 0x11B8); }
};

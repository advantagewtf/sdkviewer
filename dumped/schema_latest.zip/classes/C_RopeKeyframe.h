#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class AttachmentHandle_t;
class C_BaseEntity;
class HMaterialStrong;
class float32;
class int16;
class C_RopeKeyframe : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_RopeKeyframe(uintptr_t addr) : baseAddr(addr) {}
    C_RopeKeyframe() : baseAddr(0) {}
    uintptr_t m_LinksTouchingSomething() { return SCHEMA_TYPE(uintptr_t, 0xE90); }
    uintptr_t m_PhysicsDelegate() { return SCHEMA_TYPE(uintptr_t, 0x1168); }
    uint16_t m_RopeFlags() { return SCHEMA_TYPE(uint16_t, 0xEC8); }
    int16 m_RopeLength() { return SCHEMA_TYPE(int16, 0x1158); }
    int16 m_Slack() { return SCHEMA_TYPE(int16, 0x115A); }
    uint8_t m_Subdiv() { return SCHEMA_TYPE(uint8_t, 0x1156); }
    uintptr_t m_TextureHeight() { return SCHEMA_TYPE(uintptr_t, 0x1180); }
    float32 m_TextureScale() { return SCHEMA_TYPE(float32, 0x115C); }
    float32 m_Width() { return SCHEMA_TYPE(float32, 0x1164); }
    uintptr_t m_bApplyWind() { return SCHEMA_TYPE(uintptr_t, 0xE98); }
    bool m_bConstrainBetweenEndpoints() { return SCHEMA_TYPE(bool, 0x11F0); }
    uintptr_t m_bEndPointAttachmentAnglesDirty() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bEndPointAttachmentPositionsDirty() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bNewDataThisFrame() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bPhysicsInitted() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bPrevEndPointPos() { return SCHEMA_TYPE(uintptr_t, 0xEA4); }
    uint8_t m_fLockedPoints() { return SCHEMA_TYPE(uint8_t, 0x1160); }
    uintptr_t m_fPrevLockedPoints() { return SCHEMA_TYPE(uintptr_t, 0xE9C); }
    uintptr_t m_flCurScroll() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t m_flCurrentGustLifetime() { return SCHEMA_TYPE(uintptr_t, 0x11A0); }
    uintptr_t m_flCurrentGustTimer() { return SCHEMA_TYPE(uintptr_t, 0x119C); }
    float32 m_flScrollSpeed() { return SCHEMA_TYPE(float32, 0xEC4); }
    uintptr_t m_flTimeToNextGust() { return SCHEMA_TYPE(uintptr_t, 0x11A4); }
    CHandle<C_BaseEntity> m_hEndPoint() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x1150); }
    uintptr_t m_hMaterial() { return SCHEMA_TYPE(uintptr_t, 0x1178); }
    CHandle<C_BaseEntity> m_hStartPoint() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x114C); }
    AttachmentHandle_t m_iEndAttachment() { return SCHEMA_TYPE(AttachmentHandle_t, 0x1155); }
    uintptr_t m_iForcePointMoveCounter() { return SCHEMA_TYPE(uintptr_t, 0xEA0); }
    HMaterialStrong m_iRopeMaterialModelIndex() { return SCHEMA_TYPE(HMaterialStrong, 0xED0); }
    AttachmentHandle_t m_iStartAttachment() { return SCHEMA_TYPE(AttachmentHandle_t, 0x1154); }
    uint8_t m_nChangeCount() { return SCHEMA_TYPE(uint8_t, 0x1161); }
    uintptr_t m_nLinksTouchingSomething() { return SCHEMA_TYPE(uintptr_t, 0xE94); }
    uint8_t m_nSegments() { return SCHEMA_TYPE(uint8_t, 0x1148); }
    uintptr_t m_vCachedEndPointAttachmentAngle() { return SCHEMA_TYPE(uintptr_t, 0x11D8); }
    uintptr_t m_vCachedEndPointAttachmentPos() { return SCHEMA_TYPE(uintptr_t, 0x11C0); }
    uintptr_t m_vColorMod() { return SCHEMA_TYPE(uintptr_t, 0x11B4); }
    uintptr_t m_vPrevEndPointPos() { return SCHEMA_TYPE(uintptr_t, 0xEA8); }
    uintptr_t m_vWindDir() { return SCHEMA_TYPE(uintptr_t, 0x11A8); }
    uintptr_t m_vecImpulse() { return SCHEMA_TYPE(uintptr_t, 0x1184); }
    uintptr_t m_vecPreviousImpulse() { return SCHEMA_TYPE(uintptr_t, 0x1190); }
};

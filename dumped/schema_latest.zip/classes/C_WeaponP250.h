#pragma once
#include <cstdint>
class C_WeaponP250 : public C_CSWeaponBaseGun {
public:
};

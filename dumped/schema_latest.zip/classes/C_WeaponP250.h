#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponP250 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponP250(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponP250() : baseAddr(0) {}
};

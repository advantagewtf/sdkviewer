#pragma once
#include "../cstypes/EntityPlatformTypes_t.h"
#include "../cstypes/GameTick_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/MoveCollide_t.h"
#include "../cstypes/MoveType_t.h"
#include "../cstypes/TakeDamageFlags_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBodyComponent;
class CCollisionProperty;
class CGameSceneNode;
class CRenderComponent;

class C_BaseEntity  {
public:
    uintptr_t baseAddr;

    C_BaseEntity() : baseAddr(0) {}
    C_BaseEntity(uintptr_t base) : baseAddr(base) {}

    int m_iMaxHealth() { return SCHEMA_TYPE(int, 0x20); }
    int m_iHealth() { return SCHEMA_TYPE(int, 0x20); }
    float m_flDamageAccumulator() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_lifeState() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_ubInterpolationFrame() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nNoInterpolationTick() { return SCHEMA_TYPE(int, 0x20); }
    int m_nVisibilityNoInterpolationTick() { return SCHEMA_TYPE(int, 0x20); }
    float m_flProxyRandomValue() { return SCHEMA_TYPE(float, 0x20); }
    int m_iEFlags() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nWaterType() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nSimulationTick() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCurrentThinkContext() { return SCHEMA_TYPE(int, 0x20); }
    float m_flAnimTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSimulationTime() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_nSceneObjectOverrideFlags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nInterpolationLatchDirtyFlags() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_ListEntry() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flSpeed() { return SCHEMA_TYPE(float, 0x20); }
    uint16_t m_EntClientFlags() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint8_t m_iTeamNum() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_spawnflags() { return SCHEMA_TYPE(int, 0x20); }
    int m_fFlags() { return SCHEMA_TYPE(int, 0x20); }
    float m_flWaterLevel() { return SCHEMA_TYPE(float, 0x20); }
    int m_fEffects() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGroundBodyIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_flFriction() { return SCHEMA_TYPE(float, 0x20); }
    float m_flElasticity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flGravityScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTimeScale() { return SCHEMA_TYPE(float, 0x20); }
    uint16_t m_hThink() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint8_t m_fBBoxVisFlags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_flActualGravityScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_nFirstPredictableCommand() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLastPredictableCommand() { return SCHEMA_TYPE(int, 0x20); }
    int m_DataChangeEventRef() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCreationTick() { return SCHEMA_TYPE(int, 0x20); }
};

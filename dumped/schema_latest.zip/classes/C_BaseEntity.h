#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/Vector3.h"
class BloodType;
class CBaseEntity;
class CBodyComponent__Storage_t;
class EntityPlatformTypes_t;
class EntitySubclassID_t;
class GameTick_t;
class GameTime_t;
class MoveCollide_t;
class MoveType_t;
class TakeDamageFlags_t;
class float32;
class C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_BaseEntity(uintptr_t addr) : baseAddr(addr) {}
    C_BaseEntity() : baseAddr(0) {}
    CBodyComponent__Storage_t m_CBodyComponent() { return SCHEMA_TYPE(CBodyComponent__Storage_t, 0x38); }
    uintptr_t m_DataChangeEventRef() { return SCHEMA_TYPE(uintptr_t, 0x5B4); }
    uintptr_t m_EntClientFlags() { return SCHEMA_TYPE(uintptr_t, 0x3E8); }
    uintptr_t m_ListEntry() { return SCHEMA_TYPE(uintptr_t, 0x3C8); }
    MoveCollide_t m_MoveCollide() { return SCHEMA_TYPE(MoveCollide_t, 0x524); }
    MoveType_t m_MoveType() { return SCHEMA_TYPE(MoveType_t, 0x525); }
    uintptr_t m_NetworkTransmitComponent() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_Particles() { return SCHEMA_TYPE(uintptr_t, 0x578); }
    uintptr_t m_aThinkFunctions() { return SCHEMA_TYPE(uintptr_t, 0x398); }
    uintptr_t m_bAnimTimeChanged() { return SCHEMA_TYPE(uintptr_t, 0x5DD); }
    bool m_bAnimatedEveryTick() { return SCHEMA_TYPE(bool, 0x548); }
    uintptr_t m_bApplyLayerMatchIDToModel() { return SCHEMA_TYPE(uintptr_t, 0x37B); }
    bool m_bClientSideRagdoll() { return SCHEMA_TYPE(bool, 0x3EA); }
    uintptr_t m_bDisabledContextThinks() { return SCHEMA_TYPE(uintptr_t, 0x3B0); }
    uintptr_t m_bGravityActuallyDisabled() { return SCHEMA_TYPE(uintptr_t, 0x568); }
    bool m_bGravityDisabled() { return SCHEMA_TYPE(bool, 0x549); }
    uintptr_t m_bHasAddedVarsToInterpolation() { return SCHEMA_TYPE(uintptr_t, 0x3BE); }
    uintptr_t m_bHasSuccessfullyInterpolated() { return SCHEMA_TYPE(uintptr_t, 0x3BD); }
    uintptr_t m_bInterpolateEvenWithNoModel() { return SCHEMA_TYPE(uintptr_t, 0x379); }
    uintptr_t m_bPredictable() { return SCHEMA_TYPE(uintptr_t, 0x569); }
    uintptr_t m_bPredictionEligible() { return SCHEMA_TYPE(uintptr_t, 0x37A); }
    uintptr_t m_bRenderEvenWhenNotSuccessfullyInterpolated() { return SCHEMA_TYPE(uintptr_t, 0x3BF); }
    uintptr_t m_bRenderWithViewModels() { return SCHEMA_TYPE(uintptr_t, 0x56A); }
    uintptr_t m_bSimulationTimeChanged() { return SCHEMA_TYPE(uintptr_t, 0x5DE); }
    bool m_bTakesDamage() { return SCHEMA_TYPE(bool, 0x355); }
    uintptr_t m_dependencies() { return SCHEMA_TYPE(uintptr_t, 0x5B8); }
    uintptr_t m_fBBoxVisFlags() { return SCHEMA_TYPE(uintptr_t, 0x560); }
    uint32_t m_fEffects() { return SCHEMA_TYPE(uint32_t, 0x52C); }
    uint32_t m_fFlags() { return SCHEMA_TYPE(uint32_t, 0x3F8); }
    uintptr_t m_flActualGravityScale() { return SCHEMA_TYPE(uintptr_t, 0x564); }
    float32 m_flAnimTime() { return SCHEMA_TYPE(float32, 0x3B4); }
    GameTime_t m_flCreateTime() { return SCHEMA_TYPE(GameTime_t, 0x3E0); }
    uintptr_t m_flDamageAccumulator() { return SCHEMA_TYPE(uintptr_t, 0x350); }
    float32 m_flElasticity() { return SCHEMA_TYPE(float32, 0x53C); }
    float32 m_flFriction() { return SCHEMA_TYPE(float32, 0x538); }
    float32 m_flGravityScale() { return SCHEMA_TYPE(float32, 0x540); }
    GameTime_t m_flNavIgnoreUntilTime() { return SCHEMA_TYPE(GameTime_t, 0x54C); }
    uintptr_t m_flProxyRandomValue() { return SCHEMA_TYPE(uintptr_t, 0x370); }
    float32 m_flSimulationTime() { return SCHEMA_TYPE(float32, 0x3B8); }
    float m_flSpeed() { return SCHEMA_TYPE(float, 0x3E4); }
    float32 m_flTimeScale() { return SCHEMA_TYPE(float32, 0x544); }
    float32 m_flWaterLevel() { return SCHEMA_TYPE(float32, 0x528); }
    CHandle<CBaseEntity> m_hEffectEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x51C); }
    CHandle<CBaseEntity> m_hGroundEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x530); }
    uintptr_t m_hOldMoveParent() { return SCHEMA_TYPE(uintptr_t, 0x574); }
    CHandle<CBaseEntity> m_hOwnerEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x520); }
    uintptr_t m_hSceneObjectController() { return SCHEMA_TYPE(uintptr_t, 0x364); }
    uintptr_t m_hThink() { return SCHEMA_TYPE(uintptr_t, 0x550); }
    uintptr_t m_iCurrentThinkContext() { return SCHEMA_TYPE(uintptr_t, 0x394); }
    uintptr_t m_iEFlags() { return SCHEMA_TYPE(uintptr_t, 0x374); }
    int32_t m_iHealth() { return SCHEMA_TYPE(int32_t, 0x34C); }
    int32_t m_iMaxHealth() { return SCHEMA_TYPE(int32_t, 0x348); }
    uint8_t m_iTeamNum() { return SCHEMA_TYPE(uint8_t, 0x3EB); }
    uint8_t m_lifeState() { return SCHEMA_TYPE(uint8_t, 0x354); }
    uintptr_t m_nActualMoveType() { return SCHEMA_TYPE(uintptr_t, 0x526); }
    BloodType m_nBloodType() { return SCHEMA_TYPE(BloodType, 0x5F0); }
    uintptr_t m_nCreationTick() { return SCHEMA_TYPE(uintptr_t, 0x5D0); }
    uintptr_t m_nFirstPredictableCommand() { return SCHEMA_TYPE(uintptr_t, 0x56C); }
    int32_t m_nGroundBodyIndex() { return SCHEMA_TYPE(int32_t, 0x534); }
    uintptr_t m_nInterpolationLatchDirtyFlags() { return SCHEMA_TYPE(uintptr_t, 0x3C0); }
    uintptr_t m_nLastPredictableCommand() { return SCHEMA_TYPE(uintptr_t, 0x570); }
    uintptr_t m_nLastThinkTick() { return SCHEMA_TYPE(uintptr_t, 0x328); }
    GameTick_t m_nNextThinkTick() { return SCHEMA_TYPE(GameTick_t, 0x3F0); }
    uintptr_t m_nNoInterpolationTick() { return SCHEMA_TYPE(uintptr_t, 0x368); }
    EntityPlatformTypes_t m_nPlatformType() { return SCHEMA_TYPE(EntityPlatformTypes_t, 0x360); }
    uintptr_t m_nSceneObjectOverrideFlags() { return SCHEMA_TYPE(uintptr_t, 0x3BC); }
    uintptr_t m_nSimulationTick() { return SCHEMA_TYPE(uintptr_t, 0x390); }
    EntitySubclassID_t m_nSubclassID() { return SCHEMA_TYPE(EntitySubclassID_t, 0x380); }
    TakeDamageFlags_t m_nTakeDamageFlags() { return SCHEMA_TYPE(TakeDamageFlags_t, 0x358); }
    uintptr_t m_nVisibilityNoInterpolationTick() { return SCHEMA_TYPE(uintptr_t, 0x36C); }
    uintptr_t m_nWaterType() { return SCHEMA_TYPE(uintptr_t, 0x378); }
    uintptr_t m_pCollision() { return SCHEMA_TYPE(uintptr_t, 0x340); }
    uintptr_t m_pGameSceneNode() { return SCHEMA_TYPE(uintptr_t, 0x330); }
    uintptr_t m_pRenderComponent() { return SCHEMA_TYPE(uintptr_t, 0x338); }
    uintptr_t m_sUniqueHammerID() { return SCHEMA_TYPE(uintptr_t, 0x5E8); }
    uint32_t m_spawnflags() { return SCHEMA_TYPE(uint32_t, 0x3EC); }
    uintptr_t m_tokLayerMatchID() { return SCHEMA_TYPE(uintptr_t, 0x37C); }
    uint8_t m_ubInterpolationFrame() { return SCHEMA_TYPE(uint8_t, 0x361); }
    uintptr_t m_vecAbsVelocity() { return SCHEMA_TYPE(uintptr_t, 0x3FC); }
    uintptr_t m_vecAngVelocity() { return SCHEMA_TYPE(uintptr_t, 0x5A8); }
    Vector3 m_vecBaseVelocity() { return SCHEMA_TYPE(Vector3, 0x510); }
    uintptr_t m_vecServerVelocity() { return SCHEMA_TYPE(uintptr_t, 0x408); }
    uintptr_t m_vecVelocity() { return SCHEMA_TYPE(uintptr_t, 0x430); }
};

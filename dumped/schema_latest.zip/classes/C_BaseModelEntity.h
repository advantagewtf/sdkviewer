#pragma once
#include "../classes/CCollisionProperty.h"
#include "../classes/CGlowProperty.h"
#include "../classes/CHitboxComponent.h"
#include "../cstypes/DecalMode_t.h"
#include "../cstypes/HitGroup_t.h"
#include "../cstypes/RenderFx_t.h"
#include "../cstypes/RenderMode_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CDestructiblePartsComponent;
class CRenderComponent;

class C_BaseModelEntity  {
public:
    uintptr_t baseAddr;

    C_BaseModelEntity() : baseAddr(0) {}
    C_BaseModelEntity(uintptr_t base) : baseAddr(base) {}

    int m_nLastAddDecal() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDecalsAdded() { return SCHEMA_TYPE(int, 0x20); }
    int m_iOldHealth() { return SCHEMA_TYPE(int, 0x20); }
    float m_flGlowBackfaceMult() { return SCHEMA_TYPE(float, 0x20); }
    float m_fadeMinDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_fadeMaxDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flShadowStrength() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_nObjectCulling() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nAddDecal() { return SCHEMA_TYPE(int, 0x20); }
    int m_bvDisabledHitGroups() { return SCHEMA_TYPE(int, 0x20); }
};

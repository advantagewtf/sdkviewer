#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCollisionProperty;
class CGlowProperty;
class CHitboxComponent__Storage_t;
class CRenderComponent__Storage_t;
class Color;
class EntityRenderAttribute_t;
class RenderFx_t;
class RenderMode_t;
class float32;
class C_BaseModelEntity : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_BaseModelEntity(uintptr_t addr) : baseAddr(addr) {}
    C_BaseModelEntity() : baseAddr(0) {}
    CHitboxComponent__Storage_t m_CHitboxComponent() { return SCHEMA_TYPE(CHitboxComponent__Storage_t, 0xAF8); }
    CRenderComponent__Storage_t m_CRenderComponent() { return SCHEMA_TYPE(CRenderComponent__Storage_t, 0xAF0); }
    uintptr_t m_ClientOverrideTint() { return SCHEMA_TYPE(uintptr_t, 0xE40); }
    CCollisionProperty m_Collision() { return SCHEMA_TYPE(CCollisionProperty, 0xC10); }
    CGlowProperty m_Glow() { return SCHEMA_TYPE(CGlowProperty, 0xCC0); }
    uintptr_t m_bAllowFadeInView() { return SCHEMA_TYPE(uintptr_t, 0xB62); }
    uintptr_t m_bDoingModelEffects() { return SCHEMA_TYPE(uintptr_t, 0xB59); }
    uintptr_t m_bInitModelEffects() { return SCHEMA_TYPE(uintptr_t, 0xB58); }
    uintptr_t m_bIsStaticProp() { return SCHEMA_TYPE(uintptr_t, 0xB5A); }
    bool m_bNoInterpolate() { return SCHEMA_TYPE(bool, 0xC09); }
    bool m_bRenderToCubemaps() { return SCHEMA_TYPE(bool, 0xC08); }
    uintptr_t m_bUseClientOverrideTint() { return SCHEMA_TYPE(uintptr_t, 0xE44); }
    uint32_t m_bvDisabledHitGroups() { return SCHEMA_TYPE(uint32_t, 0xE80); }
    Color m_clrRender() { return SCHEMA_TYPE(Color, 0xB80); }
    float32 m_fadeMaxDist() { return SCHEMA_TYPE(float32, 0xD20); }
    float32 m_fadeMinDist() { return SCHEMA_TYPE(float32, 0xD1C); }
    float32 m_flFadeScale() { return SCHEMA_TYPE(float32, 0xD24); }
    float m_flGlowBackfaceMult() { return SCHEMA_TYPE(float, 0xD18); }
    float32 m_flShadowStrength() { return SCHEMA_TYPE(float32, 0xD28); }
    uintptr_t m_iOldHealth() { return SCHEMA_TYPE(uintptr_t, 0xB5C); }
    uintptr_t m_nDestructiblePartInitialStateDestructed0() { return SCHEMA_TYPE(uintptr_t, 0xB10); }
    uintptr_t m_nDestructiblePartInitialStateDestructed0_PartIndex() { return SCHEMA_TYPE(uintptr_t, 0xB24); }
    uintptr_t m_nDestructiblePartInitialStateDestructed1() { return SCHEMA_TYPE(uintptr_t, 0xB14); }
    uintptr_t m_nDestructiblePartInitialStateDestructed1_PartIndex() { return SCHEMA_TYPE(uintptr_t, 0xB28); }
    uintptr_t m_nDestructiblePartInitialStateDestructed2() { return SCHEMA_TYPE(uintptr_t, 0xB18); }
    uintptr_t m_nDestructiblePartInitialStateDestructed2_PartIndex() { return SCHEMA_TYPE(uintptr_t, 0xB2C); }
    uintptr_t m_nDestructiblePartInitialStateDestructed3() { return SCHEMA_TYPE(uintptr_t, 0xB1C); }
    uintptr_t m_nDestructiblePartInitialStateDestructed3_PartIndex() { return SCHEMA_TYPE(uintptr_t, 0xB30); }
    uintptr_t m_nDestructiblePartInitialStateDestructed4() { return SCHEMA_TYPE(uintptr_t, 0xB20); }
    uintptr_t m_nDestructiblePartInitialStateDestructed4_PartIndex() { return SCHEMA_TYPE(uintptr_t, 0xB34); }
    uint8_t m_nObjectCulling() { return SCHEMA_TYPE(uint8_t, 0xD2C); }
    RenderFx_t m_nRenderFX() { return SCHEMA_TYPE(RenderFx_t, 0xB61); }
    RenderMode_t m_nRenderMode() { return SCHEMA_TYPE(RenderMode_t, 0xB60); }
    uintptr_t m_nRequiredDecalRtEncoding() { return SCHEMA_TYPE(uintptr_t, 0xD2D); }
    uintptr_t m_pClientAlphaProperty() { return SCHEMA_TYPE(uintptr_t, 0xE38); }
    CDestructiblePartsComponent* m_pDestructiblePartsSystemComponent() { return SCHEMA_TYPE(CDestructiblePartsComponent*, 0xB38); }
    EntityRenderAttribute_t m_vecRenderAttributes() { return SCHEMA_TYPE(EntityRenderAttribute_t, 0xB88); }
    uintptr_t m_vecViewOffset() { return SCHEMA_TYPE(uintptr_t, 0xD58); }
};

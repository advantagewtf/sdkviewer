#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/Vector3.h"
#include "C_BaseModelEntity.h"
class C_BaseModelEntity : public C_BaseEntity {
public:
    uintptr_t /* CHitboxComponent::Storage_t */ m_CHitboxComponent() { return SCHEMA_TYPE(uintptr_t, 0xAE8); }
    uintptr_t /* CRenderComponent::Storage_t */ m_CRenderComponent() { return SCHEMA_TYPE(uintptr_t, 0xAE0); }
    uintptr_t m_ClientOverrideTint() { return SCHEMA_TYPE(uintptr_t, 0xE68); }
    uintptr_t /* CCollisionProperty */ m_Collision() { return SCHEMA_TYPE(uintptr_t, 0xC00); }
    CHandle<C_BaseModelEntity> m_ConfigEntitiesToPropagateMaterialDecalsTo() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0xD40); }
    uintptr_t /* CGlowProperty */ m_Glow() { return SCHEMA_TYPE(uintptr_t, 0xCB0); }
    uintptr_t m_LastHitGroup() { return SCHEMA_TYPE(uintptr_t, 0xB08); }
    uintptr_t m_bAllowFadeInView() { return SCHEMA_TYPE(uintptr_t, 0xB52); }
    uintptr_t m_bInitModelEffects() { return SCHEMA_TYPE(uintptr_t, 0xB40); }
    uintptr_t m_bIsStaticProp() { return SCHEMA_TYPE(uintptr_t, 0xB41); }
    bool m_bNoInterpolate() { return SCHEMA_TYPE(bool, 0xBF9); }
    bool m_bRenderToCubemaps() { return SCHEMA_TYPE(bool, 0xBF8); }
    uintptr_t m_bUseClientOverrideTint() { return SCHEMA_TYPE(uintptr_t, 0xE6C); }
    uint32_t m_bvDisabledHitGroups() { return SCHEMA_TYPE(uint32_t, 0xEA8); }
    uintptr_t /* Color */ m_clrRender() { return SCHEMA_TYPE(uintptr_t, 0xB70); }
    uintptr_t /* float32 */ m_fadeMaxDist() { return SCHEMA_TYPE(uintptr_t, 0xD10); }
    uintptr_t /* float32 */ m_fadeMinDist() { return SCHEMA_TYPE(uintptr_t, 0xD0C); }
    uintptr_t /* float32 */ m_flFadeScale() { return SCHEMA_TYPE(uintptr_t, 0xD14); }
    float m_flGlowBackfaceMult() { return SCHEMA_TYPE(float, 0xD08); }
    uintptr_t /* float32 */ m_flShadowStrength() { return SCHEMA_TYPE(uintptr_t, 0xD18); }
    uintptr_t m_iOldHealth() { return SCHEMA_TYPE(uintptr_t, 0xB4C); }
    int32_t m_nAddDecal() { return SCHEMA_TYPE(int32_t, 0xD20); }
    uintptr_t /* DecalMode_t */ m_nDecalMode() { return SCHEMA_TYPE(uintptr_t, 0xD3C); }
    uintptr_t m_nDecalsAdded() { return SCHEMA_TYPE(uintptr_t, 0xB48); }
    uintptr_t m_nLastAddDecal() { return SCHEMA_TYPE(uintptr_t, 0xB44); }
    uint8_t m_nObjectCulling() { return SCHEMA_TYPE(uint8_t, 0xD1C); }
    uintptr_t /* RenderFx_t */ m_nRenderFX() { return SCHEMA_TYPE(uintptr_t, 0xB51); }
    uintptr_t /* RenderMode_t */ m_nRenderMode() { return SCHEMA_TYPE(uintptr_t, 0xB50); }
    uintptr_t /* DecalMode_t */ m_nRequiredDecalMode() { return SCHEMA_TYPE(uintptr_t, 0xD3D); }
    uintptr_t m_pClientAlphaProperty() { return SCHEMA_TYPE(uintptr_t, 0xE60); }
    uintptr_t /* CDestructiblePartsComponent* */ m_pDestructiblePartsSystemComponent() { return SCHEMA_TYPE(uintptr_t, 0xB00); }
    uintptr_t m_sLastDamageSourceName() { return SCHEMA_TYPE(uintptr_t, 0xB10); }
    Vector3 m_vDecalForwardAxis() { return SCHEMA_TYPE(Vector3, 0xD30); }
    Vector3 m_vDecalPosition() { return SCHEMA_TYPE(Vector3, 0xD24); }
    uintptr_t m_vLastDamagePosition() { return SCHEMA_TYPE(uintptr_t, 0xB18); }
    uintptr_t /* EntityRenderAttribute_t */ m_vecRenderAttributes() { return SCHEMA_TYPE(uintptr_t, 0xB78); }
    uintptr_t m_vecViewOffset() { return SCHEMA_TYPE(uintptr_t, 0xD80); }
};

#pragma once
#include <cstdint>
class C_NetTestBaseCombatCharacter : public C_BaseCombatCharacter {
public:
};

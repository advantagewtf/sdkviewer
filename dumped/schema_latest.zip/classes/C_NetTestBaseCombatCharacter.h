#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_NetTestBaseCombatCharacter : public C_BaseCombatCharacter {
public:
    uintptr_t baseAddr;
    C_NetTestBaseCombatCharacter(uintptr_t addr) : baseAddr(addr) {}
    C_NetTestBaseCombatCharacter() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class SequenceHistory_t {
public:
    uintptr_t m_flCyclesPerSecond() { return SCHEMA_TYPE(uintptr_t, 0x14); }
    uintptr_t m_flPlaybackRate() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_flSeqFixedCycle() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_flSeqStartTime() { return SCHEMA_TYPE(uintptr_t, 0x4); }
    uintptr_t m_hSequence() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_nSeqLoopMode() { return SCHEMA_TYPE(uintptr_t, 0xC); }
};

#pragma once
#include "../cstypes/ParticleIndex_t.h"
#include "../cstypes/uintptr_t.h"

class C_FuncElectrifiedVolume  {
public:
    uintptr_t baseAddr;

    C_FuncElectrifiedVolume() : baseAddr(0) {}
    C_FuncElectrifiedVolume(uintptr_t base) : baseAddr(base) {}

};

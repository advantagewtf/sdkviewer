#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class C_FuncElectrifiedVolume : public C_FuncBrush {
public:
    uintptr_t baseAddr;
    C_FuncElectrifiedVolume(uintptr_t addr) : baseAddr(addr) {}
    C_FuncElectrifiedVolume() : baseAddr(0) {}
    string_t m_EffectName() { return SCHEMA_TYPE(string_t, 0xEB8); }
    bool m_bState() { return SCHEMA_TYPE(bool, 0xEC0); }
    uintptr_t m_nAmbientEffect() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

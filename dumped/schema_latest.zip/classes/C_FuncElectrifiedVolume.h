#pragma once
#include <cstdint>
#include "../types/string_t.h"
class C_FuncElectrifiedVolume : public C_FuncBrush {
public:
    string_t m_EffectName() { return SCHEMA_TYPE(string_t, 0xEB8); }
    bool m_bState() { return SCHEMA_TYPE(bool, 0xEC0); }
    uintptr_t m_nAmbientEffect() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

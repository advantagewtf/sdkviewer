#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_HEGrenade : public C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_HEGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_HEGrenade() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_HEGrenade : public C_BaseCSGrenade {
public:
};

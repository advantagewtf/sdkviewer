#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCS2WeaponGraphController {
public:
    uintptr_t baseAddr;
    CCS2WeaponGraphController(uintptr_t addr) : baseAddr(addr) {}
    CCS2WeaponGraphController() : baseAddr(0) {}
    uintptr_t m_action() { return SCHEMA_TYPE(uintptr_t, 0x90); }
    uintptr_t m_attackThrowStrength() { return SCHEMA_TYPE(uintptr_t, 0x1F8); }
    uintptr_t m_attackType() { return SCHEMA_TYPE(uintptr_t, 0x1E0); }
    uintptr_t m_bActionReset() { return SCHEMA_TYPE(uintptr_t, 0xA8); }
    uintptr_t m_bIsUsingLegacyModel() { return SCHEMA_TYPE(uintptr_t, 0x198); }
    uintptr_t m_bWeaponIsSilenced() { return SCHEMA_TYPE(uintptr_t, 0x168); }
    uintptr_t m_deployVariation() { return SCHEMA_TYPE(uintptr_t, 0x1C8); }
    uintptr_t m_flAttackVariation() { return SCHEMA_TYPE(uintptr_t, 0x210); }
    uintptr_t m_flWeaponActionSpeedScale() { return SCHEMA_TYPE(uintptr_t, 0xC0); }
    uintptr_t m_flWeaponAmmo() { return SCHEMA_TYPE(uintptr_t, 0x120); }
    uintptr_t m_flWeaponAmmoMax() { return SCHEMA_TYPE(uintptr_t, 0x138); }
    uintptr_t m_flWeaponAmmoReserve() { return SCHEMA_TYPE(uintptr_t, 0x150); }
    uintptr_t m_flWeaponIronsightAmount() { return SCHEMA_TYPE(uintptr_t, 0x180); }
    uintptr_t m_idleVariation() { return SCHEMA_TYPE(uintptr_t, 0x1B0); }
    uintptr_t m_inspectExtraInfo() { return SCHEMA_TYPE(uintptr_t, 0x240); }
    uintptr_t m_inspectVariation() { return SCHEMA_TYPE(uintptr_t, 0x228); }
    uintptr_t m_reloadStage() { return SCHEMA_TYPE(uintptr_t, 0x258); }
    uintptr_t m_weaponCategory() { return SCHEMA_TYPE(uintptr_t, 0xD8); }
    uintptr_t m_weaponExtraInfo() { return SCHEMA_TYPE(uintptr_t, 0x108); }
    uintptr_t m_weaponType() { return SCHEMA_TYPE(uintptr_t, 0xF0); }
};

#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
class C_CSPlayerPawn;

class C_BaseGrenade  {
public:
    uintptr_t baseAddr;

    C_BaseGrenade() : baseAddr(0) {}
    C_BaseGrenade(uintptr_t base) : baseAddr(base) {}

    float m_DmgRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_flWarnAITime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDamage() { return SCHEMA_TYPE(float, 0x20); }
};

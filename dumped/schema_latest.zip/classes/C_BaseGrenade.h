#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSPlayerPawn;
class GameTime_t;
class float32;
class C_BaseGrenade : public C_BaseFlex {
public:
    uintptr_t baseAddr;
    C_BaseGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_BaseGrenade() : baseAddr(0) {}
    float32 m_DmgRadius() { return SCHEMA_TYPE(float32, 0x136C); }
    uintptr_t m_ExplosionSound() { return SCHEMA_TYPE(uintptr_t, 0x1388); }
    uintptr_t m_bHasWarnedAI() { return SCHEMA_TYPE(uintptr_t, 0x1368); }
    bool m_bIsLive() { return SCHEMA_TYPE(bool, 0x136A); }
    uintptr_t m_bIsSmokeGrenade() { return SCHEMA_TYPE(uintptr_t, 0x1369); }
    float32 m_flDamage() { return SCHEMA_TYPE(float32, 0x1378); }
    GameTime_t m_flDetonateTime() { return SCHEMA_TYPE(GameTime_t, 0x1370); }
    uintptr_t m_flNextAttack() { return SCHEMA_TYPE(uintptr_t, 0x13AC); }
    uintptr_t m_flWarnAITime() { return SCHEMA_TYPE(uintptr_t, 0x1374); }
    uintptr_t m_hOriginalThrower() { return SCHEMA_TYPE(uintptr_t, 0x13B0); }
    CHandle<CCSPlayerPawn> m_hThrower() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x1394); }
    uintptr_t m_iszBounceSound() { return SCHEMA_TYPE(uintptr_t, 0x1380); }
};

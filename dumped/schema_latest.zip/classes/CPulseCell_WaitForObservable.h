#pragma once
#include <cstdint>
class CPulseCell_WaitForObservable {
public:
    uintptr_t m_Condition() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_OnTrue() { return SCHEMA_TYPE(uintptr_t, 0xC0); }
};

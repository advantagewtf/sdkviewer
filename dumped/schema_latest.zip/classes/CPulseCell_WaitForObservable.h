#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_WaitForObservable {
public:
    uintptr_t baseAddr;
    CPulseCell_WaitForObservable(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_WaitForObservable() : baseAddr(0) {}
    uintptr_t m_Condition() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_OnTrue() { return SCHEMA_TYPE(uintptr_t, 0xC0); }
};

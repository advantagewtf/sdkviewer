#pragma once
#include "../cstypes/PulseObservableBoolExpression_t.h"
#include "../cstypes/uintptr_t.h"

class CPulseCell_WaitForObservable  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForObservable() : baseAddr(0) {}
    CPulseCell_WaitForObservable(uintptr_t base) : baseAddr(base) {}

};

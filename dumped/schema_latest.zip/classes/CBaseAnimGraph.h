#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class PhysicsRagdollPose_t;
class CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    CBaseAnimGraph(uintptr_t addr) : baseAddr(addr) {}
    CBaseAnimGraph() : baseAddr(0) {}
    PhysicsRagdollPose_t m_RagdollPose() { return SCHEMA_TYPE(PhysicsRagdollPose_t, 0xFA0); }
    bool m_bAnimGraphUpdateEnabled() { return SCHEMA_TYPE(bool, 0xF50); }
    uintptr_t m_bAnimationUpdateScheduled() { return SCHEMA_TYPE(uintptr_t, 0xF68); }
    uintptr_t m_bBuiltRagdoll() { return SCHEMA_TYPE(uintptr_t, 0xF88); }
    uintptr_t m_bHasAnimatedMaterialAttributes() { return SCHEMA_TYPE(uintptr_t, 0xFF8); }
    bool m_bInitiallyPopulateInterpHistory() { return SCHEMA_TYPE(bool, 0xF40); }
    bool m_bRagdollClientSide() { return SCHEMA_TYPE(bool, 0xFE9); }
    bool m_bRagdollEnabled() { return SCHEMA_TYPE(bool, 0xFE8); }
    uintptr_t m_bSuppressAnimEventSounds() { return SCHEMA_TYPE(uintptr_t, 0xF42); }
    uintptr_t m_flMaxSlopeDistance() { return SCHEMA_TYPE(uintptr_t, 0xF54); }
    uintptr_t m_graphControllerManager() { return SCHEMA_TYPE(uintptr_t, 0xE88); }
    uintptr_t m_nAnimGraphUpdateId() { return SCHEMA_TYPE(uintptr_t, 0xF64); }
    int32_t m_nForceBone() { return SCHEMA_TYPE(int32_t, 0xF78); }
    uintptr_t m_pClientsideRagdoll() { return SCHEMA_TYPE(uintptr_t, 0xF80); }
    uintptr_t m_pMainGraphController() { return SCHEMA_TYPE(uintptr_t, 0xF38); }
    uintptr_t m_vLastSlopeCheckPos() { return SCHEMA_TYPE(uintptr_t, 0xF58); }
    Vector3 m_vecForce() { return SCHEMA_TYPE(Vector3, 0xF6C); }
};

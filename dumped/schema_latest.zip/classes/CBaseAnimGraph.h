#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class PhysicsRagdollPose_t;
class CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    CBaseAnimGraph(uintptr_t addr) : baseAddr(addr) {}
    CBaseAnimGraph() : baseAddr(0) {}
    PhysicsRagdollPose_t m_RagdollPose() { return SCHEMA_TYPE(PhysicsRagdollPose_t, 0xF88); }
    bool m_bAnimGraphUpdateEnabled() { return SCHEMA_TYPE(bool, 0xF40); }
    uintptr_t m_bAnimationUpdateScheduled() { return SCHEMA_TYPE(uintptr_t, 0xF54); }
    uintptr_t m_bBuiltRagdoll() { return SCHEMA_TYPE(uintptr_t, 0xF70); }
    uintptr_t m_bHasAnimatedMaterialAttributes() { return SCHEMA_TYPE(uintptr_t, 0xFE0); }
    bool m_bInitiallyPopulateInterpHistory() { return SCHEMA_TYPE(bool, 0xF30); }
    bool m_bRagdollClientSide() { return SCHEMA_TYPE(bool, 0xFD1); }
    bool m_bRagdollEnabled() { return SCHEMA_TYPE(bool, 0xFD0); }
    uintptr_t m_bSuppressAnimEventSounds() { return SCHEMA_TYPE(uintptr_t, 0xF32); }
    uintptr_t m_flMaxSlopeDistance() { return SCHEMA_TYPE(uintptr_t, 0xF44); }
    int32_t m_nForceBone() { return SCHEMA_TYPE(int32_t, 0xF64); }
    uintptr_t m_pClientsideRagdoll() { return SCHEMA_TYPE(uintptr_t, 0xF68); }
    uintptr_t m_vLastSlopeCheckPos() { return SCHEMA_TYPE(uintptr_t, 0xF48); }
    Vector3 m_vecForce() { return SCHEMA_TYPE(Vector3, 0xF58); }
};

#pragma once
#include "../cstypes/PhysicsRagdollPose_t.h"
#include "../types/Vector3.h"

class CBaseAnimGraph  {
public:
    uintptr_t baseAddr;

    CBaseAnimGraph() : baseAddr(0) {}
    CBaseAnimGraph(uintptr_t base) : baseAddr(base) {}

    float m_flMaxSlopeDistance() { return SCHEMA_TYPE(float, 0x20); }
    int m_nForceBone() { return SCHEMA_TYPE(int, 0x20); }
};

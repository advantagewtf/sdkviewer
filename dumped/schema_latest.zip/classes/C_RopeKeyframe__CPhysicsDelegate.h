#pragma once
class C_RopeKeyframe;

class C_RopeKeyframe__CPhysicsDelegate  {
public:
    uintptr_t baseAddr;

    C_RopeKeyframe__CPhysicsDelegate() : baseAddr(0) {}
    C_RopeKeyframe__CPhysicsDelegate(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
class C_RopeKeyframe__CPhysicsDelegate {
public:
    uintptr_t m_pKeyframe() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

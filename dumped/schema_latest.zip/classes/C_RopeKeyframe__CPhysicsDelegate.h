#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_RopeKeyframe__CPhysicsDelegate {
public:
    uintptr_t baseAddr;
    C_RopeKeyframe__CPhysicsDelegate(uintptr_t addr) : baseAddr(addr) {}
    C_RopeKeyframe__CPhysicsDelegate() : baseAddr(0) {}
    uintptr_t m_pKeyframe() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

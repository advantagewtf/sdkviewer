#pragma once
#include <cstdint>
class CPulseCell_IntervalTimer__CursorState_t {
public:
    uintptr_t m_EndTime() { return SCHEMA_TYPE(uintptr_t, 0x4); }
    uintptr_t m_StartTime() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bCompleteOnNextWake() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_flWaitInterval() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_flWaitIntervalHigh() { return SCHEMA_TYPE(uintptr_t, 0xC); }
};

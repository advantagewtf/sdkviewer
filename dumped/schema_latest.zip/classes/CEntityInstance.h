#pragma once
#include "../cstypes/uintptr_t.h"
class CEntityIdentity;
class CScriptComponent;

class CEntityInstance  {
public:
    uintptr_t baseAddr;

    CEntityInstance() : baseAddr(0) {}
    CEntityInstance(uintptr_t base) : baseAddr(base) {}

};

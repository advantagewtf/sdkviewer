#pragma once
#include <cstdint>
class CEntityInstance {
public:
    uintptr_t /* CScriptComponent::Storage_t */ m_CScriptComponent() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t m_iszPrivateVScripts() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t /* CEntityIdentity* */ m_pEntity() { return SCHEMA_TYPE(uintptr_t, 0x10); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CScriptComponent__Storage_t;
class CEntityInstance {
public:
    uintptr_t baseAddr;
    CEntityInstance(uintptr_t addr) : baseAddr(addr) {}
    CEntityInstance() : baseAddr(0) {}
    CScriptComponent__Storage_t m_CScriptComponent() { return SCHEMA_TYPE(CScriptComponent__Storage_t, 0x30); }
    uintptr_t m_iszPrivateVScripts() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    CEntityIdentity* m_pEntity() { return SCHEMA_TYPE(CEntityIdentity*, 0x10); }
};

#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/uint16_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"

class CEffectData  {
public:
    uintptr_t baseAddr;

    CEffectData() : baseAddr(0) {}
    CEffectData(uintptr_t base) : baseAddr(base) {}

    float m_flScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMagnitude() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_nDamageType() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nPenetrate() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint16_t m_nMaterial() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uintptr_t m_nHitBox() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uint8_t m_nColor() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint8_t m_fFlags() { return SCHEMA_TYPE(uint8_t, 0x8); }
    uint16_t m_iEffectName() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint8_t m_nExplosionType() { return SCHEMA_TYPE(uint8_t, 0x8); }
};

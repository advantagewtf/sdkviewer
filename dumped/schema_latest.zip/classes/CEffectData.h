#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class AttachmentHandle_t;
class CEntityHandle;
class CUtlStringToken;
class HParticleSystemDefinition;
class QAngle;
class VectorWS;
class float32;
class int16;
class CEffectData {
public:
    uintptr_t baseAddr;
    CEffectData(uintptr_t addr) : baseAddr(addr) {}
    CEffectData() : baseAddr(0) {}
    uint8_t m_fFlags() { return SCHEMA_TYPE(uint8_t, 0x63); }
    float32 m_flMagnitude() { return SCHEMA_TYPE(float32, 0x44); }
    float32 m_flRadius() { return SCHEMA_TYPE(float32, 0x48); }
    float32 m_flScale() { return SCHEMA_TYPE(float32, 0x40); }
    CEntityHandle m_hEntity() { return SCHEMA_TYPE(CEntityHandle, 0x38); }
    CEntityHandle m_hOtherEntity() { return SCHEMA_TYPE(CEntityHandle, 0x3C); }
    uint16_t m_iEffectName() { return SCHEMA_TYPE(uint16_t, 0x6C); }
    AttachmentHandle_t m_nAttachmentIndex() { return SCHEMA_TYPE(AttachmentHandle_t, 0x64); }
    CUtlStringToken m_nAttachmentName() { return SCHEMA_TYPE(CUtlStringToken, 0x68); }
    uint8_t m_nColor() { return SCHEMA_TYPE(uint8_t, 0x62); }
    uint32_t m_nDamageType() { return SCHEMA_TYPE(uint32_t, 0x58); }
    HParticleSystemDefinition m_nEffectIndex() { return SCHEMA_TYPE(HParticleSystemDefinition, 0x50); }
    uint8_t m_nExplosionType() { return SCHEMA_TYPE(uint8_t, 0x6E); }
    int16 m_nHitBox() { return SCHEMA_TYPE(int16, 0x60); }
    uint16_t m_nMaterial() { return SCHEMA_TYPE(uint16_t, 0x5E); }
    uint8_t m_nPenetrate() { return SCHEMA_TYPE(uint8_t, 0x5C); }
    CUtlStringToken m_nSurfaceProp() { return SCHEMA_TYPE(CUtlStringToken, 0x4C); }
    QAngle m_vAngles() { return SCHEMA_TYPE(QAngle, 0x2C); }
    Vector3 m_vNormal() { return SCHEMA_TYPE(Vector3, 0x20); }
    VectorWS m_vOrigin() { return SCHEMA_TYPE(VectorWS, 0x8); }
    VectorWS m_vStart() { return SCHEMA_TYPE(VectorWS, 0x14); }
};

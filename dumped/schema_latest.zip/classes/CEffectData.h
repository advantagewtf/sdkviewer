#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class CEffectData {
public:
    uint8_t m_fFlags() { return SCHEMA_TYPE(uint8_t, 0x63); }
    uintptr_t /* float32 */ m_flMagnitude() { return SCHEMA_TYPE(uintptr_t, 0x44); }
    uintptr_t /* float32 */ m_flRadius() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t /* float32 */ m_flScale() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* CEntityHandle */ m_hEntity() { return SCHEMA_TYPE(uintptr_t, 0x38); }
    uintptr_t /* CEntityHandle */ m_hOtherEntity() { return SCHEMA_TYPE(uintptr_t, 0x3C); }
    uint16_t m_iEffectName() { return SCHEMA_TYPE(uint16_t, 0x6C); }
    uintptr_t /* AttachmentHandle_t */ m_nAttachmentIndex() { return SCHEMA_TYPE(uintptr_t, 0x64); }
    uintptr_t /* CUtlStringToken */ m_nAttachmentName() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uint8_t m_nColor() { return SCHEMA_TYPE(uint8_t, 0x62); }
    uint32_t m_nDamageType() { return SCHEMA_TYPE(uint32_t, 0x58); }
    uintptr_t /* HParticleSystemDefinition */ m_nEffectIndex() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uint8_t m_nExplosionType() { return SCHEMA_TYPE(uint8_t, 0x6E); }
    uintptr_t /* int16 */ m_nHitBox() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    uint16_t m_nMaterial() { return SCHEMA_TYPE(uint16_t, 0x5E); }
    uint8_t m_nPenetrate() { return SCHEMA_TYPE(uint8_t, 0x5C); }
    uintptr_t /* CUtlStringToken */ m_nSurfaceProp() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t /* QAngle */ m_vAngles() { return SCHEMA_TYPE(uintptr_t, 0x2C); }
    Vector3 m_vNormal() { return SCHEMA_TYPE(Vector3, 0x20); }
    uintptr_t /* VectorWS */ m_vOrigin() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t /* VectorWS */ m_vStart() { return SCHEMA_TYPE(uintptr_t, 0x14); }
};

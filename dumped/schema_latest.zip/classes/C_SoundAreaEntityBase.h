#pragma once
#include <cstdint>
#include "../types/Vector3.h"
#include "../types/string_t.h"
class C_SoundAreaEntityBase : public C_BaseEntity {
public:
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0x5F8); }
    uintptr_t m_bWasEnabled() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    string_t m_iszSoundAreaType() { return SCHEMA_TYPE(string_t, 0x608); }
    Vector3 m_vPos() { return SCHEMA_TYPE(Vector3, 0x610); }
};

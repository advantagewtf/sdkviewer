#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_SoundAreaEntityBase  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntityBase() : baseAddr(0) {}
    C_SoundAreaEntityBase(uintptr_t base) : baseAddr(base) {}

};

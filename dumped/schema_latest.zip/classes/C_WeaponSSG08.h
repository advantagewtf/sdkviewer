#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponSSG08 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponSSG08(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponSSG08() : baseAddr(0) {}
};

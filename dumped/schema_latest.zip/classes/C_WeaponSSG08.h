#pragma once
#include <cstdint>
class C_WeaponSSG08 : public C_CSWeaponBaseGun {
public:
};

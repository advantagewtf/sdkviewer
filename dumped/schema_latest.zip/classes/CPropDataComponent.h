#pragma once
#include "../cstypes/uintptr_t.h"

class CPropDataComponent  {
public:
    uintptr_t baseAddr;

    CPropDataComponent() : baseAddr(0) {}
    CPropDataComponent(uintptr_t base) : baseAddr(base) {}

    float m_flDmgModBullet() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDmgModClub() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDmgModExplosive() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDmgModFire() { return SCHEMA_TYPE(float, 0x20); }
    int m_nInteractions() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDisableTakePhysicsDamageSpawnFlag() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMotionDisabledSpawnFlag() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_SceneEntity__QueuedEvents_t {
public:
    uintptr_t starttime() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

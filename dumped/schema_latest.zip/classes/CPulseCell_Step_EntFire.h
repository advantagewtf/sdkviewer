#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Step_EntFire {
public:
    uintptr_t baseAddr;
    CPulseCell_Step_EntFire(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Step_EntFire() : baseAddr(0) {}
    uintptr_t m_Input() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

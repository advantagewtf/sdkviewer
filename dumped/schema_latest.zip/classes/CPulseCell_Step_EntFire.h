#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Step_EntFire  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_EntFire() : baseAddr(0) {}
    CPulseCell_Step_EntFire(uintptr_t base) : baseAddr(base) {}

};

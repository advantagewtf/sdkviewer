#pragma once
#include <cstdint>
class CPulseCell_Step_EntFire {
public:
    uintptr_t m_Input() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

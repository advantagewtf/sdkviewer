#pragma once
#include <cstdint>
class C_CSWeaponBaseShotgun : public C_CSWeaponBase {
public:
};

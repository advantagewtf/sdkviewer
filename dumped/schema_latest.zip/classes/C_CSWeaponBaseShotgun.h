#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSWeaponBaseShotgun : public C_CSWeaponBase {
public:
    uintptr_t baseAddr;
    C_CSWeaponBaseShotgun(uintptr_t addr) : baseAddr(addr) {}
    C_CSWeaponBaseShotgun() : baseAddr(0) {}
};

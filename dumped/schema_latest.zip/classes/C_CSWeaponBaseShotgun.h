#pragma once
#include "../memory.h"

class C_CSWeaponBaseShotgun {
public:
 uintptr_t baseAddr;
 C_CSWeaponBaseShotgun() : baseAddr(0){}
 C_CSWeaponBaseShotgun(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
class C_TriggerVolume : public C_BaseModelEntity {
public:
};

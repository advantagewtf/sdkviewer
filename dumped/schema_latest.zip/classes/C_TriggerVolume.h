#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TriggerVolume : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_TriggerVolume(uintptr_t addr) : baseAddr(addr) {}
    C_TriggerVolume() : baseAddr(0) {}
};

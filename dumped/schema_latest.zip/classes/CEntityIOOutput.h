#pragma once
#include "../cstypes/uintptr_t.h"

class CEntityIOOutput  {
public:
    uintptr_t baseAddr;

    CEntityIOOutput() : baseAddr(0) {}
    CEntityIOOutput(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_TextureBasedAnimatable : public C_BaseModelEntity {
public:
    bool m_bLoop() { return SCHEMA_TYPE(bool, 0xEB0); }
    float m_flFPS() { return SCHEMA_TYPE(float, 0xEB4); }
    float m_flStartFrame() { return SCHEMA_TYPE(float, 0xEE4); }
    float m_flStartTime() { return SCHEMA_TYPE(float, 0xEE0); }
    uintptr_t /* HRenderTextureStrong */ m_hPositionKeys() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t /* HRenderTextureStrong */ m_hRotationKeys() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    Vector3 m_vAnimationBoundsMax() { return SCHEMA_TYPE(Vector3, 0xED4); }
    Vector3 m_vAnimationBoundsMin() { return SCHEMA_TYPE(Vector3, 0xEC8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class HRenderTextureStrong;
class C_TextureBasedAnimatable : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_TextureBasedAnimatable(uintptr_t addr) : baseAddr(addr) {}
    C_TextureBasedAnimatable() : baseAddr(0) {}
    bool m_bLoop() { return SCHEMA_TYPE(bool, 0xEB0); }
    float m_flFPS() { return SCHEMA_TYPE(float, 0xEB4); }
    float m_flStartFrame() { return SCHEMA_TYPE(float, 0xEE4); }
    float m_flStartTime() { return SCHEMA_TYPE(float, 0xEE0); }
    HRenderTextureStrong m_hPositionKeys() { return SCHEMA_TYPE(HRenderTextureStrong, 0xEB8); }
    HRenderTextureStrong m_hRotationKeys() { return SCHEMA_TYPE(HRenderTextureStrong, 0xEC0); }
    Vector3 m_vAnimationBoundsMax() { return SCHEMA_TYPE(Vector3, 0xED4); }
    Vector3 m_vAnimationBoundsMin() { return SCHEMA_TYPE(Vector3, 0xEC8); }
};

#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_TextureBasedAnimatable  {
public:
    uintptr_t baseAddr;

    C_TextureBasedAnimatable() : baseAddr(0) {}
    C_TextureBasedAnimatable(uintptr_t base) : baseAddr(base) {}

    float m_flFPS() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flStartFrame() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_StattrakModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t baseAddr;
    C_StattrakModule(uintptr_t addr) : baseAddr(addr) {}
    C_StattrakModule() : baseAddr(0) {}
    uintptr_t m_bKnife() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
};

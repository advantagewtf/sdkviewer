#pragma once

class C_StattrakModule  {
public:
    uintptr_t baseAddr;

    C_StattrakModule() : baseAddr(0) {}
    C_StattrakModule(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
class C_StattrakModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t m_bKnife() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
};

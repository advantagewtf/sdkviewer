#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Base {
public:
    uintptr_t baseAddr;
    CPulseCell_Base(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Base() : baseAddr(0) {}
    uintptr_t m_nEditorNodeID() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

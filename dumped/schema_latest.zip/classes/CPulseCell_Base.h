#pragma once
#include <cstdint>
class CPulseCell_Base {
public:
    uintptr_t m_nEditorNodeID() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

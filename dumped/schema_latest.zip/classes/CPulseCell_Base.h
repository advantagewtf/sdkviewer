#pragma once
#include "../cstypes/PulseDocNodeID_t.h"

class CPulseCell_Base  {
public:
    uintptr_t baseAddr;

    CPulseCell_Base() : baseAddr(0) {}
    CPulseCell_Base(uintptr_t base) : baseAddr(base) {}

};

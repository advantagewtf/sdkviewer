#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CModelState;
class CUtlStringToken;
class CSkeletonInstance : public CGameSceneNode {
public:
    uintptr_t baseAddr;
    CSkeletonInstance(uintptr_t addr) : baseAddr(addr) {}
    CSkeletonInstance() : baseAddr(0) {}
    uintptr_t m_bDirtyMotionType() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bDisableSolidCollisionsForHierarchy() { return SCHEMA_TYPE(uintptr_t, 0x432); }
    bool m_bIsAnimationEnabled() { return SCHEMA_TYPE(bool, 0x430); }
    uintptr_t m_bIsGeneratingLatchedParentSpaceState() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    bool m_bUseParentRenderBounds() { return SCHEMA_TYPE(bool, 0x431); }
    CUtlStringToken m_materialGroup() { return SCHEMA_TYPE(CUtlStringToken, 0x434); }
    CModelState m_modelState() { return SCHEMA_TYPE(CModelState, 0x160); }
    uint8_t m_nHitboxSet() { return SCHEMA_TYPE(uint8_t, 0x438); }
};

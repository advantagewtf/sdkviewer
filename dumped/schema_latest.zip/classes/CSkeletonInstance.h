#pragma once
#include <cstdint>
class CSkeletonInstance : public CGameSceneNode {
public:
    uintptr_t m_bDirtyMotionType() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_bDisableSolidCollisionsForHierarchy() { return SCHEMA_TYPE(uintptr_t, 0x492); }
    bool m_bIsAnimationEnabled() { return SCHEMA_TYPE(bool, 0x490); }
    uintptr_t m_bIsGeneratingLatchedParentSpaceState() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    bool m_bUseParentRenderBounds() { return SCHEMA_TYPE(bool, 0x491); }
    uintptr_t /* CUtlStringToken */ m_materialGroup() { return SCHEMA_TYPE(uintptr_t, 0x494); }
    uintptr_t /* CModelState */ m_modelState() { return SCHEMA_TYPE(uintptr_t, 0x190); }
    uint8_t m_nHitboxSet() { return SCHEMA_TYPE(uint8_t, 0x498); }
};

#pragma once
#include "../classes/CModelState.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"

class CSkeletonInstance  {
public:
    uintptr_t baseAddr;

    CSkeletonInstance() : baseAddr(0) {}
    CSkeletonInstance(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_bDirtyMotionType() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uintptr_t m_bIsGeneratingLatchedParentSpaceState() { return SCHEMA_TYPE(uintptr_t, 0x1); }
    uint8_t m_nHitboxSet() { return SCHEMA_TYPE(uint8_t, 0x8); }
};

#pragma once
#include <cstdint>
class C_TintController : public C_BaseEntity {
public:
};

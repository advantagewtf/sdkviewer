#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TintController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_TintController(uintptr_t addr) : baseAddr(addr) {}
    C_TintController() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_SoundEventAABBEntity {
public:
    Vector3 m_vMaxs() { return SCHEMA_TYPE(Vector3, 0x6CC); }
    Vector3 m_vMins() { return SCHEMA_TYPE(Vector3, 0x6C0); }
};

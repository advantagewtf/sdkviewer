#pragma once
#include "../types/Vector3.h"

class C_SoundEventAABBEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventAABBEntity() : baseAddr(0) {}
    C_SoundEventAABBEntity(uintptr_t base) : baseAddr(base) {}

};

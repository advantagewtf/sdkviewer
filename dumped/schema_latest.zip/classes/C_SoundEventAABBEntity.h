#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_SoundEventAABBEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventAABBEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventAABBEntity() : baseAddr(0) {}
    Vector3 m_vMaxs() { return SCHEMA_TYPE(Vector3, 0x6C4); }
    Vector3 m_vMins() { return SCHEMA_TYPE(Vector3, 0x6B8); }
};

#pragma once
#include "../memory.h"

class C_SoundEventAABBEntity {
public:
 uintptr_t baseAddr;
 C_SoundEventAABBEntity() : baseAddr(0){}
 C_SoundEventAABBEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_vMins(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
 uintptr_t m_vMaxs(){return SCHEMA_TYPE(uintptr_t,0x6CC);}
};

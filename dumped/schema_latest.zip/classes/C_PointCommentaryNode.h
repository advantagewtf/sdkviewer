#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
class C_BaseEntity;

class C_PointCommentaryNode  {
public:
    uintptr_t baseAddr;

    C_PointCommentaryNode() : baseAddr(0) {}
    C_PointCommentaryNode(uintptr_t base) : baseAddr(base) {}

    float m_flStartTimeInCommentary() { return SCHEMA_TYPE(float, 0x20); }
    int m_iNodeNumber() { return SCHEMA_TYPE(int, 0x20); }
    int m_iNodeNumberMax() { return SCHEMA_TYPE(int, 0x20); }
};

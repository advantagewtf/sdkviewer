#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/string_t.h"
#include "C_BaseEntity.h"
class C_PointCommentaryNode : public CBaseAnimGraph {
public:
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x1170); }
    bool m_bListenedTo() { return SCHEMA_TYPE(bool, 0x11A0); }
    uintptr_t m_bRestartAfterRestore() { return SCHEMA_TYPE(uintptr_t, 0x11B4); }
    uintptr_t m_bWasActive() { return SCHEMA_TYPE(uintptr_t, 0x1171); }
    uintptr_t m_flEndTime() { return SCHEMA_TYPE(uintptr_t, 0x1174); }
    uintptr_t /* GameTime_t */ m_flStartTime() { return SCHEMA_TYPE(uintptr_t, 0x1178); }
    uintptr_t /* float32 */ m_flStartTimeInCommentary() { return SCHEMA_TYPE(uintptr_t, 0x117C); }
    CHandle<C_BaseEntity> m_hViewPosition() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x11B0); }
    int32_t m_iNodeNumber() { return SCHEMA_TYPE(int32_t, 0x1198); }
    int32_t m_iNodeNumberMax() { return SCHEMA_TYPE(int32_t, 0x119C); }
    string_t m_iszCommentaryFile() { return SCHEMA_TYPE(string_t, 0x1180); }
    string_t m_iszSpeakers() { return SCHEMA_TYPE(string_t, 0x1190); }
    string_t m_iszTitle() { return SCHEMA_TYPE(string_t, 0x1188); }
};

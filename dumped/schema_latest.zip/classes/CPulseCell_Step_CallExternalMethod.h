#pragma once
#include "../cstypes/PulseMethodCallMode_t.h"
#include "../cstypes/PulseSymbol_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPulseCell_Step_CallExternalMethod  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_CallExternalMethod() : baseAddr(0) {}
    CPulseCell_Step_CallExternalMethod(uintptr_t base) : baseAddr(base) {}

};

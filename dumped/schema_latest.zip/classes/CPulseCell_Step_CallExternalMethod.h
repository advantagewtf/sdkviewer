#pragma once
#include <cstdint>
class CPulseCell_Step_CallExternalMethod {
public:
    uintptr_t m_ExpectedArgs() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_GameBlackboard() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    uintptr_t m_MethodName() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_OnFinished() { return SCHEMA_TYPE(uintptr_t, 0x80); }
    uintptr_t m_nAsyncCallMode() { return SCHEMA_TYPE(uintptr_t, 0x78); }
};

#pragma once
#include <cstdint>
class C_FuncMover : public C_BaseToggle {
public:
};

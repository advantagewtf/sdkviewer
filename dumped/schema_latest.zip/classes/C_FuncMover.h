#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FuncMover : public C_BaseToggle {
public:
    uintptr_t baseAddr;
    C_FuncMover(uintptr_t addr) : baseAddr(addr) {}
    C_FuncMover() : baseAddr(0) {}
};

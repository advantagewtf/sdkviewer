#pragma once
#include "../memory.h"

class CPulseCell_BaseFlow {
public:
 uintptr_t baseAddr;
 CPulseCell_BaseFlow() : baseAddr(0){}
 CPulseCell_BaseFlow(uintptr_t b):baseAddr(b){}
};

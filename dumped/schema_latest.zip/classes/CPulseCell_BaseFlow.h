#pragma once
#include <cstdint>
class CPulseCell_BaseFlow {
public:
};

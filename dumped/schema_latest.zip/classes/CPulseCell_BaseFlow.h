#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseFlow {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseFlow(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseFlow() : baseAddr(0) {}
};

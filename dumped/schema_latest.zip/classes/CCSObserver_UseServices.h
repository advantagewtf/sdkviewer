#pragma once
#include <cstdint>
class CCSObserver_UseServices {
public:
};

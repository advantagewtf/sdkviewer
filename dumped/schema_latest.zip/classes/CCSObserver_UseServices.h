#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSObserver_UseServices {
public:
    uintptr_t baseAddr;
    CCSObserver_UseServices(uintptr_t addr) : baseAddr(addr) {}
    CCSObserver_UseServices() : baseAddr(0) {}
};

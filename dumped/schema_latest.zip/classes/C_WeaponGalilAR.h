#pragma once
#include <cstdint>
class C_WeaponGalilAR : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponGalilAR : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponGalilAR(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponGalilAR() : baseAddr(0) {}
};

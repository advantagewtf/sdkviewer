#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchLineupEnd {
public:
 uintptr_t baseAddr;
 C_CSGO_EndOfMatchLineupEnd() : baseAddr(0){}
 C_CSGO_EndOfMatchLineupEnd(uintptr_t b):baseAddr(b){}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_EndOfMatchLineupEnd {
public:
    uintptr_t baseAddr;
    C_CSGO_EndOfMatchLineupEnd(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_EndOfMatchLineupEnd() : baseAddr(0) {}
};

#pragma once
#include "../cstypes/PointWorldTextJustifyHorizontal_t.h"
#include "../cstypes/PointWorldTextJustifyVertical_t.h"
#include "../cstypes/PointWorldTextReorientMode_t.h"
#include "../cstypes/uintptr_t.h"

class C_PointWorldText  {
public:
    uintptr_t baseAddr;

    C_PointWorldText() : baseAddr(0) {}
    C_PointWorldText(uintptr_t base) : baseAddr(base) {}

    char* m_messageText() { return SCHEMA_TYPE(char*, 0x200); }
    char* m_FontName() { return SCHEMA_TYPE(char*, 0x40); }
    char* m_BackgroundMaterialName() { return SCHEMA_TYPE(char*, 0x40); }
    float m_flWorldUnitsPerPx() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFontSize() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBackgroundBorderWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBackgroundBorderHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flBackgroundWorldToUV() { return SCHEMA_TYPE(float, 0x20); }
};

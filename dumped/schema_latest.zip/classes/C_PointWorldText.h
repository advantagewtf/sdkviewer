#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class PointWorldTextJustifyHorizontal_t;
class PointWorldTextJustifyVertical_t;
class PointWorldTextReorientMode_t;
class C_PointWorldText : public C_ModelPointEntity {
public:
    uintptr_t baseAddr;
    C_PointWorldText(uintptr_t addr) : baseAddr(addr) {}
    C_PointWorldText() : baseAddr(0) {}
    char m_BackgroundMaterialName() { return SCHEMA_TYPE(char, 0x1110); }
    Color m_Color() { return SCHEMA_TYPE(Color, 0x1170); }
    char m_FontName() { return SCHEMA_TYPE(char, 0x10D0); }
    bool m_bDrawBackground() { return SCHEMA_TYPE(bool, 0x1160); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0x1150); }
    uintptr_t m_bForceRecreateNextUpdate() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    bool m_bFullbright() { return SCHEMA_TYPE(bool, 0x1151); }
    float m_flBackgroundBorderHeight() { return SCHEMA_TYPE(float, 0x1168); }
    float m_flBackgroundBorderWidth() { return SCHEMA_TYPE(float, 0x1164); }
    float m_flBackgroundWorldToUV() { return SCHEMA_TYPE(float, 0x116C); }
    float m_flDepthOffset() { return SCHEMA_TYPE(float, 0x115C); }
    float m_flFontSize() { return SCHEMA_TYPE(float, 0x1158); }
    float m_flWorldUnitsPerPx() { return SCHEMA_TYPE(float, 0x1154); }
    char m_messageText() { return SCHEMA_TYPE(char, 0xED0); }
    PointWorldTextJustifyHorizontal_t m_nJustifyHorizontal() { return SCHEMA_TYPE(PointWorldTextJustifyHorizontal_t, 0x1174); }
    PointWorldTextJustifyVertical_t m_nJustifyVertical() { return SCHEMA_TYPE(PointWorldTextJustifyVertical_t, 0x1178); }
    PointWorldTextReorientMode_t m_nReorientMode() { return SCHEMA_TYPE(PointWorldTextReorientMode_t, 0x117C); }
};

#pragma once
#include <cstdint>
class CCSGameModeRules_Noop {
public:
};

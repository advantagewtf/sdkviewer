#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSGameModeRules_Noop {
public:
    uintptr_t baseAddr;
    CCSGameModeRules_Noop(uintptr_t addr) : baseAddr(addr) {}
    CCSGameModeRules_Noop() : baseAddr(0) {}
};

#pragma once
#include "../types/Vector3.h"

class CCSPlayer_WaterServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_WaterServices() : baseAddr(0) {}
    CCSPlayer_WaterServices(uintptr_t base) : baseAddr(base) {}

    float m_flWaterJumpTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSwimSoundTime() { return SCHEMA_TYPE(float, 0x20); }
};

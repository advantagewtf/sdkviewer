#pragma once
#include <cstdint>
class CCSPlayer_WaterServices {
public:
    uintptr_t m_flSwimSoundTime() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_flWaterJumpTime() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_vecWaterJumpVel() { return SCHEMA_TYPE(uintptr_t, 0x44); }
};

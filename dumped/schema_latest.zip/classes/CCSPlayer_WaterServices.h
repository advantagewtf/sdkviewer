#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_WaterServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_WaterServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_WaterServices() : baseAddr(0) {}
    uintptr_t m_flSwimSoundTime() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_flWaterJumpTime() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_vecWaterJumpVel() { return SCHEMA_TYPE(uintptr_t, 0x44); }
};

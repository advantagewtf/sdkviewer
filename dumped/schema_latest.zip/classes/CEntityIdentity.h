#pragma once
#include "../cstypes/ChangeAccessorFieldPathIndex_t.h"
#include "../cstypes/WorldGroupId_t.h"
#include "../cstypes/uintptr_t.h"

class CEntityIdentity  {
public:
    uintptr_t baseAddr;

    CEntityIdentity() : baseAddr(0) {}
    CEntityIdentity(uintptr_t base) : baseAddr(base) {}

    int m_nameStringableIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_flags() { return SCHEMA_TYPE(int, 0x20); }
    int m_fDataObjectTypes() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class EHANDLE;
class attributeprovidertypes_t;
class CAttributeManager {
public:
    uintptr_t baseAddr;
    CAttributeManager(uintptr_t addr) : baseAddr(addr) {}
    CAttributeManager() : baseAddr(0) {}
    uintptr_t m_CachedResults() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    attributeprovidertypes_t m_ProviderType() { return SCHEMA_TYPE(attributeprovidertypes_t, 0x2C); }
    uintptr_t m_Providers() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_bPreventLoopback() { return SCHEMA_TYPE(uintptr_t, 0x28); }
    EHANDLE m_hOuter() { return SCHEMA_TYPE(EHANDLE, 0x24); }
    int32_t m_iReapplyProvisionParity() { return SCHEMA_TYPE(int32_t, 0x20); }
};

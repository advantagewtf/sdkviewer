#pragma once
#include <cstdint>
class CAttributeManager {
public:
    uintptr_t m_CachedResults() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t /* attributeprovidertypes_t */ m_ProviderType() { return SCHEMA_TYPE(uintptr_t, 0x2C); }
    uintptr_t m_Providers() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_bPreventLoopback() { return SCHEMA_TYPE(uintptr_t, 0x28); }
    uintptr_t /* EHANDLE */ m_hOuter() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    int32_t m_iReapplyProvisionParity() { return SCHEMA_TYPE(int32_t, 0x20); }
};

#pragma once
#include "../cstypes/attributeprovidertypes_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class CAttributeManager  {
public:
    uintptr_t baseAddr;

    CAttributeManager() : baseAddr(0) {}
    CAttributeManager(uintptr_t base) : baseAddr(base) {}

    int m_iReapplyProvisionParity() { return SCHEMA_TYPE(int, 0x20); }
};

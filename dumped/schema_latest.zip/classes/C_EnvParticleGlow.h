#pragma once
#include <cstdint>
class C_EnvParticleGlow {
public:
    uintptr_t /* Color */ m_ColorTint() { return SCHEMA_TYPE(uintptr_t, 0x146C); }
    uintptr_t /* float32 */ m_flAlphaScale() { return SCHEMA_TYPE(uintptr_t, 0x1460); }
    uintptr_t /* float32 */ m_flRadiusScale() { return SCHEMA_TYPE(uintptr_t, 0x1464); }
    uintptr_t /* float32 */ m_flSelfIllumScale() { return SCHEMA_TYPE(uintptr_t, 0x1468); }
    uintptr_t /* HRenderTextureStrong */ m_hTextureOverride() { return SCHEMA_TYPE(uintptr_t, 0x1470); }
};

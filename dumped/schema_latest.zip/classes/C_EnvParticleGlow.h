#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class HRenderTextureStrong;
class float32;
class C_EnvParticleGlow {
public:
    uintptr_t baseAddr;
    C_EnvParticleGlow(uintptr_t addr) : baseAddr(addr) {}
    C_EnvParticleGlow() : baseAddr(0) {}
    Color m_ColorTint() { return SCHEMA_TYPE(Color, 0x1444); }
    float32 m_flAlphaScale() { return SCHEMA_TYPE(float32, 0x1438); }
    float32 m_flRadiusScale() { return SCHEMA_TYPE(float32, 0x143C); }
    float32 m_flSelfIllumScale() { return SCHEMA_TYPE(float32, 0x1440); }
    HRenderTextureStrong m_hTextureOverride() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1448); }
};

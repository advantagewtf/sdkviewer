#pragma once
#include "../cstypes/uintptr_t.h"

class C_EnvParticleGlow  {
public:
    uintptr_t baseAddr;

    C_EnvParticleGlow() : baseAddr(0) {}
    C_EnvParticleGlow(uintptr_t base) : baseAddr(base) {}

    float m_flAlphaScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRadiusScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSelfIllumScale() { return SCHEMA_TYPE(float, 0x20); }
};

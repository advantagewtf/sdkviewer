#pragma once
#include <cstdint>
class C_EnvDecal : public C_BaseModelEntity {
public:
    bool m_bProjectOnCharacters() { return SCHEMA_TYPE(bool, 0xEC9); }
    bool m_bProjectOnWater() { return SCHEMA_TYPE(bool, 0xECA); }
    bool m_bProjectOnWorld() { return SCHEMA_TYPE(bool, 0xEC8); }
    float m_flDepth() { return SCHEMA_TYPE(float, 0xEC0); }
    float m_flDepthSortBias() { return SCHEMA_TYPE(float, 0xECC); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0xEBC); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0xEB8); }
    uintptr_t /* HMaterialStrong */ m_hDecalMaterial() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
    uint32_t m_nRenderOrder() { return SCHEMA_TYPE(uint32_t, 0xEC4); }
};

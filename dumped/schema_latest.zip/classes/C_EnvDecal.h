#pragma once
#include "../cstypes/uintptr_t.h"

class C_EnvDecal  {
public:
    uintptr_t baseAddr;

    C_EnvDecal() : baseAddr(0) {}
    C_EnvDecal(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_hDecalMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDepth() { return SCHEMA_TYPE(float, 0x20); }
    int m_nRenderOrder() { return SCHEMA_TYPE(int, 0x20); }
    float m_flDepthSortBias() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class HMaterialStrong;
class C_EnvDecal : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_EnvDecal(uintptr_t addr) : baseAddr(addr) {}
    C_EnvDecal() : baseAddr(0) {}
    bool m_bProjectOnCharacters() { return SCHEMA_TYPE(bool, 0xEA1); }
    bool m_bProjectOnWater() { return SCHEMA_TYPE(bool, 0xEA2); }
    bool m_bProjectOnWorld() { return SCHEMA_TYPE(bool, 0xEA0); }
    float m_flDepth() { return SCHEMA_TYPE(float, 0xE98); }
    float m_flDepthSortBias() { return SCHEMA_TYPE(float, 0xEA4); }
    float m_flHeight() { return SCHEMA_TYPE(float, 0xE94); }
    float m_flWidth() { return SCHEMA_TYPE(float, 0xE90); }
    HMaterialStrong m_hDecalMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0xE88); }
    uint32_t m_nRenderOrder() { return SCHEMA_TYPE(uint32_t, 0xE9C); }
};

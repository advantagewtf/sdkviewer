#pragma once
#include "../memory.h"

class CBasePlayerControllerAPI {
public:
 uintptr_t baseAddr;
 CBasePlayerControllerAPI() : baseAddr(0){}
 CBasePlayerControllerAPI(uintptr_t b):baseAddr(b){}
};

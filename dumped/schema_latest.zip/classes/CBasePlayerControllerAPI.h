#pragma once
#include <cstdint>
class CBasePlayerControllerAPI {
public:
};

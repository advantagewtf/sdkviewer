#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBasePlayerControllerAPI {
public:
    uintptr_t baseAddr;
    CBasePlayerControllerAPI(uintptr_t addr) : baseAddr(addr) {}
    CBasePlayerControllerAPI() : baseAddr(0) {}
};

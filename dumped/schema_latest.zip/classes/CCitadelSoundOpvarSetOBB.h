#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CCitadelSoundOpvarSetOBB  {
public:
    uintptr_t baseAddr;

    CCitadelSoundOpvarSetOBB() : baseAddr(0) {}
    CCitadelSoundOpvarSetOBB(uintptr_t base) : baseAddr(base) {}

    int m_nAABBDirection() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
#include "../types/string_t.h"
class CCitadelSoundOpvarSetOBB {
public:
    uintptr_t baseAddr;
    CCitadelSoundOpvarSetOBB(uintptr_t addr) : baseAddr(addr) {}
    CCitadelSoundOpvarSetOBB() : baseAddr(0) {}
    string_t m_iszOperatorName() { return SCHEMA_TYPE(string_t, 0x618); }
    string_t m_iszOpvarName() { return SCHEMA_TYPE(string_t, 0x620); }
    string_t m_iszStackName() { return SCHEMA_TYPE(string_t, 0x610); }
    int32_t m_nAABBDirection() { return SCHEMA_TYPE(int32_t, 0x658); }
    Vector3 m_vDistanceInnerMaxs() { return SCHEMA_TYPE(Vector3, 0x634); }
    Vector3 m_vDistanceInnerMins() { return SCHEMA_TYPE(Vector3, 0x628); }
    Vector3 m_vDistanceOuterMaxs() { return SCHEMA_TYPE(Vector3, 0x64C); }
    Vector3 m_vDistanceOuterMins() { return SCHEMA_TYPE(Vector3, 0x640); }
};

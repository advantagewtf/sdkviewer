#pragma once
#include <cstdint>
class CPulseCell_WaitForCursorsWithTagBase__CursorState_t {
public:
    uintptr_t m_TagName() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

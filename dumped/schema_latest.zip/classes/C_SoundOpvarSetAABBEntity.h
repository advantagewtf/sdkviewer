#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetAABBEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetAABBEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetAABBEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_SoundOpvarSetAABBEntity {
public:
};

#pragma once
#include "../classes/CAnimGraphNetworkedVariables.h"
#include "../cstypes/AnimLoopMode_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/SequenceFinishNotifyState_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"

class CBaseAnimGraphController  {
public:
    uintptr_t baseAddr;

    CBaseAnimGraphController() : baseAddr(0) {}
    CBaseAnimGraphController(uintptr_t base) : baseAddr(base) {}

    float m_flSoundSyncTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_nActiveIKChainMask() { return SCHEMA_TYPE(int, 0x20); }
    float m_flSeqFixedCycle() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_serializedPoseRecipeAG2() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nSerializePoseRecipeSizeAG2() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSerializePoseRecipeVersionAG2() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_nGraphCreationFlagsAG2() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nServerGraphDefReloadCountAG2() { return SCHEMA_TYPE(int, 0x20); }
    int m_nServerSerializationContextIteration() { return SCHEMA_TYPE(int, 0x20); }
};

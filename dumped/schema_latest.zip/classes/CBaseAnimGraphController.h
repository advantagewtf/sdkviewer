#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class AnimLoopMode_t;
class AnimationAlgorithm_t;
class CAnimGraphNetworkedVariables;
class CBaseAnimGraph;
class CNetworkedQuantizedFloat;
class GameTime_t;
class HNmGraphDefinitionStrong;
class HSequence;
class ResourceId_t;
class CBaseAnimGraphController {
public:
    uintptr_t baseAddr;
    CBaseAnimGraphController(uintptr_t addr) : baseAddr(addr) {}
    CBaseAnimGraphController() : baseAddr(0) {}
    CAnimGraphNetworkedVariables m_animGraphNetworkedVars() { return SCHEMA_TYPE(CAnimGraphNetworkedVariables, 0x20); }
    uintptr_t m_bLastUpdateSkipped() { return SCHEMA_TYPE(uintptr_t, 0x15C7); }
    uintptr_t m_bNetworkedAnimationInputsChanged() { return SCHEMA_TYPE(uintptr_t, 0x15C5); }
    uintptr_t m_bNetworkedSequenceChanged() { return SCHEMA_TYPE(uintptr_t, 0x15C6); }
    uintptr_t m_bSequenceFinished() { return SCHEMA_TYPE(uintptr_t, 0x15C8); }
    CNetworkedQuantizedFloat m_flPlaybackRate() { return SCHEMA_TYPE(CNetworkedQuantizedFloat, 0x15B8); }
    float m_flSeqFixedCycle() { return SCHEMA_TYPE(float, 0x15B0); }
    GameTime_t m_flSeqStartTime() { return SCHEMA_TYPE(GameTime_t, 0x15AC); }
    uintptr_t m_flSoundSyncTime() { return SCHEMA_TYPE(uintptr_t, 0x1550); }
    HNmGraphDefinitionStrong m_hGraphDefinitionAG2() { return SCHEMA_TYPE(HNmGraphDefinitionStrong, 0x1868); }
    HSequence m_hSequence() { return SCHEMA_TYPE(HSequence, 0x15A8); }
    uintptr_t m_nActiveIKChainMask() { return SCHEMA_TYPE(uintptr_t, 0x1554); }
    AnimLoopMode_t m_nAnimLoopMode() { return SCHEMA_TYPE(AnimLoopMode_t, 0x15B4); }
    AnimationAlgorithm_t m_nAnimationAlgorithm() { return SCHEMA_TYPE(AnimationAlgorithm_t, 0x18); }
    uintptr_t m_nNextExternalGraphHandle() { return SCHEMA_TYPE(uintptr_t, 0x1510); }
    uintptr_t m_nNotifyState() { return SCHEMA_TYPE(uintptr_t, 0x15C4); }
    uintptr_t m_nPrevAnimUpdateTick() { return SCHEMA_TYPE(uintptr_t, 0x15CC); }
    uintptr_t m_nPrevAnimationAlgorithm() { return SCHEMA_TYPE(uintptr_t, 0x1B31); }
    int32_t m_nSecondarySkeletonMasterCount() { return SCHEMA_TYPE(int32_t, 0x1548); }
    int32_t m_nSerializePoseRecipeSizeAG2() { return SCHEMA_TYPE(int32_t, 0x1888); }
    int32_t m_nSerializePoseRecipeVersionAG2() { return SCHEMA_TYPE(int32_t, 0x188C); }
    int32_t m_nServerGraphInstanceIteration() { return SCHEMA_TYPE(int32_t, 0x1890); }
    int32_t m_nServerSerializationContextIteration() { return SCHEMA_TYPE(int32_t, 0x1894); }
    uintptr_t m_pAnimGraphInstance() { return SCHEMA_TYPE(uintptr_t, 0x14B0); }
    ResourceId_t m_primaryGraphId() { return SCHEMA_TYPE(ResourceId_t, 0x1898); }
    uintptr_t m_sAnimGraph2Identifier() { return SCHEMA_TYPE(uintptr_t, 0x18D0); }
    uint8_t m_serializedPoseRecipeAG2() { return SCHEMA_TYPE(uint8_t, 0x1870); }
    ResourceId_t m_vecExternalClipIds() { return SCHEMA_TYPE(ResourceId_t, 0x18B8); }
    ResourceId_t m_vecExternalGraphIds() { return SCHEMA_TYPE(ResourceId_t, 0x18A0); }
    uintptr_t m_vecExternalGraphs() { return SCHEMA_TYPE(uintptr_t, 0x1AF8); }
    uintptr_t m_vecSecondarySkeletonNames() { return SCHEMA_TYPE(uintptr_t, 0x1518); }
    CHandle<CBaseAnimGraph> m_vecSecondarySkeletons() { return SCHEMA_TYPE(CHandle<CBaseAnimGraph>, 0x1530); }
};

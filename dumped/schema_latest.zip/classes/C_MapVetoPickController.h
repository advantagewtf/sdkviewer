#pragma once

class C_MapVetoPickController  {
public:
    uintptr_t baseAddr;

    C_MapVetoPickController() : baseAddr(0) {}
    C_MapVetoPickController(uintptr_t base) : baseAddr(base) {}

    int m_nDraftType() { return SCHEMA_TYPE(int, 0x20); }
    int m_nTeamWinningCoinToss() { return SCHEMA_TYPE(int, 0x20); }
    int m_nTeamWithFirstChoice() { return SCHEMA_TYPE(int, 0x20); }
    int m_nVoteMapIdsList() { return SCHEMA_TYPE(int, 0x20); }
    int m_nAccountIDs() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId0() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId1() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId2() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId3() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId4() { return SCHEMA_TYPE(int, 0x20); }
    int m_nMapId5() { return SCHEMA_TYPE(int, 0x20); }
    int m_nStartingSide0() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCurrentPhase() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPhaseStartTick() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPhaseDurationTicks() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPostDataUpdateTick() { return SCHEMA_TYPE(int, 0x20); }
};

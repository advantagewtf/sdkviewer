#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MapVetoPickController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_MapVetoPickController(uintptr_t addr) : baseAddr(addr) {}
    C_MapVetoPickController() : baseAddr(0) {}
    uintptr_t m_bDisabledHud() { return SCHEMA_TYPE(uintptr_t, 0xF4C); }
    int32_t m_nAccountIDs() { return SCHEMA_TYPE(int32_t, 0x73C); }
    int32_t m_nCurrentPhase() { return SCHEMA_TYPE(int32_t, 0xF3C); }
    int32_t m_nDraftType() { return SCHEMA_TYPE(int32_t, 0x618); }
    int32_t m_nMapId0() { return SCHEMA_TYPE(int32_t, 0x83C); }
    int32_t m_nMapId1() { return SCHEMA_TYPE(int32_t, 0x93C); }
    int32_t m_nMapId2() { return SCHEMA_TYPE(int32_t, 0xA3C); }
    int32_t m_nMapId3() { return SCHEMA_TYPE(int32_t, 0xB3C); }
    int32_t m_nMapId4() { return SCHEMA_TYPE(int32_t, 0xC3C); }
    int32_t m_nMapId5() { return SCHEMA_TYPE(int32_t, 0xD3C); }
    int32_t m_nPhaseDurationTicks() { return SCHEMA_TYPE(int32_t, 0xF44); }
    int32_t m_nPhaseStartTick() { return SCHEMA_TYPE(int32_t, 0xF40); }
    uintptr_t m_nPostDataUpdateTick() { return SCHEMA_TYPE(uintptr_t, 0xF48); }
    int32_t m_nStartingSide0() { return SCHEMA_TYPE(int32_t, 0xE3C); }
    int32_t m_nTeamWinningCoinToss() { return SCHEMA_TYPE(int32_t, 0x61C); }
    int32_t m_nTeamWithFirstChoice() { return SCHEMA_TYPE(int32_t, 0x620); }
    int32_t m_nVoteMapIdsList() { return SCHEMA_TYPE(int32_t, 0x720); }
};

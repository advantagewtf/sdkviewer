#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MapVetoPickController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_MapVetoPickController(uintptr_t addr) : baseAddr(addr) {}
    C_MapVetoPickController() : baseAddr(0) {}
    uintptr_t m_bDisabledHud() { return SCHEMA_TYPE(uintptr_t, 0xF3C); }
    int32_t m_nAccountIDs() { return SCHEMA_TYPE(int32_t, 0x72C); }
    int32_t m_nCurrentPhase() { return SCHEMA_TYPE(int32_t, 0xF2C); }
    int32_t m_nDraftType() { return SCHEMA_TYPE(int32_t, 0x608); }
    int32_t m_nMapId0() { return SCHEMA_TYPE(int32_t, 0x82C); }
    int32_t m_nMapId1() { return SCHEMA_TYPE(int32_t, 0x92C); }
    int32_t m_nMapId2() { return SCHEMA_TYPE(int32_t, 0xA2C); }
    int32_t m_nMapId3() { return SCHEMA_TYPE(int32_t, 0xB2C); }
    int32_t m_nMapId4() { return SCHEMA_TYPE(int32_t, 0xC2C); }
    int32_t m_nMapId5() { return SCHEMA_TYPE(int32_t, 0xD2C); }
    int32_t m_nPhaseDurationTicks() { return SCHEMA_TYPE(int32_t, 0xF34); }
    int32_t m_nPhaseStartTick() { return SCHEMA_TYPE(int32_t, 0xF30); }
    uintptr_t m_nPostDataUpdateTick() { return SCHEMA_TYPE(uintptr_t, 0xF38); }
    int32_t m_nStartingSide0() { return SCHEMA_TYPE(int32_t, 0xE2C); }
    int32_t m_nTeamWinningCoinToss() { return SCHEMA_TYPE(int32_t, 0x60C); }
    int32_t m_nTeamWithFirstChoice() { return SCHEMA_TYPE(int32_t, 0x610); }
    int32_t m_nVoteMapIdsList() { return SCHEMA_TYPE(int32_t, 0x710); }
};

#pragma once
#include "../cstypes/uintptr_t.h"
class C_BaseModelEntity;

class C_BaseButton  {
public:
    uintptr_t baseAddr;

    C_BaseButton() : baseAddr(0) {}
    C_BaseButton(uintptr_t base) : baseAddr(base) {}

};

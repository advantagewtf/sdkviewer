#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/string_t.h"
class C_BaseButton {
public:
    CHandle<C_BaseModelEntity> m_glowEntity() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0xEB0); }
    string_t m_szDisplayText() { return SCHEMA_TYPE(string_t, 0xEB8); }
    bool m_usable() { return SCHEMA_TYPE(bool, 0xEB4); }
};

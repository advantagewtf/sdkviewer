#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
#include "../types/string_t.h"
class C_BaseModelEntity;
class C_BaseButton {
public:
    uintptr_t baseAddr;
    C_BaseButton(uintptr_t addr) : baseAddr(addr) {}
    C_BaseButton() : baseAddr(0) {}
    CHandle<C_BaseModelEntity> m_glowEntity() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0xEB0); }
    string_t m_szDisplayText() { return SCHEMA_TYPE(string_t, 0xEB8); }
    bool m_usable() { return SCHEMA_TYPE(bool, 0xEB4); }
};

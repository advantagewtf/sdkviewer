#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SmokeGrenade : public C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_SmokeGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_SmokeGrenade() : baseAddr(0) {}
};

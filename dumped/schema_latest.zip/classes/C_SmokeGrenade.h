#pragma once
#include <cstdint>
class C_SmokeGrenade : public C_BaseCSGrenade {
public:
};

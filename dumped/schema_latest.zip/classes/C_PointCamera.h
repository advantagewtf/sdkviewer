#pragma once
#include <cstdint>
class C_PointCamera : public C_BaseEntity {
public:
    uintptr_t m_DegreesPerSecond() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    float m_FOV() { return SCHEMA_TYPE(float, 0x5F8); }
    uintptr_t /* Color */ m_FogColor() { return SCHEMA_TYPE(uintptr_t, 0x601); }
    float m_Resolution() { return SCHEMA_TYPE(float, 0x5FC); }
    uintptr_t m_TargetFOV() { return SCHEMA_TYPE(uintptr_t, 0x644); }
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x614); }
    bool m_bAlignWithParent() { return SCHEMA_TYPE(bool, 0x62D); }
    bool m_bCanHLTVUse() { return SCHEMA_TYPE(bool, 0x62C); }
    bool m_bDofEnabled() { return SCHEMA_TYPE(bool, 0x62E); }
    bool m_bFogEnable() { return SCHEMA_TYPE(bool, 0x600); }
    uintptr_t m_bIsOn() { return SCHEMA_TYPE(uintptr_t, 0x64C); }
    bool m_bNoSky() { return SCHEMA_TYPE(bool, 0x61C); }
    bool m_bUseScreenAspectRatio() { return SCHEMA_TYPE(bool, 0x615); }
    float m_fBrightness() { return SCHEMA_TYPE(float, 0x620); }
    float m_flAspectRatio() { return SCHEMA_TYPE(float, 0x618); }
    float m_flDofFarBlurry() { return SCHEMA_TYPE(float, 0x63C); }
    float m_flDofFarCrisp() { return SCHEMA_TYPE(float, 0x638); }
    float m_flDofNearBlurry() { return SCHEMA_TYPE(float, 0x630); }
    float m_flDofNearCrisp() { return SCHEMA_TYPE(float, 0x634); }
    float m_flDofTiltToGround() { return SCHEMA_TYPE(float, 0x640); }
    float m_flFogEnd() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flFogMaxDensity() { return SCHEMA_TYPE(float, 0x610); }
    float m_flFogStart() { return SCHEMA_TYPE(float, 0x608); }
    float m_flZFar() { return SCHEMA_TYPE(float, 0x624); }
    float m_flZNear() { return SCHEMA_TYPE(float, 0x628); }
    uintptr_t m_pNext() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_PointCamera  {
public:
    uintptr_t baseAddr;

    C_PointCamera() : baseAddr(0) {}
    C_PointCamera(uintptr_t base) : baseAddr(base) {}

    float m_FOV() { return SCHEMA_TYPE(float, 0x20); }
    float m_Resolution() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogEnd() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxDensity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flAspectRatio() { return SCHEMA_TYPE(float, 0x20); }
    float m_fBrightness() { return SCHEMA_TYPE(float, 0x20); }
    float m_flZFar() { return SCHEMA_TYPE(float, 0x20); }
    float m_flZNear() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofNearBlurry() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofNearCrisp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofFarCrisp() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofFarBlurry() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDofTiltToGround() { return SCHEMA_TYPE(float, 0x20); }
    float m_TargetFOV() { return SCHEMA_TYPE(float, 0x20); }
    float m_DegreesPerSecond() { return SCHEMA_TYPE(float, 0x20); }
};

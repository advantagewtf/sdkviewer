#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class C_PointCamera : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PointCamera(uintptr_t addr) : baseAddr(addr) {}
    C_PointCamera() : baseAddr(0) {}
    uintptr_t m_DegreesPerSecond() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    float m_FOV() { return SCHEMA_TYPE(float, 0x608); }
    Color m_FogColor() { return SCHEMA_TYPE(Color, 0x611); }
    float m_Resolution() { return SCHEMA_TYPE(float, 0x60C); }
    uintptr_t m_TargetFOV() { return SCHEMA_TYPE(uintptr_t, 0x654); }
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x624); }
    bool m_bAlignWithParent() { return SCHEMA_TYPE(bool, 0x63D); }
    bool m_bCanHLTVUse() { return SCHEMA_TYPE(bool, 0x63C); }
    bool m_bDofEnabled() { return SCHEMA_TYPE(bool, 0x63E); }
    bool m_bFogEnable() { return SCHEMA_TYPE(bool, 0x610); }
    uintptr_t m_bIsOn() { return SCHEMA_TYPE(uintptr_t, 0x65C); }
    bool m_bNoSky() { return SCHEMA_TYPE(bool, 0x62C); }
    bool m_bUseScreenAspectRatio() { return SCHEMA_TYPE(bool, 0x625); }
    float m_fBrightness() { return SCHEMA_TYPE(float, 0x630); }
    float m_flAspectRatio() { return SCHEMA_TYPE(float, 0x628); }
    float m_flDofFarBlurry() { return SCHEMA_TYPE(float, 0x64C); }
    float m_flDofFarCrisp() { return SCHEMA_TYPE(float, 0x648); }
    float m_flDofNearBlurry() { return SCHEMA_TYPE(float, 0x640); }
    float m_flDofNearCrisp() { return SCHEMA_TYPE(float, 0x644); }
    float m_flDofTiltToGround() { return SCHEMA_TYPE(float, 0x650); }
    float m_flFogEnd() { return SCHEMA_TYPE(float, 0x61C); }
    float m_flFogMaxDensity() { return SCHEMA_TYPE(float, 0x620); }
    float m_flFogStart() { return SCHEMA_TYPE(float, 0x618); }
    float m_flZFar() { return SCHEMA_TYPE(float, 0x634); }
    float m_flZNear() { return SCHEMA_TYPE(float, 0x638); }
    uintptr_t m_pNext() { return SCHEMA_TYPE(uintptr_t, 0x660); }
};

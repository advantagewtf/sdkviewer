#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_MolotovGrenade : public C_BaseCSGrenade {
public:
    uintptr_t baseAddr;
    C_MolotovGrenade(uintptr_t addr) : baseAddr(addr) {}
    C_MolotovGrenade() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_MolotovGrenade : public C_BaseCSGrenade {
public:
};

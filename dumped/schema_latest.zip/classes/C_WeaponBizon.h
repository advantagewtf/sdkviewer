#pragma once
#include <cstdint>
class C_WeaponBizon : public C_CSWeaponBaseGun {
public:
};

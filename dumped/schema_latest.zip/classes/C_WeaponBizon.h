#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponBizon : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponBizon(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponBizon() : baseAddr(0) {}
};

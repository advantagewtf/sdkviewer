#pragma once
#include <cstdint>
class CPulseCell_Step_DebugLog {
public:
};

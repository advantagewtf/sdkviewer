#pragma once
#include "../memory.h"

class CPulseCell_Step_DebugLog {
public:
 uintptr_t baseAddr;
 CPulseCell_Step_DebugLog() : baseAddr(0){}
 CPulseCell_Step_DebugLog(uintptr_t b):baseAddr(b){}
};

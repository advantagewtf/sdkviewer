#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Step_DebugLog {
public:
    uintptr_t baseAddr;
    CPulseCell_Step_DebugLog(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Step_DebugLog() : baseAddr(0) {}
};

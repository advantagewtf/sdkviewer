#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_KeychainModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t baseAddr;
    C_KeychainModule(uintptr_t addr) : baseAddr(addr) {}
    C_KeychainModule() : baseAddr(0) {}
    uintptr_t m_nKeychainDefID() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    uintptr_t m_nKeychainSeed() { return SCHEMA_TYPE(uintptr_t, 0x1174); }
};

#pragma once
#include <cstdint>
class C_KeychainModule : public C_CS2WeaponModuleBase {
public:
    uintptr_t m_nKeychainDefID() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
    uintptr_t m_nKeychainSeed() { return SCHEMA_TYPE(uintptr_t, 0x1164); }
};

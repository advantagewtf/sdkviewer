#pragma once

class C_KeychainModule  {
public:
    uintptr_t baseAddr;

    C_KeychainModule() : baseAddr(0) {}
    C_KeychainModule(uintptr_t base) : baseAddr(base) {}

    int m_nKeychainDefID() { return SCHEMA_TYPE(int, 0x20); }
    int m_nKeychainSeed() { return SCHEMA_TYPE(int, 0x20); }
};

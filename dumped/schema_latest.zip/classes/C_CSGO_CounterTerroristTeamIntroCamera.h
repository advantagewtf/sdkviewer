#pragma once
#include <cstdint>
class C_CSGO_CounterTerroristTeamIntroCamera {
public:
};

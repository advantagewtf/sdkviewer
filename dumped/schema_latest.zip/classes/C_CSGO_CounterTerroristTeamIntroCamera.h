#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_CounterTerroristTeamIntroCamera {
public:
    uintptr_t baseAddr;
    C_CSGO_CounterTerroristTeamIntroCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_CounterTerroristTeamIntroCamera() : baseAddr(0) {}
};

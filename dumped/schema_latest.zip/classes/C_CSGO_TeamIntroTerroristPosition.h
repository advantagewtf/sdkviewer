#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamIntroTerroristPosition : public C_CSGO_TeamIntroCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamIntroTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamIntroTerroristPosition() : baseAddr(0) {}
};

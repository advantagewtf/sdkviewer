#pragma once
#include "../cstypes/PulseDocNodeID_t.h"
#include "../cstypes/PulseRegisterMap_t.h"
#include "../cstypes/PulseRuntimeChunkIndex_t.h"
#include "../cstypes/PulseSymbol_t.h"

class CPulse_CallInfo  {
public:
    uintptr_t baseAddr;

    CPulse_CallInfo() : baseAddr(0) {}
    CPulse_CallInfo(uintptr_t base) : baseAddr(base) {}

    int m_nSrcInstruction() { return SCHEMA_TYPE(int, 0x20); }
};

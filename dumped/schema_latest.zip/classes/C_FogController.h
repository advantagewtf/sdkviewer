#pragma once
#include <cstdint>
class C_FogController : public C_BaseEntity {
public:
    uintptr_t m_bUseAngles() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    uintptr_t /* fogparams_t */ m_fog() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_iChangedVariables() { return SCHEMA_TYPE(uintptr_t, 0x664); }
};

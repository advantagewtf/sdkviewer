#pragma once
#include "../cstypes/fogparams_t.h"

class C_FogController  {
public:
    uintptr_t baseAddr;

    C_FogController() : baseAddr(0) {}
    C_FogController(uintptr_t base) : baseAddr(base) {}

    int m_iChangedVariables() { return SCHEMA_TYPE(int, 0x20); }
};

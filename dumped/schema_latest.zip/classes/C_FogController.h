#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class fogparams_t;
class C_FogController : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_FogController(uintptr_t addr) : baseAddr(addr) {}
    C_FogController() : baseAddr(0) {}
    uintptr_t m_bUseAngles() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    fogparams_t m_fog() { return SCHEMA_TYPE(fogparams_t, 0x5F8); }
    uintptr_t m_iChangedVariables() { return SCHEMA_TYPE(uintptr_t, 0x664); }
};

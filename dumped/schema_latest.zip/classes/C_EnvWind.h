#pragma once
#include "../classes/C_EnvWindShared.h"

class C_EnvWind  {
public:
    uintptr_t baseAddr;

    C_EnvWind() : baseAddr(0) {}
    C_EnvWind(uintptr_t base) : baseAddr(base) {}

};

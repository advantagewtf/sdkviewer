#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvWindShared;
class C_EnvWind : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvWind(uintptr_t addr) : baseAddr(addr) {}
    C_EnvWind() : baseAddr(0) {}
    CEnvWindShared m_EnvWindShared() { return SCHEMA_TYPE(CEnvWindShared, 0x5F8); }
};

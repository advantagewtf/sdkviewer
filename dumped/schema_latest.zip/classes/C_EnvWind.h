#pragma once
#include <cstdint>
class C_EnvWind : public C_BaseEntity {
public:
    uintptr_t /* CEnvWindShared */ m_EnvWindShared() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

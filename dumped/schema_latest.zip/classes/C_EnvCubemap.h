#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_EnvCubemap  {
public:
    uintptr_t baseAddr;

    C_EnvCubemap() : baseAddr(0) {}
    C_EnvCubemap(uintptr_t base) : baseAddr(base) {}

    float m_Entity_flInfluenceRadius() { return SCHEMA_TYPE(float, 0x20); }
    int m_Entity_nHandshake() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nEnvCubeMapArrayIndex() { return SCHEMA_TYPE(int, 0x20); }
    int m_Entity_nPriority() { return SCHEMA_TYPE(int, 0x20); }
    float m_Entity_flEdgeFadeDist() { return SCHEMA_TYPE(float, 0x20); }
    float m_Entity_flDiffuseScale() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class HRenderTextureStrong;
class C_EnvCubemap : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvCubemap(uintptr_t addr) : baseAddr(addr) {}
    C_EnvCubemap() : baseAddr(0) {}
    bool m_Entity_bCopyDiffuseFromDefaultCubemap() { return SCHEMA_TYPE(bool, 0x6D8); }
    bool m_Entity_bCustomCubemapTexture() { return SCHEMA_TYPE(bool, 0x690); }
    bool m_Entity_bDefaultEnvMap() { return SCHEMA_TYPE(bool, 0x6D5); }
    bool m_Entity_bDefaultSpecEnvMap() { return SCHEMA_TYPE(bool, 0x6D6); }
    bool m_Entity_bEnabled() { return SCHEMA_TYPE(bool, 0x6E8); }
    bool m_Entity_bIndoorCubeMap() { return SCHEMA_TYPE(bool, 0x6D7); }
    bool m_Entity_bMoveable() { return SCHEMA_TYPE(bool, 0x6B0); }
    bool m_Entity_bStartDisabled() { return SCHEMA_TYPE(bool, 0x6D4); }
    float m_Entity_flDiffuseScale() { return SCHEMA_TYPE(float, 0x6D0); }
    float m_Entity_flEdgeFadeDist() { return SCHEMA_TYPE(float, 0x6C0); }
    float m_Entity_flInfluenceRadius() { return SCHEMA_TYPE(float, 0x694); }
    HRenderTextureStrong m_Entity_hCubemapTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x688); }
    int32_t m_Entity_nEnvCubeMapArrayIndex() { return SCHEMA_TYPE(int32_t, 0x6B8); }
    int32_t m_Entity_nHandshake() { return SCHEMA_TYPE(int32_t, 0x6B4); }
    int32_t m_Entity_nPriority() { return SCHEMA_TYPE(int32_t, 0x6BC); }
    Vector3 m_Entity_vBoxProjectMaxs() { return SCHEMA_TYPE(Vector3, 0x6A4); }
    Vector3 m_Entity_vBoxProjectMins() { return SCHEMA_TYPE(Vector3, 0x698); }
    Vector3 m_Entity_vEdgeFadeDists() { return SCHEMA_TYPE(Vector3, 0x6C4); }
};

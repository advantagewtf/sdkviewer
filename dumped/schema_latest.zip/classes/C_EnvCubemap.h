#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_EnvCubemap : public C_BaseEntity {
public:
    bool m_Entity_bCopyDiffuseFromDefaultCubemap() { return SCHEMA_TYPE(bool, 0x6C8); }
    bool m_Entity_bCustomCubemapTexture() { return SCHEMA_TYPE(bool, 0x680); }
    bool m_Entity_bDefaultEnvMap() { return SCHEMA_TYPE(bool, 0x6C5); }
    bool m_Entity_bDefaultSpecEnvMap() { return SCHEMA_TYPE(bool, 0x6C6); }
    bool m_Entity_bEnabled() { return SCHEMA_TYPE(bool, 0x6D8); }
    bool m_Entity_bIndoorCubeMap() { return SCHEMA_TYPE(bool, 0x6C7); }
    bool m_Entity_bMoveable() { return SCHEMA_TYPE(bool, 0x6A0); }
    bool m_Entity_bStartDisabled() { return SCHEMA_TYPE(bool, 0x6C4); }
    float m_Entity_flDiffuseScale() { return SCHEMA_TYPE(float, 0x6C0); }
    float m_Entity_flEdgeFadeDist() { return SCHEMA_TYPE(float, 0x6B0); }
    float m_Entity_flInfluenceRadius() { return SCHEMA_TYPE(float, 0x684); }
    uintptr_t /* HRenderTextureStrong */ m_Entity_hCubemapTexture() { return SCHEMA_TYPE(uintptr_t, 0x678); }
    int32_t m_Entity_nEnvCubeMapArrayIndex() { return SCHEMA_TYPE(int32_t, 0x6A8); }
    int32_t m_Entity_nHandshake() { return SCHEMA_TYPE(int32_t, 0x6A4); }
    int32_t m_Entity_nPriority() { return SCHEMA_TYPE(int32_t, 0x6AC); }
    Vector3 m_Entity_vBoxProjectMaxs() { return SCHEMA_TYPE(Vector3, 0x694); }
    Vector3 m_Entity_vBoxProjectMins() { return SCHEMA_TYPE(Vector3, 0x688); }
    Vector3 m_Entity_vEdgeFadeDists() { return SCHEMA_TYPE(Vector3, 0x6B4); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseYieldingInflow {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseYieldingInflow(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseYieldingInflow() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPulseCell_BaseYieldingInflow {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume : public C_EnvCombinedLightProbeVolume {
public:
    uintptr_t baseAddr;
    C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume(uintptr_t addr) : baseAddr(addr) {}
    C_EnvCombinedLightProbeVolumeAlias_func_combined_light_probe_volume() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class PulseSelectorOutflowList_t {
public:
    uintptr_t m_Outflows() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

#pragma once
#include "../cstypes/PulseSymbol_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPulseGraphDef  {
public:
    uintptr_t baseAddr;

    CPulseGraphDef() : baseAddr(0) {}
    CPulseGraphDef(uintptr_t base) : baseAddr(base) {}

};

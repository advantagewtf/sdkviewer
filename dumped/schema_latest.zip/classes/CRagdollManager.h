#pragma once
#include "../cstypes/uintptr_t.h"

class CRagdollManager  {
public:
    uintptr_t baseAddr;

    CRagdollManager() : baseAddr(0) {}
    CRagdollManager(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iCurrentMaxRagdollCount() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

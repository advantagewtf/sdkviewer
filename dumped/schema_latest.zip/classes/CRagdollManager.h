#pragma once
#include <cstdint>
class CRagdollManager {
public:
    uintptr_t /* int8 */ m_iCurrentMaxRagdollCount() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class int8;
class CRagdollManager {
public:
    uintptr_t baseAddr;
    CRagdollManager(uintptr_t addr) : baseAddr(addr) {}
    CRagdollManager() : baseAddr(0) {}
    int8 m_iCurrentMaxRagdollCount() { return SCHEMA_TYPE(int8, 0x5F8); }
};

#pragma once
class C_PointClientUIWorldPanel;

class CPointOffScreenIndicatorUi  {
public:
    uintptr_t baseAddr;

    CPointOffScreenIndicatorUi() : baseAddr(0) {}
    CPointOffScreenIndicatorUi(uintptr_t base) : baseAddr(base) {}

    float m_flSeenTargetTime() { return SCHEMA_TYPE(float, 0x20); }
};

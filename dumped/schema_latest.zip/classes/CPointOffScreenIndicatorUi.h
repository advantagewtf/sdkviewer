#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPointOffScreenIndicatorUi {
public:
    uintptr_t baseAddr;
    CPointOffScreenIndicatorUi(uintptr_t addr) : baseAddr(addr) {}
    CPointOffScreenIndicatorUi() : baseAddr(0) {}
    uintptr_t m_bBeenEnabled() { return SCHEMA_TYPE(uintptr_t, 0x10E0); }
    uintptr_t m_bHide() { return SCHEMA_TYPE(uintptr_t, 0x10E1); }
    uintptr_t m_flSeenTargetTime() { return SCHEMA_TYPE(uintptr_t, 0x10E4); }
    uintptr_t m_pTargetPanel() { return SCHEMA_TYPE(uintptr_t, 0x10E8); }
};

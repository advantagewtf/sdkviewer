#pragma once
#include <cstdint>
class C_CSGO_TeamPreviewCamera : public C_CSGO_MapPreviewCameraPath {
public:
    uintptr_t m_nVariant() { return SCHEMA_TYPE(uintptr_t, 0x680); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamPreviewCamera : public C_CSGO_MapPreviewCameraPath {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamPreviewCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamPreviewCamera() : baseAddr(0) {}
    uintptr_t m_nVariant() { return SCHEMA_TYPE(uintptr_t, 0x690); }
};

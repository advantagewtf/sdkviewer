#pragma once

class C_CSGO_TeamPreviewCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_TeamPreviewCamera() : baseAddr(0) {}
    C_CSGO_TeamPreviewCamera(uintptr_t base) : baseAddr(base) {}

    int m_nVariant() { return SCHEMA_TYPE(int, 0x20); }
};

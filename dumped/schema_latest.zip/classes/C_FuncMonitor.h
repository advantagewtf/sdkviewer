#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlString;
class EHANDLE;
class C_FuncMonitor : public C_FuncBrush {
public:
    uintptr_t baseAddr;
    C_FuncMonitor(uintptr_t addr) : baseAddr(addr) {}
    C_FuncMonitor() : baseAddr(0) {}
    bool m_bDraw3DSkybox() { return SCHEMA_TYPE(bool, 0xECD); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xECC); }
    bool m_bRenderShadows() { return SCHEMA_TYPE(bool, 0xEBC); }
    bool m_bUseUniqueColorTarget() { return SCHEMA_TYPE(bool, 0xEBD); }
    CUtlString m_brushModelName() { return SCHEMA_TYPE(CUtlString, 0xEC0); }
    EHANDLE m_hTargetCamera() { return SCHEMA_TYPE(EHANDLE, 0xEC8); }
    int32_t m_nResolutionEnum() { return SCHEMA_TYPE(int32_t, 0xEB8); }
    CUtlString m_targetCamera() { return SCHEMA_TYPE(CUtlString, 0xEB0); }
};

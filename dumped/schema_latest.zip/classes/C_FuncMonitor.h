#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlString;
class EHANDLE;
class C_FuncMonitor : public C_FuncBrush {
public:
    uintptr_t baseAddr;
    C_FuncMonitor(uintptr_t addr) : baseAddr(addr) {}
    C_FuncMonitor() : baseAddr(0) {}
    bool m_bDraw3DSkybox() { return SCHEMA_TYPE(bool, 0xEA5); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xEA4); }
    bool m_bRenderShadows() { return SCHEMA_TYPE(bool, 0xE94); }
    bool m_bUseUniqueColorTarget() { return SCHEMA_TYPE(bool, 0xE95); }
    CUtlString m_brushModelName() { return SCHEMA_TYPE(CUtlString, 0xE98); }
    EHANDLE m_hTargetCamera() { return SCHEMA_TYPE(EHANDLE, 0xEA0); }
    int32_t m_nResolutionEnum() { return SCHEMA_TYPE(int32_t, 0xE90); }
    CUtlString m_targetCamera() { return SCHEMA_TYPE(CUtlString, 0xE88); }
};

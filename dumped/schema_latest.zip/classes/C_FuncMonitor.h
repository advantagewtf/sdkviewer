#pragma once
#include <cstdint>
class C_FuncMonitor : public C_FuncBrush {
public:
    bool m_bDraw3DSkybox() { return SCHEMA_TYPE(bool, 0xECD); }
    bool m_bEnabled() { return SCHEMA_TYPE(bool, 0xECC); }
    bool m_bRenderShadows() { return SCHEMA_TYPE(bool, 0xEBC); }
    bool m_bUseUniqueColorTarget() { return SCHEMA_TYPE(bool, 0xEBD); }
    uintptr_t /* CUtlString */ m_brushModelName() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t /* EHANDLE */ m_hTargetCamera() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    int32_t m_nResolutionEnum() { return SCHEMA_TYPE(int32_t, 0xEB8); }
    uintptr_t /* CUtlString */ m_targetCamera() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

#pragma once
#include "../cstypes/uintptr_t.h"
class C_BaseEntity;

class C_FuncMonitor  {
public:
    uintptr_t baseAddr;

    C_FuncMonitor() : baseAddr(0) {}
    C_FuncMonitor(uintptr_t base) : baseAddr(base) {}

    int m_nResolutionEnum() { return SCHEMA_TYPE(int, 0x20); }
};

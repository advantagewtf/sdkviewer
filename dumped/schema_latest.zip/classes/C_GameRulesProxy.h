#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_GameRulesProxy : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_GameRulesProxy(uintptr_t addr) : baseAddr(addr) {}
    C_GameRulesProxy() : baseAddr(0) {}
};

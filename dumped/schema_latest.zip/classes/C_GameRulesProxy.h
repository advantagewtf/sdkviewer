#pragma once
#include <cstdint>
class C_GameRulesProxy : public C_BaseEntity {
public:
};

#pragma once
class C_BaseEntity;
class C_CSPlayerPawn;

class C_PlayerPing  {
public:
    uintptr_t baseAddr;

    C_PlayerPing() : baseAddr(0) {}
    C_PlayerPing(uintptr_t base) : baseAddr(base) {}

    int m_iType() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szPlaceName() { return SCHEMA_TYPE(char*, 0x12); }
};

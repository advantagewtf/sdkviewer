#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class CCSPlayerPawn;
class C_PlayerPing : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PlayerPing(uintptr_t addr) : baseAddr(addr) {}
    C_PlayerPing() : baseAddr(0) {}
    bool m_bUrgent() { return SCHEMA_TYPE(bool, 0x634); }
    CHandle<CBaseEntity> m_hPingedEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x62C); }
    CHandle<CCSPlayerPawn> m_hPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x628); }
    int32_t m_iType() { return SCHEMA_TYPE(int32_t, 0x630); }
    char m_szPlaceName() { return SCHEMA_TYPE(char, 0x635); }
};

#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_PlayerPing : public C_BaseEntity {
public:
    bool m_bUrgent() { return SCHEMA_TYPE(bool, 0x634); }
    CHandle<CBaseEntity> m_hPingedEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x62C); }
    CHandle<CCSPlayerPawn> m_hPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x628); }
    int32_t m_iType() { return SCHEMA_TYPE(int32_t, 0x630); }
    uintptr_t /* char */ m_szPlaceName() { return SCHEMA_TYPE(uintptr_t, 0x635); }
};

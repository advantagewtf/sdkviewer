#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBaseTriggerAPI {
public:
    uintptr_t baseAddr;
    CBaseTriggerAPI(uintptr_t addr) : baseAddr(addr) {}
    CBaseTriggerAPI() : baseAddr(0) {}
};

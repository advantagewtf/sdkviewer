#pragma once
#include <cstdint>
class CBaseTriggerAPI {
public:
};

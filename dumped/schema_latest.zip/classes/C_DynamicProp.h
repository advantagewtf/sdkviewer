#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DynamicProp : public C_BreakableProp {
public:
    uintptr_t baseAddr;
    C_DynamicProp(uintptr_t addr) : baseAddr(addr) {}
    C_DynamicProp() : baseAddr(0) {}
    uintptr_t m_OnAnimReachedEnd() { return SCHEMA_TYPE(uintptr_t, 0x1338); }
    uintptr_t m_OnAnimReachedStart() { return SCHEMA_TYPE(uintptr_t, 0x1320); }
    uintptr_t m_bCreateNonSolid() { return SCHEMA_TYPE(uintptr_t, 0x1360); }
    uintptr_t m_bFiredStartEndOutput() { return SCHEMA_TYPE(uintptr_t, 0x135E); }
    uintptr_t m_bForceNpcExclude() { return SCHEMA_TYPE(uintptr_t, 0x135F); }
    uintptr_t m_bIsOverrideProp() { return SCHEMA_TYPE(uintptr_t, 0x1361); }
    uintptr_t m_bRandomizeCycle() { return SCHEMA_TYPE(uintptr_t, 0x135C); }
    uintptr_t m_bStartDisabled() { return SCHEMA_TYPE(uintptr_t, 0x135D); }
    bool m_bUseAnimGraph() { return SCHEMA_TYPE(bool, 0x12D1); }
    bool m_bUseHitboxesForRenderBox() { return SCHEMA_TYPE(bool, 0x12D0); }
    uintptr_t m_glowColor() { return SCHEMA_TYPE(uintptr_t, 0x1370); }
    uintptr_t m_iCachedFrameCount() { return SCHEMA_TYPE(uintptr_t, 0x1378); }
    uintptr_t m_iInitialGlowState() { return SCHEMA_TYPE(uintptr_t, 0x1364); }
    uintptr_t m_iszIdleAnim() { return SCHEMA_TYPE(uintptr_t, 0x1350); }
    uintptr_t m_nGlowRange() { return SCHEMA_TYPE(uintptr_t, 0x1368); }
    uintptr_t m_nGlowRangeMin() { return SCHEMA_TYPE(uintptr_t, 0x136C); }
    uintptr_t m_nGlowTeam() { return SCHEMA_TYPE(uintptr_t, 0x1374); }
    uintptr_t m_nIdleAnimLoopMode() { return SCHEMA_TYPE(uintptr_t, 0x1358); }
    uintptr_t m_pOutputAnimBegun() { return SCHEMA_TYPE(uintptr_t, 0x12D8); }
    uintptr_t m_pOutputAnimLoopCycleOver() { return SCHEMA_TYPE(uintptr_t, 0x1308); }
    uintptr_t m_pOutputAnimOver() { return SCHEMA_TYPE(uintptr_t, 0x12F0); }
    uintptr_t m_vecCachedRenderMaxs() { return SCHEMA_TYPE(uintptr_t, 0x1388); }
    uintptr_t m_vecCachedRenderMins() { return SCHEMA_TYPE(uintptr_t, 0x137C); }
};

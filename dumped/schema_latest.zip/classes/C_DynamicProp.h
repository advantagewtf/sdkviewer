#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/AnimLoopMode_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_DynamicProp  {
public:
    uintptr_t baseAddr;

    C_DynamicProp() : baseAddr(0) {}
    C_DynamicProp(uintptr_t base) : baseAddr(base) {}

    int m_iInitialGlowState() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGlowRange() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGlowRangeMin() { return SCHEMA_TYPE(int, 0x20); }
    int m_nGlowTeam() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCachedFrameCount() { return SCHEMA_TYPE(int, 0x20); }
};

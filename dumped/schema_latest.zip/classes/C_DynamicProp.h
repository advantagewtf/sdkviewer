#pragma once
#include <cstdint>
class C_DynamicProp : public C_BreakableProp {
public:
    uintptr_t m_OnAnimReachedEnd() { return SCHEMA_TYPE(uintptr_t, 0x13A8); }
    uintptr_t m_OnAnimReachedStart() { return SCHEMA_TYPE(uintptr_t, 0x1380); }
    uintptr_t m_bCreateNonSolid() { return SCHEMA_TYPE(uintptr_t, 0x13E0); }
    uintptr_t m_bFiredStartEndOutput() { return SCHEMA_TYPE(uintptr_t, 0x13DE); }
    uintptr_t m_bForceNpcExclude() { return SCHEMA_TYPE(uintptr_t, 0x13DF); }
    uintptr_t m_bIsOverrideProp() { return SCHEMA_TYPE(uintptr_t, 0x13E1); }
    uintptr_t m_bRandomizeCycle() { return SCHEMA_TYPE(uintptr_t, 0x13DC); }
    uintptr_t m_bStartDisabled() { return SCHEMA_TYPE(uintptr_t, 0x13DD); }
    bool m_bUseAnimGraph() { return SCHEMA_TYPE(bool, 0x1301); }
    bool m_bUseHitboxesForRenderBox() { return SCHEMA_TYPE(bool, 0x1300); }
    uintptr_t m_glowColor() { return SCHEMA_TYPE(uintptr_t, 0x13F0); }
    uintptr_t m_iCachedFrameCount() { return SCHEMA_TYPE(uintptr_t, 0x13F8); }
    uintptr_t m_iInitialGlowState() { return SCHEMA_TYPE(uintptr_t, 0x13E4); }
    uintptr_t m_iszIdleAnim() { return SCHEMA_TYPE(uintptr_t, 0x13D0); }
    uintptr_t m_nGlowRange() { return SCHEMA_TYPE(uintptr_t, 0x13E8); }
    uintptr_t m_nGlowRangeMin() { return SCHEMA_TYPE(uintptr_t, 0x13EC); }
    uintptr_t m_nGlowTeam() { return SCHEMA_TYPE(uintptr_t, 0x13F4); }
    uintptr_t m_nIdleAnimLoopMode() { return SCHEMA_TYPE(uintptr_t, 0x13D8); }
    uintptr_t m_pOutputAnimBegun() { return SCHEMA_TYPE(uintptr_t, 0x1308); }
    uintptr_t m_pOutputAnimLoopCycleOver() { return SCHEMA_TYPE(uintptr_t, 0x1358); }
    uintptr_t m_pOutputAnimOver() { return SCHEMA_TYPE(uintptr_t, 0x1330); }
    uintptr_t m_vecCachedRenderMaxs() { return SCHEMA_TYPE(uintptr_t, 0x1408); }
    uintptr_t m_vecCachedRenderMins() { return SCHEMA_TYPE(uintptr_t, 0x13FC); }
};

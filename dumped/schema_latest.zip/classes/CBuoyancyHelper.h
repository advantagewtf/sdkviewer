#pragma once
#include "../cstypes/uintptr_t.h"

class CBuoyancyHelper  {
public:
    uintptr_t baseAddr;

    CBuoyancyHelper() : baseAddr(0) {}
    CBuoyancyHelper(uintptr_t base) : baseAddr(base) {}

    float m_flFluidDensity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNeutrallyBuoyantGravity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNeutrallyBuoyantLinearDamping() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNeutrallyBuoyantAngularDamping() { return SCHEMA_TYPE(float, 0x20); }
    float m_vecFractionOfWheelSubmergedForWheelFriction() { return SCHEMA_TYPE(float, 0x20); }
    float m_vecWheelFrictionScales() { return SCHEMA_TYPE(float, 0x20); }
    float m_vecFractionOfWheelSubmergedForWheelDrag() { return SCHEMA_TYPE(float, 0x20); }
    float m_vecWheelDrag() { return SCHEMA_TYPE(float, 0x20); }
};

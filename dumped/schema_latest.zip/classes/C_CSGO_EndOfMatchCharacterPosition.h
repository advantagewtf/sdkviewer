#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_EndOfMatchCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_EndOfMatchCharacterPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_EndOfMatchCharacterPosition() : baseAddr(0) {}
};

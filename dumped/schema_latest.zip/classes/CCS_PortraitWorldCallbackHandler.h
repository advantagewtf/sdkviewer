#pragma once
#include <cstdint>
class CCS_PortraitWorldCallbackHandler {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCS_PortraitWorldCallbackHandler {
public:
    uintptr_t baseAddr;
    CCS_PortraitWorldCallbackHandler(uintptr_t addr) : baseAddr(addr) {}
    CCS_PortraitWorldCallbackHandler() : baseAddr(0) {}
};

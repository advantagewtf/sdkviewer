#pragma once
#include <cstdint>
class CPulseCell_Inflow_Yield {
public:
    uintptr_t m_UnyieldResume() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include "../memory.h"

class CPulseCell_Inflow_Yield {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_Yield() : baseAddr(0){}
 CPulseCell_Inflow_Yield(uintptr_t b):baseAddr(b){}
 uintptr_t m_UnyieldResume(){return SCHEMA_TYPE(uintptr_t,0x48);}
};

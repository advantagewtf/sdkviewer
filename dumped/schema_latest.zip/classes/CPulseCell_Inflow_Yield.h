#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Inflow_Yield  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Yield() : baseAddr(0) {}
    CPulseCell_Inflow_Yield(uintptr_t base) : baseAddr(base) {}

};

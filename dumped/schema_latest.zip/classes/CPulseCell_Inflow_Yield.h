#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_Yield {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_Yield(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_Yield() : baseAddr(0) {}
    uintptr_t m_UnyieldResume() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

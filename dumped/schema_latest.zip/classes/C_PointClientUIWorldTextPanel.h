#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PointClientUIWorldTextPanel : public C_PointClientUIWorldPanel {
public:
    uintptr_t baseAddr;
    C_PointClientUIWorldTextPanel(uintptr_t addr) : baseAddr(addr) {}
    C_PointClientUIWorldTextPanel() : baseAddr(0) {}
    char m_messageText() { return SCHEMA_TYPE(char, 0x1100); }
};

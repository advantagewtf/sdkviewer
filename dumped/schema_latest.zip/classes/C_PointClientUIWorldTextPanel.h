#pragma once
#include <cstdint>
class C_PointClientUIWorldTextPanel : public C_PointClientUIWorldPanel {
public:
    uintptr_t /* char */ m_messageText() { return SCHEMA_TYPE(uintptr_t, 0x1100); }
};

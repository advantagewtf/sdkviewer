#pragma once

class C_PointClientUIWorldTextPanel  {
public:
    uintptr_t baseAddr;

    C_PointClientUIWorldTextPanel() : baseAddr(0) {}
    C_PointClientUIWorldTextPanel(uintptr_t base) : baseAddr(base) {}

    char* m_messageText() { return SCHEMA_TYPE(char*, 0x200); }
};

#pragma once
#include <cstdint>
class C_CSGO_PreviewModel : public C_BaseFlex {
public:
    uintptr_t m_defaultAnim() { return SCHEMA_TYPE(uintptr_t, 0x1368); }
    uintptr_t m_flInitialModelScale() { return SCHEMA_TYPE(uintptr_t, 0x1374); }
    uintptr_t m_nDefaultAnimLoopMode() { return SCHEMA_TYPE(uintptr_t, 0x1370); }
    uintptr_t m_sInitialWeaponState() { return SCHEMA_TYPE(uintptr_t, 0x1378); }
};

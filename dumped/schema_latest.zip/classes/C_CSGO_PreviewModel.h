#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_PreviewModel : public C_BaseFlex {
public:
    uintptr_t baseAddr;
    C_CSGO_PreviewModel(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_PreviewModel() : baseAddr(0) {}
    uintptr_t m_defaultAnim() { return SCHEMA_TYPE(uintptr_t, 0x1350); }
    uintptr_t m_flInitialModelScale() { return SCHEMA_TYPE(uintptr_t, 0x135C); }
    uintptr_t m_nDefaultAnimLoopMode() { return SCHEMA_TYPE(uintptr_t, 0x1358); }
    uintptr_t m_sInitialWeaponState() { return SCHEMA_TYPE(uintptr_t, 0x1360); }
};

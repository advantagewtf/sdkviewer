#pragma once
#include "../cstypes/AnimLoopMode_t.h"
#include "../cstypes/uintptr_t.h"

class C_CSGO_PreviewModel  {
public:
    uintptr_t baseAddr;

    C_CSGO_PreviewModel() : baseAddr(0) {}
    C_CSGO_PreviewModel(uintptr_t base) : baseAddr(base) {}

    float m_flInitialModelScale() { return SCHEMA_TYPE(float, 0x20); }
};

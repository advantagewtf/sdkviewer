#pragma once
#include "../cstypes/PulseRegisterMap_t.h"
#include "../cstypes/PulseRuntimeCellIndex_t.h"
#include "../cstypes/PulseRuntimeChunkIndex_t.h"
#include "../cstypes/PulseSymbol_t.h"

class CPulse_InvokeBinding  {
public:
    uintptr_t baseAddr;

    CPulse_InvokeBinding() : baseAddr(0) {}
    CPulse_InvokeBinding(uintptr_t base) : baseAddr(base) {}

    int m_nSrcInstruction() { return SCHEMA_TYPE(int, 0x20); }
};

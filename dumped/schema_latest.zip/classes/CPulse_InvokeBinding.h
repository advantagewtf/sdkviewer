#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulse_InvokeBinding {
public:
    uintptr_t baseAddr;
    CPulse_InvokeBinding(uintptr_t addr) : baseAddr(addr) {}
    CPulse_InvokeBinding() : baseAddr(0) {}
    uintptr_t m_FuncName() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    uintptr_t m_RegisterMap() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_nCellIndex() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_nSrcChunk() { return SCHEMA_TYPE(uintptr_t, 0x44); }
    uintptr_t m_nSrcInstruction() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

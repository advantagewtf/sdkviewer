#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CS2HudModelArms {
public:
    uintptr_t baseAddr;
    C_CS2HudModelArms(uintptr_t addr) : baseAddr(addr) {}
    C_CS2HudModelArms() : baseAddr(0) {}
};

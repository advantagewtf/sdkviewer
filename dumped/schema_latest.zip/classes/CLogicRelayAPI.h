#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CLogicRelayAPI {
public:
    uintptr_t baseAddr;
    CLogicRelayAPI(uintptr_t addr) : baseAddr(addr) {}
    CLogicRelayAPI() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CLogicRelayAPI {
public:
};

#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../classes/CPropDataComponent.h"
#include "../cstypes/BreakableContentsType_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/PerformanceMode_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;
class C_BasePlayerPawn;

class C_BreakableProp  {
public:
    uintptr_t baseAddr;

    C_BreakableProp() : baseAddr(0) {}
    C_BreakableProp(uintptr_t base) : baseAddr(base) {}

    float m_OnHealthChanged() { return SCHEMA_TYPE(float, 0x20); }
    float m_impactEnergyScale() { return SCHEMA_TYPE(float, 0x20); }
    int m_iMinHealthDmg() { return SCHEMA_TYPE(int, 0x20); }
    float m_flPressureDelay() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefBurstScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_explodeDamage() { return SCHEMA_TYPE(float, 0x20); }
    float m_explodeRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_explosionDelay() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefaultFadeScale() { return SCHEMA_TYPE(float, 0x20); }
};

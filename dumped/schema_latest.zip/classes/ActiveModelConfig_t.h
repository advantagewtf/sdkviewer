#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "../types/string_t.h"
class ActiveModelConfig_t {
public:
    CHandle<C_BaseModelEntity> m_AssociatedEntities() { return SCHEMA_TYPE(CHandle<C_BaseModelEntity>, 0x40); }
    string_t m_AssociatedEntityNames() { return SCHEMA_TYPE(string_t, 0x58); }
    uintptr_t /* ModelConfigHandle_t */ m_Handle() { return SCHEMA_TYPE(uintptr_t, 0x30); }
    string_t m_Name() { return SCHEMA_TYPE(string_t, 0x38); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayerLegacyJump {
public:
    uintptr_t baseAddr;
    CCSPlayerLegacyJump(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerLegacyJump() : baseAddr(0) {}
    bool m_bOldJumpPressed() { return SCHEMA_TYPE(bool, 0x10); }
    uintptr_t m_flJumpPressedTime() { return SCHEMA_TYPE(uintptr_t, 0x14); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Value_Curve {
public:
    uintptr_t baseAddr;
    CPulseCell_Value_Curve(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Value_Curve() : baseAddr(0) {}
    uintptr_t m_Curve() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

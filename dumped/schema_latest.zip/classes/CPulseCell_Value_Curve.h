#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_Value_Curve  {
public:
    uintptr_t baseAddr;

    CPulseCell_Value_Curve() : baseAddr(0) {}
    CPulseCell_Value_Curve(uintptr_t base) : baseAddr(base) {}

};

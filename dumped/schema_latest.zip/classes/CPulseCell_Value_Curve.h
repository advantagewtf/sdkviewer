#pragma once
#include "../memory.h"

class CPulseCell_Value_Curve {
public:
 uintptr_t baseAddr;
 CPulseCell_Value_Curve() : baseAddr(0){}
 CPulseCell_Value_Curve(uintptr_t b):baseAddr(b){}
 uintptr_t m_Curve(){return SCHEMA_TYPE(uintptr_t,0x48);}
};

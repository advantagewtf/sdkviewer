#pragma once
#include <cstdint>
class CPulseCell_Value_Curve {
public:
    uintptr_t m_Curve() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class CBaseFilter;

class C_BaseTrigger  {
public:
    uintptr_t baseAddr;

    C_BaseTrigger() : baseAddr(0) {}
    C_BaseTrigger(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_BaseTrigger : public C_BaseToggle {
public:
    uintptr_t baseAddr;
    C_BaseTrigger(uintptr_t addr) : baseAddr(addr) {}
    C_BaseTrigger() : baseAddr(0) {}
    uintptr_t m_OnEndTouch() { return SCHEMA_TYPE(uintptr_t, 0xF00); }
    uintptr_t m_OnEndTouchAll() { return SCHEMA_TYPE(uintptr_t, 0xF28); }
    uintptr_t m_OnNotTouching() { return SCHEMA_TYPE(uintptr_t, 0xFA0); }
    uintptr_t m_OnStartTouch() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
    uintptr_t m_OnStartTouchAll() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    uintptr_t m_OnTouching() { return SCHEMA_TYPE(uintptr_t, 0xF50); }
    uintptr_t m_OnTouchingEachEntity() { return SCHEMA_TYPE(uintptr_t, 0xF78); }
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0xFEC); }
    uintptr_t m_hFilter() { return SCHEMA_TYPE(uintptr_t, 0xFE8); }
    uintptr_t m_hTouchingEntities() { return SCHEMA_TYPE(uintptr_t, 0xFC8); }
    uintptr_t m_iFilterName() { return SCHEMA_TYPE(uintptr_t, 0xFE0); }
};

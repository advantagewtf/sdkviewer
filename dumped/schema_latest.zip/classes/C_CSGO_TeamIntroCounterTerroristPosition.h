#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamIntroCounterTerroristPosition : public C_CSGO_TeamIntroCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamIntroCounterTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamIntroCounterTerroristPosition() : baseAddr(0) {}
};

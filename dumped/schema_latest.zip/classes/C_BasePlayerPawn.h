#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBasePlayerController;
class GameTime_t;
class ViewAngleServerChange_t;
class sky3dparams_t;
class C_BasePlayerPawn : public C_BaseCombatCharacter {
public:
    uintptr_t baseAddr;
    C_BasePlayerPawn(uintptr_t addr) : baseAddr(addr) {}
    C_BasePlayerPawn() : baseAddr(0) {}
    ViewAngleServerChange_t m_ServerViewAngleChanges() { return SCHEMA_TYPE(ViewAngleServerChange_t, 0x1440); }
    uintptr_t m_bIsSwappingToPredictableController() { return SCHEMA_TYPE(uintptr_t, 0x15C0); }
    GameTime_t m_flDeathTime() { return SCHEMA_TYPE(GameTime_t, 0x1558); }
    uintptr_t m_flFOVSensitivityAdjust() { return SCHEMA_TYPE(uintptr_t, 0x1598); }
    uintptr_t m_flLastCameraSetupTime() { return SCHEMA_TYPE(uintptr_t, 0x1594); }
    uintptr_t m_flMouseSensitivity() { return SCHEMA_TYPE(uintptr_t, 0x159C); }
    uintptr_t m_flOldSimulationTime() { return SCHEMA_TYPE(uintptr_t, 0x15AC); }
    uintptr_t m_flPredictionErrorTime() { return SCHEMA_TYPE(uintptr_t, 0x1568); }
    CHandle<CBasePlayerController> m_hController() { return SCHEMA_TYPE(CHandle<CBasePlayerController>, 0x15B8); }
    CHandle<CBasePlayerController> m_hDefaultController() { return SCHEMA_TYPE(CHandle<CBasePlayerController>, 0x15BC); }
    uint32_t m_iHideHUD() { return SCHEMA_TYPE(uint32_t, 0x14C0); }
    uintptr_t m_nLastExecutedCommandNumber() { return SCHEMA_TYPE(uintptr_t, 0x15B0); }
    uintptr_t m_nLastExecutedCommandTick() { return SCHEMA_TYPE(uintptr_t, 0x15B4); }
    CPlayer_AutoaimServices* m_pAutoaimServices() { return SCHEMA_TYPE(CPlayer_AutoaimServices*, 0x1400); }
    CPlayer_CameraServices* m_pCameraServices() { return SCHEMA_TYPE(CPlayer_CameraServices*, 0x1428); }
    CPlayer_FlashlightServices* m_pFlashlightServices() { return SCHEMA_TYPE(CPlayer_FlashlightServices*, 0x1420); }
    CPlayer_ItemServices* m_pItemServices() { return SCHEMA_TYPE(CPlayer_ItemServices*, 0x13F8); }
    CPlayer_MovementServices* m_pMovementServices() { return SCHEMA_TYPE(CPlayer_MovementServices*, 0x1430); }
    CPlayer_ObserverServices* m_pObserverServices() { return SCHEMA_TYPE(CPlayer_ObserverServices*, 0x1408); }
    CPlayer_UseServices* m_pUseServices() { return SCHEMA_TYPE(CPlayer_UseServices*, 0x1418); }
    CPlayer_WaterServices* m_pWaterServices() { return SCHEMA_TYPE(CPlayer_WaterServices*, 0x1410); }
    CPlayer_WeaponServices* m_pWeaponServices() { return SCHEMA_TYPE(CPlayer_WeaponServices*, 0x13F0); }
    sky3dparams_t m_skybox3d() { return SCHEMA_TYPE(sky3dparams_t, 0x14C8); }
    uintptr_t m_vOldOrigin() { return SCHEMA_TYPE(uintptr_t, 0x15A0); }
    uintptr_t m_vecLastCameraSetupLocalOrigin() { return SCHEMA_TYPE(uintptr_t, 0x1588); }
    uintptr_t m_vecPredictionError() { return SCHEMA_TYPE(uintptr_t, 0x155C); }
    uintptr_t v_angle() { return SCHEMA_TYPE(uintptr_t, 0x14A8); }
    uintptr_t v_anglePrevious() { return SCHEMA_TYPE(uintptr_t, 0x14B4); }
};

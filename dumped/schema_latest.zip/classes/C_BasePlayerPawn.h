#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/sky3dparams_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class CPlayer_CameraServices;
class CPlayer_MovementServices;
class CPlayer_ObserverServices;
class CPlayer_WeaponServices;

class C_BasePlayerPawn  {
public:
    uintptr_t baseAddr;

    C_BasePlayerPawn() : baseAddr(0) {}
    C_BasePlayerPawn(uintptr_t base) : baseAddr(base) {}

    int m_iHideHUD() { return SCHEMA_TYPE(int, 0x20); }
    sky3dparams_t m_skybox3d() { return SCHEMA_TYPE(sky3dparams_t, 0x3); }
    float m_flFOVSensitivityAdjust() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMouseSensitivity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOldSimulationTime() { return SCHEMA_TYPE(float, 0x20); }
    int m_nLastExecutedCommandNumber() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLastExecutedCommandTick() { return SCHEMA_TYPE(int, 0x20); }
};

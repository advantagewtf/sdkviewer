#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundEventConeEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventConeEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventConeEntity() : baseAddr(0) {}
    uintptr_t m_flAttenMax() { return SCHEMA_TYPE(uintptr_t, 0x6C4); }
    uintptr_t m_flAttenMin() { return SCHEMA_TYPE(uintptr_t, 0x6C0); }
    uintptr_t m_flEmitterAngle() { return SCHEMA_TYPE(uintptr_t, 0x6B8); }
    uintptr_t m_flSweetSpotAngle() { return SCHEMA_TYPE(uintptr_t, 0x6BC); }
    uintptr_t m_iszParameterName() { return SCHEMA_TYPE(uintptr_t, 0x6C8); }
};

#pragma once
#include <cstdint>
class CBodyComponent {
public:
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_pSceneNode() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

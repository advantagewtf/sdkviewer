#pragma once
#include "../classes/CNetworkVarChainer.h"
class CGameSceneNode;

class CBodyComponent  {
public:
    uintptr_t baseAddr;

    CBodyComponent() : baseAddr(0) {}
    CBodyComponent(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBodyComponent {
public:
    uintptr_t baseAddr;
    CBodyComponent(uintptr_t addr) : baseAddr(addr) {}
    CBodyComponent() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_pSceneNode() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

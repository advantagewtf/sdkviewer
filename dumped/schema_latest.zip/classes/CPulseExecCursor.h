#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseExecCursor {
public:
    uintptr_t baseAddr;
    CPulseExecCursor(uintptr_t addr) : baseAddr(addr) {}
    CPulseExecCursor() : baseAddr(0) {}
};

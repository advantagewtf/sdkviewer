#pragma once
#include <cstdint>
class CPulseExecCursor {
public:
};

#pragma once
#include <cstdint>
class CTakeDamageInfoAPI {
public:
};

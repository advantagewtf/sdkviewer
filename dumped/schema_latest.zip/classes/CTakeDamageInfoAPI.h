#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CTakeDamageInfoAPI {
public:
    uintptr_t baseAddr;
    CTakeDamageInfoAPI(uintptr_t addr) : baseAddr(addr) {}
    CTakeDamageInfoAPI() : baseAddr(0) {}
};

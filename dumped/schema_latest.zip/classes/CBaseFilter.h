#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBaseFilter {
public:
    uintptr_t baseAddr;
    CBaseFilter(uintptr_t addr) : baseAddr(addr) {}
    CBaseFilter() : baseAddr(0) {}
    uintptr_t m_OnFail() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    uintptr_t m_OnPass() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_bNegated() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

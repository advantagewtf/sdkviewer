#pragma once
#include "../classes/CEntityIOOutput.h"

class CBaseFilter  {
public:
    uintptr_t baseAddr;

    CBaseFilter() : baseAddr(0) {}
    CBaseFilter(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
class CBaseFilter {
public:
    uintptr_t m_OnFail() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    uintptr_t m_OnPass() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_bNegated() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

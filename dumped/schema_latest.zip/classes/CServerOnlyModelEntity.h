#pragma once
#include <cstdint>
class CServerOnlyModelEntity {
public:
};

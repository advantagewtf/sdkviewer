#pragma once
#include "../memory.h"

class CServerOnlyModelEntity {
public:
 uintptr_t baseAddr;
 CServerOnlyModelEntity() : baseAddr(0){}
 CServerOnlyModelEntity(uintptr_t b):baseAddr(b){}
};

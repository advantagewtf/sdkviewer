#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CServerOnlyModelEntity {
public:
    uintptr_t baseAddr;
    CServerOnlyModelEntity(uintptr_t addr) : baseAddr(addr) {}
    CServerOnlyModelEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetOBBWindEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetOBBWindEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetOBBWindEntity() : baseAddr(0) {}
};

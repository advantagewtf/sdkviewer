#pragma once
#include <cstdint>
class C_SoundOpvarSetOBBWindEntity {
public:
};

#pragma once
#include <cstdint>
class EntitySpottedState_t {
public:
    bool m_bSpotted() { return SCHEMA_TYPE(bool, 0x8); }
    uint32_t m_bSpottedByMask() { return SCHEMA_TYPE(uint32_t, 0xC); }
};

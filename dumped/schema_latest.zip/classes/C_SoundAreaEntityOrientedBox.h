#pragma once
#include "../types/Vector3.h"

class C_SoundAreaEntityOrientedBox  {
public:
    uintptr_t baseAddr;

    C_SoundAreaEntityOrientedBox() : baseAddr(0) {}
    C_SoundAreaEntityOrientedBox(uintptr_t base) : baseAddr(base) {}

};

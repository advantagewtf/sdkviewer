#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_SoundAreaEntityOrientedBox : public C_SoundAreaEntityBase {
public:
    Vector3 m_vMax() { return SCHEMA_TYPE(Vector3, 0x62C); }
    Vector3 m_vMin() { return SCHEMA_TYPE(Vector3, 0x620); }
};

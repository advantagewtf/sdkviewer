#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_SoundAreaEntityOrientedBox : public C_SoundAreaEntityBase {
public:
    uintptr_t baseAddr;
    C_SoundAreaEntityOrientedBox(uintptr_t addr) : baseAddr(addr) {}
    C_SoundAreaEntityOrientedBox() : baseAddr(0) {}
    Vector3 m_vMax() { return SCHEMA_TYPE(Vector3, 0x62C); }
    Vector3 m_vMin() { return SCHEMA_TYPE(Vector3, 0x620); }
};

#pragma once
#include "../cstypes/GameTime_t.h"

class C_WeaponTaser  {
public:
    uintptr_t baseAddr;

    C_WeaponTaser() : baseAddr(0) {}
    C_WeaponTaser(uintptr_t base) : baseAddr(base) {}

    int m_nLastAttackTick() { return SCHEMA_TYPE(int, 0x20); }
};

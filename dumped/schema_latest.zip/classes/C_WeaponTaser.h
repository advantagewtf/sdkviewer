#pragma once
#include <cstdint>
class C_WeaponTaser : public C_CSWeaponBaseGun {
public:
    uintptr_t /* GameTime_t */ m_fFireTime() { return SCHEMA_TYPE(uintptr_t, 0x1FB0); }
    uintptr_t m_nLastAttackTick() { return SCHEMA_TYPE(uintptr_t, 0x1FB4); }
};

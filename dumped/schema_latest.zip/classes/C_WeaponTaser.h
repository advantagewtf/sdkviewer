#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class GameTime_t;
class C_WeaponTaser : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponTaser(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponTaser() : baseAddr(0) {}
    GameTime_t m_fFireTime() { return SCHEMA_TYPE(GameTime_t, 0x1F70); }
    uintptr_t m_nLastAttackTick() { return SCHEMA_TYPE(uintptr_t, 0x1F74); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponAWP : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponAWP(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponAWP() : baseAddr(0) {}
};

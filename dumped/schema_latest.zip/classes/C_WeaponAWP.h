#pragma once
#include <cstdint>
class C_WeaponAWP : public C_CSWeaponBaseGun {
public:
};

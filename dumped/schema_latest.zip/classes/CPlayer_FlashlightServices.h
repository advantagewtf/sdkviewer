#pragma once
#include <cstdint>
class CPlayer_FlashlightServices {
public:
};

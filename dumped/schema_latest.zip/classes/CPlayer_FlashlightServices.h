#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPlayer_FlashlightServices {
public:
    uintptr_t baseAddr;
    CPlayer_FlashlightServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_FlashlightServices() : baseAddr(0) {}
};

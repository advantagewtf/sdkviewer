#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CHostageRescueZoneShim {
public:
    uintptr_t baseAddr;
    CHostageRescueZoneShim(uintptr_t addr) : baseAddr(addr) {}
    CHostageRescueZoneShim() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CHostageRescueZoneShim {
public:
};

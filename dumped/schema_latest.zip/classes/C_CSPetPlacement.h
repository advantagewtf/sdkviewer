#pragma once
#include <cstdint>
class C_CSPetPlacement : public C_BaseEntity {
public:
};

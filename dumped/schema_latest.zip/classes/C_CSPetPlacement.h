#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSPetPlacement : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_CSPetPlacement(uintptr_t addr) : baseAddr(addr) {}
    C_CSPetPlacement() : baseAddr(0) {}
};

#pragma once
#include "../cstypes/AttachmentHandle_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"

class C_ClientRagdoll  {
public:
    uintptr_t baseAddr;

    C_ClientRagdoll() : baseAddr(0) {}
    C_ClientRagdoll(uintptr_t base) : baseAddr(base) {}

    int m_iCurrentFriction() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMinFriction() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMaxFriction() { return SCHEMA_TYPE(int, 0x20); }
    int m_iFrictionAnimState() { return SCHEMA_TYPE(int, 0x20); }
    float m_flScaleEnd() { return SCHEMA_TYPE(float, 0x20); }
    uintptr_t m_flScaleTimeStart() { return SCHEMA_TYPE(uintptr_t, 0xa); }
    uintptr_t m_flScaleTimeEnd() { return SCHEMA_TYPE(uintptr_t, 0xa); }
};

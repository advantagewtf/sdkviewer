#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_ClientRagdoll : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_ClientRagdoll(uintptr_t addr) : baseAddr(addr) {}
    C_ClientRagdoll() : baseAddr(0) {}
    uintptr_t m_bFadeOut() { return SCHEMA_TYPE(uintptr_t, 0x1168); }
    uintptr_t m_bFadingOut() { return SCHEMA_TYPE(uintptr_t, 0x1186); }
    uintptr_t m_bImportant() { return SCHEMA_TYPE(uintptr_t, 0x1169); }
    uintptr_t m_bReleaseRagdoll() { return SCHEMA_TYPE(uintptr_t, 0x1184); }
    uintptr_t m_flEffectTime() { return SCHEMA_TYPE(uintptr_t, 0x116C); }
    uintptr_t m_flScaleEnd() { return SCHEMA_TYPE(uintptr_t, 0x1188); }
    uintptr_t m_flScaleTimeEnd() { return SCHEMA_TYPE(uintptr_t, 0x11D8); }
    uintptr_t m_flScaleTimeStart() { return SCHEMA_TYPE(uintptr_t, 0x11B0); }
    uintptr_t m_gibDespawnTime() { return SCHEMA_TYPE(uintptr_t, 0x1170); }
    uintptr_t m_iCurrentFriction() { return SCHEMA_TYPE(uintptr_t, 0x1174); }
    uintptr_t m_iEyeAttachment() { return SCHEMA_TYPE(uintptr_t, 0x1185); }
    uintptr_t m_iFrictionAnimState() { return SCHEMA_TYPE(uintptr_t, 0x1180); }
    uintptr_t m_iMaxFriction() { return SCHEMA_TYPE(uintptr_t, 0x117C); }
    uintptr_t m_iMinFriction() { return SCHEMA_TYPE(uintptr_t, 0x1178); }
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_SmokeGrenadeProjectile : public C_BaseCSGrenadeProjectile {
public:
    uint8_t m_VoxelFrameData() { return SCHEMA_TYPE(uint8_t, 0x1490); }
    bool m_bDidSmokeEffect() { return SCHEMA_TYPE(bool, 0x146C); }
    uintptr_t m_bSmokeEffectSpawned() { return SCHEMA_TYPE(uintptr_t, 0x14B1); }
    uintptr_t m_bSmokeVolumeDataReceived() { return SCHEMA_TYPE(uintptr_t, 0x14B0); }
    int32_t m_nRandomSeed() { return SCHEMA_TYPE(int32_t, 0x1470); }
    int32_t m_nSmokeEffectTickBegin() { return SCHEMA_TYPE(int32_t, 0x1468); }
    int32_t m_nVoxelFrameDataSize() { return SCHEMA_TYPE(int32_t, 0x14A8); }
    int32_t m_nVoxelUpdate() { return SCHEMA_TYPE(int32_t, 0x14AC); }
    Vector3 m_vSmokeColor() { return SCHEMA_TYPE(Vector3, 0x1474); }
    Vector3 m_vSmokeDetonationPos() { return SCHEMA_TYPE(Vector3, 0x1480); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_SmokeGrenadeProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_SmokeGrenadeProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_SmokeGrenadeProjectile() : baseAddr(0) {}
    uint8_t m_VoxelFrameData() { return SCHEMA_TYPE(uint8_t, 0x1478); }
    bool m_bDidSmokeEffect() { return SCHEMA_TYPE(bool, 0x1454); }
    uintptr_t m_bSmokeEffectSpawned() { return SCHEMA_TYPE(uintptr_t, 0x1499); }
    uintptr_t m_bSmokeVolumeDataReceived() { return SCHEMA_TYPE(uintptr_t, 0x1498); }
    int32_t m_nRandomSeed() { return SCHEMA_TYPE(int32_t, 0x1458); }
    int32_t m_nSmokeEffectTickBegin() { return SCHEMA_TYPE(int32_t, 0x1450); }
    int32_t m_nVoxelFrameDataSize() { return SCHEMA_TYPE(int32_t, 0x1490); }
    int32_t m_nVoxelUpdate() { return SCHEMA_TYPE(int32_t, 0x1494); }
    Vector3 m_vSmokeColor() { return SCHEMA_TYPE(Vector3, 0x145C); }
    Vector3 m_vSmokeDetonationPos() { return SCHEMA_TYPE(Vector3, 0x1468); }
};

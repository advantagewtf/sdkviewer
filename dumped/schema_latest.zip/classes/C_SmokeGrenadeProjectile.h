#pragma once
#include "../cstypes/uint8_t.h"
#include "../types/Vector3.h"

class C_SmokeGrenadeProjectile  {
public:
    uintptr_t baseAddr;

    C_SmokeGrenadeProjectile() : baseAddr(0) {}
    C_SmokeGrenadeProjectile(uintptr_t base) : baseAddr(base) {}

    int m_nSmokeEffectTickBegin() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRandomSeed() { return SCHEMA_TYPE(int, 0x20); }
    uint8_t m_VoxelFrameData() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_nVoxelFrameDataSize() { return SCHEMA_TYPE(int, 0x20); }
    int m_nVoxelUpdate() { return SCHEMA_TYPE(int, 0x20); }
};

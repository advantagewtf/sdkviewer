#pragma once
#include "../memory.h"

class C_CSGO_CounterTerroristWingmanIntroCamera {
public:
 uintptr_t baseAddr;
 C_CSGO_CounterTerroristWingmanIntroCamera() : baseAddr(0){}
 C_CSGO_CounterTerroristWingmanIntroCamera(uintptr_t b):baseAddr(b){}
};

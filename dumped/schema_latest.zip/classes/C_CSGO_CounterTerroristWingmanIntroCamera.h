#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_CounterTerroristWingmanIntroCamera {
public:
    uintptr_t baseAddr;
    C_CSGO_CounterTerroristWingmanIntroCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_CounterTerroristWingmanIntroCamera() : baseAddr(0) {}
};

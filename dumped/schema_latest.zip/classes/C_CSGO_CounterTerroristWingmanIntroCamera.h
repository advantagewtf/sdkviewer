#pragma once
#include <cstdint>
class C_CSGO_CounterTerroristWingmanIntroCamera {
public:
};

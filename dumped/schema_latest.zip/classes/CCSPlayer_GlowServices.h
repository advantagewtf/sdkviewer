#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_GlowServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_GlowServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_GlowServices() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CCSPlayer_GlowServices {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponGlock : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponGlock(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponGlock() : baseAddr(0) {}
};

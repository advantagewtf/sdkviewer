#pragma once
#include <cstdint>
class C_WeaponGlock : public C_CSWeaponBaseGun {
public:
};

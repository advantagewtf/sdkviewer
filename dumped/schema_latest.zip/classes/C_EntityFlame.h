#pragma once
#include "../memory.h"

class C_EntityFlame {
public:
 uintptr_t baseAddr;
 C_EntityFlame() : baseAddr(0){}
 C_EntityFlame(uintptr_t b):baseAddr(b){}
 uintptr_t m_hEntAttached(){return SCHEMA_TYPE(uintptr_t,0x5F8);}
 uintptr_t m_hOldAttached(){return SCHEMA_TYPE(uintptr_t,0x620);}
 uintptr_t m_bCheapEffect(){return SCHEMA_TYPE(uintptr_t,0x624);}
};

#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "C_BaseEntity.h"
class C_EntityFlame : public C_BaseEntity {
public:
    bool m_bCheapEffect() { return SCHEMA_TYPE(bool, 0x624); }
    CHandle<C_BaseEntity> m_hEntAttached() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x5F8); }
    uintptr_t m_hOldAttached() { return SCHEMA_TYPE(uintptr_t, 0x620); }
};

#pragma once
class C_BaseEntity;

class C_EntityFlame  {
public:
    uintptr_t baseAddr;

    C_EntityFlame() : baseAddr(0) {}
    C_EntityFlame(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class C_BaseEntity;
class C_EntityFlame : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EntityFlame(uintptr_t addr) : baseAddr(addr) {}
    C_EntityFlame() : baseAddr(0) {}
    bool m_bCheapEffect() { return SCHEMA_TYPE(bool, 0x624); }
    CHandle<C_BaseEntity> m_hEntAttached() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x5F8); }
    uintptr_t m_hOldAttached() { return SCHEMA_TYPE(uintptr_t, 0x620); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class HParticleSystemDefinitionStrong;
class C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_BaseCSGrenadeProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_BaseCSGrenadeProjectile() : baseAddr(0) {}
    uintptr_t flNextTrailLineTime() { return SCHEMA_TYPE(uintptr_t, 0x1400); }
    uintptr_t m_arrTrajectoryTrailPointCreationTimes() { return SCHEMA_TYPE(uintptr_t, 0x1430); }
    uintptr_t m_arrTrajectoryTrailPoints() { return SCHEMA_TYPE(uintptr_t, 0x1418); }
    uintptr_t m_bCanCreateGrenadeTrail() { return SCHEMA_TYPE(uintptr_t, 0x1405); }
    uintptr_t m_bExplodeEffectBegan() { return SCHEMA_TYPE(uintptr_t, 0x1404); }
    uintptr_t m_flSpawnTime() { return SCHEMA_TYPE(uintptr_t, 0x13F0); }
    uintptr_t m_flTrajectoryTrailEffectCreationTime() { return SCHEMA_TYPE(uintptr_t, 0x1448); }
    uintptr_t m_hSnapshotTrajectoryParticleSnapshot() { return SCHEMA_TYPE(uintptr_t, 0x1410); }
    int32_t m_nBounces() { return SCHEMA_TYPE(int32_t, 0x13D0); }
    HParticleSystemDefinitionStrong m_nExplodeEffectIndex() { return SCHEMA_TYPE(HParticleSystemDefinitionStrong, 0x13D8); }
    int32_t m_nExplodeEffectTickBegin() { return SCHEMA_TYPE(int32_t, 0x13E0); }
    uintptr_t m_nSnapshotTrajectoryEffectIndex() { return SCHEMA_TYPE(uintptr_t, 0x1408); }
    Vector3 m_vInitialPosition() { return SCHEMA_TYPE(Vector3, 0x13B8); }
    Vector3 m_vInitialVelocity() { return SCHEMA_TYPE(Vector3, 0x13C4); }
    Vector3 m_vecExplodeEffectOrigin() { return SCHEMA_TYPE(Vector3, 0x13E4); }
    uintptr_t vecLastTrailLinePos() { return SCHEMA_TYPE(uintptr_t, 0x13F4); }
};

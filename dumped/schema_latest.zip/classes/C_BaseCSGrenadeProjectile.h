#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/ParticleIndex_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class C_BaseCSGrenadeProjectile  {
public:
    uintptr_t baseAddr;

    C_BaseCSGrenadeProjectile() : baseAddr(0) {}
    C_BaseCSGrenadeProjectile(uintptr_t base) : baseAddr(base) {}

    int m_nBounces() { return SCHEMA_TYPE(int, 0x20); }
    int m_nExplodeEffectTickBegin() { return SCHEMA_TYPE(int, 0x20); }
    float m_arrTrajectoryTrailPointCreationTimes() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTrajectoryTrailEffectCreationTime() { return SCHEMA_TYPE(float, 0x20); }
};

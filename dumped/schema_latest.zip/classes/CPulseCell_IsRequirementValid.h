#pragma once
#include <cstdint>
class CPulseCell_IsRequirementValid {
public:
};

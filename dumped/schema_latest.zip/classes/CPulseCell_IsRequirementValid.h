#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_IsRequirementValid {
public:
    uintptr_t baseAddr;
    CPulseCell_IsRequirementValid(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_IsRequirementValid() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPulseCell_LimitCount__Criteria_t {
public:
    uintptr_t m_bLimitCountPasses() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

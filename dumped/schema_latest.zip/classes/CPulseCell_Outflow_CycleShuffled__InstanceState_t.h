#pragma once
#include <cstdint>
class CPulseCell_Outflow_CycleShuffled__InstanceState_t {
public:
    uintptr_t m_Shuffle() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_nNextShuffle() { return SCHEMA_TYPE(uintptr_t, 0x20); }
};

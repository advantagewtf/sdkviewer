#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CSkyboxReference {
public:
    uintptr_t baseAddr;
    CSkyboxReference(uintptr_t addr) : baseAddr(addr) {}
    CSkyboxReference() : baseAddr(0) {}
    uintptr_t m_hSkyCamera() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t m_worldGroupId() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

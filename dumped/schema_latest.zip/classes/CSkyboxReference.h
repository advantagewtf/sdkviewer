#pragma once
#include <cstdint>
class CSkyboxReference {
public:
    uintptr_t m_hSkyCamera() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t m_worldGroupId() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
};

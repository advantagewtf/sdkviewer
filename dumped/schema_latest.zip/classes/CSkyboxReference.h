#pragma once
#include "../cstypes/WorldGroupId_t.h"
class C_SkyCamera;

class CSkyboxReference  {
public:
    uintptr_t baseAddr;

    CSkyboxReference() : baseAddr(0) {}
    CSkyboxReference(uintptr_t base) : baseAddr(base) {}

};

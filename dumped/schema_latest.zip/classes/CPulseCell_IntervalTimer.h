#pragma once
#include <cstdint>
class CPulseCell_IntervalTimer {
public:
    uintptr_t m_Completed() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_OnInterval() { return SCHEMA_TYPE(uintptr_t, 0x90); }
};

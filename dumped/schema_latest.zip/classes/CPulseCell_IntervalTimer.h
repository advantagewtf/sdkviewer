#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_IntervalTimer  {
public:
    uintptr_t baseAddr;

    CPulseCell_IntervalTimer() : baseAddr(0) {}
    CPulseCell_IntervalTimer(uintptr_t base) : baseAddr(base) {}

};

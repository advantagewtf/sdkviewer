#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_IntervalTimer {
public:
    uintptr_t baseAddr;
    CPulseCell_IntervalTimer(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_IntervalTimer() : baseAddr(0) {}
    uintptr_t m_Completed() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_OnInterval() { return SCHEMA_TYPE(uintptr_t, 0x90); }
};

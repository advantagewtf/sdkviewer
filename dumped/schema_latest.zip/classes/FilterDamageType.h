#pragma once

class FilterDamageType  {
public:
    uintptr_t baseAddr;

    FilterDamageType() : baseAddr(0) {}
    FilterDamageType(uintptr_t base) : baseAddr(base) {}

    int m_iDamageType() { return SCHEMA_TYPE(int, 0x20); }
};

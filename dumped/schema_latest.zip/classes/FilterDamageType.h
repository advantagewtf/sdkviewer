#pragma once
#include <cstdint>
class FilterDamageType : public CBaseFilter {
public:
    uintptr_t m_iDamageType() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

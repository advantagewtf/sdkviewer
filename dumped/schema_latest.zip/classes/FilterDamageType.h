#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class FilterDamageType : public CBaseFilter {
public:
    uintptr_t baseAddr;
    FilterDamageType(uintptr_t addr) : baseAddr(addr) {}
    FilterDamageType() : baseAddr(0) {}
    uintptr_t m_iDamageType() { return SCHEMA_TYPE(uintptr_t, 0x640); }
};

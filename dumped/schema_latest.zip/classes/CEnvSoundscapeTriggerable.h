#pragma once
#include <cstdint>
class CEnvSoundscapeTriggerable : public CEnvSoundscape {
public:
};

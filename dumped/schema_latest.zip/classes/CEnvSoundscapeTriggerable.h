#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvSoundscapeTriggerable : public CEnvSoundscape {
public:
    uintptr_t baseAddr;
    CEnvSoundscapeTriggerable(uintptr_t addr) : baseAddr(addr) {}
    CEnvSoundscapeTriggerable() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CPlayer_AutoaimServices {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPlayer_AutoaimServices {
public:
    uintptr_t baseAddr;
    CPlayer_AutoaimServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_AutoaimServices() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class SellbackPurchaseEntry_t {
public:
    bool m_bPrevHelmet() { return SCHEMA_TYPE(bool, 0x3C); }
    uintptr_t /* CEntityHandle */ m_hItem() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    int32_t m_nCost() { return SCHEMA_TYPE(int32_t, 0x34); }
    int32_t m_nPrevArmor() { return SCHEMA_TYPE(int32_t, 0x38); }
    uintptr_t /* item_definition_index_t */ m_unDefIdx() { return SCHEMA_TYPE(uintptr_t, 0x30); }
};

#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_Beam : public C_BaseModelEntity {
public:
    bool m_bTurnedOff() { return SCHEMA_TYPE(bool, 0xF58); }
    uintptr_t /* float32 */ m_fAmplitude() { return SCHEMA_TYPE(uintptr_t, 0xF44); }
    uintptr_t /* float32 */ m_fEndWidth() { return SCHEMA_TYPE(uintptr_t, 0xF38); }
    uintptr_t /* float32 */ m_fFadeLength() { return SCHEMA_TYPE(uintptr_t, 0xF3C); }
    uintptr_t /* float32 */ m_fHaloScale() { return SCHEMA_TYPE(uintptr_t, 0xF40); }
    uintptr_t /* float32 */ m_fSpeed() { return SCHEMA_TYPE(uintptr_t, 0xF4C); }
    uintptr_t /* float32 */ m_fStartFrame() { return SCHEMA_TYPE(uintptr_t, 0xF48); }
    uintptr_t /* float32 */ m_fWidth() { return SCHEMA_TYPE(uintptr_t, 0xF34); }
    uintptr_t m_flDamage() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    uintptr_t m_flFireTime() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t /* float32 */ m_flFrame() { return SCHEMA_TYPE(uintptr_t, 0xF50); }
    uintptr_t /* float32 */ m_flFrameRate() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
    uintptr_t /* float32 */ m_flHDRColorScale() { return SCHEMA_TYPE(uintptr_t, 0xEB4); }
    CHandle<CBaseEntity> m_hAttachEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0xF00); }
    uintptr_t /* HMaterialStrong */ m_hBaseMaterial() { return SCHEMA_TYPE(uintptr_t, 0xEE8); }
    uintptr_t m_hEndEntity() { return SCHEMA_TYPE(uintptr_t, 0xF68); }
    uintptr_t /* AttachmentHandle_t */ m_nAttachIndex() { return SCHEMA_TYPE(uintptr_t, 0xF28); }
    uint32_t m_nBeamFlags() { return SCHEMA_TYPE(uint32_t, 0xEFC); }
    uintptr_t /* BeamType_t */ m_nBeamType() { return SCHEMA_TYPE(uintptr_t, 0xEF8); }
    uintptr_t /* BeamClipStyle_t */ m_nClipStyle() { return SCHEMA_TYPE(uintptr_t, 0xF54); }
    uintptr_t /* HMaterialStrong */ m_nHaloIndex() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uint8_t m_nNumBeamEnts() { return SCHEMA_TYPE(uint8_t, 0xEC0); }
    uintptr_t m_queryHandleHalo() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t /* VectorWS */ m_vecEndPos() { return SCHEMA_TYPE(uintptr_t, 0xF5C); }
};

#pragma once
#include "../cstypes/BeamClipStyle_t.h"
#include "../cstypes/BeamType_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint8_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_Beam  {
public:
    uintptr_t baseAddr;

    C_Beam() : baseAddr(0) {}
    C_Beam(uintptr_t base) : baseAddr(base) {}

    float m_flFrameRate() { return SCHEMA_TYPE(float, 0x20); }
    float m_flHDRColorScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDamage() { return SCHEMA_TYPE(float, 0x20); }
    uint8_t m_nNumBeamEnts() { return SCHEMA_TYPE(uint8_t, 0x8); }
    int m_queryHandleHalo() { return SCHEMA_TYPE(int, 0x20); }
    uintptr_t m_hBaseMaterial() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    uintptr_t m_nHaloIndex() { return SCHEMA_TYPE(uintptr_t, 0x2); }
    int m_nBeamFlags() { return SCHEMA_TYPE(int, 0x20); }
    C_BaseEntity* m_hAttachEntity() { return SCHEMA_TYPE(C_BaseEntity*, 0xa); }
    uintptr_t m_nAttachIndex() { return SCHEMA_TYPE(uintptr_t, 0xa); }
    float m_fWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_fEndWidth() { return SCHEMA_TYPE(float, 0x20); }
    float m_fFadeLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_fHaloScale() { return SCHEMA_TYPE(float, 0x20); }
    float m_fAmplitude() { return SCHEMA_TYPE(float, 0x20); }
    float m_fStartFrame() { return SCHEMA_TYPE(float, 0x20); }
    float m_fSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFrame() { return SCHEMA_TYPE(float, 0x20); }
};

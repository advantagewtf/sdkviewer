#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class AttachmentHandle_t;
class BeamClipStyle_t;
class BeamType_t;
class CBaseEntity;
class HMaterialStrong;
class VectorWS;
class float32;
class C_Beam : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_Beam(uintptr_t addr) : baseAddr(addr) {}
    C_Beam() : baseAddr(0) {}
    bool m_bTurnedOff() { return SCHEMA_TYPE(bool, 0xF30); }
    float32 m_fAmplitude() { return SCHEMA_TYPE(float32, 0xF1C); }
    float32 m_fEndWidth() { return SCHEMA_TYPE(float32, 0xF10); }
    float32 m_fFadeLength() { return SCHEMA_TYPE(float32, 0xF14); }
    float32 m_fHaloScale() { return SCHEMA_TYPE(float32, 0xF18); }
    float32 m_fSpeed() { return SCHEMA_TYPE(float32, 0xF24); }
    float32 m_fStartFrame() { return SCHEMA_TYPE(float32, 0xF20); }
    float32 m_fWidth() { return SCHEMA_TYPE(float32, 0xF0C); }
    uintptr_t m_flDamage() { return SCHEMA_TYPE(uintptr_t, 0xE94); }
    uintptr_t m_flFireTime() { return SCHEMA_TYPE(uintptr_t, 0xE90); }
    float32 m_flFrame() { return SCHEMA_TYPE(float32, 0xF28); }
    float32 m_flFrameRate() { return SCHEMA_TYPE(float32, 0xE88); }
    float32 m_flHDRColorScale() { return SCHEMA_TYPE(float32, 0xE8C); }
    CHandle<CBaseEntity> m_hAttachEntity() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0xED8); }
    HMaterialStrong m_hBaseMaterial() { return SCHEMA_TYPE(HMaterialStrong, 0xEC0); }
    uintptr_t m_hEndEntity() { return SCHEMA_TYPE(uintptr_t, 0xF40); }
    AttachmentHandle_t m_nAttachIndex() { return SCHEMA_TYPE(AttachmentHandle_t, 0xF00); }
    uint32_t m_nBeamFlags() { return SCHEMA_TYPE(uint32_t, 0xED4); }
    BeamType_t m_nBeamType() { return SCHEMA_TYPE(BeamType_t, 0xED0); }
    BeamClipStyle_t m_nClipStyle() { return SCHEMA_TYPE(BeamClipStyle_t, 0xF2C); }
    HMaterialStrong m_nHaloIndex() { return SCHEMA_TYPE(HMaterialStrong, 0xEC8); }
    uint8_t m_nNumBeamEnts() { return SCHEMA_TYPE(uint8_t, 0xE98); }
    uintptr_t m_queryHandleHalo() { return SCHEMA_TYPE(uintptr_t, 0xE9C); }
    VectorWS m_vecEndPos() { return SCHEMA_TYPE(VectorWS, 0xF34); }
};

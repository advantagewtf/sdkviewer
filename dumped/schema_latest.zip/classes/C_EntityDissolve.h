#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class EntityDisolveType_t;
class GameTime_t;
class float32;
class C_EntityDissolve : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_EntityDissolve(uintptr_t addr) : baseAddr(addr) {}
    C_EntityDissolve() : baseAddr(0) {}
    uintptr_t m_bCoreExplode() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t m_bLinkedToServerEnt() { return SCHEMA_TYPE(uintptr_t, 0xEC5); }
    float32 m_flFadeInLength() { return SCHEMA_TYPE(float32, 0xE98); }
    float32 m_flFadeInStart() { return SCHEMA_TYPE(float32, 0xE94); }
    float32 m_flFadeOutLength() { return SCHEMA_TYPE(float32, 0xEA8); }
    float32 m_flFadeOutModelLength() { return SCHEMA_TYPE(float32, 0xEA0); }
    float32 m_flFadeOutModelStart() { return SCHEMA_TYPE(float32, 0xE9C); }
    float32 m_flFadeOutStart() { return SCHEMA_TYPE(float32, 0xEA4); }
    uintptr_t m_flNextSparkTime() { return SCHEMA_TYPE(uintptr_t, 0xEAC); }
    GameTime_t m_flStartTime() { return SCHEMA_TYPE(GameTime_t, 0xE90); }
    EntityDisolveType_t m_nDissolveType() { return SCHEMA_TYPE(EntityDisolveType_t, 0xEB0); }
    uint32_t m_nMagnitude() { return SCHEMA_TYPE(uint32_t, 0xEC0); }
    Vector3 m_vDissolverOrigin() { return SCHEMA_TYPE(Vector3, 0xEB4); }
};

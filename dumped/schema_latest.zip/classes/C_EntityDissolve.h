#pragma once
#include "../cstypes/EntityDisolveType_t.h"
#include "../cstypes/GameTime_t.h"
#include "../types/Vector3.h"

class C_EntityDissolve  {
public:
    uintptr_t baseAddr;

    C_EntityDissolve() : baseAddr(0) {}
    C_EntityDissolve(uintptr_t base) : baseAddr(base) {}

    float m_flFadeInStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeInLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeOutModelStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeOutModelLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeOutStart() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeOutLength() { return SCHEMA_TYPE(float, 0x20); }
    int m_nMagnitude() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_EntityDissolve : public C_BaseModelEntity {
public:
    uintptr_t m_bCoreExplode() { return SCHEMA_TYPE(uintptr_t, 0xEEC); }
    uintptr_t m_bLinkedToServerEnt() { return SCHEMA_TYPE(uintptr_t, 0xEED); }
    uintptr_t /* float32 */ m_flFadeInLength() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t /* float32 */ m_flFadeInStart() { return SCHEMA_TYPE(uintptr_t, 0xEBC); }
    uintptr_t /* float32 */ m_flFadeOutLength() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    uintptr_t /* float32 */ m_flFadeOutModelLength() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    uintptr_t /* float32 */ m_flFadeOutModelStart() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t /* float32 */ m_flFadeOutStart() { return SCHEMA_TYPE(uintptr_t, 0xECC); }
    uintptr_t m_flNextSparkTime() { return SCHEMA_TYPE(uintptr_t, 0xED4); }
    uintptr_t /* GameTime_t */ m_flStartTime() { return SCHEMA_TYPE(uintptr_t, 0xEB8); }
    uintptr_t /* EntityDisolveType_t */ m_nDissolveType() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    uint32_t m_nMagnitude() { return SCHEMA_TYPE(uint32_t, 0xEE8); }
    Vector3 m_vDissolverOrigin() { return SCHEMA_TYPE(Vector3, 0xEDC); }
};

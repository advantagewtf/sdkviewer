#pragma once
#include "../cstypes/uintptr_t.h"

class CPathSimple  {
public:
    uintptr_t baseAddr;

    CPathSimple() : baseAddr(0) {}
    CPathSimple(uintptr_t base) : baseAddr(base) {}

};

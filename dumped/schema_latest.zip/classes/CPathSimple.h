#pragma once
#include <cstdint>
class CPathSimple {
public:
    uintptr_t /* CPathQueryComponent::Storage_t */ m_CPathQueryComponent() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_bClosedLoop() { return SCHEMA_TYPE(uintptr_t, 0x6F8); }
    uintptr_t /* CUtlString */ m_pathString() { return SCHEMA_TYPE(uintptr_t, 0x6F0); }
};

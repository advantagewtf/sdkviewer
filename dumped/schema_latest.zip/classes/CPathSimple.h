#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPathQueryComponent__Storage_t;
class CUtlString;
class CPathSimple {
public:
    uintptr_t baseAddr;
    CPathSimple(uintptr_t addr) : baseAddr(addr) {}
    CPathSimple() : baseAddr(0) {}
    CPathQueryComponent__Storage_t m_CPathQueryComponent() { return SCHEMA_TYPE(CPathQueryComponent__Storage_t, 0x610); }
    uintptr_t m_bClosedLoop() { return SCHEMA_TYPE(uintptr_t, 0x708); }
    CUtlString m_pathString() { return SCHEMA_TYPE(CUtlString, 0x700); }
};

#pragma once
#include <cstdint>
class CFilterLOS : public CBaseFilter {
public:
};

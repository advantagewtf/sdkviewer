#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterLOS : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterLOS(uintptr_t addr) : baseAddr(addr) {}
    CFilterLOS() : baseAddr(0) {}
};

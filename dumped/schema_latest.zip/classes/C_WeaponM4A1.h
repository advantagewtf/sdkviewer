#pragma once
#include <cstdint>
class C_WeaponM4A1 : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayerController_InGameMoneyServices {
public:
    uintptr_t baseAddr;
    CCSPlayerController_InGameMoneyServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerController_InGameMoneyServices() : baseAddr(0) {}
    int32_t m_iAccount() { return SCHEMA_TYPE(int32_t, 0x40); }
    int32_t m_iCashSpentThisRound() { return SCHEMA_TYPE(int32_t, 0x4C); }
    int32_t m_iStartAccount() { return SCHEMA_TYPE(int32_t, 0x44); }
    int32_t m_iTotalCashSpent() { return SCHEMA_TYPE(int32_t, 0x48); }
};

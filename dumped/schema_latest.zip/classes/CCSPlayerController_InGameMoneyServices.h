#pragma once
#include <cstdint>
class CCSPlayerController_InGameMoneyServices {
public:
    int32_t m_iAccount() { return SCHEMA_TYPE(int32_t, 0x40); }
    int32_t m_iCashSpentThisRound() { return SCHEMA_TYPE(int32_t, 0x4C); }
    int32_t m_iStartAccount() { return SCHEMA_TYPE(int32_t, 0x44); }
    int32_t m_iTotalCashSpent() { return SCHEMA_TYPE(int32_t, 0x48); }
};

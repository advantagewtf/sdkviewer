#pragma once

class CCSPlayerController_InGameMoneyServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_InGameMoneyServices() : baseAddr(0) {}
    CCSPlayerController_InGameMoneyServices(uintptr_t base) : baseAddr(base) {}

    int m_iAccount() { return SCHEMA_TYPE(int, 0x20); }
    int m_iStartAccount() { return SCHEMA_TYPE(int, 0x20); }
    int m_iTotalCashSpent() { return SCHEMA_TYPE(int, 0x20); }
    int m_iCashSpentThisRound() { return SCHEMA_TYPE(int, 0x20); }
};

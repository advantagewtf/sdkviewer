#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class HSequence;
class float32;
class CNetworkedSequenceOperation {
public:
    uintptr_t baseAddr;
    CNetworkedSequenceOperation(uintptr_t addr) : baseAddr(addr) {}
    CNetworkedSequenceOperation() : baseAddr(0) {}
    uintptr_t m_bDiscontinuity() { return SCHEMA_TYPE(uintptr_t, 0x1D); }
    uintptr_t m_bSequenceChangeNetworked() { return SCHEMA_TYPE(uintptr_t, 0x1C); }
    float32 m_flCycle() { return SCHEMA_TYPE(float32, 0x10); }
    float32 m_flPrevCycle() { return SCHEMA_TYPE(float32, 0xC); }
    uintptr_t m_flPrevCycleForAnimEventDetection() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    uintptr_t m_flPrevCycleFromDiscontinuity() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    uintptr_t m_flWeight() { return SCHEMA_TYPE(uintptr_t, 0x14); }
    HSequence m_hSequence() { return SCHEMA_TYPE(HSequence, 0x8); }
};

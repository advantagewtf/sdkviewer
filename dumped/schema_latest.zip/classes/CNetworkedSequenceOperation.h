#pragma once
#include "../cstypes/uintptr_t.h"

class CNetworkedSequenceOperation  {
public:
    uintptr_t baseAddr;

    CNetworkedSequenceOperation() : baseAddr(0) {}
    CNetworkedSequenceOperation(uintptr_t base) : baseAddr(base) {}

    float m_flPrevCycle() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCycle() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPrevCycleFromDiscontinuity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPrevCycleForAnimEventDetection() { return SCHEMA_TYPE(float, 0x20); }
};

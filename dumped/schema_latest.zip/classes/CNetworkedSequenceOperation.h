#pragma once
#include <cstdint>
class CNetworkedSequenceOperation {
public:
    uintptr_t m_bDiscontinuity() { return SCHEMA_TYPE(uintptr_t, 0x1D); }
    uintptr_t m_bSequenceChangeNetworked() { return SCHEMA_TYPE(uintptr_t, 0x1C); }
    uintptr_t /* float32 */ m_flCycle() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t /* float32 */ m_flPrevCycle() { return SCHEMA_TYPE(uintptr_t, 0xC); }
    uintptr_t m_flPrevCycleForAnimEventDetection() { return SCHEMA_TYPE(uintptr_t, 0x24); }
    uintptr_t m_flPrevCycleFromDiscontinuity() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    uintptr_t m_flWeight() { return SCHEMA_TYPE(uintptr_t, 0x14); }
    uintptr_t /* HSequence */ m_hSequence() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

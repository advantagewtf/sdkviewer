#pragma once
#include <cstdint>
class C_CSGO_TeamSelectCamera : public C_CSGO_TeamPreviewCamera {
public:
};

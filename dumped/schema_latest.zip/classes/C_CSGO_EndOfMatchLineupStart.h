#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_EndOfMatchLineupStart : public C_CSGO_EndOfMatchLineupEndpoint {
public:
    uintptr_t baseAddr;
    C_CSGO_EndOfMatchLineupStart(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_EndOfMatchLineupStart() : baseAddr(0) {}
};

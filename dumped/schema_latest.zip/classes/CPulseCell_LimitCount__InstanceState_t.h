#pragma once
#include <cstdint>
class CPulseCell_LimitCount__InstanceState_t {
public:
    uintptr_t m_nCurrentCount() { return SCHEMA_TYPE(uintptr_t, 0x0); }
};

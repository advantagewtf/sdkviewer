#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterMultipleAPI {
public:
    uintptr_t baseAddr;
    CFilterMultipleAPI(uintptr_t addr) : baseAddr(addr) {}
    CFilterMultipleAPI() : baseAddr(0) {}
};

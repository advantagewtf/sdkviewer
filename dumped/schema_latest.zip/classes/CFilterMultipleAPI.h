#pragma once
#include <cstdint>
class CFilterMultipleAPI {
public:
};

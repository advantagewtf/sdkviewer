#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TerroristWingmanIntroCamera : public C_CSGO_TeamPreviewCamera {
public:
    uintptr_t baseAddr;
    C_CSGO_TerroristWingmanIntroCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TerroristWingmanIntroCamera() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_CSGO_TerroristWingmanIntroCamera : public C_CSGO_TeamPreviewCamera {
public:
};

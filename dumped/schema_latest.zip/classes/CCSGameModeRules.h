#pragma once
#include <cstdint>
class CCSGameModeRules {
public:
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

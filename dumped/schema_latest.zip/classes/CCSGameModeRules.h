#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSGameModeRules {
public:
    uintptr_t baseAddr;
    CCSGameModeRules(uintptr_t addr) : baseAddr(addr) {}
    CCSGameModeRules() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

#pragma once
#include "../classes/CNetworkVarChainer.h"

class CCSGameModeRules  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules() : baseAddr(0) {}
    CCSGameModeRules(uintptr_t base) : baseAddr(base) {}

};

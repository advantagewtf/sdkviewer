#pragma once
#include <cstdint>
class CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t {
public:
    uintptr_t pItem() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t slot() { return SCHEMA_TYPE(uintptr_t, 0xA); }
    uintptr_t team() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

#pragma once
#include <cstdint>
class CPulse_BlackboardReference {
public:
    uintptr_t m_BlackboardResource() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_NodeName() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    uintptr_t m_hBlackboardResource() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t m_nNodeID() { return SCHEMA_TYPE(uintptr_t, 0x18); }
};

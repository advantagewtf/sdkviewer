#pragma once
#include "../cstypes/PulseDocNodeID_t.h"
#include "../cstypes/PulseSymbol_t.h"
#include "../cstypes/uintptr_t.h"

class CPulse_BlackboardReference  {
public:
    uintptr_t baseAddr;

    CPulse_BlackboardReference() : baseAddr(0) {}
    CPulse_BlackboardReference(uintptr_t base) : baseAddr(base) {}

};

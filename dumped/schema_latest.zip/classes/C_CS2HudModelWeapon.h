#pragma once
#include <cstdint>
class C_CS2HudModelWeapon : public C_CS2HudModelBase {
public:
};

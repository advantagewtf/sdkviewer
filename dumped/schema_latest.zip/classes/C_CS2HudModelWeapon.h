#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CS2HudModelWeapon : public C_CS2HudModelBase {
public:
    uintptr_t baseAddr;
    C_CS2HudModelWeapon(uintptr_t addr) : baseAddr(addr) {}
    C_CS2HudModelWeapon() : baseAddr(0) {}
};

#pragma once

class FilterHealth  {
public:
    uintptr_t baseAddr;

    FilterHealth() : baseAddr(0) {}
    FilterHealth(uintptr_t base) : baseAddr(base) {}

    int m_iHealthMin() { return SCHEMA_TYPE(int, 0x20); }
    int m_iHealthMax() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class FilterHealth : public CBaseFilter {
public:
    uintptr_t baseAddr;
    FilterHealth(uintptr_t addr) : baseAddr(addr) {}
    FilterHealth() : baseAddr(0) {}
    uintptr_t m_bAdrenalineActive() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    uintptr_t m_iHealthMax() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    uintptr_t m_iHealthMin() { return SCHEMA_TYPE(uintptr_t, 0x654); }
};

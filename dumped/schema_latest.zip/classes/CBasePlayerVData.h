#pragma once
#include "../cstypes/uintptr_t.h"

class CBasePlayerVData  {
public:
    uintptr_t baseAddr;

    CBasePlayerVData() : baseAddr(0) {}
    CBasePlayerVData(uintptr_t base) : baseAddr(base) {}

    float m_flHoldBreathTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDrowningDamageInterval() { return SCHEMA_TYPE(float, 0x20); }
    int m_nDrowningDamageInitial() { return SCHEMA_TYPE(int, 0x20); }
    int m_nDrowningDamageMax() { return SCHEMA_TYPE(int, 0x20); }
    int m_nWaterSpeed() { return SCHEMA_TYPE(int, 0x20); }
    float m_flUseRange() { return SCHEMA_TYPE(float, 0x20); }
    float m_flUseAngleTolerance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCrouchTime() { return SCHEMA_TYPE(float, 0x20); }
};

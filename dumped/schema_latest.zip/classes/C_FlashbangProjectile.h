#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FlashbangProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_FlashbangProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_FlashbangProjectile() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_FlashbangProjectile : public C_BaseCSGrenadeProjectile {
public:
};

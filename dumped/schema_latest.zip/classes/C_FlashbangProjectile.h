#pragma once
#include "../memory.h"

class C_FlashbangProjectile {
public:
 uintptr_t baseAddr;
 C_FlashbangProjectile() : baseAddr(0){}
 C_FlashbangProjectile(uintptr_t b):baseAddr(b){}
};

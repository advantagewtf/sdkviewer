#pragma once
#include <cstdint>
class C_LightOrthoEntity : public C_LightEntity {
public:
};

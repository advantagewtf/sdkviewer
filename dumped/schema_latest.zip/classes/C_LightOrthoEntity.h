#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_LightOrthoEntity : public C_LightEntity {
public:
    uintptr_t baseAddr;
    C_LightOrthoEntity(uintptr_t addr) : baseAddr(addr) {}
    C_LightOrthoEntity() : baseAddr(0) {}
};

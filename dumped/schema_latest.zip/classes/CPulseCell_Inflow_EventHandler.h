#pragma once
#include "../memory.h"

class CPulseCell_Inflow_EventHandler {
public:
 uintptr_t baseAddr;
 CPulseCell_Inflow_EventHandler() : baseAddr(0){}
 CPulseCell_Inflow_EventHandler(uintptr_t b):baseAddr(b){}
 uintptr_t m_EventName(){return SCHEMA_TYPE(uintptr_t,0x80);}
};

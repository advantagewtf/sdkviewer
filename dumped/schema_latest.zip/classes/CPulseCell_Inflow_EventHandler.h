#pragma once
#include "../cstypes/PulseSymbol_t.h"

class CPulseCell_Inflow_EventHandler  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_EventHandler() : baseAddr(0) {}
    CPulseCell_Inflow_EventHandler(uintptr_t base) : baseAddr(base) {}

};

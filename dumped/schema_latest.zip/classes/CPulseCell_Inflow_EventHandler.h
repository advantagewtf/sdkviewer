#pragma once
#include <cstdint>
class CPulseCell_Inflow_EventHandler {
public:
    uintptr_t m_EventName() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

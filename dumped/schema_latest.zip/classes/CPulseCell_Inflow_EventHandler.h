#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Inflow_EventHandler {
public:
    uintptr_t baseAddr;
    CPulseCell_Inflow_EventHandler(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Inflow_EventHandler() : baseAddr(0) {}
    uintptr_t m_EventName() { return SCHEMA_TYPE(uintptr_t, 0x80); }
};

#pragma once
#include <cstdint>
class CPulseCell_Value_RandomFloat {
public:
};

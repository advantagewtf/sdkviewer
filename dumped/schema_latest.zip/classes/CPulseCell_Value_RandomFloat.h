#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Value_RandomFloat {
public:
    uintptr_t baseAddr;
    CPulseCell_Value_RandomFloat(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Value_RandomFloat() : baseAddr(0) {}
};

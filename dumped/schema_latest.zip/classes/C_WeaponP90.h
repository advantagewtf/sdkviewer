#pragma once
#include <cstdint>
class C_WeaponP90 : public C_CSWeaponBaseGun {
public:
};

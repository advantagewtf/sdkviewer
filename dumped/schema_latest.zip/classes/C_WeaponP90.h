#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponP90 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponP90(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponP90() : baseAddr(0) {}
};

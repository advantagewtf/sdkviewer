#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_HEGrenadeProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_HEGrenadeProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_HEGrenadeProjectile() : baseAddr(0) {}
};

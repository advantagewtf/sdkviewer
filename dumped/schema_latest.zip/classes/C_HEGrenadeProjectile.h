#pragma once
#include <cstdint>
class C_HEGrenadeProjectile : public C_BaseCSGrenadeProjectile {
public:
};

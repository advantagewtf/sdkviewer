#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CPathNode;
class CTransform;
class CPathWithDynamicNodes : public CPathSimple {
public:
    uintptr_t baseAddr;
    CPathWithDynamicNodes(uintptr_t addr) : baseAddr(addr) {}
    CPathWithDynamicNodes() : baseAddr(0) {}
    CHandle<CPathNode> m_vecPathNodes() { return SCHEMA_TYPE(CHandle<CPathNode>, 0x710); }
    CTransform m_xInitialPathWorldToLocal() { return SCHEMA_TYPE(CTransform, 0x730); }
};

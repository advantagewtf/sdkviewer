#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class HRenderTextureStrong;
class C_EnvLightProbeVolume : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvLightProbeVolume(uintptr_t addr) : baseAddr(addr) {}
    C_EnvLightProbeVolume() : baseAddr(0) {}
    bool m_Entity_bEnabled() { return SCHEMA_TYPE(bool, 0x1681); }
    bool m_Entity_bMoveable() { return SCHEMA_TYPE(bool, 0x1650); }
    bool m_Entity_bStartDisabled() { return SCHEMA_TYPE(bool, 0x165C); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightIndicesTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1620); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightScalarsTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1628); }
    HRenderTextureStrong m_Entity_hLightProbeDirectLightShadowsTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1630); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_AmbientCube() { return SCHEMA_TYPE(HRenderTextureStrong, 0x15F0); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SDF() { return SCHEMA_TYPE(HRenderTextureStrong, 0x15F8); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_B() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1618); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_DC() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1600); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_G() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1610); }
    HRenderTextureStrong m_Entity_hLightProbeTexture_SH2_R() { return SCHEMA_TYPE(HRenderTextureStrong, 0x1608); }
    int32_t m_Entity_nHandshake() { return SCHEMA_TYPE(int32_t, 0x1654); }
    int32_t m_Entity_nLightProbeAtlasX() { return SCHEMA_TYPE(int32_t, 0x166C); }
    int32_t m_Entity_nLightProbeAtlasY() { return SCHEMA_TYPE(int32_t, 0x1670); }
    int32_t m_Entity_nLightProbeAtlasZ() { return SCHEMA_TYPE(int32_t, 0x1674); }
    int32_t m_Entity_nLightProbeSizeX() { return SCHEMA_TYPE(int32_t, 0x1660); }
    int32_t m_Entity_nLightProbeSizeY() { return SCHEMA_TYPE(int32_t, 0x1664); }
    int32_t m_Entity_nLightProbeSizeZ() { return SCHEMA_TYPE(int32_t, 0x1668); }
    int32_t m_Entity_nPriority() { return SCHEMA_TYPE(int32_t, 0x1658); }
    Vector3 m_Entity_vBoxMaxs() { return SCHEMA_TYPE(Vector3, 0x1644); }
    Vector3 m_Entity_vBoxMins() { return SCHEMA_TYPE(Vector3, 0x1638); }
};

#pragma once
#include "../types/Vector3.h"

class C_FuncLadder  {
public:
    uintptr_t baseAddr;

    C_FuncLadder() : baseAddr(0) {}
    C_FuncLadder(uintptr_t base) : baseAddr(base) {}

    float m_flAutoRideSpeed() { return SCHEMA_TYPE(float, 0x20); }
};

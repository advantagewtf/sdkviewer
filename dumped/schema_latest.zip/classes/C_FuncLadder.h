#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class VectorWS;
class C_FuncLadder : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncLadder(uintptr_t addr) : baseAddr(addr) {}
    C_FuncLadder() : baseAddr(0) {}
    uintptr_t m_Dismounts() { return SCHEMA_TYPE(uintptr_t, 0xEC0); }
    uintptr_t m_bDisabled() { return SCHEMA_TYPE(uintptr_t, 0xF00); }
    bool m_bFakeLadder() { return SCHEMA_TYPE(bool, 0xF01); }
    uintptr_t m_bHasSlack() { return SCHEMA_TYPE(uintptr_t, 0xF02); }
    float m_flAutoRideSpeed() { return SCHEMA_TYPE(float, 0xEFC); }
    Vector3 m_vecLadderDir() { return SCHEMA_TYPE(Vector3, 0xEB0); }
    uintptr_t m_vecLocalTop() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    VectorWS m_vecPlayerMountPositionBottom() { return SCHEMA_TYPE(VectorWS, 0xEF0); }
    VectorWS m_vecPlayerMountPositionTop() { return SCHEMA_TYPE(VectorWS, 0xEE4); }
};

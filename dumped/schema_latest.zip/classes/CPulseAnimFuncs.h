#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseAnimFuncs {
public:
    uintptr_t baseAddr;
    CPulseAnimFuncs(uintptr_t addr) : baseAddr(addr) {}
    CPulseAnimFuncs() : baseAddr(0) {}
};

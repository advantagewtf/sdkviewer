#pragma once
#include <cstdint>
class CPulseAnimFuncs {
public:
};

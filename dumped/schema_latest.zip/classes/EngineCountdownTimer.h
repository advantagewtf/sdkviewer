#pragma once
#include <cstdint>
class EngineCountdownTimer {
public:
    uintptr_t /* float32 */ m_duration() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t /* float32 */ m_timescale() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t /* float32 */ m_timestamp() { return SCHEMA_TYPE(uintptr_t, 0xC); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class float32;
class EngineCountdownTimer {
public:
    uintptr_t baseAddr;
    EngineCountdownTimer(uintptr_t addr) : baseAddr(addr) {}
    EngineCountdownTimer() : baseAddr(0) {}
    float32 m_duration() { return SCHEMA_TYPE(float32, 0x8); }
    float32 m_timescale() { return SCHEMA_TYPE(float32, 0x10); }
    float32 m_timestamp() { return SCHEMA_TYPE(float32, 0xC); }
};

#pragma once

class EngineCountdownTimer  {
public:
    uintptr_t baseAddr;

    EngineCountdownTimer() : baseAddr(0) {}
    EngineCountdownTimer(uintptr_t base) : baseAddr(base) {}

    float m_duration() { return SCHEMA_TYPE(float, 0x20); }
    float m_timestamp() { return SCHEMA_TYPE(float, 0x20); }
    float m_timescale() { return SCHEMA_TYPE(float, 0x20); }
};

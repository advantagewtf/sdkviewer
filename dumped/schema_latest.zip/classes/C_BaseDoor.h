#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_BaseDoor {
public:
    uintptr_t baseAddr;
    C_BaseDoor(uintptr_t addr) : baseAddr(addr) {}
    C_BaseDoor() : baseAddr(0) {}
    bool m_bIsUsable() { return SCHEMA_TYPE(bool, 0xE88); }
};

#pragma once
#include <cstdint>
class C_BaseDoor {
public:
    bool m_bIsUsable() { return SCHEMA_TYPE(bool, 0xEB0); }
};

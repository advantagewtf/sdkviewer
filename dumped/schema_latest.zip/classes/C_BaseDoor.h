#pragma once

class C_BaseDoor  {
public:
    uintptr_t baseAddr;

    C_BaseDoor() : baseAddr(0) {}
    C_BaseDoor(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamSelectCharacterPosition : public C_CSGO_TeamPreviewCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamSelectCharacterPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamSelectCharacterPosition() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CFilterMassGreater : public CBaseFilter {
public:
    uintptr_t m_fFilterMass() { return SCHEMA_TYPE(uintptr_t, 0x650); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CFilterMassGreater : public CBaseFilter {
public:
    uintptr_t baseAddr;
    CFilterMassGreater(uintptr_t addr) : baseAddr(addr) {}
    CFilterMassGreater() : baseAddr(0) {}
    uintptr_t m_fFilterMass() { return SCHEMA_TYPE(uintptr_t, 0x640); }
};

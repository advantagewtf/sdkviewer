#pragma once

class CFilterMassGreater  {
public:
    uintptr_t baseAddr;

    CFilterMassGreater() : baseAddr(0) {}
    CFilterMassGreater(uintptr_t base) : baseAddr(base) {}

    float m_fFilterMass() { return SCHEMA_TYPE(float, 0x20); }
};

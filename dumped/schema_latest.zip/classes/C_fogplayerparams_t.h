#pragma once
#include "../memory.h"

class C_fogplayerparams_t {
public:
 uintptr_t baseAddr;
 C_fogplayerparams_t() : baseAddr(0){}
 C_fogplayerparams_t(uintptr_t b):baseAddr(b){}
 uintptr_t m_hCtrl(){return SCHEMA_TYPE(uintptr_t,0x8);}
 uintptr_t m_flTransitionTime(){return SCHEMA_TYPE(uintptr_t,0xC);}
 uintptr_t m_OldColor(){return SCHEMA_TYPE(uintptr_t,0x10);}
 uintptr_t m_flOldStart(){return SCHEMA_TYPE(uintptr_t,0x14);}
 uintptr_t m_flOldEnd(){return SCHEMA_TYPE(uintptr_t,0x18);}
 uintptr_t m_flOldMaxDensity(){return SCHEMA_TYPE(uintptr_t,0x1C);}
 uintptr_t m_flOldHDRColorScale(){return SCHEMA_TYPE(uintptr_t,0x20);}
 uintptr_t m_flOldFarZ(){return SCHEMA_TYPE(uintptr_t,0x24);}
 uintptr_t m_NewColor(){return SCHEMA_TYPE(uintptr_t,0x28);}
 uintptr_t m_flNewStart(){return SCHEMA_TYPE(uintptr_t,0x2C);}
 uintptr_t m_flNewEnd(){return SCHEMA_TYPE(uintptr_t,0x30);}
 uintptr_t m_flNewMaxDensity(){return SCHEMA_TYPE(uintptr_t,0x34);}
 uintptr_t m_flNewHDRColorScale(){return SCHEMA_TYPE(uintptr_t,0x38);}
 uintptr_t m_flNewFarZ(){return SCHEMA_TYPE(uintptr_t,0x3C);}
};

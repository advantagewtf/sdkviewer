#pragma once

class C_PhysicsProp  {
public:
    uintptr_t baseAddr;

    C_PhysicsProp() : baseAddr(0) {}
    C_PhysicsProp(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PhysicsProp : public C_BreakableProp {
public:
    uintptr_t baseAddr;
    C_PhysicsProp(uintptr_t addr) : baseAddr(addr) {}
    C_PhysicsProp() : baseAddr(0) {}
    bool m_bAwake() { return SCHEMA_TYPE(bool, 0x1300); }
};

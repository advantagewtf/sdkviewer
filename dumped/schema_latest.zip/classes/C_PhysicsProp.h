#pragma once
#include <cstdint>
class C_PhysicsProp : public C_BreakableProp {
public:
    bool m_bAwake() { return SCHEMA_TYPE(bool, 0x1300); }
};

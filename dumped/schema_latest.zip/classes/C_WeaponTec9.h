#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponTec9 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponTec9(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponTec9() : baseAddr(0) {}
};

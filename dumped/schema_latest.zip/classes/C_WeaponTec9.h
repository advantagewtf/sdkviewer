#pragma once
#include <cstdint>
class C_WeaponTec9 : public C_CSWeaponBaseGun {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEntityComponent {
public:
    uintptr_t baseAddr;
    CEntityComponent(uintptr_t addr) : baseAddr(addr) {}
    CEntityComponent() : baseAddr(0) {}
};

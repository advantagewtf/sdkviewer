#pragma once
#include <cstdint>
class CEntityComponent {
public:
};

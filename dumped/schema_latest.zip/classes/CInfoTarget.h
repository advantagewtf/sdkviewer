#pragma once
#include <cstdint>
class CInfoTarget {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CInfoTarget {
public:
    uintptr_t baseAddr;
    CInfoTarget(uintptr_t addr) : baseAddr(addr) {}
    CInfoTarget() : baseAddr(0) {}
};

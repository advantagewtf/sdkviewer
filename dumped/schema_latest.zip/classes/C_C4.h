#pragma once
#include "../cstypes/C4LightEffect_t.h"
#include "../cstypes/EntitySpottedState_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/ParticleIndex_t.h"

class C_C4  {
public:
    uintptr_t baseAddr;

    C_C4() : baseAddr(0) {}
    C_C4(uintptr_t base) : baseAddr(base) {}

    C4LightEffect_t m_eActiveLightEffect() { return SCHEMA_TYPE(C4LightEffect_t, 0x4); }
    int m_nSpotRules() { return SCHEMA_TYPE(int, 0x20); }
    bool m_bPlayedArmingBeeps() { return SCHEMA_TYPE(bool, 0x7); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class EntitySpottedState_t;
class GameTime_t;
class C_C4 {
public:
    uintptr_t baseAddr;
    C_C4(uintptr_t addr) : baseAddr(addr) {}
    C_C4() : baseAddr(0) {}
    uintptr_t m_activeLightParticleIndex() { return SCHEMA_TYPE(uintptr_t, 0x1F80); }
    bool m_bBombPlacedAnimation() { return SCHEMA_TYPE(bool, 0x1F90); }
    uintptr_t m_bBombPlanted() { return SCHEMA_TYPE(uintptr_t, 0x1FBB); }
    bool m_bIsPlantingViaUse() { return SCHEMA_TYPE(bool, 0x1F91); }
    uintptr_t m_bPlayedArmingBeeps() { return SCHEMA_TYPE(uintptr_t, 0x1FB4); }
    bool m_bStartedArming() { return SCHEMA_TYPE(bool, 0x1F88); }
    uintptr_t m_eActiveLightEffect() { return SCHEMA_TYPE(uintptr_t, 0x1F84); }
    EntitySpottedState_t m_entitySpottedState() { return SCHEMA_TYPE(EntitySpottedState_t, 0x1F98); }
    GameTime_t m_fArmedTime() { return SCHEMA_TYPE(GameTime_t, 0x1F8C); }
    uintptr_t m_nSpotRules() { return SCHEMA_TYPE(uintptr_t, 0x1FB0); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class C_GradientFog  {
public:
    uintptr_t baseAddr;

    C_GradientFog() : baseAddr(0) {}
    C_GradientFog(uintptr_t base) : baseAddr(base) {}

    float m_flFogStartDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogEndDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogStartHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogEndHeight() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFarZ() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogMaxOpacity() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogFalloffExponent() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogVerticalExponent() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFogStrength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFadeTime() { return SCHEMA_TYPE(float, 0x20); }
};

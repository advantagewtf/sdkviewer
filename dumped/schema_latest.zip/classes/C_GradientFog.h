#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class Color;
class HRenderTextureStrong;
class C_GradientFog : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_GradientFog(uintptr_t addr) : baseAddr(addr) {}
    C_GradientFog() : baseAddr(0) {}
    uintptr_t m_bGradientFogNeedsTextures() { return SCHEMA_TYPE(uintptr_t, 0x632); }
    bool m_bHeightFogEnabled() { return SCHEMA_TYPE(bool, 0x608); }
    bool m_bIsEnabled() { return SCHEMA_TYPE(bool, 0x631); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x630); }
    float m_flFadeTime() { return SCHEMA_TYPE(float, 0x62C); }
    float m_flFarZ() { return SCHEMA_TYPE(float, 0x614); }
    float m_flFogEndDistance() { return SCHEMA_TYPE(float, 0x604); }
    float m_flFogEndHeight() { return SCHEMA_TYPE(float, 0x610); }
    float m_flFogFalloffExponent() { return SCHEMA_TYPE(float, 0x61C); }
    float m_flFogMaxOpacity() { return SCHEMA_TYPE(float, 0x618); }
    float m_flFogStartDistance() { return SCHEMA_TYPE(float, 0x600); }
    float m_flFogStartHeight() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flFogStrength() { return SCHEMA_TYPE(float, 0x628); }
    float m_flFogVerticalExponent() { return SCHEMA_TYPE(float, 0x620); }
    Color m_fogColor() { return SCHEMA_TYPE(Color, 0x624); }
    HRenderTextureStrong m_hGradientFogTexture() { return SCHEMA_TYPE(HRenderTextureStrong, 0x5F8); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CChoreoInfoTarget {
public:
    uintptr_t baseAddr;
    CChoreoInfoTarget(uintptr_t addr) : baseAddr(addr) {}
    CChoreoInfoTarget() : baseAddr(0) {}
};

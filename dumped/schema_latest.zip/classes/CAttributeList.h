#pragma once
#include "../types/Vector3.h"
class CAttributeManager;

class CAttributeList  {
public:
    uintptr_t baseAddr;

    CAttributeList() : baseAddr(0) {}
    CAttributeList(uintptr_t base) : baseAddr(base) {}

};

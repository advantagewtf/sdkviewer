#pragma once
#include <cstdint>
class CAttributeList {
public:
    uintptr_t /* CEconItemAttribute */ m_Attributes() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t m_pManager() { return SCHEMA_TYPE(uintptr_t, 0x70); }
};

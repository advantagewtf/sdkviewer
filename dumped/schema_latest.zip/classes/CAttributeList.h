#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEconItemAttribute;
class CAttributeList {
public:
    uintptr_t baseAddr;
    CAttributeList(uintptr_t addr) : baseAddr(addr) {}
    CAttributeList() : baseAddr(0) {}
    CEconItemAttribute m_Attributes() { return SCHEMA_TYPE(CEconItemAttribute, 0x8); }
    uintptr_t m_pManager() { return SCHEMA_TYPE(uintptr_t, 0x70); }
};

#pragma once
#include <cstdint>
class CAttributeManager__cached_attribute_float_t {
public:
    uintptr_t flIn() { return SCHEMA_TYPE(uintptr_t, 0x0); }
    uintptr_t flOut() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t iAttribHook() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

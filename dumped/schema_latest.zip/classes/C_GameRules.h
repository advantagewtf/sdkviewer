#pragma once
#include "../classes/CNetworkVarChainer.h"

class C_GameRules  {
public:
    uintptr_t baseAddr;

    C_GameRules() : baseAddr(0) {}
    C_GameRules(uintptr_t base) : baseAddr(base) {}

    int m_nTotalPausedTicks() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPauseStartTick() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_GameRules {
public:
    uintptr_t baseAddr;
    C_GameRules(uintptr_t addr) : baseAddr(addr) {}
    C_GameRules() : baseAddr(0) {}
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    bool m_bGamePaused() { return SCHEMA_TYPE(bool, 0x38); }
    int32_t m_nPauseStartTick() { return SCHEMA_TYPE(int32_t, 0x34); }
    int32_t m_nTotalPausedTicks() { return SCHEMA_TYPE(int32_t, 0x30); }
};

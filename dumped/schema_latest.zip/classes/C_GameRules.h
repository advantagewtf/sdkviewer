#pragma once
#include <cstdint>
class C_GameRules {
public:
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    bool m_bGamePaused() { return SCHEMA_TYPE(bool, 0x38); }
    int32_t m_nPauseStartTick() { return SCHEMA_TYPE(int32_t, 0x34); }
    int32_t m_nTotalPausedTicks() { return SCHEMA_TYPE(int32_t, 0x30); }
};

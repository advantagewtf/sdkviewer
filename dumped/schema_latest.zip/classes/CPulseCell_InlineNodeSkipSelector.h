#pragma once
#include "../classes/CPulse_OutflowConnection.h"
#include "../cstypes/PulseDocNodeID_t.h"
#include "../cstypes/PulseSelectorOutflowList_t.h"

class CPulseCell_InlineNodeSkipSelector  {
public:
    uintptr_t baseAddr;

    CPulseCell_InlineNodeSkipSelector() : baseAddr(0) {}
    CPulseCell_InlineNodeSkipSelector(uintptr_t base) : baseAddr(base) {}

};

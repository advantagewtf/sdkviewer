#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_InlineNodeSkipSelector {
public:
    uintptr_t baseAddr;
    CPulseCell_InlineNodeSkipSelector(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_InlineNodeSkipSelector() : baseAddr(0) {}
    uintptr_t m_FailOutflow() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_PassOutflow() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_bAnd() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t m_nFlowNodeID() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include <cstdint>
class CPulseCell_InlineNodeSkipSelector {
public:
    uintptr_t m_FailOutflow() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_PassOutflow() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_bAnd() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t m_nFlowNodeID() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

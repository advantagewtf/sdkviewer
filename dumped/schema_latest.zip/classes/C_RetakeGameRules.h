#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSPlayerPawn;
class C_RetakeGameRules {
public:
    uintptr_t baseAddr;
    C_RetakeGameRules(uintptr_t addr) : baseAddr(addr) {}
    C_RetakeGameRules() : baseAddr(0) {}
    bool m_bBlockersPresent() { return SCHEMA_TYPE(bool, 0x13C); }
    bool m_bRoundInProgress() { return SCHEMA_TYPE(bool, 0x13D); }
    CHandle<CCSPlayerPawn> m_hBombPlanter() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x148); }
    int32_t m_iBombSite() { return SCHEMA_TYPE(int32_t, 0x144); }
    int32_t m_iFirstSecondHalfRound() { return SCHEMA_TYPE(int32_t, 0x140); }
    int32_t m_nMatchSeed() { return SCHEMA_TYPE(int32_t, 0x138); }
};

#pragma once
class C_CSPlayerPawn;

class C_RetakeGameRules  {
public:
    uintptr_t baseAddr;

    C_RetakeGameRules() : baseAddr(0) {}
    C_RetakeGameRules(uintptr_t base) : baseAddr(base) {}

    int m_nMatchSeed() { return SCHEMA_TYPE(int, 0x20); }
    int m_iFirstSecondHalfRound() { return SCHEMA_TYPE(int, 0x20); }
    int m_iBombSite() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
class CLightComponent;

class C_LightEntity  {
public:
    uintptr_t baseAddr;

    C_LightEntity() : baseAddr(0) {}
    C_LightEntity(uintptr_t base) : baseAddr(base) {}

};

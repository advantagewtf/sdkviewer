#pragma once
#include <cstdint>
class C_LightEntity : public C_BaseModelEntity {
public:
    uintptr_t /* CLightComponent::Storage_t */ m_CLightComponent() { return SCHEMA_TYPE(uintptr_t, 0xEB0); }
};

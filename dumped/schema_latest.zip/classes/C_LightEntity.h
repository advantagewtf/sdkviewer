#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CLightComponent__Storage_t;
class C_LightEntity : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_LightEntity(uintptr_t addr) : baseAddr(addr) {}
    C_LightEntity() : baseAddr(0) {}
    CLightComponent__Storage_t m_CLightComponent() { return SCHEMA_TYPE(CLightComponent__Storage_t, 0xE88); }
};

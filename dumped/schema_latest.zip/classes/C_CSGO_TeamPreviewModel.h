#pragma once
#include <cstdint>
class C_CSGO_TeamPreviewModel : public C_CSGO_PreviewPlayer {
public:
};

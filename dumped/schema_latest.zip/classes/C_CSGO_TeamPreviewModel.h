#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamPreviewModel : public C_CSGO_PreviewPlayer {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamPreviewModel(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamPreviewModel() : baseAddr(0) {}
};

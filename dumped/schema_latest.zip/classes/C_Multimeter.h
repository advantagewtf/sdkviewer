#pragma once
class C_PlantedC4;

class C_Multimeter  {
public:
    uintptr_t baseAddr;

    C_Multimeter() : baseAddr(0) {}
    C_Multimeter(uintptr_t base) : baseAddr(base) {}

    C_PlantedC4* m_hTargetC4() { return SCHEMA_TYPE(C_PlantedC4*, 0x4); }
};

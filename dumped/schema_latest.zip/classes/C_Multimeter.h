#pragma once
#include <cstdint>
class C_Multimeter : public CBaseAnimGraph {
public:
    uintptr_t m_hTargetC4() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
};

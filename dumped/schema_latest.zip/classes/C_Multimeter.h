#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Multimeter : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_Multimeter(uintptr_t addr) : baseAddr(addr) {}
    C_Multimeter() : baseAddr(0) {}
    uintptr_t m_hTargetC4() { return SCHEMA_TYPE(uintptr_t, 0x1160); }
};

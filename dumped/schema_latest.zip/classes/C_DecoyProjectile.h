#pragma once
#include <cstdint>
class C_DecoyProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t m_flTimeParticleEffectSpawn() { return SCHEMA_TYPE(uintptr_t, 0x1478); }
    uintptr_t m_nClientLastKnownDecoyShotTick() { return SCHEMA_TYPE(uintptr_t, 0x1454); }
    int32_t m_nDecoyShotTick() { return SCHEMA_TYPE(int32_t, 0x1450); }
};

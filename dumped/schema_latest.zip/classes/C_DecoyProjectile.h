#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_DecoyProjectile : public C_BaseCSGrenadeProjectile {
public:
    uintptr_t baseAddr;
    C_DecoyProjectile(uintptr_t addr) : baseAddr(addr) {}
    C_DecoyProjectile() : baseAddr(0) {}
    uintptr_t m_flTimeParticleEffectSpawn() { return SCHEMA_TYPE(uintptr_t, 0x1460); }
    uintptr_t m_nClientLastKnownDecoyShotTick() { return SCHEMA_TYPE(uintptr_t, 0x143C); }
    int32_t m_nDecoyShotTick() { return SCHEMA_TYPE(int32_t, 0x1438); }
};

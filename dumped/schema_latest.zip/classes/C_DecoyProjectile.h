#pragma once
#include "../cstypes/GameTime_t.h"

class C_DecoyProjectile  {
public:
    uintptr_t baseAddr;

    C_DecoyProjectile() : baseAddr(0) {}
    C_DecoyProjectile(uintptr_t base) : baseAddr(base) {}

    int m_nDecoyShotTick() { return SCHEMA_TYPE(int, 0x20); }
    int m_nClientLastKnownDecoyShotTick() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
class C_TonemapController2Alias_env_tonemap_controller2 : public C_TonemapController2 {
public:
};

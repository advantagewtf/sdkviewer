#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_TonemapController2Alias_env_tonemap_controller2 : public C_TonemapController2 {
public:
    uintptr_t baseAddr;
    C_TonemapController2Alias_env_tonemap_controller2(uintptr_t addr) : baseAddr(addr) {}
    C_TonemapController2Alias_env_tonemap_controller2() : baseAddr(0) {}
};

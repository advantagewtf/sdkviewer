#pragma once
#include "../cstypes/PulseSymbol_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPulseCell_Inflow_Method  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Method() : baseAddr(0) {}
    CPulseCell_Inflow_Method(uintptr_t base) : baseAddr(base) {}

};

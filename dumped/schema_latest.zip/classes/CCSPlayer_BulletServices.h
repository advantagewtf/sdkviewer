#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSPlayer_BulletServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_BulletServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_BulletServices() : baseAddr(0) {}
    int32_t m_totalHitsOnServer() { return SCHEMA_TYPE(int32_t, 0x48); }
};

#pragma once
#include <cstdint>
class CCSPlayer_BulletServices {
public:
    int32_t m_totalHitsOnServer() { return SCHEMA_TYPE(int32_t, 0x40); }
};

#pragma once

class CCSPlayer_BulletServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_BulletServices() : baseAddr(0) {}
    CCSPlayer_BulletServices(uintptr_t base) : baseAddr(base) {}

    int m_totalHitsOnServer() { return SCHEMA_TYPE(int, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CUtlStringToken;
class sky3dparams_t;
class C_SkyCamera : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_SkyCamera(uintptr_t addr) : baseAddr(addr) {}
    C_SkyCamera() : baseAddr(0) {}
    uintptr_t m_bUseAngles() { return SCHEMA_TYPE(uintptr_t, 0x69C); }
    uintptr_t m_pNext() { return SCHEMA_TYPE(uintptr_t, 0x6A0); }
    sky3dparams_t m_skyboxData() { return SCHEMA_TYPE(sky3dparams_t, 0x608); }
    CUtlStringToken m_skyboxSlotToken() { return SCHEMA_TYPE(CUtlStringToken, 0x698); }
};

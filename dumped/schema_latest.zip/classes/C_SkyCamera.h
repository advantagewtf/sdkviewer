#pragma once
#include "../cstypes/sky3dparams_t.h"
#include "../cstypes/uintptr_t.h"

class C_SkyCamera  {
public:
    uintptr_t baseAddr;

    C_SkyCamera() : baseAddr(0) {}
    C_SkyCamera(uintptr_t base) : baseAddr(base) {}

    sky3dparams_t m_skyboxData() { return SCHEMA_TYPE(sky3dparams_t, 0x3); }
};

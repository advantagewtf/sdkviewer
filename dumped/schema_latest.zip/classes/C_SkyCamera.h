#pragma once
#include <cstdint>
class C_SkyCamera : public C_BaseEntity {
public:
    uintptr_t m_bUseAngles() { return SCHEMA_TYPE(uintptr_t, 0x68C); }
    uintptr_t m_pNext() { return SCHEMA_TYPE(uintptr_t, 0x690); }
    uintptr_t /* sky3dparams_t */ m_skyboxData() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t /* CUtlStringToken */ m_skyboxSlotToken() { return SCHEMA_TYPE(uintptr_t, 0x688); }
};

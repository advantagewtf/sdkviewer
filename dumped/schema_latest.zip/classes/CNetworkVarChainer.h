#pragma once
#include "../cstypes/ChangeAccessorFieldPathIndex_t.h"

class CNetworkVarChainer  {
public:
    uintptr_t baseAddr;

    CNetworkVarChainer() : baseAddr(0) {}
    CNetworkVarChainer(uintptr_t base) : baseAddr(base) {}

};

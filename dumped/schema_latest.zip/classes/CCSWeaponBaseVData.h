#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSWeaponBaseVData {
public:
    uintptr_t baseAddr;
    CCSWeaponBaseVData(uintptr_t addr) : baseAddr(addr) {}
    CCSWeaponBaseVData() : baseAddr(0) {}
    uintptr_t m_DefaultLoadoutSlot() { return SCHEMA_TYPE(uintptr_t, 0x628); }
    uintptr_t m_GearSlot() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_GearSlotPosition() { return SCHEMA_TYPE(uintptr_t, 0x624); }
    uintptr_t m_WeaponCategory() { return SCHEMA_TYPE(uintptr_t, 0x444); }
    uintptr_t m_WeaponType() { return SCHEMA_TYPE(uintptr_t, 0x440); }
    uintptr_t m_bAllowBurstHolster() { return SCHEMA_TYPE(uintptr_t, 0x6F0); }
    uintptr_t m_bCannotShootUnderwater() { return SCHEMA_TYPE(uintptr_t, 0x63F); }
    uintptr_t m_bHasBurstMode() { return SCHEMA_TYPE(uintptr_t, 0x63D); }
    uintptr_t m_bHideViewModelWhenZoomed() { return SCHEMA_TYPE(uintptr_t, 0x711); }
    uintptr_t m_bIsFullAuto() { return SCHEMA_TYPE(uintptr_t, 0x654); }
    uintptr_t m_bIsRevolver() { return SCHEMA_TYPE(uintptr_t, 0x63E); }
    uintptr_t m_bMeleeWeapon() { return SCHEMA_TYPE(uintptr_t, 0x63C); }
    uintptr_t m_bReloadsSingleShells() { return SCHEMA_TYPE(uintptr_t, 0x65C); }
    uintptr_t m_bUnzoomsAfterShot() { return SCHEMA_TYPE(uintptr_t, 0x710); }
    uintptr_t m_eSilencerType() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    uintptr_t m_flArmorRatio() { return SCHEMA_TYPE(uintptr_t, 0x748); }
    uintptr_t m_flAttackMovespeedFactor() { return SCHEMA_TYPE(uintptr_t, 0x6FC); }
    uintptr_t m_flCycleTime() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    uintptr_t m_flDeployDuration() { return SCHEMA_TYPE(uintptr_t, 0x6E4); }
    uintptr_t m_flDisallowAttackAfterReloadStartDuration() { return SCHEMA_TYPE(uintptr_t, 0x6E8); }
    uintptr_t m_flFlinchVelocityModifierLarge() { return SCHEMA_TYPE(uintptr_t, 0x758); }
    uintptr_t m_flFlinchVelocityModifierSmall() { return SCHEMA_TYPE(uintptr_t, 0x75C); }
    uintptr_t m_flHeadshotMultiplier() { return SCHEMA_TYPE(uintptr_t, 0x744); }
    uintptr_t m_flInaccuracyAltSoundThreshold() { return SCHEMA_TYPE(uintptr_t, 0x704); }
    uintptr_t m_flInaccuracyCrouch() { return SCHEMA_TYPE(uintptr_t, 0x678); }
    uintptr_t m_flInaccuracyFire() { return SCHEMA_TYPE(uintptr_t, 0x6A0); }
    uintptr_t m_flInaccuracyJump() { return SCHEMA_TYPE(uintptr_t, 0x688); }
    uintptr_t m_flInaccuracyJumpApex() { return SCHEMA_TYPE(uintptr_t, 0x6DC); }
    uintptr_t m_flInaccuracyJumpInitial() { return SCHEMA_TYPE(uintptr_t, 0x6D8); }
    uintptr_t m_flInaccuracyLadder() { return SCHEMA_TYPE(uintptr_t, 0x698); }
    uintptr_t m_flInaccuracyLand() { return SCHEMA_TYPE(uintptr_t, 0x690); }
    uintptr_t m_flInaccuracyMove() { return SCHEMA_TYPE(uintptr_t, 0x6A8); }
    uintptr_t m_flInaccuracyPitchShift() { return SCHEMA_TYPE(uintptr_t, 0x700); }
    uintptr_t m_flInaccuracyReload() { return SCHEMA_TYPE(uintptr_t, 0x6E0); }
    uintptr_t m_flInaccuracyStand() { return SCHEMA_TYPE(uintptr_t, 0x680); }
    uintptr_t m_flIronSightFOV() { return SCHEMA_TYPE(uintptr_t, 0x734); }
    uintptr_t m_flIronSightLooseness() { return SCHEMA_TYPE(uintptr_t, 0x73C); }
    uintptr_t m_flIronSightPivotForward() { return SCHEMA_TYPE(uintptr_t, 0x738); }
    uintptr_t m_flIronSightPullUpSpeed() { return SCHEMA_TYPE(uintptr_t, 0x72C); }
    uintptr_t m_flIronSightPutDownSpeed() { return SCHEMA_TYPE(uintptr_t, 0x730); }
    uintptr_t m_flMaxSpeed() { return SCHEMA_TYPE(uintptr_t, 0x668); }
    uintptr_t m_flPenetration() { return SCHEMA_TYPE(uintptr_t, 0x74C); }
    uintptr_t m_flRange() { return SCHEMA_TYPE(uintptr_t, 0x750); }
    uintptr_t m_flRangeModifier() { return SCHEMA_TYPE(uintptr_t, 0x754); }
    uintptr_t m_flRecoilAngle() { return SCHEMA_TYPE(uintptr_t, 0x6B0); }
    uintptr_t m_flRecoilAngleVariance() { return SCHEMA_TYPE(uintptr_t, 0x6B8); }
    uintptr_t m_flRecoilMagnitude() { return SCHEMA_TYPE(uintptr_t, 0x6C0); }
    uintptr_t m_flRecoilMagnitudeVariance() { return SCHEMA_TYPE(uintptr_t, 0x6C8); }
    uintptr_t m_flRecoveryTimeCrouch() { return SCHEMA_TYPE(uintptr_t, 0x760); }
    uintptr_t m_flRecoveryTimeCrouchFinal() { return SCHEMA_TYPE(uintptr_t, 0x768); }
    uintptr_t m_flRecoveryTimeStand() { return SCHEMA_TYPE(uintptr_t, 0x764); }
    uintptr_t m_flRecoveryTimeStandFinal() { return SCHEMA_TYPE(uintptr_t, 0x76C); }
    uintptr_t m_flSpread() { return SCHEMA_TYPE(uintptr_t, 0x670); }
    uintptr_t m_flThrowVelocity() { return SCHEMA_TYPE(uintptr_t, 0x778); }
    uintptr_t m_flZoomTime0() { return SCHEMA_TYPE(uintptr_t, 0x720); }
    uintptr_t m_flZoomTime1() { return SCHEMA_TYPE(uintptr_t, 0x724); }
    uintptr_t m_flZoomTime2() { return SCHEMA_TYPE(uintptr_t, 0x728); }
    uintptr_t m_nBurstShotCount() { return SCHEMA_TYPE(uintptr_t, 0x6EC); }
    uintptr_t m_nCrosshairDeltaDistance() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    uintptr_t m_nCrosshairMinDistance() { return SCHEMA_TYPE(uintptr_t, 0x64C); }
    uintptr_t m_nDamage() { return SCHEMA_TYPE(uintptr_t, 0x740); }
    uintptr_t m_nKillAward() { return SCHEMA_TYPE(uintptr_t, 0x630); }
    uintptr_t m_nNumBullets() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    uintptr_t m_nPrice() { return SCHEMA_TYPE(uintptr_t, 0x62C); }
    uintptr_t m_nPrimaryReserveAmmoMax() { return SCHEMA_TYPE(uintptr_t, 0x634); }
    uintptr_t m_nRecoilSeed() { return SCHEMA_TYPE(uintptr_t, 0x6F4); }
    uintptr_t m_nRecoveryTransitionEndBullet() { return SCHEMA_TYPE(uintptr_t, 0x774); }
    uintptr_t m_nRecoveryTransitionStartBullet() { return SCHEMA_TYPE(uintptr_t, 0x770); }
    uintptr_t m_nSecondaryReserveAmmoMax() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    uintptr_t m_nSpreadSeed() { return SCHEMA_TYPE(uintptr_t, 0x6F8); }
    uintptr_t m_nTracerFrequency() { return SCHEMA_TYPE(uintptr_t, 0x6D0); }
    uintptr_t m_nZoomFOV1() { return SCHEMA_TYPE(uintptr_t, 0x718); }
    uintptr_t m_nZoomFOV2() { return SCHEMA_TYPE(uintptr_t, 0x71C); }
    uintptr_t m_nZoomLevels() { return SCHEMA_TYPE(uintptr_t, 0x714); }
    uintptr_t m_szAnimClass() { return SCHEMA_TYPE(uintptr_t, 0x788); }
    uintptr_t m_szAnimSkeleton() { return SCHEMA_TYPE(uintptr_t, 0x448); }
    uintptr_t m_szName() { return SCHEMA_TYPE(uintptr_t, 0x640); }
    uintptr_t m_szTracerParticle() { return SCHEMA_TYPE(uintptr_t, 0x540); }
    uintptr_t m_szUseRadioSubtitle() { return SCHEMA_TYPE(uintptr_t, 0x708); }
    uintptr_t m_vSmokeColor() { return SCHEMA_TYPE(uintptr_t, 0x77C); }
    uintptr_t m_vecMuzzlePos0() { return SCHEMA_TYPE(uintptr_t, 0x528); }
    uintptr_t m_vecMuzzlePos1() { return SCHEMA_TYPE(uintptr_t, 0x534); }
};

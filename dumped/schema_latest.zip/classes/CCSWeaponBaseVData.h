#pragma once
#include "../cstypes/gear_slot_t.h"
#include "../cstypes/loadout_slot_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CCSWeaponBaseVData  {
public:
    uintptr_t baseAddr;

    CCSWeaponBaseVData() : baseAddr(0) {}
    CCSWeaponBaseVData(uintptr_t base) : baseAddr(base) {}

    int m_GearSlotPosition() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPrice() { return SCHEMA_TYPE(int, 0x20); }
    int m_nKillAward() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPrimaryReserveAmmoMax() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSecondaryReserveAmmoMax() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCrosshairMinDistance() { return SCHEMA_TYPE(int, 0x20); }
    int m_nCrosshairDeltaDistance() { return SCHEMA_TYPE(int, 0x20); }
    int m_nNumBullets() { return SCHEMA_TYPE(int, 0x20); }
    float m_flInaccuracyJumpInitial() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInaccuracyJumpApex() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInaccuracyReload() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDeployDuration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDisallowAttackAfterReloadStartDuration() { return SCHEMA_TYPE(float, 0x20); }
    int m_nBurstShotCount() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRecoilSeed() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSpreadSeed() { return SCHEMA_TYPE(int, 0x20); }
    float m_flAttackMovespeedFactor() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInaccuracyPitchShift() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInaccuracyAltSoundThreshold() { return SCHEMA_TYPE(float, 0x20); }
    int m_nZoomLevels() { return SCHEMA_TYPE(int, 0x20); }
    int m_nZoomFOV1() { return SCHEMA_TYPE(int, 0x20); }
    int m_nZoomFOV2() { return SCHEMA_TYPE(int, 0x20); }
    float m_flZoomTime0() { return SCHEMA_TYPE(float, 0x20); }
    float m_flZoomTime1() { return SCHEMA_TYPE(float, 0x20); }
    float m_flZoomTime2() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIronSightPullUpSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIronSightPutDownSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIronSightFOV() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIronSightPivotForward() { return SCHEMA_TYPE(float, 0x20); }
    float m_flIronSightLooseness() { return SCHEMA_TYPE(float, 0x20); }
    int m_nDamage() { return SCHEMA_TYPE(int, 0x20); }
    float m_flHeadshotMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flArmorRatio() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPenetration() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRange() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRangeModifier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlinchVelocityModifierLarge() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFlinchVelocityModifierSmall() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRecoveryTimeCrouch() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRecoveryTimeStand() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRecoveryTimeCrouchFinal() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRecoveryTimeStandFinal() { return SCHEMA_TYPE(float, 0x20); }
    int m_nRecoveryTransitionStartBullet() { return SCHEMA_TYPE(int, 0x20); }
    int m_nRecoveryTransitionEndBullet() { return SCHEMA_TYPE(int, 0x20); }
    float m_flThrowVelocity() { return SCHEMA_TYPE(float, 0x20); }
};

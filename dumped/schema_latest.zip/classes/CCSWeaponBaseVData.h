#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSWeaponBaseVData {
public:
    uintptr_t baseAddr;
    CCSWeaponBaseVData(uintptr_t addr) : baseAddr(addr) {}
    CCSWeaponBaseVData() : baseAddr(0) {}
    uintptr_t m_DefaultLoadoutSlot() { return SCHEMA_TYPE(uintptr_t, 0x708); }
    uintptr_t m_GearSlot() { return SCHEMA_TYPE(uintptr_t, 0x700); }
    uintptr_t m_GearSlotPosition() { return SCHEMA_TYPE(uintptr_t, 0x704); }
    uintptr_t m_WeaponCategory() { return SCHEMA_TYPE(uintptr_t, 0x444); }
    uintptr_t m_WeaponType() { return SCHEMA_TYPE(uintptr_t, 0x440); }
    uintptr_t m_bAllowBurstHolster() { return SCHEMA_TYPE(uintptr_t, 0x7D0); }
    uintptr_t m_bCannotShootUnderwater() { return SCHEMA_TYPE(uintptr_t, 0x71F); }
    uintptr_t m_bHasBurstMode() { return SCHEMA_TYPE(uintptr_t, 0x71D); }
    uintptr_t m_bHideViewModelWhenZoomed() { return SCHEMA_TYPE(uintptr_t, 0x7F1); }
    uintptr_t m_bIsFullAuto() { return SCHEMA_TYPE(uintptr_t, 0x734); }
    uintptr_t m_bIsRevolver() { return SCHEMA_TYPE(uintptr_t, 0x71E); }
    uintptr_t m_bMeleeWeapon() { return SCHEMA_TYPE(uintptr_t, 0x71C); }
    uintptr_t m_bReloadsSingleShells() { return SCHEMA_TYPE(uintptr_t, 0x73C); }
    uintptr_t m_bUnzoomsAfterShot() { return SCHEMA_TYPE(uintptr_t, 0x7F0); }
    uintptr_t m_eSilencerType() { return SCHEMA_TYPE(uintptr_t, 0x728); }
    uintptr_t m_flArmorRatio() { return SCHEMA_TYPE(uintptr_t, 0x828); }
    uintptr_t m_flAttackMovespeedFactor() { return SCHEMA_TYPE(uintptr_t, 0x7DC); }
    uintptr_t m_flCycleTime() { return SCHEMA_TYPE(uintptr_t, 0x740); }
    uintptr_t m_flDeployDuration() { return SCHEMA_TYPE(uintptr_t, 0x7C4); }
    uintptr_t m_flDisallowAttackAfterReloadStartDuration() { return SCHEMA_TYPE(uintptr_t, 0x7C8); }
    uintptr_t m_flFlinchVelocityModifierLarge() { return SCHEMA_TYPE(uintptr_t, 0x838); }
    uintptr_t m_flFlinchVelocityModifierSmall() { return SCHEMA_TYPE(uintptr_t, 0x83C); }
    uintptr_t m_flHeadshotMultiplier() { return SCHEMA_TYPE(uintptr_t, 0x824); }
    uintptr_t m_flInaccuracyAltSoundThreshold() { return SCHEMA_TYPE(uintptr_t, 0x7E4); }
    uintptr_t m_flInaccuracyCrouch() { return SCHEMA_TYPE(uintptr_t, 0x758); }
    uintptr_t m_flInaccuracyFire() { return SCHEMA_TYPE(uintptr_t, 0x780); }
    uintptr_t m_flInaccuracyJump() { return SCHEMA_TYPE(uintptr_t, 0x768); }
    uintptr_t m_flInaccuracyJumpApex() { return SCHEMA_TYPE(uintptr_t, 0x7BC); }
    uintptr_t m_flInaccuracyJumpInitial() { return SCHEMA_TYPE(uintptr_t, 0x7B8); }
    uintptr_t m_flInaccuracyLadder() { return SCHEMA_TYPE(uintptr_t, 0x778); }
    uintptr_t m_flInaccuracyLand() { return SCHEMA_TYPE(uintptr_t, 0x770); }
    uintptr_t m_flInaccuracyMove() { return SCHEMA_TYPE(uintptr_t, 0x788); }
    uintptr_t m_flInaccuracyPitchShift() { return SCHEMA_TYPE(uintptr_t, 0x7E0); }
    uintptr_t m_flInaccuracyReload() { return SCHEMA_TYPE(uintptr_t, 0x7C0); }
    uintptr_t m_flInaccuracyStand() { return SCHEMA_TYPE(uintptr_t, 0x760); }
    uintptr_t m_flIronSightFOV() { return SCHEMA_TYPE(uintptr_t, 0x814); }
    uintptr_t m_flIronSightLooseness() { return SCHEMA_TYPE(uintptr_t, 0x81C); }
    uintptr_t m_flIronSightPivotForward() { return SCHEMA_TYPE(uintptr_t, 0x818); }
    uintptr_t m_flIronSightPullUpSpeed() { return SCHEMA_TYPE(uintptr_t, 0x80C); }
    uintptr_t m_flIronSightPutDownSpeed() { return SCHEMA_TYPE(uintptr_t, 0x810); }
    uintptr_t m_flMaxSpeed() { return SCHEMA_TYPE(uintptr_t, 0x748); }
    uintptr_t m_flPenetration() { return SCHEMA_TYPE(uintptr_t, 0x82C); }
    uintptr_t m_flRange() { return SCHEMA_TYPE(uintptr_t, 0x830); }
    uintptr_t m_flRangeModifier() { return SCHEMA_TYPE(uintptr_t, 0x834); }
    uintptr_t m_flRecoilAngle() { return SCHEMA_TYPE(uintptr_t, 0x790); }
    uintptr_t m_flRecoilAngleVariance() { return SCHEMA_TYPE(uintptr_t, 0x798); }
    uintptr_t m_flRecoilMagnitude() { return SCHEMA_TYPE(uintptr_t, 0x7A0); }
    uintptr_t m_flRecoilMagnitudeVariance() { return SCHEMA_TYPE(uintptr_t, 0x7A8); }
    uintptr_t m_flRecoveryTimeCrouch() { return SCHEMA_TYPE(uintptr_t, 0x840); }
    uintptr_t m_flRecoveryTimeCrouchFinal() { return SCHEMA_TYPE(uintptr_t, 0x848); }
    uintptr_t m_flRecoveryTimeStand() { return SCHEMA_TYPE(uintptr_t, 0x844); }
    uintptr_t m_flRecoveryTimeStandFinal() { return SCHEMA_TYPE(uintptr_t, 0x84C); }
    uintptr_t m_flSpread() { return SCHEMA_TYPE(uintptr_t, 0x750); }
    uintptr_t m_flThrowVelocity() { return SCHEMA_TYPE(uintptr_t, 0x858); }
    uintptr_t m_flZoomTime0() { return SCHEMA_TYPE(uintptr_t, 0x800); }
    uintptr_t m_flZoomTime1() { return SCHEMA_TYPE(uintptr_t, 0x804); }
    uintptr_t m_flZoomTime2() { return SCHEMA_TYPE(uintptr_t, 0x808); }
    uintptr_t m_nBurstShotCount() { return SCHEMA_TYPE(uintptr_t, 0x7CC); }
    uintptr_t m_nCrosshairDeltaDistance() { return SCHEMA_TYPE(uintptr_t, 0x730); }
    uintptr_t m_nCrosshairMinDistance() { return SCHEMA_TYPE(uintptr_t, 0x72C); }
    uintptr_t m_nDamage() { return SCHEMA_TYPE(uintptr_t, 0x820); }
    uintptr_t m_nKillAward() { return SCHEMA_TYPE(uintptr_t, 0x710); }
    uintptr_t m_nNumBullets() { return SCHEMA_TYPE(uintptr_t, 0x738); }
    uintptr_t m_nPrice() { return SCHEMA_TYPE(uintptr_t, 0x70C); }
    uintptr_t m_nPrimaryReserveAmmoMax() { return SCHEMA_TYPE(uintptr_t, 0x714); }
    uintptr_t m_nRecoilSeed() { return SCHEMA_TYPE(uintptr_t, 0x7D4); }
    uintptr_t m_nRecoveryTransitionEndBullet() { return SCHEMA_TYPE(uintptr_t, 0x854); }
    uintptr_t m_nRecoveryTransitionStartBullet() { return SCHEMA_TYPE(uintptr_t, 0x850); }
    uintptr_t m_nSecondaryReserveAmmoMax() { return SCHEMA_TYPE(uintptr_t, 0x718); }
    uintptr_t m_nSpreadSeed() { return SCHEMA_TYPE(uintptr_t, 0x7D8); }
    uintptr_t m_nTracerFrequency() { return SCHEMA_TYPE(uintptr_t, 0x7B0); }
    uintptr_t m_nZoomFOV1() { return SCHEMA_TYPE(uintptr_t, 0x7F8); }
    uintptr_t m_nZoomFOV2() { return SCHEMA_TYPE(uintptr_t, 0x7FC); }
    uintptr_t m_nZoomLevels() { return SCHEMA_TYPE(uintptr_t, 0x7F4); }
    uintptr_t m_szAnimClass() { return SCHEMA_TYPE(uintptr_t, 0x868); }
    uintptr_t m_szAnimSkeleton() { return SCHEMA_TYPE(uintptr_t, 0x528); }
    uintptr_t m_szModel_AG2() { return SCHEMA_TYPE(uintptr_t, 0x448); }
    uintptr_t m_szName() { return SCHEMA_TYPE(uintptr_t, 0x720); }
    uintptr_t m_szTracerParticle() { return SCHEMA_TYPE(uintptr_t, 0x620); }
    uintptr_t m_szUseRadioSubtitle() { return SCHEMA_TYPE(uintptr_t, 0x7E8); }
    uintptr_t m_vSmokeColor() { return SCHEMA_TYPE(uintptr_t, 0x85C); }
    uintptr_t m_vecMuzzlePos0() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_vecMuzzlePos1() { return SCHEMA_TYPE(uintptr_t, 0x614); }
};

#pragma once
#include "../cstypes/CSMatchStats_t.h"
#include "../types/Vector3.h"

class CCSPlayerController_ActionTrackingServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_ActionTrackingServices() : baseAddr(0) {}
    CCSPlayerController_ActionTrackingServices(uintptr_t base) : baseAddr(base) {}

    int m_iNumRoundKills() { return SCHEMA_TYPE(int, 0x20); }
    int m_iNumRoundKillsHeadshots() { return SCHEMA_TYPE(int, 0x20); }
    float m_flTotalRoundDamageDealt() { return SCHEMA_TYPE(float, 0x20); }
};

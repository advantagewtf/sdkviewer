#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CSMatchStats_t;
class CSPerRoundStats_t;
class CCSPlayerController_ActionTrackingServices {
public:
    uintptr_t baseAddr;
    CCSPlayerController_ActionTrackingServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerController_ActionTrackingServices() : baseAddr(0) {}
    float m_flTotalRoundDamageDealt() { return SCHEMA_TYPE(float, 0x130); }
    int32_t m_iNumRoundKills() { return SCHEMA_TYPE(int32_t, 0x128); }
    int32_t m_iNumRoundKillsHeadshots() { return SCHEMA_TYPE(int32_t, 0x12C); }
    CSMatchStats_t m_matchStats() { return SCHEMA_TYPE(CSMatchStats_t, 0xA8); }
    CSPerRoundStats_t m_perRoundStats() { return SCHEMA_TYPE(CSPerRoundStats_t, 0x40); }
};

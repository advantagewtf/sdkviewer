#pragma once
#include <cstdint>
class CCSPlayerController_ActionTrackingServices {
public:
    float m_flTotalRoundDamageDealt() { return SCHEMA_TYPE(float, 0x130); }
    int32_t m_iNumRoundKills() { return SCHEMA_TYPE(int32_t, 0x128); }
    int32_t m_iNumRoundKillsHeadshots() { return SCHEMA_TYPE(int32_t, 0x12C); }
    uintptr_t /* CSMatchStats_t */ m_matchStats() { return SCHEMA_TYPE(uintptr_t, 0xA8); }
    uintptr_t /* CSPerRoundStats_t */ m_perRoundStats() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

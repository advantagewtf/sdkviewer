#pragma once
#include "../cstypes/PointTemplateClientOnlyEntityBehavior_t.h"
#include "../cstypes/PointTemplateOwnerSpawnGroupType_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPointTemplate  {
public:
    uintptr_t baseAddr;

    CPointTemplate() : baseAddr(0) {}
    CPointTemplate(uintptr_t base) : baseAddr(base) {}

    float m_flTimeoutInterval() { return SCHEMA_TYPE(float, 0x20); }
    int m_createdSpawnGroupHandles() { return SCHEMA_TYPE(int, 0x20); }
};

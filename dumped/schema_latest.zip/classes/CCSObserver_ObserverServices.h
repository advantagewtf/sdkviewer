#pragma once
#include <cstdint>
class CCSObserver_ObserverServices {
public:
    uintptr_t m_obsInterpState() { return SCHEMA_TYPE(uintptr_t, 0x5C); }
};

#pragma once
#include "../memory.h"

class CCSObserver_ObserverServices {
public:
 uintptr_t baseAddr;
 CCSObserver_ObserverServices() : baseAddr(0){}
 CCSObserver_ObserverServices(uintptr_t b):baseAddr(b){}
 uintptr_t m_obsInterpState(){return SCHEMA_TYPE(uintptr_t,0x5C);}
};

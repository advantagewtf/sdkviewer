#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CCSObserver_ObserverServices {
public:
    uintptr_t baseAddr;
    CCSObserver_ObserverServices(uintptr_t addr) : baseAddr(addr) {}
    CCSObserver_ObserverServices() : baseAddr(0) {}
    uintptr_t m_obsInterpState() { return SCHEMA_TYPE(uintptr_t, 0x64); }
};

#pragma once
#include "../cstypes/ObserverInterpState_t.h"

class CCSObserver_ObserverServices  {
public:
    uintptr_t baseAddr;

    CCSObserver_ObserverServices() : baseAddr(0) {}
    CCSObserver_ObserverServices(uintptr_t base) : baseAddr(base) {}

};

#pragma once

class C_Knife  {
public:
    uintptr_t baseAddr;

    C_Knife() : baseAddr(0) {}
    C_Knife(uintptr_t base) : baseAddr(base) {}

};

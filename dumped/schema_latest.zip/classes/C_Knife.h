#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_Knife : public C_CSWeaponBase {
public:
    uintptr_t baseAddr;
    C_Knife(uintptr_t addr) : baseAddr(addr) {}
    C_Knife() : baseAddr(0) {}
    bool m_bFirstAttack() { return SCHEMA_TYPE(bool, 0x1F80); }
};

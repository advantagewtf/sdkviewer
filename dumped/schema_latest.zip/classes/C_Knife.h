#pragma once
#include <cstdint>
class C_Knife : public C_CSWeaponBase {
public:
    bool m_bFirstAttack() { return SCHEMA_TYPE(bool, 0x1F80); }
};

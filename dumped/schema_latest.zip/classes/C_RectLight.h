#pragma once

class C_RectLight  {
public:
    uintptr_t baseAddr;

    C_RectLight() : baseAddr(0) {}
    C_RectLight(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
class C_RectLight : public C_BarnLight {
public:
    bool m_bShowLight() { return SCHEMA_TYPE(bool, 0x1200); }
};

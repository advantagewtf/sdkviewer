#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_RectLight : public C_BarnLight {
public:
    uintptr_t baseAddr;
    C_RectLight(uintptr_t addr) : baseAddr(addr) {}
    C_RectLight() : baseAddr(0) {}
    bool m_bShowLight() { return SCHEMA_TYPE(bool, 0x1198); }
};

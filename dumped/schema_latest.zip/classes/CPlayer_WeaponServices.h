#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBasePlayerWeapon;
class C_BasePlayerWeapon;
class CPlayer_WeaponServices {
public:
    uintptr_t baseAddr;
    CPlayer_WeaponServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_WeaponServices() : baseAddr(0) {}
    CHandle<CBasePlayerWeapon> m_hActiveWeapon() { return SCHEMA_TYPE(CHandle<CBasePlayerWeapon>, 0x60); }
    CHandle<CBasePlayerWeapon> m_hLastWeapon() { return SCHEMA_TYPE(CHandle<CBasePlayerWeapon>, 0x64); }
    CHandle<C_BasePlayerWeapon> m_hMyWeapons() { return SCHEMA_TYPE(CHandle<C_BasePlayerWeapon>, 0x48); }
    uint16_t m_iAmmo() { return SCHEMA_TYPE(uint16_t, 0x68); }
};

#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class CPlayer_WeaponServices {
public:
    CHandle<CBasePlayerWeapon> m_hActiveWeapon() { return SCHEMA_TYPE(CHandle<CBasePlayerWeapon>, 0x58); }
    CHandle<CBasePlayerWeapon> m_hLastWeapon() { return SCHEMA_TYPE(CHandle<CBasePlayerWeapon>, 0x5C); }
    CHandle<C_BasePlayerWeapon> m_hMyWeapons() { return SCHEMA_TYPE(CHandle<C_BasePlayerWeapon>, 0x40); }
    uint16_t m_iAmmo() { return SCHEMA_TYPE(uint16_t, 0x60); }
};

#pragma once
#include "../cstypes/uint16_t.h"
#include "../types/Vector3.h"
class C_BasePlayerWeapon;

class CPlayer_WeaponServices  {
public:
    uintptr_t baseAddr;

    CPlayer_WeaponServices() : baseAddr(0) {}
    CPlayer_WeaponServices(uintptr_t base) : baseAddr(base) {}

    uint16_t m_iAmmo() { return SCHEMA_TYPE(uint16_t, 0x10); }
};

#pragma once

class C_SoundEventSphereEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventSphereEntity() : baseAddr(0) {}
    C_SoundEventSphereEntity(uintptr_t base) : baseAddr(base) {}

    float m_flRadius() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class C_SoundEventSphereEntity : public C_SoundEventEntity {
public:
    float m_flRadius() { return SCHEMA_TYPE(float, 0x6C0); }
};

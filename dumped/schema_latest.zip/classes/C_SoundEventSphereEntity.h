#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundEventSphereEntity : public C_SoundEventEntity {
public:
    uintptr_t baseAddr;
    C_SoundEventSphereEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundEventSphereEntity() : baseAddr(0) {}
    float m_flRadius() { return SCHEMA_TYPE(float, 0x6C0); }
};

#pragma once
#include "../memory.h"

class C_SoundEventSphereEntity {
public:
 uintptr_t baseAddr;
 C_SoundEventSphereEntity() : baseAddr(0){}
 C_SoundEventSphereEntity(uintptr_t b):baseAddr(b){}
 uintptr_t m_flRadius(){return SCHEMA_TYPE(uintptr_t,0x6C0);}
};

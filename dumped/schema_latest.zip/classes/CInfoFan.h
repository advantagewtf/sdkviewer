#pragma once
#include "../cstypes/uintptr_t.h"

class CInfoFan  {
public:
    uintptr_t baseAddr;

    CInfoFan() : baseAddr(0) {}
    CInfoFan(uintptr_t base) : baseAddr(base) {}

    float m_fFanForceMaxRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_fFanForceMinRadius() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurveDistRange() { return SCHEMA_TYPE(float, 0x20); }
};

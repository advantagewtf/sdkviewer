#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/string_t.h"
class CInfoFan {
public:
    uintptr_t baseAddr;
    CInfoFan(uintptr_t addr) : baseAddr(addr) {}
    CInfoFan() : baseAddr(0) {}
    string_t m_FanForceCurveString() { return SCHEMA_TYPE(string_t, 0x648); }
    float m_fFanForceMaxRadius() { return SCHEMA_TYPE(float, 0x638); }
    float m_fFanForceMinRadius() { return SCHEMA_TYPE(float, 0x63C); }
    float m_flCurveDistRange() { return SCHEMA_TYPE(float, 0x640); }
};

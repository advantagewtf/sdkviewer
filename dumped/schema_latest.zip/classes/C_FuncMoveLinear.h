#pragma once
#include <cstdint>
class C_FuncMoveLinear : public C_BaseToggle {
public:
};

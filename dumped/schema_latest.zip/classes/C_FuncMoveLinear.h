#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FuncMoveLinear : public C_BaseToggle {
public:
    uintptr_t baseAddr;
    C_FuncMoveLinear(uintptr_t addr) : baseAddr(addr) {}
    C_FuncMoveLinear() : baseAddr(0) {}
};

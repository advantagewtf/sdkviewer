#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_OmniLight : public C_BarnLight {
public:
    uintptr_t baseAddr;
    C_OmniLight(uintptr_t addr) : baseAddr(addr) {}
    C_OmniLight() : baseAddr(0) {}
    bool m_bShowLight() { return SCHEMA_TYPE(bool, 0x1208); }
    float m_flInnerAngle() { return SCHEMA_TYPE(float, 0x1200); }
    float m_flOuterAngle() { return SCHEMA_TYPE(float, 0x1204); }
};

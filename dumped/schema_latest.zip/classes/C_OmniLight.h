#pragma once
#include <cstdint>
class C_OmniLight : public C_BarnLight {
public:
    bool m_bShowLight() { return SCHEMA_TYPE(bool, 0x1208); }
    float m_flInnerAngle() { return SCHEMA_TYPE(float, 0x1200); }
    float m_flOuterAngle() { return SCHEMA_TYPE(float, 0x1204); }
};

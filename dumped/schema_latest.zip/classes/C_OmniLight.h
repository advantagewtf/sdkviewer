#pragma once

class C_OmniLight  {
public:
    uintptr_t baseAddr;

    C_OmniLight() : baseAddr(0) {}
    C_OmniLight(uintptr_t base) : baseAddr(base) {}

    float m_flInnerAngle() { return SCHEMA_TYPE(float, 0x20); }
    float m_flOuterAngle() { return SCHEMA_TYPE(float, 0x20); }
};

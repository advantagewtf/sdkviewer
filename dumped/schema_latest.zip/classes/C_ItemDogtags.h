#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSPlayerPawn;
class C_ItemDogtags : public C_Item {
public:
    uintptr_t baseAddr;
    C_ItemDogtags(uintptr_t addr) : baseAddr(addr) {}
    C_ItemDogtags() : baseAddr(0) {}
    CHandle<CCSPlayerPawn> m_KillingPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x19C4); }
    CHandle<CCSPlayerPawn> m_OwningPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x19C0); }
};

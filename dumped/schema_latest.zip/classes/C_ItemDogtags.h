#pragma once
class C_CSPlayerPawn;

class C_ItemDogtags  {
public:
    uintptr_t baseAddr;

    C_ItemDogtags() : baseAddr(0) {}
    C_ItemDogtags(uintptr_t base) : baseAddr(base) {}

};

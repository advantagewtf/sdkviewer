#pragma once
#include <cstdint>
#include "../types/CHandle.h"
class C_ItemDogtags : public C_Item {
public:
    CHandle<CCSPlayerPawn> m_KillingPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x19E4); }
    CHandle<CCSPlayerPawn> m_OwningPlayer() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x19E0); }
};

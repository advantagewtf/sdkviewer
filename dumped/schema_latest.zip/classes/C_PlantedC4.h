#pragma once
#include "../classes/C_AttributeContainer.h"
#include "../cstypes/EntitySpottedState_t.h"
#include "../cstypes/GameTime_t.h"
#include "../types/QAngle.h"
#include "../types/Vector3.h"
class CBasePlayerController;
class C_CSPlayerPawn;
class C_Multimeter;

class C_PlantedC4  {
public:
    uintptr_t baseAddr;

    C_PlantedC4() : baseAddr(0) {}
    C_PlantedC4(uintptr_t base) : baseAddr(base) {}

    int m_nBombSite() { return SCHEMA_TYPE(int, 0x20); }
    int m_nSourceSoundscapeHash() { return SCHEMA_TYPE(int, 0x20); }
    float m_flTimerLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_bTriggerWarning() { return SCHEMA_TYPE(float, 0x20); }
    float m_bExplodeWarning() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDefuseLength() { return SCHEMA_TYPE(float, 0x20); }
    float m_flC4ExplodeSpectateDuration() { return SCHEMA_TYPE(float, 0x20); }
};

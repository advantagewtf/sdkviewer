#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CAttributeContainer;
class CCSPlayerPawn;
class EntitySpottedState_t;
class GameTime_t;
class C_PlantedC4 : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_PlantedC4(uintptr_t addr) : baseAddr(addr) {}
    C_PlantedC4() : baseAddr(0) {}
    CAttributeContainer m_AttributeManager() { return SCHEMA_TYPE(CAttributeContainer, 0x11D0); }
    bool m_bBeingDefused() { return SCHEMA_TYPE(bool, 0x11AC); }
    bool m_bBombDefused() { return SCHEMA_TYPE(bool, 0x11C4); }
    bool m_bBombTicking() { return SCHEMA_TYPE(bool, 0x1170); }
    uintptr_t m_bC4Activated() { return SCHEMA_TYPE(uintptr_t, 0x11B8); }
    bool m_bCannotBeDefused() { return SCHEMA_TYPE(bool, 0x11A4); }
    uintptr_t m_bExplodeWarning() { return SCHEMA_TYPE(uintptr_t, 0x11B4); }
    bool m_bHasExploded() { return SCHEMA_TYPE(bool, 0x11A5); }
    uintptr_t m_bRadarFlash() { return SCHEMA_TYPE(uintptr_t, 0x16A8); }
    uintptr_t m_bTenSecWarning() { return SCHEMA_TYPE(uintptr_t, 0x11B9); }
    uintptr_t m_bTriggerWarning() { return SCHEMA_TYPE(uintptr_t, 0x11B0); }
    EntitySpottedState_t m_entitySpottedState() { return SCHEMA_TYPE(EntitySpottedState_t, 0x1180); }
    uintptr_t m_fLastDefuseTime() { return SCHEMA_TYPE(uintptr_t, 0x16B0); }
    GameTime_t m_flC4Blow() { return SCHEMA_TYPE(GameTime_t, 0x11A0); }
    uintptr_t m_flC4ExplodeSpectateDuration() { return SCHEMA_TYPE(uintptr_t, 0x16D8); }
    GameTime_t m_flDefuseCountDown() { return SCHEMA_TYPE(GameTime_t, 0x11C0); }
    float m_flDefuseLength() { return SCHEMA_TYPE(float, 0x11BC); }
    uintptr_t m_flNextBeep() { return SCHEMA_TYPE(uintptr_t, 0x119C); }
    uintptr_t m_flNextGlow() { return SCHEMA_TYPE(uintptr_t, 0x1198); }
    uintptr_t m_flNextRadarFlashTime() { return SCHEMA_TYPE(uintptr_t, 0x16A4); }
    float m_flTimerLength() { return SCHEMA_TYPE(float, 0x11A8); }
    CHandle<CCSPlayerPawn> m_hBombDefuser() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x11C8); }
    uintptr_t m_hDefuserMultimeter() { return SCHEMA_TYPE(uintptr_t, 0x16A0); }
    int32_t m_nBombSite() { return SCHEMA_TYPE(int32_t, 0x1174); }
    int32_t m_nSourceSoundscapeHash() { return SCHEMA_TYPE(int32_t, 0x1178); }
    uintptr_t m_pBombDefuser() { return SCHEMA_TYPE(uintptr_t, 0x16AC); }
    uintptr_t m_pPredictionOwner() { return SCHEMA_TYPE(uintptr_t, 0x16B8); }
    uintptr_t m_vecC4ExplodeSpectateAng() { return SCHEMA_TYPE(uintptr_t, 0x16CC); }
    uintptr_t m_vecC4ExplodeSpectatePos() { return SCHEMA_TYPE(uintptr_t, 0x16C0); }
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class sky3dparams_t {
public:
    bool bClip3DSkyBoxNearToWorldFar() { return SCHEMA_TYPE(bool, 0x18); }
    uintptr_t /* float32 */ flClip3DSkyBoxNearToWorldFarOffset() { return SCHEMA_TYPE(uintptr_t, 0x1C); }
    uintptr_t /* fogparams_t */ fog() { return SCHEMA_TYPE(uintptr_t, 0x20); }
    uintptr_t /* WorldGroupId_t */ m_nWorldGroupID() { return SCHEMA_TYPE(uintptr_t, 0x88); }
    Vector3 origin() { return SCHEMA_TYPE(Vector3, 0xC); }
    uintptr_t /* int16 */ scale() { return SCHEMA_TYPE(uintptr_t, 0x8); }
};

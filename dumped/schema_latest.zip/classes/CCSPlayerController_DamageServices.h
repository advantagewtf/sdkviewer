#pragma once
#include <cstdint>
class CCSPlayerController_DamageServices {
public:
    uintptr_t /* CDamageRecord */ m_DamageList() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    int32_t m_nSendUpdate() { return SCHEMA_TYPE(int32_t, 0x40); }
};

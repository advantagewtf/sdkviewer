#pragma once
#include "../types/Vector3.h"

class CCSPlayerController_DamageServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_DamageServices() : baseAddr(0) {}
    CCSPlayerController_DamageServices(uintptr_t base) : baseAddr(base) {}

    int m_nSendUpdate() { return SCHEMA_TYPE(int, 0x20); }
};

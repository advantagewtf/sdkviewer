#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CDamageRecord;
class CCSPlayerController_DamageServices {
public:
    uintptr_t baseAddr;
    CCSPlayerController_DamageServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerController_DamageServices() : baseAddr(0) {}
    CDamageRecord m_DamageList() { return SCHEMA_TYPE(CDamageRecord, 0x48); }
    int32_t m_nSendUpdate() { return SCHEMA_TYPE(int32_t, 0x40); }
};

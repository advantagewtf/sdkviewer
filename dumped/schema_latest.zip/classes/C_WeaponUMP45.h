#pragma once
#include "../memory.h"

class C_WeaponUMP45 {
public:
 uintptr_t baseAddr;
 C_WeaponUMP45() : baseAddr(0){}
 C_WeaponUMP45(uintptr_t b):baseAddr(b){}
};

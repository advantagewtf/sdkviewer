#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_WeaponUMP45 : public C_CSWeaponBaseGun {
public:
    uintptr_t baseAddr;
    C_WeaponUMP45(uintptr_t addr) : baseAddr(addr) {}
    C_WeaponUMP45() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class C_WeaponUMP45 : public C_CSWeaponBaseGun {
public:
};

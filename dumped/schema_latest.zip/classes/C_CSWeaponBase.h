#pragma once
#include "../classes/CEntityIOOutput.h"
#include "../cstypes/GameTick_t.h"
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"
class C_CSPlayerPawn;

class C_CSWeaponBase  {
public:
    uintptr_t baseAddr;

    C_CSWeaponBase() : baseAddr(0) {}
    C_CSWeaponBase(uintptr_t base) : baseAddr(base) {}

    float m_flCrosshairDistance() { return SCHEMA_TYPE(float, 0x20); }
    int m_iAmmoLastCheck() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLastEmptySoundCmdNum() { return SCHEMA_TYPE(int, 0x20); }
    float m_flTurningInaccuracyDelta() { return SCHEMA_TYPE(float, 0x20); }
    float m_flTurningInaccuracy() { return SCHEMA_TYPE(float, 0x20); }
    float m_fAccuracyPenalty() { return SCHEMA_TYPE(float, 0x20); }
    float m_fAccuracySmoothedForZoom() { return SCHEMA_TYPE(float, 0x20); }
    int m_iRecoilIndex() { return SCHEMA_TYPE(int, 0x20); }
    float m_flRecoilIndex() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPostponeFireReadyFrac() { return SCHEMA_TYPE(float, 0x20); }
    int m_iOriginalTeamNumber() { return SCHEMA_TYPE(int, 0x20); }
    int m_iMostRecentTeamNumber() { return SCHEMA_TYPE(int, 0x20); }
    float m_flNextAttackRenderTimeOffset() { return SCHEMA_TYPE(float, 0x20); }
    int m_nCustomEconReloadEventId() { return SCHEMA_TYPE(int, 0x20); }
    float m_flNextClientFireBulletTime() { return SCHEMA_TYPE(float, 0x20); }
    float m_flNextClientFireBulletTime_Repredict() { return SCHEMA_TYPE(float, 0x20); }
    int m_iIronSightMode() { return SCHEMA_TYPE(int, 0x20); }
    float m_flWatTickOffset() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CCSPlayerPawn;
class CSWeaponMode;
class GameTick_t;
class GameTime_t;
class WeaponGameplayAnimState;
class C_CSWeaponBase : public C_BasePlayerWeapon {
public:
    uintptr_t baseAddr;
    C_CSWeaponBase(uintptr_t addr) : baseAddr(addr) {}
    C_CSWeaponBase() : baseAddr(0) {}
    uintptr_t m_IronSightController() { return SCHEMA_TYPE(uintptr_t, 0x1C50); }
    uintptr_t m_OnPlayerPickup() { return SCHEMA_TYPE(uintptr_t, 0x1990); }
    bool m_bBurstMode() { return SCHEMA_TYPE(bool, 0x19D4); }
    uintptr_t m_bClearWeaponIdentifyingUGC() { return SCHEMA_TYPE(uintptr_t, 0x1AA0); }
    bool m_bDroppedNearBuyZone() { return SCHEMA_TYPE(bool, 0x1A00); }
    uintptr_t m_bFireOnEmpty() { return SCHEMA_TYPE(uintptr_t, 0x198C); }
    bool m_bInReload() { return SCHEMA_TYPE(bool, 0x19E4); }
    bool m_bInspectPending() { return SCHEMA_TYPE(bool, 0x1954); }
    bool m_bInspectShouldLoop() { return SCHEMA_TYPE(bool, 0x1955); }
    bool m_bIsHauledBack() { return SCHEMA_TYPE(bool, 0x19EC); }
    bool m_bSilencerOn() { return SCHEMA_TYPE(bool, 0x19ED); }
    uintptr_t m_bUIWeapon() { return SCHEMA_TYPE(uintptr_t, 0x1AA2); }
    uintptr_t m_bVisualsDataSet() { return SCHEMA_TYPE(uintptr_t, 0x1AA1); }
    bool m_bWasActiveWeaponWhenDropped() { return SCHEMA_TYPE(bool, 0x1ABC); }
    uintptr_t m_bWasOwnedByCT() { return SCHEMA_TYPE(uintptr_t, 0x1AE4); }
    uintptr_t m_bWasOwnedByTerrorist() { return SCHEMA_TYPE(uintptr_t, 0x1AE5); }
    uintptr_t m_donated() { return SCHEMA_TYPE(uintptr_t, 0x1ADC); }
    float m_fAccuracyPenalty() { return SCHEMA_TYPE(float, 0x19C0); }
    uintptr_t m_fAccuracySmoothedForZoom() { return SCHEMA_TYPE(uintptr_t, 0x19C8); }
    GameTime_t m_fLastShotTime() { return SCHEMA_TYPE(GameTime_t, 0x1AE0); }
    uintptr_t m_flCrosshairDistance() { return SCHEMA_TYPE(uintptr_t, 0x1980); }
    GameTime_t m_flDroppedAtTime() { return SCHEMA_TYPE(GameTime_t, 0x19E8); }
    GameTime_t m_flInspectCancelCompleteTime() { return SCHEMA_TYPE(GameTime_t, 0x1950); }
    uintptr_t m_flLastAccuracyUpdateTime() { return SCHEMA_TYPE(uintptr_t, 0x19C4); }
    uintptr_t m_flLastBurstModeChangeTime() { return SCHEMA_TYPE(uintptr_t, 0x19D8); }
    uintptr_t m_flLastLOSTraceFailureTime() { return SCHEMA_TYPE(uintptr_t, 0x1D18); }
    GameTime_t m_flLastShakeTime() { return SCHEMA_TYPE(GameTime_t, 0x1D8C); }
    uintptr_t m_flNextAttackRenderTimeOffset() { return SCHEMA_TYPE(uintptr_t, 0x1A04); }
    uintptr_t m_flNextClientFireBulletTime() { return SCHEMA_TYPE(uintptr_t, 0x1AE8); }
    uintptr_t m_flNextClientFireBulletTime_Repredict() { return SCHEMA_TYPE(uintptr_t, 0x1AEC); }
    float m_flPostponeFireReadyFrac() { return SCHEMA_TYPE(float, 0x19E0); }
    float m_flRecoilIndex() { return SCHEMA_TYPE(float, 0x19D0); }
    GameTime_t m_flTimeSilencerSwitchComplete() { return SCHEMA_TYPE(GameTime_t, 0x19F0); }
    uintptr_t m_flTurningInaccuracy() { return SCHEMA_TYPE(uintptr_t, 0x19BC); }
    uintptr_t m_flTurningInaccuracyDelta() { return SCHEMA_TYPE(uintptr_t, 0x19AC); }
    float m_flWatTickOffset() { return SCHEMA_TYPE(float, 0x1D78); }
    float m_flWeaponActionPlaybackRate() { return SCHEMA_TYPE(float, 0x19F4); }
    GameTime_t m_flWeaponGameplayAnimStateTimestamp() { return SCHEMA_TYPE(GameTime_t, 0x194C); }
    CHandle<CCSPlayerPawn> m_hPrevOwner() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x1AB4); }
    uintptr_t m_iAmmoLastCheck() { return SCHEMA_TYPE(uintptr_t, 0x1984); }
    int32_t m_iIronSightMode() { return SCHEMA_TYPE(int32_t, 0x1D00); }
    int32_t m_iMostRecentTeamNumber() { return SCHEMA_TYPE(int32_t, 0x19FC); }
    int32_t m_iOriginalTeamNumber() { return SCHEMA_TYPE(int32_t, 0x19F8); }
    int32_t m_iRecoilIndex() { return SCHEMA_TYPE(int32_t, 0x19CC); }
    WeaponGameplayAnimState m_iWeaponGameplayAnimState() { return SCHEMA_TYPE(WeaponGameplayAnimState, 0x1948); }
    uintptr_t m_nCustomEconReloadEventId() { return SCHEMA_TYPE(uintptr_t, 0x1AA4); }
    GameTick_t m_nDropTick() { return SCHEMA_TYPE(GameTick_t, 0x1AB8); }
    uintptr_t m_nLastEmptySoundCmdNum() { return SCHEMA_TYPE(uintptr_t, 0x1988); }
    GameTick_t m_nPostponeFireReadyTicks() { return SCHEMA_TYPE(GameTick_t, 0x19DC); }
    GameTime_t m_nextPrevOwnerUseTime() { return SCHEMA_TYPE(GameTime_t, 0x1AB0); }
    uintptr_t m_vecTurningInaccuracyEyeDirLast() { return SCHEMA_TYPE(uintptr_t, 0x19B0); }
    CSWeaponMode m_weaponMode() { return SCHEMA_TYPE(CSWeaponMode, 0x19A8); }
};

#pragma once
#include <cstdint>
class CPlayer_ItemServices {
public:
};

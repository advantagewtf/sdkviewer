#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPlayer_ItemServices {
public:
    uintptr_t baseAddr;
    CPlayer_ItemServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_ItemServices() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/Vector3.h"
class C_FuncConveyor : public C_BaseModelEntity {
public:
    uintptr_t m_flCurrentConveyorOffset() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uintptr_t m_flCurrentConveyorSpeed() { return SCHEMA_TYPE(uintptr_t, 0xEF4); }
    uintptr_t /* float32 */ m_flTargetSpeed() { return SCHEMA_TYPE(uintptr_t, 0xEC4); }
    uintptr_t /* float32 */ m_flTransitionStartSpeed() { return SCHEMA_TYPE(uintptr_t, 0xED0); }
    uintptr_t /* EHANDLE */ m_hConveyorModels() { return SCHEMA_TYPE(uintptr_t, 0xED8); }
    int32_t m_nTransitionDurationTicks() { return SCHEMA_TYPE(int32_t, 0xECC); }
    uintptr_t /* GameTick_t */ m_nTransitionStartTick() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    Vector3 m_vecMoveDirEntitySpace() { return SCHEMA_TYPE(Vector3, 0xEB8); }
};

#pragma once
#include "../cstypes/GameTick_t.h"
#include "../types/Vector3.h"

class C_FuncConveyor  {
public:
    uintptr_t baseAddr;

    C_FuncConveyor() : baseAddr(0) {}
    C_FuncConveyor(uintptr_t base) : baseAddr(base) {}

    float m_flTargetSpeed() { return SCHEMA_TYPE(float, 0x20); }
    int m_nTransitionDurationTicks() { return SCHEMA_TYPE(int, 0x20); }
    float m_flTransitionStartSpeed() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurrentConveyorOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurrentConveyorSpeed() { return SCHEMA_TYPE(float, 0x20); }
};

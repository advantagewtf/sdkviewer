#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class EHANDLE;
class GameTick_t;
class float32;
class C_FuncConveyor : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncConveyor(uintptr_t addr) : baseAddr(addr) {}
    C_FuncConveyor() : baseAddr(0) {}
    uintptr_t m_flCurrentConveyorOffset() { return SCHEMA_TYPE(uintptr_t, 0xEF0); }
    uintptr_t m_flCurrentConveyorSpeed() { return SCHEMA_TYPE(uintptr_t, 0xEF4); }
    float32 m_flTargetSpeed() { return SCHEMA_TYPE(float32, 0xEC4); }
    float32 m_flTransitionStartSpeed() { return SCHEMA_TYPE(float32, 0xED0); }
    EHANDLE m_hConveyorModels() { return SCHEMA_TYPE(EHANDLE, 0xED8); }
    int32_t m_nTransitionDurationTicks() { return SCHEMA_TYPE(int32_t, 0xECC); }
    GameTick_t m_nTransitionStartTick() { return SCHEMA_TYPE(GameTick_t, 0xEC8); }
    Vector3 m_vecMoveDirEntitySpace() { return SCHEMA_TYPE(Vector3, 0xEB8); }
};

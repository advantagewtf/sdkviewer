#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class EHANDLE;
class GameTick_t;
class float32;
class C_FuncConveyor : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncConveyor(uintptr_t addr) : baseAddr(addr) {}
    C_FuncConveyor() : baseAddr(0) {}
    uintptr_t m_flCurrentConveyorOffset() { return SCHEMA_TYPE(uintptr_t, 0xEC8); }
    uintptr_t m_flCurrentConveyorSpeed() { return SCHEMA_TYPE(uintptr_t, 0xECC); }
    float32 m_flTargetSpeed() { return SCHEMA_TYPE(float32, 0xE9C); }
    float32 m_flTransitionStartSpeed() { return SCHEMA_TYPE(float32, 0xEA8); }
    EHANDLE m_hConveyorModels() { return SCHEMA_TYPE(EHANDLE, 0xEB0); }
    int32_t m_nTransitionDurationTicks() { return SCHEMA_TYPE(int32_t, 0xEA4); }
    GameTick_t m_nTransitionStartTick() { return SCHEMA_TYPE(GameTick_t, 0xEA0); }
    Vector3 m_vecMoveDirEntitySpace() { return SCHEMA_TYPE(Vector3, 0xE90); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class CGameSceneNodeHandle  {
public:
    uintptr_t baseAddr;

    CGameSceneNodeHandle() : baseAddr(0) {}
    CGameSceneNodeHandle(uintptr_t base) : baseAddr(base) {}

};

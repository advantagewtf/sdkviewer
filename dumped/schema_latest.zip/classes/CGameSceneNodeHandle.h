#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEntityHandle;
class CUtlStringToken;
class CGameSceneNodeHandle {
public:
    uintptr_t baseAddr;
    CGameSceneNodeHandle(uintptr_t addr) : baseAddr(addr) {}
    CGameSceneNodeHandle() : baseAddr(0) {}
    CEntityHandle m_hOwner() { return SCHEMA_TYPE(CEntityHandle, 0x8); }
    CUtlStringToken m_name() { return SCHEMA_TYPE(CUtlStringToken, 0xC); }
};

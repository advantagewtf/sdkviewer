#pragma once
#include <cstdint>
class CGameSceneNodeHandle {
public:
    uintptr_t /* CEntityHandle */ m_hOwner() { return SCHEMA_TYPE(uintptr_t, 0x8); }
    uintptr_t /* CUtlStringToken */ m_name() { return SCHEMA_TYPE(uintptr_t, 0xC); }
};

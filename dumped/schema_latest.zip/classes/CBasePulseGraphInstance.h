#pragma once
#include <cstdint>
class CBasePulseGraphInstance {
public:
};

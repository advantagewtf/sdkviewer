#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CBasePulseGraphInstance {
public:
    uintptr_t baseAddr;
    CBasePulseGraphInstance(uintptr_t addr) : baseAddr(addr) {}
    CBasePulseGraphInstance() : baseAddr(0) {}
};

#pragma once
#include "../types/Vector3.h"

class CPulseCell_Outflow_CycleShuffled  {
public:
    uintptr_t baseAddr;

    CPulseCell_Outflow_CycleShuffled() : baseAddr(0) {}
    CPulseCell_Outflow_CycleShuffled(uintptr_t base) : baseAddr(base) {}

};

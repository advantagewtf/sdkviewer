#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_EndOfMatchCamera {
public:
    uintptr_t baseAddr;
    C_CSGO_EndOfMatchCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_EndOfMatchCamera() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class CRenderComponent : public CEntityComponent {
public:
    uintptr_t __m_pChainEntity() { return SCHEMA_TYPE(uintptr_t, 0x10); }
    uintptr_t m_bEnableRendering() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    uintptr_t m_bInterpolationReadyToDraw() { return SCHEMA_TYPE(uintptr_t, 0xA8); }
    uintptr_t m_bIsRenderingWithViewModels() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_nSplitscreenFlags() { return SCHEMA_TYPE(uintptr_t, 0x54); }
};

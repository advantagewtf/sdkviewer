#pragma once
#include "../classes/CNetworkVarChainer.h"

class CRenderComponent  {
public:
    uintptr_t baseAddr;

    CRenderComponent() : baseAddr(0) {}
    CRenderComponent(uintptr_t base) : baseAddr(base) {}

    int m_nSplitscreenFlags() { return SCHEMA_TYPE(int, 0x20); }
};

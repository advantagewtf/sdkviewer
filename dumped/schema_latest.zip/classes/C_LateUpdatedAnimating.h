#pragma once
#include <cstdint>
class C_LateUpdatedAnimating : public CBaseAnimGraph {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_LateUpdatedAnimating : public CBaseAnimGraph {
public:
    uintptr_t baseAddr;
    C_LateUpdatedAnimating(uintptr_t addr) : baseAddr(addr) {}
    C_LateUpdatedAnimating() : baseAddr(0) {}
};

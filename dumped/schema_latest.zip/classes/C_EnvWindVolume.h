#pragma once
#include "../types/Vector3.h"

class C_EnvWindVolume  {
public:
    uintptr_t baseAddr;

    C_EnvWindVolume() : baseAddr(0) {}
    C_EnvWindVolume(uintptr_t base) : baseAddr(base) {}

    int m_nShape() { return SCHEMA_TYPE(int, 0x20); }
    float m_fWindSpeedMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_fWindTurbulenceMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_fWindSpeedVariationMultiplier() { return SCHEMA_TYPE(float, 0x20); }
    float m_fWindDirectionVariationMultiplier() { return SCHEMA_TYPE(float, 0x20); }
};

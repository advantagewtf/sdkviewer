#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class C_EnvWindVolume : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvWindVolume(uintptr_t addr) : baseAddr(addr) {}
    C_EnvWindVolume() : baseAddr(0) {}
    bool m_bActive() { return SCHEMA_TYPE(bool, 0x608); }
    bool m_bStartDisabled() { return SCHEMA_TYPE(bool, 0x624); }
    float m_fWindDirectionVariationMultiplier() { return SCHEMA_TYPE(float, 0x638); }
    float m_fWindSpeedMultiplier() { return SCHEMA_TYPE(float, 0x62C); }
    float m_fWindSpeedVariationMultiplier() { return SCHEMA_TYPE(float, 0x634); }
    float m_fWindTurbulenceMultiplier() { return SCHEMA_TYPE(float, 0x630); }
    int32_t m_nShape() { return SCHEMA_TYPE(int32_t, 0x628); }
    Vector3 m_vBoxMaxs() { return SCHEMA_TYPE(Vector3, 0x618); }
    Vector3 m_vBoxMins() { return SCHEMA_TYPE(Vector3, 0x60C); }
};

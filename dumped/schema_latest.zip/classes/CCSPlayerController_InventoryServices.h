#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class MedalRank_t;
class ServerAuthoritativeWeaponSlot_t;
class item_definition_index_t;
class CCSPlayerController_InventoryServices {
public:
    uintptr_t baseAddr;
    CCSPlayerController_InventoryServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayerController_InventoryServices() : baseAddr(0) {}
    int32_t m_nPersonaDataPublicCommendsFriendly() { return SCHEMA_TYPE(int32_t, 0x80); }
    int32_t m_nPersonaDataPublicCommendsLeader() { return SCHEMA_TYPE(int32_t, 0x78); }
    int32_t m_nPersonaDataPublicCommendsTeacher() { return SCHEMA_TYPE(int32_t, 0x7C); }
    int32_t m_nPersonaDataPublicLevel() { return SCHEMA_TYPE(int32_t, 0x74); }
    int32_t m_nPersonaDataXpTrailLevel() { return SCHEMA_TYPE(int32_t, 0x84); }
    MedalRank_t m_rank() { return SCHEMA_TYPE(MedalRank_t, 0x5C); }
    item_definition_index_t m_unMusicID() { return SCHEMA_TYPE(item_definition_index_t, 0x58); }
    uintptr_t m_vecNetworkableLoadout() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    ServerAuthoritativeWeaponSlot_t m_vecServerAuthoritativeWeaponSlots() { return SCHEMA_TYPE(ServerAuthoritativeWeaponSlot_t, 0x88); }
};

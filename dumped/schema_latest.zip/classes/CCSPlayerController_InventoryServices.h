#pragma once
#include "../cstypes/uint16_t.h"
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CCSPlayerController_InventoryServices  {
public:
    uintptr_t baseAddr;

    CCSPlayerController_InventoryServices() : baseAddr(0) {}
    CCSPlayerController_InventoryServices(uintptr_t base) : baseAddr(base) {}

    uint16_t m_unMusicID() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uintptr_t m_rank() { return SCHEMA_TYPE(uintptr_t, 0x6); }
    int m_nPersonaDataPublicLevel() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPersonaDataPublicCommendsLeader() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPersonaDataPublicCommendsTeacher() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPersonaDataPublicCommendsFriendly() { return SCHEMA_TYPE(int, 0x20); }
    int m_nPersonaDataXpTrailLevel() { return SCHEMA_TYPE(int, 0x20); }
};

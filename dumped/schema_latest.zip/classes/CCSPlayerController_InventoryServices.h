#pragma once
#include <cstdint>
class CCSPlayerController_InventoryServices {
public:
    int32_t m_nPersonaDataPublicCommendsFriendly() { return SCHEMA_TYPE(int32_t, 0x80); }
    int32_t m_nPersonaDataPublicCommendsLeader() { return SCHEMA_TYPE(int32_t, 0x78); }
    int32_t m_nPersonaDataPublicCommendsTeacher() { return SCHEMA_TYPE(int32_t, 0x7C); }
    int32_t m_nPersonaDataPublicLevel() { return SCHEMA_TYPE(int32_t, 0x74); }
    int32_t m_nPersonaDataXpTrailLevel() { return SCHEMA_TYPE(int32_t, 0x84); }
    uintptr_t /* MedalRank_t */ m_rank() { return SCHEMA_TYPE(uintptr_t, 0x5C); }
    uintptr_t /* item_definition_index_t */ m_unMusicID() { return SCHEMA_TYPE(uintptr_t, 0x58); }
    uintptr_t m_vecNetworkableLoadout() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* ServerAuthoritativeWeaponSlot_t */ m_vecServerAuthoritativeWeaponSlots() { return SCHEMA_TYPE(uintptr_t, 0x88); }
};

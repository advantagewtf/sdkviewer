#pragma once

class CLogicRelay  {
public:
    uintptr_t baseAddr;

    CLogicRelay() : baseAddr(0) {}
    CLogicRelay(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CLogicRelay {
public:
    uintptr_t baseAddr;
    CLogicRelay(uintptr_t addr) : baseAddr(addr) {}
    CLogicRelay() : baseAddr(0) {}
    uintptr_t m_bDisabled() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_bFastRetrigger() { return SCHEMA_TYPE(uintptr_t, 0x5FB); }
    uintptr_t m_bPassthoughCaller() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t m_bTriggerOnce() { return SCHEMA_TYPE(uintptr_t, 0x5FA); }
    uintptr_t m_bWaitForRefire() { return SCHEMA_TYPE(uintptr_t, 0x5F9); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CLogicRelay {
public:
    uintptr_t baseAddr;
    CLogicRelay(uintptr_t addr) : baseAddr(addr) {}
    CLogicRelay() : baseAddr(0) {}
    uintptr_t m_bDisabled() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_bFastRetrigger() { return SCHEMA_TYPE(uintptr_t, 0x60B); }
    uintptr_t m_bPassthoughCaller() { return SCHEMA_TYPE(uintptr_t, 0x60C); }
    uintptr_t m_bTriggerOnce() { return SCHEMA_TYPE(uintptr_t, 0x60A); }
    uintptr_t m_bWaitForRefire() { return SCHEMA_TYPE(uintptr_t, 0x609); }
};

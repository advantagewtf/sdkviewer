#pragma once
#include <cstdint>
class SignatureOutflow_Resume {
public:
};

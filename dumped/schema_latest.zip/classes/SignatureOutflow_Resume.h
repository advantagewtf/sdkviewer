#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class SignatureOutflow_Resume {
public:
    uintptr_t baseAddr;
    SignatureOutflow_Resume(uintptr_t addr) : baseAddr(addr) {}
    SignatureOutflow_Resume() : baseAddr(0) {}
};

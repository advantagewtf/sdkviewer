#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "CCSPlayerController.h"
class CDamageRecord {
public:
    uint64_t m_DamagerXuid() { return SCHEMA_TYPE(uint64_t, 0x50); }
    CHandle<CCSPlayerPawn> m_PlayerDamager() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x30); }
    CHandle<CCSPlayerPawn> m_PlayerRecipient() { return SCHEMA_TYPE(CHandle<CCSPlayerPawn>, 0x34); }
    uint64_t m_RecipientXuid() { return SCHEMA_TYPE(uint64_t, 0x58); }
    bool m_bIsOtherEnemy() { return SCHEMA_TYPE(bool, 0x74); }
    float m_flActualHealthRemoved() { return SCHEMA_TYPE(float, 0x68); }
    uintptr_t m_flBulletsDamage() { return SCHEMA_TYPE(uintptr_t, 0x60); }
    float m_flDamage() { return SCHEMA_TYPE(float, 0x64); }
    CHandle<CCSPlayerController> m_hPlayerControllerDamager() { return SCHEMA_TYPE(CHandle<CCSPlayerController>, 0x38); }
    CHandle<CCSPlayerController> m_hPlayerControllerRecipient() { return SCHEMA_TYPE(CHandle<CCSPlayerController>, 0x3C); }
    int32_t m_iLastBulletUpdate() { return SCHEMA_TYPE(int32_t, 0x70); }
    int32_t m_iNumHits() { return SCHEMA_TYPE(int32_t, 0x6C); }
    uintptr_t /* EKillTypes_t */ m_killType() { return SCHEMA_TYPE(uintptr_t, 0x75); }
    uintptr_t /* CUtlString */ m_szPlayerDamagerName() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t /* CUtlString */ m_szPlayerRecipientName() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include "../cstypes/EKillTypes_t.h"
#include "../cstypes/uintptr_t.h"
class CCSPlayerController;
class C_CSPlayerPawn;

class CDamageRecord  {
public:
    uintptr_t baseAddr;

    CDamageRecord() : baseAddr(0) {}
    CDamageRecord(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_DamagerXuid() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    uintptr_t m_RecipientXuid() { return SCHEMA_TYPE(uintptr_t, 0x40); }
    float m_flBulletsDamage() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDamage() { return SCHEMA_TYPE(float, 0x20); }
    float m_flActualHealthRemoved() { return SCHEMA_TYPE(float, 0x20); }
    int m_iNumHits() { return SCHEMA_TYPE(int, 0x20); }
    int m_iLastBulletUpdate() { return SCHEMA_TYPE(int, 0x20); }
};

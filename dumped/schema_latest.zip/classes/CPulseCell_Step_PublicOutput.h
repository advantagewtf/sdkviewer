#pragma once
#include "../cstypes/PulseRuntimeOutputIndex_t.h"

class CPulseCell_Step_PublicOutput  {
public:
    uintptr_t baseAddr;

    CPulseCell_Step_PublicOutput() : baseAddr(0) {}
    CPulseCell_Step_PublicOutput(uintptr_t base) : baseAddr(base) {}

};

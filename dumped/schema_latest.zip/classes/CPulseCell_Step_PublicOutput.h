#pragma once
#include <cstdint>
class CPulseCell_Step_PublicOutput {
public:
    uintptr_t m_OutputIndex() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

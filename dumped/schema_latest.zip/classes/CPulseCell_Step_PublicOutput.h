#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Step_PublicOutput {
public:
    uintptr_t baseAddr;
    CPulseCell_Step_PublicOutput(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Step_PublicOutput() : baseAddr(0) {}
    uintptr_t m_OutputIndex() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

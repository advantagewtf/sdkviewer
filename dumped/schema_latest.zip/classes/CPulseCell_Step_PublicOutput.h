#pragma once
#include "../memory.h"

class CPulseCell_Step_PublicOutput {
public:
 uintptr_t baseAddr;
 CPulseCell_Step_PublicOutput() : baseAddr(0){}
 CPulseCell_Step_PublicOutput(uintptr_t b):baseAddr(b){}
 uintptr_t m_OutputIndex(){return SCHEMA_TYPE(uintptr_t,0x48);}
};

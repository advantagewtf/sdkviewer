#pragma once
#include <cstdint>
class CCSPlayer_BuyServices {
public:
    uintptr_t /* SellbackPurchaseEntry_t */ m_vecSellbackPurchaseEntries() { return SCHEMA_TYPE(uintptr_t, 0x40); }
};

#pragma once
#include "../types/Vector3.h"

class CCSPlayer_BuyServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_BuyServices() : baseAddr(0) {}
    CCSPlayer_BuyServices(uintptr_t base) : baseAddr(base) {}

};

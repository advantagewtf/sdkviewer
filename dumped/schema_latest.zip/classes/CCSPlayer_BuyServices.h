#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class SellbackPurchaseEntry_t;
class CCSPlayer_BuyServices {
public:
    uintptr_t baseAddr;
    CCSPlayer_BuyServices(uintptr_t addr) : baseAddr(addr) {}
    CCSPlayer_BuyServices() : baseAddr(0) {}
    SellbackPurchaseEntry_t m_vecSellbackPurchaseEntries() { return SCHEMA_TYPE(SellbackPurchaseEntry_t, 0x48); }
};

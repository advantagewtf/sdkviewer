#pragma once
#include "../classes/C_EnvWindShared.h"

class C_EnvWindClientside  {
public:
    uintptr_t baseAddr;

    C_EnvWindClientside() : baseAddr(0) {}
    C_EnvWindClientside(uintptr_t base) : baseAddr(base) {}

};

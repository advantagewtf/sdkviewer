#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CEnvWindShared;
class C_EnvWindClientside : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_EnvWindClientside(uintptr_t addr) : baseAddr(addr) {}
    C_EnvWindClientside() : baseAddr(0) {}
    CEnvWindShared m_EnvWindShared() { return SCHEMA_TYPE(CEnvWindShared, 0x5F8); }
};

#pragma once
#include <cstdint>
class C_LightDirectionalEntity {
public:
};

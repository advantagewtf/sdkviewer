#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_LightDirectionalEntity {
public:
    uintptr_t baseAddr;
    C_LightDirectionalEntity(uintptr_t addr) : baseAddr(addr) {}
    C_LightDirectionalEntity() : baseAddr(0) {}
};

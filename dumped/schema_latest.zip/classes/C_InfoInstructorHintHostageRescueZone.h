#pragma once
#include <cstdint>
class C_InfoInstructorHintHostageRescueZone {
public:
};

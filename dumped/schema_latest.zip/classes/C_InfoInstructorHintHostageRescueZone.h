#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_InfoInstructorHintHostageRescueZone {
public:
    uintptr_t baseAddr;
    C_InfoInstructorHintHostageRescueZone(uintptr_t addr) : baseAddr(addr) {}
    C_InfoInstructorHintHostageRescueZone() : baseAddr(0) {}
};

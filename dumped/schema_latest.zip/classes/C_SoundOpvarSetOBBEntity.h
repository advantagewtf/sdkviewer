#pragma once
#include <cstdint>
class C_SoundOpvarSetOBBEntity : public C_SoundOpvarSetAABBEntity {
public:
};

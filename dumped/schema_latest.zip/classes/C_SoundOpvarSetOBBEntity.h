#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetOBBEntity : public C_SoundOpvarSetAABBEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetOBBEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetOBBEntity() : baseAddr(0) {}
};

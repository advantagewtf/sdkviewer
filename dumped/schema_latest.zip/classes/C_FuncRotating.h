#pragma once
#include "../memory.h"

class C_FuncRotating {
public:
 uintptr_t baseAddr;
 C_FuncRotating() : baseAddr(0){}
 C_FuncRotating(uintptr_t b):baseAddr(b){}
};

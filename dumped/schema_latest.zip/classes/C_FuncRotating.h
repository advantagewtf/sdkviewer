#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_FuncRotating : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_FuncRotating(uintptr_t addr) : baseAddr(addr) {}
    C_FuncRotating() : baseAddr(0) {}
};

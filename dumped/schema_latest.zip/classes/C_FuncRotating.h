#pragma once
#include <cstdint>
class C_FuncRotating : public C_BaseModelEntity {
public:
};

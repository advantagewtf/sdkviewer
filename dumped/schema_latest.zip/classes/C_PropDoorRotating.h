#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_PropDoorRotating : public C_BasePropDoor {
public:
    uintptr_t baseAddr;
    C_PropDoorRotating(uintptr_t addr) : baseAddr(addr) {}
    C_PropDoorRotating() : baseAddr(0) {}
};

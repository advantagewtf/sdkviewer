#pragma once
#include <cstdint>
class C_PropDoorRotating : public C_BasePropDoor {
public:
};

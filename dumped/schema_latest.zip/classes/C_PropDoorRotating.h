#pragma once
#include "../memory.h"

class C_PropDoorRotating {
public:
 uintptr_t baseAddr;
 C_PropDoorRotating() : baseAddr(0){}
 C_PropDoorRotating(uintptr_t b):baseAddr(b){}
};

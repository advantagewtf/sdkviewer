#pragma once
#include <cstdint>
class C_SoundOpvarSetAutoRoomEntity {
public:
};

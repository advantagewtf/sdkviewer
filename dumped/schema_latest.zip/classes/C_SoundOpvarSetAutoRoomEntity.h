#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_SoundOpvarSetAutoRoomEntity {
public:
    uintptr_t baseAddr;
    C_SoundOpvarSetAutoRoomEntity(uintptr_t addr) : baseAddr(addr) {}
    C_SoundOpvarSetAutoRoomEntity() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class TimelineCompression_t;
class CTimeline {
public:
    uintptr_t baseAddr;
    CTimeline(uintptr_t addr) : baseAddr(addr) {}
    CTimeline() : baseAddr(0) {}
    bool m_bStopped() { return SCHEMA_TYPE(bool, 0x220); }
    float m_flFinalValue() { return SCHEMA_TYPE(float, 0x218); }
    float m_flInterval() { return SCHEMA_TYPE(float, 0x214); }
    float m_flValues() { return SCHEMA_TYPE(float, 0x10); }
    int32_t m_nBucketCount() { return SCHEMA_TYPE(int32_t, 0x210); }
    TimelineCompression_t m_nCompressionType() { return SCHEMA_TYPE(TimelineCompression_t, 0x21C); }
    int32_t m_nValueCounts() { return SCHEMA_TYPE(int32_t, 0x110); }
};

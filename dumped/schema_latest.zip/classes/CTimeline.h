#pragma once
#include "../cstypes/TimelineCompression_t.h"

class CTimeline  {
public:
    uintptr_t baseAddr;

    CTimeline() : baseAddr(0) {}
    CTimeline(uintptr_t base) : baseAddr(base) {}

    float m_flValues() { return SCHEMA_TYPE(float, 0x20); }
    int m_nValueCounts() { return SCHEMA_TYPE(int, 0x20); }
    int m_nBucketCount() { return SCHEMA_TYPE(int, 0x20); }
    float m_flInterval() { return SCHEMA_TYPE(float, 0x20); }
    float m_flFinalValue() { return SCHEMA_TYPE(float, 0x20); }
};

#pragma once
#include <cstdint>
class CPulseCell_Timeline {
public:
    uintptr_t m_OnCanceled() { return SCHEMA_TYPE(uintptr_t, 0xB0); }
    uintptr_t m_OnFinished() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_TimelineEvents() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_bWaitForChildOutflows() { return SCHEMA_TYPE(uintptr_t, 0x60); }
};

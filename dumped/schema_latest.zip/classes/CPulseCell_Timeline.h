#pragma once
#include "../cstypes/uintptr_t.h"
#include "../types/Vector3.h"

class CPulseCell_Timeline  {
public:
    uintptr_t baseAddr;

    CPulseCell_Timeline() : baseAddr(0) {}
    CPulseCell_Timeline(uintptr_t base) : baseAddr(base) {}

};

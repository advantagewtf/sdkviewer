#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_Timeline {
public:
    uintptr_t baseAddr;
    CPulseCell_Timeline(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_Timeline() : baseAddr(0) {}
    uintptr_t m_OnCanceled() { return SCHEMA_TYPE(uintptr_t, 0xB0); }
    uintptr_t m_OnFinished() { return SCHEMA_TYPE(uintptr_t, 0x68); }
    uintptr_t m_TimelineEvents() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uintptr_t m_bWaitForChildOutflows() { return SCHEMA_TYPE(uintptr_t, 0x60); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSTeam {
public:
    uintptr_t baseAddr;
    C_CSTeam(uintptr_t addr) : baseAddr(addr) {}
    C_CSTeam() : baseAddr(0) {}
    bool m_bSurrendered() { return SCHEMA_TYPE(bool, 0x8C4); }
    uint32_t m_iClanID() { return SCHEMA_TYPE(uint32_t, 0x958); }
    int32_t m_numMapVictories() { return SCHEMA_TYPE(int32_t, 0x8C0); }
    int32_t m_scoreFirstHalf() { return SCHEMA_TYPE(int32_t, 0x8C8); }
    int32_t m_scoreOvertime() { return SCHEMA_TYPE(int32_t, 0x8D0); }
    int32_t m_scoreSecondHalf() { return SCHEMA_TYPE(int32_t, 0x8CC); }
    char m_szClanTeamname() { return SCHEMA_TYPE(char, 0x8D4); }
    char m_szTeamFlagImage() { return SCHEMA_TYPE(char, 0x95C); }
    char m_szTeamLogoImage() { return SCHEMA_TYPE(char, 0x964); }
    char m_szTeamMatchStat() { return SCHEMA_TYPE(char, 0x6C0); }
};

#pragma once

class C_CSTeam  {
public:
    uintptr_t baseAddr;

    C_CSTeam() : baseAddr(0) {}
    C_CSTeam(uintptr_t base) : baseAddr(base) {}

    char* m_szTeamMatchStat() { return SCHEMA_TYPE(char*, 0x200); }
    int m_numMapVictories() { return SCHEMA_TYPE(int, 0x20); }
    int m_scoreFirstHalf() { return SCHEMA_TYPE(int, 0x20); }
    int m_scoreSecondHalf() { return SCHEMA_TYPE(int, 0x20); }
    int m_scoreOvertime() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szClanTeamname() { return SCHEMA_TYPE(char*, 0x81); }
    int m_iClanID() { return SCHEMA_TYPE(int, 0x20); }
    char* m_szTeamFlagImage() { return SCHEMA_TYPE(char*, 0x8); }
    char* m_szTeamLogoImage() { return SCHEMA_TYPE(char*, 0x8); }
};

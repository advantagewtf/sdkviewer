#pragma once
#include <cstdint>
class C_CSTeam {
public:
    bool m_bSurrendered() { return SCHEMA_TYPE(bool, 0x8B4); }
    uint32_t m_iClanID() { return SCHEMA_TYPE(uint32_t, 0x948); }
    int32_t m_numMapVictories() { return SCHEMA_TYPE(int32_t, 0x8B0); }
    int32_t m_scoreFirstHalf() { return SCHEMA_TYPE(int32_t, 0x8B8); }
    int32_t m_scoreOvertime() { return SCHEMA_TYPE(int32_t, 0x8C0); }
    int32_t m_scoreSecondHalf() { return SCHEMA_TYPE(int32_t, 0x8BC); }
    uintptr_t /* char */ m_szClanTeamname() { return SCHEMA_TYPE(uintptr_t, 0x8C4); }
    uintptr_t /* char */ m_szTeamFlagImage() { return SCHEMA_TYPE(uintptr_t, 0x94C); }
    uintptr_t /* char */ m_szTeamLogoImage() { return SCHEMA_TYPE(uintptr_t, 0x954); }
    uintptr_t /* char */ m_szTeamMatchStat() { return SCHEMA_TYPE(uintptr_t, 0x6B0); }
};

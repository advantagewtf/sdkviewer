#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class C_BaseEntity;
class ValueRemapperHapticsType_t;
class ValueRemapperInputType_t;
class ValueRemapperMomentumType_t;
class ValueRemapperOutputType_t;
class ValueRemapperRatchetType_t;
class C_PointValueRemapper : public C_BaseEntity {
public:
    uintptr_t baseAddr;
    C_PointValueRemapper(uintptr_t addr) : baseAddr(addr) {}
    C_PointValueRemapper() : baseAddr(0) {}
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0x5F8); }
    uintptr_t m_bDisabledOld() { return SCHEMA_TYPE(uintptr_t, 0x5F9); }
    uintptr_t m_bEngaged() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    uintptr_t m_bFirstUpdate() { return SCHEMA_TYPE(uintptr_t, 0x659); }
    bool m_bRequiresUseKey() { return SCHEMA_TYPE(bool, 0x614); }
    bool m_bUpdateOnClient() { return SCHEMA_TYPE(bool, 0x5FA); }
    uintptr_t m_flCurrentMomentum() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    float m_flDisengageDistance() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flEngageDistance() { return SCHEMA_TYPE(float, 0x610); }
    float m_flInputOffset() { return SCHEMA_TYPE(float, 0x654); }
    float m_flMaximumChangePerSecond() { return SCHEMA_TYPE(float, 0x608); }
    float m_flMomentumModifier() { return SCHEMA_TYPE(float, 0x640); }
    uintptr_t m_flPreviousUpdateTickTime() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    uintptr_t m_flPreviousValue() { return SCHEMA_TYPE(uintptr_t, 0x65C); }
    uintptr_t m_flRatchetOffset() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    float m_flSnapValue() { return SCHEMA_TYPE(float, 0x644); }
    CHandle<C_BaseEntity> m_hOutputEntities() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x620); }
    CHandle<CBaseEntity> m_hRemapLineEnd() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x604); }
    CHandle<CBaseEntity> m_hRemapLineStart() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x600); }
    ValueRemapperHapticsType_t m_nHapticsType() { return SCHEMA_TYPE(ValueRemapperHapticsType_t, 0x638); }
    ValueRemapperInputType_t m_nInputType() { return SCHEMA_TYPE(ValueRemapperInputType_t, 0x5FC); }
    ValueRemapperMomentumType_t m_nMomentumType() { return SCHEMA_TYPE(ValueRemapperMomentumType_t, 0x63C); }
    ValueRemapperOutputType_t m_nOutputType() { return SCHEMA_TYPE(ValueRemapperOutputType_t, 0x618); }
    ValueRemapperRatchetType_t m_nRatchetType() { return SCHEMA_TYPE(ValueRemapperRatchetType_t, 0x64C); }
    uintptr_t m_vecPreviousTestPoint() { return SCHEMA_TYPE(uintptr_t, 0x664); }
};

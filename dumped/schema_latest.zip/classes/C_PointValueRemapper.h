#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/ValueRemapperHapticsType_t.h"
#include "../cstypes/ValueRemapperInputType_t.h"
#include "../cstypes/ValueRemapperMomentumType_t.h"
#include "../cstypes/ValueRemapperOutputType_t.h"
#include "../cstypes/ValueRemapperRatchetType_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_PointValueRemapper  {
public:
    uintptr_t baseAddr;

    C_PointValueRemapper() : baseAddr(0) {}
    C_PointValueRemapper(uintptr_t base) : baseAddr(base) {}

    float m_flMaximumChangePerSecond() { return SCHEMA_TYPE(float, 0x20); }
    float m_flDisengageDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flEngageDistance() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMomentumModifier() { return SCHEMA_TYPE(float, 0x20); }
    float m_flSnapValue() { return SCHEMA_TYPE(float, 0x20); }
    float m_flCurrentMomentum() { return SCHEMA_TYPE(float, 0x20); }
    float m_flRatchetOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flInputOffset() { return SCHEMA_TYPE(float, 0x20); }
    float m_flPreviousValue() { return SCHEMA_TYPE(float, 0x20); }
};

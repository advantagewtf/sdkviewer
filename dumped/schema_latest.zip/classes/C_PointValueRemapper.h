#pragma once
#include <cstdint>
#include "../types/CHandle.h"
#include "C_BaseEntity.h"
class C_PointValueRemapper : public C_BaseEntity {
public:
    bool m_bDisabled() { return SCHEMA_TYPE(bool, 0x5F8); }
    uintptr_t m_bDisabledOld() { return SCHEMA_TYPE(uintptr_t, 0x5F9); }
    uintptr_t m_bEngaged() { return SCHEMA_TYPE(uintptr_t, 0x658); }
    uintptr_t m_bFirstUpdate() { return SCHEMA_TYPE(uintptr_t, 0x659); }
    bool m_bRequiresUseKey() { return SCHEMA_TYPE(bool, 0x614); }
    bool m_bUpdateOnClient() { return SCHEMA_TYPE(bool, 0x5FA); }
    uintptr_t m_flCurrentMomentum() { return SCHEMA_TYPE(uintptr_t, 0x648); }
    float m_flDisengageDistance() { return SCHEMA_TYPE(float, 0x60C); }
    float m_flEngageDistance() { return SCHEMA_TYPE(float, 0x610); }
    float m_flInputOffset() { return SCHEMA_TYPE(float, 0x654); }
    float m_flMaximumChangePerSecond() { return SCHEMA_TYPE(float, 0x608); }
    float m_flMomentumModifier() { return SCHEMA_TYPE(float, 0x640); }
    uintptr_t m_flPreviousUpdateTickTime() { return SCHEMA_TYPE(uintptr_t, 0x660); }
    uintptr_t m_flPreviousValue() { return SCHEMA_TYPE(uintptr_t, 0x65C); }
    uintptr_t m_flRatchetOffset() { return SCHEMA_TYPE(uintptr_t, 0x650); }
    float m_flSnapValue() { return SCHEMA_TYPE(float, 0x644); }
    CHandle<C_BaseEntity> m_hOutputEntities() { return SCHEMA_TYPE(CHandle<C_BaseEntity>, 0x620); }
    CHandle<CBaseEntity> m_hRemapLineEnd() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x604); }
    CHandle<CBaseEntity> m_hRemapLineStart() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x600); }
    uintptr_t /* ValueRemapperHapticsType_t */ m_nHapticsType() { return SCHEMA_TYPE(uintptr_t, 0x638); }
    uintptr_t /* ValueRemapperInputType_t */ m_nInputType() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t /* ValueRemapperMomentumType_t */ m_nMomentumType() { return SCHEMA_TYPE(uintptr_t, 0x63C); }
    uintptr_t /* ValueRemapperOutputType_t */ m_nOutputType() { return SCHEMA_TYPE(uintptr_t, 0x618); }
    uintptr_t /* ValueRemapperRatchetType_t */ m_nRatchetType() { return SCHEMA_TYPE(uintptr_t, 0x64C); }
    uintptr_t m_vecPreviousTestPoint() { return SCHEMA_TYPE(uintptr_t, 0x664); }
};

#pragma once
#include <cstdint>
class CPulseCell_BaseLerp {
public:
    uintptr_t m_WakeResume() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

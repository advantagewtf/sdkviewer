#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CPulseCell_BaseLerp {
public:
    uintptr_t baseAddr;
    CPulseCell_BaseLerp(uintptr_t addr) : baseAddr(addr) {}
    CPulseCell_BaseLerp() : baseAddr(0) {}
    uintptr_t m_WakeResume() { return SCHEMA_TYPE(uintptr_t, 0x48); }
};

#pragma once
#include "../cstypes/uintptr_t.h"

class CPulseCell_BaseLerp  {
public:
    uintptr_t baseAddr;

    CPulseCell_BaseLerp() : baseAddr(0) {}
    CPulseCell_BaseLerp(uintptr_t base) : baseAddr(base) {}

};

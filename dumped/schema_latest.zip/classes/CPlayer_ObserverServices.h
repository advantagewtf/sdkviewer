#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/ObserverMode_t.h"
#include "../cstypes/uint8_t.h"
class C_BaseEntity;

class CPlayer_ObserverServices  {
public:
    uintptr_t baseAddr;

    CPlayer_ObserverServices() : baseAddr(0) {}
    CPlayer_ObserverServices(uintptr_t base) : baseAddr(base) {}

    uint8_t m_iObserverMode() { return SCHEMA_TYPE(uint8_t, 0x8); }
    float m_flObserverChaseDistance() { return SCHEMA_TYPE(float, 0x20); }
};

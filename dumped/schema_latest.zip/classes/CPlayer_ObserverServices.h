#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/CHandle.h"
class CBaseEntity;
class CPlayer_ObserverServices {
public:
    uintptr_t baseAddr;
    CPlayer_ObserverServices(uintptr_t addr) : baseAddr(addr) {}
    CPlayer_ObserverServices() : baseAddr(0) {}
    uintptr_t m_bForcedObserverMode() { return SCHEMA_TYPE(uintptr_t, 0x4C); }
    uintptr_t m_flObserverChaseDistance() { return SCHEMA_TYPE(uintptr_t, 0x50); }
    uintptr_t m_flObserverChaseDistanceCalcTime() { return SCHEMA_TYPE(uintptr_t, 0x54); }
    CHandle<CBaseEntity> m_hObserverTarget() { return SCHEMA_TYPE(CHandle<CBaseEntity>, 0x44); }
    uintptr_t m_iObserverLastMode() { return SCHEMA_TYPE(uintptr_t, 0x48); }
    uint8_t m_iObserverMode() { return SCHEMA_TYPE(uint8_t, 0x40); }
};

#pragma once
class C_BaseEntity;

class CInfoDynamicShadowHint  {
public:
    uintptr_t baseAddr;

    CInfoDynamicShadowHint() : baseAddr(0) {}
    CInfoDynamicShadowHint(uintptr_t base) : baseAddr(base) {}

    float m_flRange() { return SCHEMA_TYPE(float, 0x20); }
    int m_nImportance() { return SCHEMA_TYPE(int, 0x20); }
    int m_nLightChoice() { return SCHEMA_TYPE(int, 0x20); }
};

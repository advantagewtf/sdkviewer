#pragma once
#include <cstdint>
class CInfoDynamicShadowHint {
public:
    uintptr_t m_bDisabled() { return SCHEMA_TYPE(uintptr_t, 0x5F8); }
    uintptr_t m_flRange() { return SCHEMA_TYPE(uintptr_t, 0x5FC); }
    uintptr_t m_hLight() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_nImportance() { return SCHEMA_TYPE(uintptr_t, 0x600); }
    uintptr_t m_nLightChoice() { return SCHEMA_TYPE(uintptr_t, 0x604); }
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class CInfoDynamicShadowHint {
public:
    uintptr_t baseAddr;
    CInfoDynamicShadowHint(uintptr_t addr) : baseAddr(addr) {}
    CInfoDynamicShadowHint() : baseAddr(0) {}
    uintptr_t m_bDisabled() { return SCHEMA_TYPE(uintptr_t, 0x608); }
    uintptr_t m_flRange() { return SCHEMA_TYPE(uintptr_t, 0x60C); }
    uintptr_t m_hLight() { return SCHEMA_TYPE(uintptr_t, 0x618); }
    uintptr_t m_nImportance() { return SCHEMA_TYPE(uintptr_t, 0x610); }
    uintptr_t m_nLightChoice() { return SCHEMA_TYPE(uintptr_t, 0x614); }
};

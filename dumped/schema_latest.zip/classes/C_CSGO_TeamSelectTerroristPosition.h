#pragma once
#include <cstdint>
class C_CSGO_TeamSelectTerroristPosition : public C_CSGO_TeamSelectCharacterPosition {
public:
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TeamSelectTerroristPosition : public C_CSGO_TeamSelectCharacterPosition {
public:
    uintptr_t baseAddr;
    C_CSGO_TeamSelectTerroristPosition(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TeamSelectTerroristPosition() : baseAddr(0) {}
};

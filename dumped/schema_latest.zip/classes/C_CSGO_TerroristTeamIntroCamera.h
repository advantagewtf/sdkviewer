#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_CSGO_TerroristTeamIntroCamera : public C_CSGO_TeamPreviewCamera {
public:
    uintptr_t baseAddr;
    C_CSGO_TerroristTeamIntroCamera(uintptr_t addr) : baseAddr(addr) {}
    C_CSGO_TerroristTeamIntroCamera() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class SignatureOutflow_Continue {
public:
    uintptr_t baseAddr;
    SignatureOutflow_Continue(uintptr_t addr) : baseAddr(addr) {}
    SignatureOutflow_Continue() : baseAddr(0) {}
};

#pragma once
#include <cstdint>
class SignatureOutflow_Continue {
public:
};

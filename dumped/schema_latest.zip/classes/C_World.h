#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
class C_World : public C_BaseModelEntity {
public:
    uintptr_t baseAddr;
    C_World(uintptr_t addr) : baseAddr(addr) {}
    C_World() : baseAddr(0) {}
};

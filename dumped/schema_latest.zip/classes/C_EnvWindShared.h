#pragma once
#include <cstdint>
#include "../types/SchemaRead.h"
#include "../types/Vector3.h"
class GameTime_t;
class float32;
class C_EnvWindShared {
public:
    uintptr_t baseAddr;
    C_EnvWindShared(uintptr_t addr) : baseAddr(addr) {}
    C_EnvWindShared() : baseAddr(0) {}
    float32 m_flGustDuration() { return SCHEMA_TYPE(float32, 0x24); }
    float32 m_flInitialWindSpeed() { return SCHEMA_TYPE(float32, 0x2C); }
    float32 m_flMaxGustDelay() { return SCHEMA_TYPE(float32, 0x20); }
    float32 m_flMinGustDelay() { return SCHEMA_TYPE(float32, 0x1C); }
    GameTime_t m_flStartTime() { return SCHEMA_TYPE(GameTime_t, 0x8); }
    uintptr_t m_hEntOwner() { return SCHEMA_TYPE(uintptr_t, 0x3C); }
    uint16_t m_iGustDirChange() { return SCHEMA_TYPE(uint16_t, 0x28); }
    uint16_t m_iInitialWindDir() { return SCHEMA_TYPE(uint16_t, 0x2A); }
    uint16_t m_iMaxGust() { return SCHEMA_TYPE(uint16_t, 0x1A); }
    uint16_t m_iMaxWind() { return SCHEMA_TYPE(uint16_t, 0x12); }
    uint16_t m_iMinGust() { return SCHEMA_TYPE(uint16_t, 0x18); }
    uint16_t m_iMinWind() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint32_t m_iWindSeed() { return SCHEMA_TYPE(uint32_t, 0xC); }
    Vector3 m_location() { return SCHEMA_TYPE(Vector3, 0x30); }
    int32_t m_windRadius() { return SCHEMA_TYPE(int32_t, 0x14); }
};

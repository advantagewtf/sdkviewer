#pragma once
#include "../cstypes/GameTime_t.h"
#include "../cstypes/uint16_t.h"
#include "../types/Vector3.h"
class C_BaseEntity;

class C_EnvWindShared  {
public:
    uintptr_t baseAddr;

    C_EnvWindShared() : baseAddr(0) {}
    C_EnvWindShared(uintptr_t base) : baseAddr(base) {}

    int m_iWindSeed() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_iMinWind() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint16_t m_iMaxWind() { return SCHEMA_TYPE(uint16_t, 0x10); }
    int m_windRadius() { return SCHEMA_TYPE(int, 0x20); }
    uint16_t m_iMinGust() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint16_t m_iMaxGust() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flMinGustDelay() { return SCHEMA_TYPE(float, 0x20); }
    float m_flMaxGustDelay() { return SCHEMA_TYPE(float, 0x20); }
    float m_flGustDuration() { return SCHEMA_TYPE(float, 0x20); }
    uint16_t m_iGustDirChange() { return SCHEMA_TYPE(uint16_t, 0x10); }
    uint16_t m_iInitialWindDir() { return SCHEMA_TYPE(uint16_t, 0x10); }
    float m_flInitialWindSpeed() { return SCHEMA_TYPE(float, 0x20); }
};

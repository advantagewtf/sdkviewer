#pragma once
#include "memory.h"

#include "types/Vector2.h"
#include "types/Vector3.h"
#include "types/QAngle.h"
#include "types/CUtlString.h"
#include "types/CUtlStringToken.h"

inline c_offsets offsets_instance;

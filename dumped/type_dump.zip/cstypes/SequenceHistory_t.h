#pragma once

struct SequenceHistory_t {
    char PAD_000[0x20];
    float m_flSeqFixedCycle; // 0x20
    float m_flPlaybackRate; // 0x24
    float m_flCyclesPerSecond; // 0x28
};

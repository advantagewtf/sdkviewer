#pragma once

struct CCSPlayerController_InventoryServices__NetworkedLoadoutSlot_t {
    char PAD_000[0x10];
    uint16_t team; // 0x10
    uint16_t slot; // 0x12
};

#pragma once

struct ViewAngleServerChange_t {
    char PAD_000[0x20];
    int nIndex; // 0x20
};

#pragma once

struct EntityRenderAttribute_t {
    char PAD_000[0x4];
    Vector3 m_Values; // 0x4
};

#pragma once

struct C_EconEntity__AttachedModelData_t {
    char PAD_000[0x20];
    int m_iModelDisplayFlags; // 0x20
};

#pragma once

struct EventClientFrameSimulate_t {
    char PAD_000[0x20];
    float m_flRealTime; // 0x20
    float m_flFrameTime; // 0x24
};

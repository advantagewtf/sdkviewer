#pragma once

struct audioparams_t {
    char PAD_000[0x8];
    Vector3 localSound; // 0x8
    uint8_t localBits; // 0x14
    char PAD_015[0xB];
    int soundscapeIndex; // 0x20
    int soundscapeEntityListIndex; // 0x24
    int soundEventHash; // 0x28
};

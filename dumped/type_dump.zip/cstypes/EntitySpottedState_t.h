#pragma once

struct EntitySpottedState_t {
    char PAD_000[0x20];
    int m_bSpottedByMask; // 0x20
};

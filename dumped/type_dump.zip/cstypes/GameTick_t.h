#pragma once

struct GameTick_t {
    char PAD_000[0x20];
    int m_Value; // 0x20
};

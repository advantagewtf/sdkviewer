#pragma once

struct CPulseCell_IntervalTimer__CursorState_t {
    char PAD_000[0x20];
    float m_flWaitInterval; // 0x20
    float m_flWaitIntervalHigh; // 0x24
};

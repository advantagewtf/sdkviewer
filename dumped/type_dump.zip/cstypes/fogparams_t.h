#pragma once

struct fogparams_t {
    char PAD_000[0x20];
    float start; // 0x20
    float end; // 0x24
    float farz; // 0x28
    float maxdensity; // 0x2C
    float exponent; // 0x30
    float HDRColorScale; // 0x34
    float skyboxFogFactor; // 0x38
    float skyboxFogFactorLerpTo; // 0x3C
    float startLerpTo; // 0x40
    float endLerpTo; // 0x44
    float maxdensityLerpTo; // 0x48
    float duration; // 0x4C
    float blendtobackground; // 0x50
    float scattering; // 0x54
    float locallightscale; // 0x58
};

#pragma once

struct EventPostAdvanceTick_t {
    char PAD_000[0x20];
    int m_nCurrentTick; // 0x20
    int m_nCurrentTickThisFrame; // 0x24
    int m_nTotalTicksThisFrame; // 0x28
    int m_nTotalTicks; // 0x2C
};

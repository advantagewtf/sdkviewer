#pragma once

struct SellbackPurchaseEntry_t {
    char PAD_000[0x10];
    uint16_t m_unDefIdx; // 0x10
    char PAD_012[0xE];
    int m_nCost; // 0x20
    int m_nPrevArmor; // 0x24
};

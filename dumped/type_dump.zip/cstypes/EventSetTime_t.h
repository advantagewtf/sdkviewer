#pragma once

struct EventSetTime_t {
    char PAD_000[0x20];
    int m_nClientOutputFrames; // 0x20
    char PAD_024[0x1C];
    float64 m_flRealTime; // 0x40  UNKNOWN TYPE  (struct may be misaligned)
    float64 m_flRenderTime; // 0x48  UNKNOWN TYPE  (struct may be misaligned)
    float64 m_flRenderFrameTime; // 0x50  UNKNOWN TYPE  (struct may be misaligned)
    float64 m_flRenderFrameTimeUnbounded; // 0x58  UNKNOWN TYPE  (struct may be misaligned)
    float64 m_flRenderFrameTimeUnscaled; // 0x60  UNKNOWN TYPE  (struct may be misaligned)
    float64 m_flTickRemainder; // 0x68  UNKNOWN TYPE  (struct may be misaligned)
};

#pragma once

struct EventClientPostOutput_t {
    char PAD_000[0x20];
    float m_flRenderFrameTime; // 0x20
    float m_flRenderFrameTimeUnbounded; // 0x24
    char PAD_028[0x18];
    float64 m_flRenderTime; // 0x40  UNKNOWN TYPE  (struct may be misaligned)
};

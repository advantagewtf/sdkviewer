#pragma once

struct EventClientPollNetworking_t {
    char PAD_000[0x20];
    int m_nTickCount; // 0x20
};

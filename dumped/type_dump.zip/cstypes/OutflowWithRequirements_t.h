#pragma once

struct OutflowWithRequirements_t {
    char PAD_000[0x20];
    int m_nCursorStateBlockIndex; // 0x20
};

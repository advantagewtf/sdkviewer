#pragma once

struct CSMatchStats_t {
    char PAD_000[0x20];
    int m_iEnemy5Ks; // 0x20
    int m_iEnemy4Ks; // 0x24
    int m_iEnemy3Ks; // 0x28
    int m_iEnemyKnifeKills; // 0x2C
    int m_iEnemyTaserKills; // 0x30
};

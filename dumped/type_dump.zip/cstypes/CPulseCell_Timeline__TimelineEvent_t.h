#pragma once

struct CPulseCell_Timeline__TimelineEvent_t {
    char PAD_000[0x20];
    float m_flTimeFromPrevious; // 0x20
};

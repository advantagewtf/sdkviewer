#pragma once

struct CPulseCell_LimitCount__InstanceState_t {
    char PAD_000[0x20];
    int m_nCurrentCount; // 0x20
};

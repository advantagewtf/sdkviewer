#pragma once

struct C_fogplayerparams_t {
    char PAD_000[0x20];
    float m_flTransitionTime; // 0x20
    float m_flOldStart; // 0x24
    float m_flOldEnd; // 0x28
    float m_flOldMaxDensity; // 0x2C
    float m_flOldHDRColorScale; // 0x30
    float m_flOldFarZ; // 0x34
    float m_flNewStart; // 0x38
    float m_flNewEnd; // 0x3C
    float m_flNewMaxDensity; // 0x40
    float m_flNewHDRColorScale; // 0x44
    float m_flNewFarZ; // 0x48
};

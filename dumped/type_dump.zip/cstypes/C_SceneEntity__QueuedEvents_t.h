#pragma once

struct C_SceneEntity__QueuedEvents_t {
    char PAD_000[0x20];
    float starttime; // 0x20
};

#pragma once

struct EventClientProcessInput_t {
    char PAD_000[0x20];
    float m_flRealTime; // 0x20
    float m_flTickInterval; // 0x24
    char PAD_028[0x18];
    float64 m_flTickStartTime; // 0x40  UNKNOWN TYPE  (struct may be misaligned)
};

#pragma once

struct EventAppShutdown_t {
    char PAD_000[0x20];
    int m_nDummy0; // 0x20
};

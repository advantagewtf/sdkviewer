#pragma once

struct VPhysicsCollisionAttribute_t {
    char PAD_000[0x8];
    uint8_t m_nDetailLayerMaskType; // 0x8
    uint8_t m_nTargetDetailLayer; // 0x9
    uint8_t m_nCollisionGroup; // 0xA
    uint8_t m_nCollisionFunctionMask; // 0xB
    char PAD_00C[0x4];
    uint16_t m_nHierarchyId; // 0x10
    uint16_t m_nDetailLayerMask; // 0x12
    char PAD_014[0xC];
    int m_nEntityId; // 0x20
    int m_nOwnerId; // 0x24
    char PAD_028[0x18];
    uint64 m_nInteractsAs; // 0x40  UNKNOWN TYPE  (struct may be misaligned)
    uint64 m_nInteractsWith; // 0x48  UNKNOWN TYPE  (struct may be misaligned)
    uint64 m_nInteractsExclude; // 0x50  UNKNOWN TYPE  (struct may be misaligned)
};

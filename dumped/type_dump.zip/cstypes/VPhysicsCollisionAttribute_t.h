#pragma once

struct VPhysicsCollisionAttribute_t {
    char PAD_000[0x8];
    uint8_t m_nCollisionGroup; // 0x8
    uint8_t m_nCollisionFunctionMask; // 0x9
    char PAD_00A[0x6];
    uint16_t m_nHierarchyId; // 0x10
    char PAD_012[0xE];
    int m_nEntityId; // 0x20
    int m_nOwnerId; // 0x24
    char PAD_028[0x18];
    uint64 m_nInteractsAs; // 0x40  UNKNOWN TYPE  (struct may be misaligned)
    uint64 m_nInteractsWith; // 0x48  UNKNOWN TYPE  (struct may be misaligned)
    uint64 m_nInteractsExclude; // 0x50  UNKNOWN TYPE  (struct may be misaligned)
};

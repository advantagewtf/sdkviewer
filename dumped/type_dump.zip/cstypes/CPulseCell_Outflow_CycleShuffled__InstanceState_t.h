#pragma once

struct CPulseCell_Outflow_CycleShuffled__InstanceState_t {
    char PAD_000[0x8];
    uint8_t m_Shuffle; // 0x8
    char PAD_009[0x17];
    int m_nNextShuffle; // 0x20
};

#pragma once

struct EngineLoopState_t {
    char PAD_000[0x20];
    int m_nPlatWindowWidth; // 0x20
    int m_nPlatWindowHeight; // 0x24
    int m_nRenderWidth; // 0x28
    int m_nRenderHeight; // 0x2C
};

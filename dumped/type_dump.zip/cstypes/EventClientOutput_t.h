#pragma once

struct EventClientOutput_t {
    char PAD_000[0x20];
    float m_flRenderTime; // 0x20
    float m_flRealTime; // 0x24
    float m_flRenderFrameTimeUnbounded; // 0x28
};

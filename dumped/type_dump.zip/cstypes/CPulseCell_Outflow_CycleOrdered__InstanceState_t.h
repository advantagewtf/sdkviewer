#pragma once

struct CPulseCell_Outflow_CycleOrdered__InstanceState_t {
    char PAD_000[0x20];
    int m_nNextIndex; // 0x20
};

#pragma once

struct CAttributeManager__cached_attribute_float_t {
    char PAD_000[0x20];
    float flIn; // 0x20
    float flOut; // 0x24
};

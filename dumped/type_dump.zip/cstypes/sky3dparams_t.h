#pragma once

struct sky3dparams_t {
    char PAD_000[0x10];
    int16 scale; // 0x10  UNKNOWN TYPE  (struct may be misaligned)
    char PAD_018[0x8];
    float flClip3DSkyBoxNearToWorldFarOffset; // 0x20
};

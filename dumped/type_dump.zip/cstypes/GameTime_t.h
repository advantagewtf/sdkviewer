#pragma once

struct GameTime_t {
    char PAD_000[0x20];
    float m_Value; // 0x20
};

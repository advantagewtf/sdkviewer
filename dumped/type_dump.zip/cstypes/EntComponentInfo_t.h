#pragma once

struct EntComponentInfo_t {
    char PAD_000[0x20];
    int m_nRuntimeIndex; // 0x20
    int m_nFlags; // 0x24
};

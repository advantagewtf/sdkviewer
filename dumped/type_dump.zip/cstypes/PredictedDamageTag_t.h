#pragma once

struct PredictedDamageTag_t {
    char PAD_000[0x20];
    float flFlinchModSmall; // 0x20
    float flFlinchModLarge; // 0x24
    float flFriendlyFireDamageReductionRatio; // 0x28
};

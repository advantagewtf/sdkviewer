#pragma once

struct shard_model_desc_t {
    char PAD_000[0x2];
    CStrongHandle<InfoForResourceTypeIMaterial2> m_hMaterialBase; // 0x2  UNKNOWN TYPE  (struct may be misaligned)
    CStrongHandle<InfoForResourceTypeIMaterial2> m_hMaterialDamageOverlay; // 0xA  UNKNOWN TYPE  (struct may be misaligned)
    Vector3 m_vecPanelSize; // 0x12
    Vector3 m_vecStressPositionA; // 0x1E
    Vector3 m_vecStressPositionB; // 0x2A
    Vector3 m_vecPanelVertices; // 0x36
    Vector3 m_vInitialPanelVertices; // 0x42
    int m_nModelID; // 0x4E
    float m_flGlassHalfThickness; // 0x52
};

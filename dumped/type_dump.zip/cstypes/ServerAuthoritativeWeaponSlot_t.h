#pragma once

struct ServerAuthoritativeWeaponSlot_t {
    char PAD_000[0x10];
    uint16_t unClass; // 0x10
    uint16_t unSlot; // 0x12
    uint16_t unItemDefIdx; // 0x14
};

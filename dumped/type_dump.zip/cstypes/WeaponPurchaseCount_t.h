#pragma once

struct WeaponPurchaseCount_t {
    char PAD_000[0x10];
    uint16_t m_nItemDefIndex; // 0x10
    uint16_t m_nCount; // 0x12
};

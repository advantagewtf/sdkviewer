#pragma once

struct EventPostDataUpdate_t {
    char PAD_000[0x20];
    int m_nCount; // 0x20
};

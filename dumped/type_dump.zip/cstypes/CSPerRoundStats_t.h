#pragma once

struct CSPerRoundStats_t {
    char PAD_000[0x20];
    int m_iKills; // 0x20
    int m_iDeaths; // 0x24
    int m_iAssists; // 0x28
    int m_iDamage; // 0x2C
    int m_iEquipmentValue; // 0x30
    int m_iMoneySaved; // 0x34
    int m_iKillReward; // 0x38
    int m_iLiveTime; // 0x3C
    int m_iHeadShotKills; // 0x40
    int m_iObjective; // 0x44
    int m_iCashEarned; // 0x48
    int m_iUtilityDamage; // 0x4C
    int m_iEnemiesFlashed; // 0x50
};

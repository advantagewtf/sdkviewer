#pragma once

struct EventFrameBoundary_t {
    char PAD_000[0x20];
    float m_flFrameTime; // 0x20
};

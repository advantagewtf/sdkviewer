#pragma once

enum class CompositeMaterialVarSystemVar_t : uint32_t {
    COMPMATSYSVAR_COMPOSITETIME = 0x0,
    COMPMATSYSVAR_EMPTY_RESOURCE_SPACER = 0x1
};

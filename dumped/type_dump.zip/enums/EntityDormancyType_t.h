#pragma once

enum class EntityDormancyType_t : uint32_t {
    ENTITY_NOT_DORMANT = 0x0,
    ENTITY_DORMANT = 0x1,
    ENTITY_SUSPENDED = 0x2
};

#pragma once
#include "../memory.h"
class CBaseAnimGraph;

class CPulseCell_PlaySequence__CursorState_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_PlaySequence__CursorState_t() : baseAddr(0) {}
    CPulseCell_PlaySequence__CursorState_t(uintptr_t base) : baseAddr(base) {}

    CBaseAnimGraph* m_hTarget() { return read<CBaseAnimGraph*>(baseAddr + offsets_instance.get("CPulseCell_PlaySequence__CursorState_t", "m_hTarget")); }
};

#pragma once
#include "../memory.h"
class C_BaseEntity;

class CCSPlayer_HostageServices  {
public:
    uintptr_t baseAddr;

    CCSPlayer_HostageServices() : baseAddr(0) {}
    CCSPlayer_HostageServices(uintptr_t base) : baseAddr(base) {}

    C_BaseEntity* m_hCarriedHostage() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CCSPlayer_HostageServices", "m_hCarriedHostage")); }
    C_BaseEntity* m_hCarriedHostageProp() { return read<C_BaseEntity*>(baseAddr + offsets_instance.get("CCSPlayer_HostageServices", "m_hCarriedHostageProp")); }
};

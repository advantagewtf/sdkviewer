#pragma once
#include "../memory.h"

class CPulseCell_LimitCount  {
public:
    uintptr_t baseAddr;

    CPulseCell_LimitCount() : baseAddr(0) {}
    CPulseCell_LimitCount(uintptr_t base) : baseAddr(base) {}

    int m_nLimitCount() { return read<int>(baseAddr + offsets_instance.get("CPulseCell_LimitCount", "m_nLimitCount")); }
};

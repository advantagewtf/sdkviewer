#pragma once
#include "../memory.h"

class CPulseCell_Inflow_Yield  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Yield() : baseAddr(0) {}
    CPulseCell_Inflow_Yield(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_UnyieldResume() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Yield", "m_UnyieldResume")); }
};

#pragma once
#include "../memory.h"

class CBombTarget  {
public:
    uintptr_t baseAddr;

    CBombTarget() : baseAddr(0) {}
    CBombTarget(uintptr_t base) : baseAddr(base) {}

    bool m_bBombPlantedHere() { return read<bool>(baseAddr + offsets_instance.get("CBombTarget", "m_bBombPlantedHere")); }
};

#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"

class CPulseCell_Timeline__TimelineEvent_t  {
public:
    uintptr_t baseAddr;

    CPulseCell_Timeline__TimelineEvent_t() : baseAddr(0) {}
    CPulseCell_Timeline__TimelineEvent_t(uintptr_t base) : baseAddr(base) {}

    float m_flTimeFromPrevious() { return read<float>(baseAddr + offsets_instance.get("CPulseCell_Timeline__TimelineEvent_t", "m_flTimeFromPrevious")); }
    CPulse_OutflowConnection m_EventOutflow() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("CPulseCell_Timeline__TimelineEvent_t", "m_EventOutflow")); }
};

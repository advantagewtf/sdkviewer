#pragma once
#include "../memory.h"
#include "../classes/PulseObservableBoolExpression_t.h"

class CPulseCell_WaitForObservable  {
public:
    uintptr_t baseAddr;

    CPulseCell_WaitForObservable() : baseAddr(0) {}
    CPulseCell_WaitForObservable(uintptr_t base) : baseAddr(base) {}

    PulseObservableBoolExpression_t m_Condition() { return read<PulseObservableBoolExpression_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_Condition")); }
    uintptr_t m_OnTrue() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_WaitForObservable", "m_OnTrue")); }
};

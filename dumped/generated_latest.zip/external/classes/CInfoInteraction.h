#pragma once
#include "../memory.h"

class CInfoInteraction  {
public:
    uintptr_t baseAddr;

    CInfoInteraction() { baseAddr = 0; }
    CInfoInteraction(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_strSlotEntityName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoInteraction", "m_strSlotEntityName")); }
    uintptr_t m_strInteractVData() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoInteraction", "m_strInteractVData")); }
    float m_flInteractRadius() { return read<float>(baseAddr + offsets_instance.get("CInfoInteraction", "m_flInteractRadius")); }
};

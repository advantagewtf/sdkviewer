#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"
#include "../types/Vector3.h"

class C_PhysPropClientside  {
public:
    uintptr_t baseAddr;

    C_PhysPropClientside() { baseAddr = 0; }
    C_PhysPropClientside(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_flTouchDelta() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PhysPropClientside", "m_flTouchDelta")); }
    GameTime_t m_fDeathTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_PhysPropClientside", "m_fDeathTime")); }
    Vector3 m_vecDamagePosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_PhysPropClientside", "m_vecDamagePosition")); }
    Vector3 m_vecDamageDirection() { return read<Vector3>(baseAddr + offsets_instance.get("C_PhysPropClientside", "m_vecDamageDirection")); }
    uintptr_t m_nDamageType() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_PhysPropClientside", "m_nDamageType")); }
};

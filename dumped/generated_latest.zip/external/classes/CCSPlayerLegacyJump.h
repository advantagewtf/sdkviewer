#pragma once
#include "../memory.h"

class CCSPlayerLegacyJump  {
public:
    uintptr_t baseAddr;

    CCSPlayerLegacyJump() { baseAddr = 0; }
    CCSPlayerLegacyJump(uintptr_t base) : baseAddr(base) {}

    bool m_bOldJumpPressed() { return read<bool>(baseAddr + offsets_instance.get("CCSPlayerLegacyJump", "m_bOldJumpPressed")); }
    float m_flJumpPressedTime() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerLegacyJump", "m_flJumpPressedTime")); }
};

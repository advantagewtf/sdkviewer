#pragma once
#include "../memory.h"

class SignatureOutflow_Resume  {
public:
    uintptr_t baseAddr;

    SignatureOutflow_Resume() { baseAddr = 0; }
    SignatureOutflow_Resume(uintptr_t base) : baseAddr(base) {}

};

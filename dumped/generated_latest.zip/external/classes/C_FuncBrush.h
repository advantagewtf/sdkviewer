#pragma once
#include "../memory.h"

class C_FuncBrush  {
public:
    uintptr_t baseAddr;

    C_FuncBrush() { baseAddr = 0; }
    C_FuncBrush(uintptr_t base) : baseAddr(base) {}

};

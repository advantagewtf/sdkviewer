#pragma once
#include "../memory.h"
class CLightComponent;

class C_LightEntity  {
public:
    uintptr_t baseAddr;

    C_LightEntity() { baseAddr = 0; }
    C_LightEntity(uintptr_t base) : baseAddr(base) {}

    CLightComponent* m_CLightComponent() { return read<CLightComponent*>(baseAddr + offsets_instance.get("C_LightEntity", "m_CLightComponent")); }
};

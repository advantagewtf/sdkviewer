#pragma once
#include "../memory.h"

class C_TonemapController2Alias_env_tonemap_controller2  {
public:
    uintptr_t baseAddr;

    C_TonemapController2Alias_env_tonemap_controller2() { baseAddr = 0; }
    C_TonemapController2Alias_env_tonemap_controller2(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include "../memory.h"

class CRenderComponent  {
public:
    uintptr_t baseAddr;

    CRenderComponent() { baseAddr = 0; }
    CRenderComponent(uintptr_t base) : baseAddr(base) {}

    uintptr_t __m_pChainEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CRenderComponent", "__m_pChainEntity")); }
    bool m_bIsRenderingWithViewModels() { return read<bool>(baseAddr + offsets_instance.get("CRenderComponent", "m_bIsRenderingWithViewModels")); }
    int m_nSplitscreenFlags() { return read<int>(baseAddr + offsets_instance.get("CRenderComponent", "m_nSplitscreenFlags")); }
    bool m_bEnableRendering() { return read<bool>(baseAddr + offsets_instance.get("CRenderComponent", "m_bEnableRendering")); }
    bool m_bInterpolationReadyToDraw() { return read<bool>(baseAddr + offsets_instance.get("CRenderComponent", "m_bInterpolationReadyToDraw")); }
};

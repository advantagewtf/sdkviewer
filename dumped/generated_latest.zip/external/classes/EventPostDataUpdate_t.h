#pragma once
#include "../memory.h"

class EventPostDataUpdate_t  {
public:
    uintptr_t baseAddr;

    EventPostDataUpdate_t() { baseAddr = 0; }
    EventPostDataUpdate_t(uintptr_t base) : baseAddr(base) {}

    int m_nCount() { return read<int>(baseAddr + offsets_instance.get("EventPostDataUpdate_t", "m_nCount")); }
};

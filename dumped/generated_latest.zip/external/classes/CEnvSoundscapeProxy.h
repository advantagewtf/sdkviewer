#pragma once
#include "../memory.h"

class CEnvSoundscapeProxy  {
public:
    uintptr_t baseAddr;

    CEnvSoundscapeProxy() { baseAddr = 0; }
    CEnvSoundscapeProxy(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_MainSoundscapeName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CEnvSoundscapeProxy", "m_MainSoundscapeName")); }
};

#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventClientFrameSimulate_t  {
public:
    uintptr_t baseAddr;

    EventClientFrameSimulate_t() { baseAddr = 0; }
    EventClientFrameSimulate_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventClientFrameSimulate_t", "m_LoopState")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("EventClientFrameSimulate_t", "m_flRealTime")); }
    float m_flFrameTime() { return read<float>(baseAddr + offsets_instance.get("EventClientFrameSimulate_t", "m_flFrameTime")); }
    bool m_bScheduleSendTickPacket() { return read<bool>(baseAddr + offsets_instance.get("EventClientFrameSimulate_t", "m_bScheduleSendTickPacket")); }
};

#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class dump  {
public:
    uintptr_t baseAddr;

    dump() { baseAddr = 0; }
    dump(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("dump", "m_LoopState")); }
    float m_flRealTime() { return read<float>(baseAddr + offsets_instance.get("dump", "m_flRealTime")); }
    float m_flFrameTime() { return read<float>(baseAddr + offsets_instance.get("dump", "m_flFrameTime")); }
};

#pragma once
#include "../memory.h"

class GameTime_t  {
public:
    uintptr_t baseAddr;

    GameTime_t() { baseAddr = 0; }
    GameTime_t(uintptr_t base) : baseAddr(base) {}

    float m_Value() { return read<float>(baseAddr + offsets_instance.get("GameTime_t", "m_Value")); }
};

#pragma once
#include "../memory.h"

class CPulseCell_Inflow_Wait  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Wait() { baseAddr = 0; }
    CPulseCell_Inflow_Wait(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_WakeResume() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Wait", "m_WakeResume")); }
};

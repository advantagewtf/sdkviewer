#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"

class CPulseCell_Inflow_Wait  {
public:
    uintptr_t baseAddr;

    CPulseCell_Inflow_Wait() { baseAddr = 0; }
    CPulseCell_Inflow_Wait(uintptr_t base) : baseAddr(base) {}

    CPulse_ResumePoint m_WakeResume() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_Inflow_Wait", "m_WakeResume")); }
};

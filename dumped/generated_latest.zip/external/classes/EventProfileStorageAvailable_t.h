#pragma once
#include "../memory.h"

class EventProfileStorageAvailable_t  {
public:
    uintptr_t baseAddr;

    EventProfileStorageAvailable_t() { baseAddr = 0; }
    EventProfileStorageAvailable_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nSplitScreenSlot() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventProfileStorageAvailable_t", "m_nSplitScreenSlot")); }
};

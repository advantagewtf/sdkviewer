#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_BaseFlex  {
public:
    uintptr_t baseAddr;

    C_BaseFlex() { baseAddr = 0; }
    C_BaseFlex(uintptr_t base) : baseAddr(base) {}

    float m_flexWeight() { return read<float>(baseAddr + offsets_instance.get("C_BaseFlex", "m_flexWeight")); }
    Vector3 m_vLookTargetPosition() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_vLookTargetPosition")); }
    int m_nLastFlexUpdateFrameCount() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nLastFlexUpdateFrameCount")); }
    Vector3 m_CachedViewTarget() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_CachedViewTarget")); }
    uintptr_t m_nNextSceneEventId() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nNextSceneEventId")); }
    uintptr_t m_iMouthAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iMouthAttachment")); }
    uintptr_t m_iEyeAttachment() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_iEyeAttachment")); }
    bool m_bResetFlexWeightsOnModelChange() { return read<bool>(baseAddr + offsets_instance.get("C_BaseFlex", "m_bResetFlexWeightsOnModelChange")); }
    int m_nEyeOcclusionRendererBone() { return read<int>(baseAddr + offsets_instance.get("C_BaseFlex", "m_nEyeOcclusionRendererBone")); }
    uintptr_t m_mEyeOcclusionRendererCameraToBoneTransform() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_mEyeOcclusionRendererCameraToBoneTransform")); }
    Vector3 m_vEyeOcclusionRendererHalfExtent() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseFlex", "m_vEyeOcclusionRendererHalfExtent")); }
    uintptr_t m_PhonemeClasses() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseFlex", "m_PhonemeClasses")); }
};

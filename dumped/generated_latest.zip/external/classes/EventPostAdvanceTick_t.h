#pragma once
#include "../memory.h"

class EventPostAdvanceTick_t  {
public:
    uintptr_t baseAddr;

    EventPostAdvanceTick_t() { baseAddr = 0; }
    EventPostAdvanceTick_t(uintptr_t base) : baseAddr(base) {}

    int m_nCurrentTick() { return read<int>(baseAddr + offsets_instance.get("EventPostAdvanceTick_t", "m_nCurrentTick")); }
    int m_nCurrentTickThisFrame() { return read<int>(baseAddr + offsets_instance.get("EventPostAdvanceTick_t", "m_nCurrentTickThisFrame")); }
    int m_nTotalTicksThisFrame() { return read<int>(baseAddr + offsets_instance.get("EventPostAdvanceTick_t", "m_nTotalTicksThisFrame")); }
    int m_nTotalTicks() { return read<int>(baseAddr + offsets_instance.get("EventPostAdvanceTick_t", "m_nTotalTicks")); }
};

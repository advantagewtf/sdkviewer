#pragma once
#include "../memory.h"
class C_CSGameRules;

class C_CSGameRulesProxy  {
public:
    uintptr_t baseAddr;

    C_CSGameRulesProxy() { baseAddr = 0; }
    C_CSGameRulesProxy(uintptr_t base) : baseAddr(base) {}

    C_CSGameRules* m_pGameRules() { return read<C_CSGameRules*>(baseAddr + offsets_instance.get("C_CSGameRulesProxy", "m_pGameRules")); }
};

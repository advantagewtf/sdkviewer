#pragma once
#include "../memory.h"

class EventPreDataUpdate_t  {
public:
    uintptr_t baseAddr;

    EventPreDataUpdate_t() { baseAddr = 0; }
    EventPreDataUpdate_t(uintptr_t base) : baseAddr(base) {}

    int m_nCount() { return read<int>(baseAddr + offsets_instance.get("EventPreDataUpdate_t", "m_nCount")); }
};

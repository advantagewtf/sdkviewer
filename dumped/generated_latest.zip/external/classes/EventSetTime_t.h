#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventSetTime_t  {
public:
    uintptr_t baseAddr;

    EventSetTime_t() { baseAddr = 0; }
    EventSetTime_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_LoopState")); }
    int m_nClientOutputFrames() { return read<int>(baseAddr + offsets_instance.get("EventSetTime_t", "m_nClientOutputFrames")); }
    uintptr_t m_flRealTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flRealTime")); }
    uintptr_t m_flRenderTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flRenderTime")); }
    uintptr_t m_flRenderFrameTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flRenderFrameTime")); }
    uintptr_t m_flRenderFrameTimeUnbounded() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flRenderFrameTimeUnbounded")); }
    uintptr_t m_flRenderFrameTimeUnscaled() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flRenderFrameTimeUnscaled")); }
    uintptr_t m_flTickRemainder() { return read<uintptr_t>(baseAddr + offsets_instance.get("EventSetTime_t", "m_flTickRemainder")); }
};

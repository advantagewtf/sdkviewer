#pragma once
#include "../memory.h"

class C_WeaponG3SG1  {
public:
    uintptr_t baseAddr;

    C_WeaponG3SG1() { baseAddr = 0; }
    C_WeaponG3SG1(uintptr_t base) : baseAddr(base) {}

};

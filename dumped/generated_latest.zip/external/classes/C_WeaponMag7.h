#pragma once
#include "../memory.h"

class C_WeaponMag7  {
public:
    uintptr_t baseAddr;

    C_WeaponMag7() { baseAddr = 0; }
    C_WeaponMag7(uintptr_t base) : baseAddr(base) {}

};

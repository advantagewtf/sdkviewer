#pragma once
#include "../memory.h"
#include "../types/Vector3.h"
class CPathWithDynamicNodes;

class CPathNode  {
public:
    uintptr_t baseAddr;

    CPathNode() { baseAddr = 0; }
    CPathNode(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vInTangentLocal() { return read<Vector3>(baseAddr + offsets_instance.get("CPathNode", "m_vInTangentLocal")); }
    Vector3 m_vOutTangentLocal() { return read<Vector3>(baseAddr + offsets_instance.get("CPathNode", "m_vOutTangentLocal")); }
    uintptr_t m_strParentPathUniqueID() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathNode", "m_strParentPathUniqueID")); }
    uintptr_t m_strPathNodeParameter() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathNode", "m_strPathNodeParameter")); }
    uintptr_t m_xWSPrevParent() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathNode", "m_xWSPrevParent")); }
    CPathWithDynamicNodes* m_hPath() { return read<CPathWithDynamicNodes*>(baseAddr + offsets_instance.get("CPathNode", "m_hPath")); }
};

#pragma once
#include "../memory.h"

class C_BaseEntityAPI  {
public:
    uintptr_t baseAddr;

    C_BaseEntityAPI() { baseAddr = 0; }
    C_BaseEntityAPI(uintptr_t base) : baseAddr(base) {}

};

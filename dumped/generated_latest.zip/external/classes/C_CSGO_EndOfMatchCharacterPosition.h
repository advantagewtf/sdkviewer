#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchCharacterPosition  {
public:
    uintptr_t baseAddr;

    C_CSGO_EndOfMatchCharacterPosition() { baseAddr = 0; }
    C_CSGO_EndOfMatchCharacterPosition(uintptr_t base) : baseAddr(base) {}

};

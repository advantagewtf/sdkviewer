#pragma once
#include "../memory.h"

class CPulseCell_IsRequirementValid  {
public:
    uintptr_t baseAddr;

    CPulseCell_IsRequirementValid() { baseAddr = 0; }
    CPulseCell_IsRequirementValid(uintptr_t base) : baseAddr(base) {}

};

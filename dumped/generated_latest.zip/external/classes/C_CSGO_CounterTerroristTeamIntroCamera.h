#pragma once
#include "../memory.h"

class C_CSGO_CounterTerroristTeamIntroCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_CounterTerroristTeamIntroCamera() { baseAddr = 0; }
    C_CSGO_CounterTerroristTeamIntroCamera(uintptr_t base) : baseAddr(base) {}

};

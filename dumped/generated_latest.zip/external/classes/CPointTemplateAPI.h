#pragma once
#include "../memory.h"

class CPointTemplateAPI  {
public:
    uintptr_t baseAddr;

    CPointTemplateAPI() { baseAddr = 0; }
    CPointTemplateAPI(uintptr_t base) : baseAddr(base) {}

};

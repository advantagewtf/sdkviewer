#pragma once
#include "../memory.h"

class CCSPlayerModernJump  {
public:
    uintptr_t baseAddr;

    CCSPlayerModernJump() { baseAddr = 0; }
    CCSPlayerModernJump(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nLastActualJumpPressTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_nLastActualJumpPressTick")); }
    float m_flLastActualJumpPressFrac() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastActualJumpPressFrac")); }
    uintptr_t m_nLastUsableJumpPressTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_nLastUsableJumpPressTick")); }
    float m_flLastUsableJumpPressFrac() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastUsableJumpPressFrac")); }
    uintptr_t m_nLastLandedTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_nLastLandedTick")); }
    float m_flLastLandedFrac() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastLandedFrac")); }
    float m_flLastLandedVelocityX() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastLandedVelocityX")); }
    float m_flLastLandedVelocityY() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastLandedVelocityY")); }
    float m_flLastLandedVelocityZ() { return read<float>(baseAddr + offsets_instance.get("CCSPlayerModernJump", "m_flLastLandedVelocityZ")); }
};

#pragma once
#include "../memory.h"

class CFilterLOS  {
public:
    uintptr_t baseAddr;

    CFilterLOS() { baseAddr = 0; }
    CFilterLOS(uintptr_t base) : baseAddr(base) {}

};

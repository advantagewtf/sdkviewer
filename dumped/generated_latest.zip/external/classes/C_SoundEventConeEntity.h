#pragma once
#include "../memory.h"

class C_SoundEventConeEntity  {
public:
    uintptr_t baseAddr;

    C_SoundEventConeEntity() { baseAddr = 0; }
    C_SoundEventConeEntity(uintptr_t base) : baseAddr(base) {}

    float m_flEmitterAngle() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventConeEntity", "m_flEmitterAngle")); }
    float m_flSweetSpotAngle() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventConeEntity", "m_flSweetSpotAngle")); }
    float m_flAttenMin() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventConeEntity", "m_flAttenMin")); }
    float m_flAttenMax() { return read<float>(baseAddr + offsets_instance.get("C_SoundEventConeEntity", "m_flAttenMax")); }
    uintptr_t m_iszParameterName() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SoundEventConeEntity", "m_iszParameterName")); }
};

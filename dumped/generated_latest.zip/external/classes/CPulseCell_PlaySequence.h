#pragma once
#include "../memory.h"
#include "../classes/PulseNodeDynamicOutflows_t.h"

class CPulseCell_PlaySequence  {
public:
    uintptr_t baseAddr;

    CPulseCell_PlaySequence() { baseAddr = 0; }
    CPulseCell_PlaySequence(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_SequenceName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PlaySequence", "m_SequenceName")); }
    PulseNodeDynamicOutflows_t m_PulseAnimEvents() { return read<PulseNodeDynamicOutflows_t>(baseAddr + offsets_instance.get("CPulseCell_PlaySequence", "m_PulseAnimEvents")); }
    uintptr_t m_OnFinished() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PlaySequence", "m_OnFinished")); }
    uintptr_t m_OnCanceled() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPulseCell_PlaySequence", "m_OnCanceled")); }
};

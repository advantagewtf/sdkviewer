#pragma once
#include "../memory.h"

class GameTick_t  {
public:
    uintptr_t baseAddr;

    GameTick_t() { baseAddr = 0; }
    GameTick_t(uintptr_t base) : baseAddr(base) {}

    int m_Value() { return read<int>(baseAddr + offsets_instance.get("GameTick_t", "m_Value")); }
};

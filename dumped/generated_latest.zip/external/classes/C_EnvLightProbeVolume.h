#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class C_EnvLightProbeVolume  {
public:
    uintptr_t baseAddr;

    C_EnvLightProbeVolume() { baseAddr = 0; }
    C_EnvLightProbeVolume(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_Entity_hLightProbeTexture_AmbientCube() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_AmbientCube")); }
    uintptr_t m_Entity_hLightProbeTexture_SDF() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_SDF")); }
    uintptr_t m_Entity_hLightProbeTexture_SH2_DC() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_SH2_DC")); }
    uintptr_t m_Entity_hLightProbeTexture_SH2_R() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_SH2_R")); }
    uintptr_t m_Entity_hLightProbeTexture_SH2_G() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_SH2_G")); }
    uintptr_t m_Entity_hLightProbeTexture_SH2_B() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeTexture_SH2_B")); }
    uintptr_t m_Entity_hLightProbeDirectLightIndicesTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeDirectLightIndicesTexture")); }
    uintptr_t m_Entity_hLightProbeDirectLightScalarsTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeDirectLightScalarsTexture")); }
    uintptr_t m_Entity_hLightProbeDirectLightShadowsTexture() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_hLightProbeDirectLightShadowsTexture")); }
    Vector3 m_Entity_vBoxMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_vBoxMins")); }
    Vector3 m_Entity_vBoxMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_vBoxMaxs")); }
    bool m_Entity_bMoveable() { return read<bool>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_bMoveable")); }
    int m_Entity_nHandshake() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nHandshake")); }
    int m_Entity_nPriority() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nPriority")); }
    bool m_Entity_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_bStartDisabled")); }
    int m_Entity_nLightProbeSizeX() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeSizeX")); }
    int m_Entity_nLightProbeSizeY() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeSizeY")); }
    int m_Entity_nLightProbeSizeZ() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeSizeZ")); }
    int m_Entity_nLightProbeAtlasX() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeAtlasX")); }
    int m_Entity_nLightProbeAtlasY() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeAtlasY")); }
    int m_Entity_nLightProbeAtlasZ() { return read<int>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_nLightProbeAtlasZ")); }
    bool m_Entity_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_EnvLightProbeVolume", "m_Entity_bEnabled")); }
};

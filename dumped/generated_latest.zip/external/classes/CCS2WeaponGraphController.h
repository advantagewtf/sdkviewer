#pragma once
#include "../memory.h"

class CCS2WeaponGraphController  {
public:
    uintptr_t baseAddr;

    CCS2WeaponGraphController() { baseAddr = 0; }
    CCS2WeaponGraphController(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_action() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_action")); }
    bool m_bActionReset() { return read<bool>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_bActionReset")); }
    float m_flWeaponActionSpeedScale() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flWeaponActionSpeedScale")); }
    uintptr_t m_weaponCategory() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_weaponCategory")); }
    uintptr_t m_weaponType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_weaponType")); }
    uintptr_t m_weaponExtraInfo() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_weaponExtraInfo")); }
    float m_flWeaponAmmo() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flWeaponAmmo")); }
    float m_flWeaponAmmoMax() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flWeaponAmmoMax")); }
    float m_flWeaponAmmoReserve() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flWeaponAmmoReserve")); }
    bool m_bWeaponIsSilenced() { return read<bool>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_bWeaponIsSilenced")); }
    float m_flWeaponIronsightAmount() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flWeaponIronsightAmount")); }
    bool m_bIsUsingLegacyModel() { return read<bool>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_bIsUsingLegacyModel")); }
    float m_idleVariation() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_idleVariation")); }
    float m_deployVariation() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_deployVariation")); }
    uintptr_t m_attackType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_attackType")); }
    float m_attackThrowStrength() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_attackThrowStrength")); }
    float m_flAttackVariation() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_flAttackVariation")); }
    float m_inspectVariation() { return read<float>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_inspectVariation")); }
    uintptr_t m_inspectExtraInfo() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_inspectExtraInfo")); }
    uintptr_t m_reloadStage() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCS2WeaponGraphController", "m_reloadStage")); }
};

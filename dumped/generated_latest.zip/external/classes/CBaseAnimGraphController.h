#pragma once
#include "../memory.h"
#include "../classes/CAnimGraphNetworkedVariables.h"
#include "../types/Vector3.h"

class CBaseAnimGraphController  {
public:
    uintptr_t baseAddr;

    CBaseAnimGraphController() { baseAddr = 0; }
    CBaseAnimGraphController(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_nAnimationAlgorithm() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nAnimationAlgorithm")); }
    CAnimGraphNetworkedVariables m_animGraphNetworkedVars() { return read<CAnimGraphNetworkedVariables>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_animGraphNetworkedVars")); }
    uintptr_t m_pAnimGraphInstance() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_pAnimGraphInstance")); }
    uintptr_t m_nNextExternalGraphHandle() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nNextExternalGraphHandle")); }
    Vector3 m_vecSecondarySkeletonNames() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_vecSecondarySkeletonNames")); }
    Vector3 m_vecSecondarySkeletons() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_vecSecondarySkeletons")); }
    int m_nSecondarySkeletonMasterCount() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nSecondarySkeletonMasterCount")); }
    float m_flSoundSyncTime() { return read<float>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSoundSyncTime")); }
    int m_nActiveIKChainMask() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nActiveIKChainMask")); }
    uintptr_t m_hSequence() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_hSequence")); }
    uintptr_t m_flSeqStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSeqStartTime")); }
    float m_flSeqFixedCycle() { return read<float>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flSeqFixedCycle")); }
    uintptr_t m_nAnimLoopMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nAnimLoopMode")); }
    uintptr_t m_flPlaybackRate() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_flPlaybackRate")); }
    uintptr_t m_nNotifyState() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nNotifyState")); }
    bool m_bNetworkedAnimationInputsChanged() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bNetworkedAnimationInputsChanged")); }
    bool m_bNetworkedSequenceChanged() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bNetworkedSequenceChanged")); }
    bool m_bLastUpdateSkipped() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bLastUpdateSkipped")); }
    bool m_bSequenceFinished() { return read<bool>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_bSequenceFinished")); }
    uintptr_t m_nPrevAnimUpdateTick() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nPrevAnimUpdateTick")); }
    uintptr_t m_hGraphDefinitionAG2() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_hGraphDefinitionAG2")); }
    uint8_t m_serializedPoseRecipeAG2() { return read<uint8_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_serializedPoseRecipeAG2")); }
    int m_nSerializePoseRecipeSizeAG2() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nSerializePoseRecipeSizeAG2")); }
    int m_nSerializePoseRecipeVersionAG2() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nSerializePoseRecipeVersionAG2")); }
    int m_nServerGraphInstanceIteration() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nServerGraphInstanceIteration")); }
    int m_nServerSerializationContextIteration() { return read<int>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nServerSerializationContextIteration")); }
    uintptr_t m_primaryGraphId() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_primaryGraphId")); }
    Vector3 m_vecExternalGraphIds() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_vecExternalGraphIds")); }
    Vector3 m_vecExternalClipIds() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_vecExternalClipIds")); }
    uintptr_t m_sAnimGraph2Identifier() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_sAnimGraph2Identifier")); }
    Vector3 m_vecExternalGraphs() { return read<Vector3>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_vecExternalGraphs")); }
    uintptr_t m_nPrevAnimationAlgorithm() { return read<uintptr_t>(baseAddr + offsets_instance.get("CBaseAnimGraphController", "m_nPrevAnimationAlgorithm")); }
};

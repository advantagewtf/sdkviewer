#pragma once
#include "../memory.h"

class CPulseTestScriptLib  {
public:
    uintptr_t baseAddr;

    CPulseTestScriptLib() { baseAddr = 0; }
    CPulseTestScriptLib(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include "../memory.h"

class EventFrameBoundary_t  {
public:
    uintptr_t baseAddr;

    EventFrameBoundary_t() { baseAddr = 0; }
    EventFrameBoundary_t(uintptr_t base) : baseAddr(base) {}

    float m_flFrameTime() { return read<float>(baseAddr + offsets_instance.get("EventFrameBoundary_t", "m_flFrameTime")); }
};

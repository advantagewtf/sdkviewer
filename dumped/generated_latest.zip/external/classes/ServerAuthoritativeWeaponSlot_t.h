#pragma once
#include "../memory.h"

class ServerAuthoritativeWeaponSlot_t  {
public:
    uintptr_t baseAddr;

    ServerAuthoritativeWeaponSlot_t() { baseAddr = 0; }
    ServerAuthoritativeWeaponSlot_t(uintptr_t base) : baseAddr(base) {}

    uint16_t unClass() { return read<uint16_t>(baseAddr + offsets_instance.get("ServerAuthoritativeWeaponSlot_t", "unClass")); }
    uint16_t unSlot() { return read<uint16_t>(baseAddr + offsets_instance.get("ServerAuthoritativeWeaponSlot_t", "unSlot")); }
    uint16_t unItemDefIdx() { return read<uint16_t>(baseAddr + offsets_instance.get("ServerAuthoritativeWeaponSlot_t", "unItemDefIdx")); }
};

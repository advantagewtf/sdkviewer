#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"

class PulseNodeDynamicOutflows_t__DynamicOutflow_t  {
public:
    uintptr_t baseAddr;

    PulseNodeDynamicOutflows_t__DynamicOutflow_t() { baseAddr = 0; }
    PulseNodeDynamicOutflows_t__DynamicOutflow_t(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_OutflowID() { return read<uintptr_t>(baseAddr + offsets_instance.get("PulseNodeDynamicOutflows_t__DynamicOutflow_t", "m_OutflowID")); }
    CPulse_OutflowConnection m_Connection() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("PulseNodeDynamicOutflows_t__DynamicOutflow_t", "m_Connection")); }
};

#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchLineupEndpoint  {
public:
    uintptr_t baseAddr;

    C_CSGO_EndOfMatchLineupEndpoint() { baseAddr = 0; }
    C_CSGO_EndOfMatchLineupEndpoint(uintptr_t base) : baseAddr(base) {}

};

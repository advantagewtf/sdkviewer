#pragma once
#include "../memory.h"

class EventClientAdvanceTick_t  {
public:
    uintptr_t baseAddr;

    EventClientAdvanceTick_t() { baseAddr = 0; }
    EventClientAdvanceTick_t(uintptr_t base) : baseAddr(base) {}

};

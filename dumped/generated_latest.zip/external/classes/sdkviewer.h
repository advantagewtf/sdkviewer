#pragma once
#include "../memory.h"
class CEntityIdentity;
class CScriptComponent;

class sdkviewer  {
public:
    uintptr_t baseAddr;

    sdkviewer() { baseAddr = 0; }
    sdkviewer(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_iszPrivateVScripts() { return read<uintptr_t>(baseAddr + offsets_instance.get("sdkviewer", "m_iszPrivateVScripts")); }
    CEntityIdentity* m_pEntity() { return read<CEntityIdentity*>(baseAddr + offsets_instance.get("sdkviewer", "m_pEntity")); }
    CScriptComponent* m_CScriptComponent() { return read<CScriptComponent*>(baseAddr + offsets_instance.get("sdkviewer", "m_CScriptComponent")); }
};

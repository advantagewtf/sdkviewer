#pragma once
#include "../memory.h"
#include "../classes/CNetworkVarChainer.h"

class C_GameRules  {
public:
    uintptr_t baseAddr;

    C_GameRules() { baseAddr = 0; }
    C_GameRules(uintptr_t base) : baseAddr(base) {}

    CNetworkVarChainer __m_pChainEntity() { return read<CNetworkVarChainer>(baseAddr + offsets_instance.get("C_GameRules", "__m_pChainEntity")); }
    int m_nTotalPausedTicks() { return read<int>(baseAddr + offsets_instance.get("C_GameRules", "m_nTotalPausedTicks")); }
    int m_nPauseStartTick() { return read<int>(baseAddr + offsets_instance.get("C_GameRules", "m_nPauseStartTick")); }
    bool m_bGamePaused() { return read<bool>(baseAddr + offsets_instance.get("C_GameRules", "m_bGamePaused")); }
};

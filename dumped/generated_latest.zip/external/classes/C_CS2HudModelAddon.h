#pragma once
#include "../memory.h"

class C_CS2HudModelAddon  {
public:
    uintptr_t baseAddr;

    C_CS2HudModelAddon() { baseAddr = 0; }
    C_CS2HudModelAddon(uintptr_t base) : baseAddr(base) {}

};

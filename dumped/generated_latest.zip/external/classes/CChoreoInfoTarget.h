#pragma once
#include "../memory.h"

class CChoreoInfoTarget  {
public:
    uintptr_t baseAddr;

    CChoreoInfoTarget() { baseAddr = 0; }
    CChoreoInfoTarget(uintptr_t base) : baseAddr(base) {}

};

#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class C_ColorCorrectionVolume  {
public:
    uintptr_t baseAddr;

    C_ColorCorrectionVolume() { baseAddr = 0; }
    C_ColorCorrectionVolume(uintptr_t base) : baseAddr(base) {}

    float m_LastEnterWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_LastEnterWeight")); }
    GameTime_t m_LastEnterTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_LastEnterTime")); }
    float m_LastExitWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_LastExitWeight")); }
    GameTime_t m_LastExitTime() { return read<GameTime_t>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_LastExitTime")); }
    bool m_bEnabled() { return read<bool>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_bEnabled")); }
    float m_MaxWeight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_MaxWeight")); }
    float m_FadeDuration() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_FadeDuration")); }
    float m_Weight() { return read<float>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_Weight")); }
    char* m_lookupFilename() { return read<char*>(baseAddr + offsets_instance.get("C_ColorCorrectionVolume", "m_lookupFilename")); }
};

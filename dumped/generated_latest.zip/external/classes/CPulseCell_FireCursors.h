#pragma once
#include "../memory.h"
#include "../classes/CPulse_ResumePoint.h"
#include "../types/Vector3.h"

class CPulseCell_FireCursors  {
public:
    uintptr_t baseAddr;

    CPulseCell_FireCursors() { baseAddr = 0; }
    CPulseCell_FireCursors(uintptr_t base) : baseAddr(base) {}

    Vector3 m_Outflows() { return read<Vector3>(baseAddr + offsets_instance.get("CPulseCell_FireCursors", "m_Outflows")); }
    bool m_bWaitForChildOutflows() { return read<bool>(baseAddr + offsets_instance.get("CPulseCell_FireCursors", "m_bWaitForChildOutflows")); }
    CPulse_ResumePoint m_OnFinished() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_FireCursors", "m_OnFinished")); }
    CPulse_ResumePoint m_OnCanceled() { return read<CPulse_ResumePoint>(baseAddr + offsets_instance.get("CPulseCell_FireCursors", "m_OnCanceled")); }
};

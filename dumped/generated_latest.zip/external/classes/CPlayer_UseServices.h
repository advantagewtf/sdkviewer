#pragma once
#include "../memory.h"

class CPlayer_UseServices  {
public:
    uintptr_t baseAddr;

    CPlayer_UseServices() { baseAddr = 0; }
    CPlayer_UseServices(uintptr_t base) : baseAddr(base) {}

};

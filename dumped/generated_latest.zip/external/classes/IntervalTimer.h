#pragma once
#include "../memory.h"
#include "../classes/GameTime_t.h"

class IntervalTimer  {
public:
    uintptr_t baseAddr;

    IntervalTimer() { baseAddr = 0; }
    IntervalTimer(uintptr_t base) : baseAddr(base) {}

    GameTime_t m_timestamp() { return read<GameTime_t>(baseAddr + offsets_instance.get("IntervalTimer", "m_timestamp")); }
    uintptr_t m_nWorldGroupId() { return read<uintptr_t>(baseAddr + offsets_instance.get("IntervalTimer", "m_nWorldGroupId")); }
};

#pragma once
#include "../memory.h"
#include "../classes/EngineLoopState_t.h"

class EventSimulate_t  {
public:
    uintptr_t baseAddr;

    EventSimulate_t() { baseAddr = 0; }
    EventSimulate_t(uintptr_t base) : baseAddr(base) {}

    EngineLoopState_t m_LoopState() { return read<EngineLoopState_t>(baseAddr + offsets_instance.get("EventSimulate_t", "m_LoopState")); }
    bool m_bFirstTick() { return read<bool>(baseAddr + offsets_instance.get("EventSimulate_t", "m_bFirstTick")); }
    bool m_bLastTick() { return read<bool>(baseAddr + offsets_instance.get("EventSimulate_t", "m_bLastTick")); }
};

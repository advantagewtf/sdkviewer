#pragma once
#include "../memory.h"

class C_WeaponAWP  {
public:
    uintptr_t baseAddr;

    C_WeaponAWP() { baseAddr = 0; }
    C_WeaponAWP(uintptr_t base) : baseAddr(base) {}

};

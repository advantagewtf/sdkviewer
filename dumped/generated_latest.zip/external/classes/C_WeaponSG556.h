#pragma once
#include "../memory.h"

class C_WeaponSG556  {
public:
    uintptr_t baseAddr;

    C_WeaponSG556() { baseAddr = 0; }
    C_WeaponSG556(uintptr_t base) : baseAddr(base) {}

};

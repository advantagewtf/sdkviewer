#pragma once
#include "../memory.h"
#include "../classes/C_EnvWindShared.h"

class C_EnvWindController  {
public:
    uintptr_t baseAddr;

    C_EnvWindController() { baseAddr = 0; }
    C_EnvWindController(uintptr_t base) : baseAddr(base) {}

    C_EnvWindShared m_EnvWindShared() { return read<C_EnvWindShared>(baseAddr + offsets_instance.get("C_EnvWindController", "m_EnvWindShared")); }
    float m_fDirectionVariation() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindController", "m_fDirectionVariation")); }
    float m_fSpeedVariation() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindController", "m_fSpeedVariation")); }
    float m_fTurbulence() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindController", "m_fTurbulence")); }
    float m_fVolumeHalfExtentXY() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindController", "m_fVolumeHalfExtentXY")); }
    float m_fVolumeHalfExtentZ() { return read<float>(baseAddr + offsets_instance.get("C_EnvWindController", "m_fVolumeHalfExtentZ")); }
    int m_nVolumeResolutionXY() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindController", "m_nVolumeResolutionXY")); }
    int m_nVolumeResolutionZ() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindController", "m_nVolumeResolutionZ")); }
    int m_nClipmapLevels() { return read<int>(baseAddr + offsets_instance.get("C_EnvWindController", "m_nClipmapLevels")); }
    bool m_bIsMaster() { return read<bool>(baseAddr + offsets_instance.get("C_EnvWindController", "m_bIsMaster")); }
    bool m_bFirstTime() { return read<bool>(baseAddr + offsets_instance.get("C_EnvWindController", "m_bFirstTime")); }
};

#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPlayer_MovementServices_Humanoid  {
public:
    uintptr_t baseAddr;

    CPlayer_MovementServices_Humanoid() { baseAddr = 0; }
    CPlayer_MovementServices_Humanoid(uintptr_t base) : baseAddr(base) {}

    float m_flStepSoundTime() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_flStepSoundTime")); }
    float m_flFallVelocity() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_flFallVelocity")); }
    Vector3 m_groundNormal() { return read<Vector3>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_groundNormal")); }
    float m_flSurfaceFriction() { return read<float>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_flSurfaceFriction")); }
    uintptr_t m_surfaceProps() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_surfaceProps")); }
    int m_nStepside() { return read<int>(baseAddr + offsets_instance.get("CPlayer_MovementServices_Humanoid", "m_nStepside")); }
};

#pragma once
#include "../memory.h"
#include "../classes/sky3dparams_t.h"

class C_SkyCamera  {
public:
    uintptr_t baseAddr;

    C_SkyCamera() { baseAddr = 0; }
    C_SkyCamera(uintptr_t base) : baseAddr(base) {}

    sky3dparams_t m_skyboxData() { return read<sky3dparams_t>(baseAddr + offsets_instance.get("C_SkyCamera", "m_skyboxData")); }
    uintptr_t m_skyboxSlotToken() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_SkyCamera", "m_skyboxSlotToken")); }
    bool m_bUseAngles() { return read<bool>(baseAddr + offsets_instance.get("C_SkyCamera", "m_bUseAngles")); }
    C_SkyCamera* m_pNext() { return read<C_SkyCamera*>(baseAddr + offsets_instance.get("C_SkyCamera", "m_pNext")); }
};

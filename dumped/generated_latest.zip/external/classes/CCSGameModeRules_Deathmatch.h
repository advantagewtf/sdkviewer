#pragma once
#include "../memory.h"

class CCSGameModeRules_Deathmatch  {
public:
    uintptr_t baseAddr;

    CCSGameModeRules_Deathmatch() { baseAddr = 0; }
    CCSGameModeRules_Deathmatch(uintptr_t base) : baseAddr(base) {}

    uintptr_t m_flDMBonusStartTime() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSGameModeRules_Deathmatch", "m_flDMBonusStartTime")); }
    float m_flDMBonusTimeLength() { return read<float>(baseAddr + offsets_instance.get("CCSGameModeRules_Deathmatch", "m_flDMBonusTimeLength")); }
    uintptr_t m_sDMBonusWeapon() { return read<uintptr_t>(baseAddr + offsets_instance.get("CCSGameModeRules_Deathmatch", "m_sDMBonusWeapon")); }
};

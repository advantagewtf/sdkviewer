#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CInfoOffscreenPanoramaTexture  {
public:
    uintptr_t baseAddr;

    CInfoOffscreenPanoramaTexture() { baseAddr = 0; }
    CInfoOffscreenPanoramaTexture(uintptr_t base) : baseAddr(base) {}

    bool m_bDisabled() { return read<bool>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_bDisabled")); }
    int m_nResolutionX() { return read<int>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_nResolutionX")); }
    int m_nResolutionY() { return read<int>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_nResolutionY")); }
    uintptr_t m_szPanelType() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_szPanelType")); }
    uintptr_t m_szLayoutFileName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_szLayoutFileName")); }
    uintptr_t m_RenderAttrName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_RenderAttrName")); }
    Vector3 m_TargetEntities() { return read<Vector3>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_TargetEntities")); }
    int m_nTargetChangeCount() { return read<int>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_nTargetChangeCount")); }
    Vector3 m_vecCSSClasses() { return read<Vector3>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_vecCSSClasses")); }
    uintptr_t m_szTargetsName() { return read<uintptr_t>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_szTargetsName")); }
    Vector3 m_AdditionalTargetEntities() { return read<Vector3>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_AdditionalTargetEntities")); }
    bool m_bCheckCSSClasses() { return read<bool>(baseAddr + offsets_instance.get("CInfoOffscreenPanoramaTexture", "m_bCheckCSSClasses")); }
};

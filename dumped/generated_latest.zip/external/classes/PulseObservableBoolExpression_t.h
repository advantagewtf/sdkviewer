#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"
#include "../types/Vector3.h"

class PulseObservableBoolExpression_t  {
public:
    uintptr_t baseAddr;

    PulseObservableBoolExpression_t() { baseAddr = 0; }
    PulseObservableBoolExpression_t(uintptr_t base) : baseAddr(base) {}

    CPulse_OutflowConnection m_EvaluateConnection() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_EvaluateConnection")); }
    Vector3 m_DependentObservableVars() { return read<Vector3>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_DependentObservableVars")); }
    Vector3 m_DependentObservableBlackboardReferences() { return read<Vector3>(baseAddr + offsets_instance.get("PulseObservableBoolExpression_t", "m_DependentObservableBlackboardReferences")); }
};

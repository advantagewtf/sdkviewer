#pragma once
#include "../memory.h"

class C_CSGO_EndOfMatchCamera  {
public:
    uintptr_t baseAddr;

    C_CSGO_EndOfMatchCamera() { baseAddr = 0; }
    C_CSGO_EndOfMatchCamera(uintptr_t base) : baseAddr(base) {}

};

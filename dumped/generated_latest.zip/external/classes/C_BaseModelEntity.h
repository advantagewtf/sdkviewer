#pragma once
#include "../memory.h"
#include "../classes/CCollisionProperty.h"
#include "../classes/CGlowProperty.h"
#include "../classes/CHitboxComponent.h"
#include "../types/Vector3.h"
class CDestructiblePartsComponent;
class CRenderComponent;

class C_BaseModelEntity  {
public:
    uintptr_t baseAddr;

    C_BaseModelEntity() { baseAddr = 0; }
    C_BaseModelEntity(uintptr_t base) : baseAddr(base) {}

    CRenderComponent* m_CRenderComponent() { return read<CRenderComponent*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_CRenderComponent")); }
    CHitboxComponent m_CHitboxComponent() { return read<CHitboxComponent>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_CHitboxComponent")); }
    uintptr_t m_nDestructiblePartInitialStateDestructed0() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed0")); }
    uintptr_t m_nDestructiblePartInitialStateDestructed1() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed1")); }
    uintptr_t m_nDestructiblePartInitialStateDestructed2() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed2")); }
    uintptr_t m_nDestructiblePartInitialStateDestructed3() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed3")); }
    uintptr_t m_nDestructiblePartInitialStateDestructed4() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed4")); }
    int m_nDestructiblePartInitialStateDestructed0_PartIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed0_PartIndex")); }
    int m_nDestructiblePartInitialStateDestructed1_PartIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed1_PartIndex")); }
    int m_nDestructiblePartInitialStateDestructed2_PartIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed2_PartIndex")); }
    int m_nDestructiblePartInitialStateDestructed3_PartIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed3_PartIndex")); }
    int m_nDestructiblePartInitialStateDestructed4_PartIndex() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nDestructiblePartInitialStateDestructed4_PartIndex")); }
    CDestructiblePartsComponent* m_pDestructiblePartsSystemComponent() { return read<CDestructiblePartsComponent*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_pDestructiblePartsSystemComponent")); }
    bool m_bInitModelEffects() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bInitModelEffects")); }
    bool m_bDoingModelEffects() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bDoingModelEffects")); }
    bool m_bIsStaticProp() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bIsStaticProp")); }
    int m_iOldHealth() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_iOldHealth")); }
    uintptr_t m_nRenderMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRenderMode")); }
    uintptr_t m_nRenderFX() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRenderFX")); }
    bool m_bAllowFadeInView() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bAllowFadeInView")); }
    uintptr_t m_clrRender() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_clrRender")); }
    Vector3 m_vecRenderAttributes() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vecRenderAttributes")); }
    bool m_bRenderToCubemaps() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bRenderToCubemaps")); }
    bool m_bNoInterpolate() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bNoInterpolate")); }
    CCollisionProperty m_Collision() { return read<CCollisionProperty>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_Collision")); }
    CGlowProperty m_Glow() { return read<CGlowProperty>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_Glow")); }
    float m_flGlowBackfaceMult() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flGlowBackfaceMult")); }
    float m_fadeMinDist() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_fadeMinDist")); }
    float m_fadeMaxDist() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_fadeMaxDist")); }
    float m_flFadeScale() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flFadeScale")); }
    float m_flShadowStrength() { return read<float>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_flShadowStrength")); }
    uint8_t m_nObjectCulling() { return read<uint8_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nObjectCulling")); }
    uintptr_t m_nRequiredDecalRtEncoding() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_nRequiredDecalRtEncoding")); }
    Vector3 m_vecViewOffset() { return read<Vector3>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_vecViewOffset")); }
    uintptr_t* m_pClientAlphaProperty() { return read<uintptr_t*>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_pClientAlphaProperty")); }
    uintptr_t m_ClientOverrideTint() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_ClientOverrideTint")); }
    bool m_bUseClientOverrideTint() { return read<bool>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bUseClientOverrideTint")); }
    int m_bvDisabledHitGroups() { return read<int>(baseAddr + offsets_instance.get("C_BaseModelEntity", "m_bvDisabledHitGroups")); }
};

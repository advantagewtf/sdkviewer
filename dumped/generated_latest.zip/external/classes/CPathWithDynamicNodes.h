#pragma once
#include "../memory.h"
#include "../types/Vector3.h"

class CPathWithDynamicNodes  {
public:
    uintptr_t baseAddr;

    CPathWithDynamicNodes() { baseAddr = 0; }
    CPathWithDynamicNodes(uintptr_t base) : baseAddr(base) {}

    Vector3 m_vecPathNodes() { return read<Vector3>(baseAddr + offsets_instance.get("CPathWithDynamicNodes", "m_vecPathNodes")); }
    uintptr_t m_xInitialPathWorldToLocal() { return read<uintptr_t>(baseAddr + offsets_instance.get("CPathWithDynamicNodes", "m_xInitialPathWorldToLocal")); }
};

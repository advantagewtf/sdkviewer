#pragma once
#include "../memory.h"
#include "../classes/CPulse_OutflowConnection.h"
#include "../types/Vector3.h"

class OutflowWithRequirements_t  {
public:
    uintptr_t baseAddr;

    OutflowWithRequirements_t() { baseAddr = 0; }
    OutflowWithRequirements_t(uintptr_t base) : baseAddr(base) {}

    CPulse_OutflowConnection m_Connection() { return read<CPulse_OutflowConnection>(baseAddr + offsets_instance.get("OutflowWithRequirements_t", "m_Connection")); }
    uintptr_t m_DestinationFlowNodeID() { return read<uintptr_t>(baseAddr + offsets_instance.get("OutflowWithRequirements_t", "m_DestinationFlowNodeID")); }
    Vector3 m_RequirementNodeIDs() { return read<Vector3>(baseAddr + offsets_instance.get("OutflowWithRequirements_t", "m_RequirementNodeIDs")); }
    int m_nCursorStateBlockIndex() { return read<int>(baseAddr + offsets_instance.get("OutflowWithRequirements_t", "m_nCursorStateBlockIndex")); }
};

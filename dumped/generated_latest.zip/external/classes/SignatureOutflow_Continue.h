#pragma once
#include "../memory.h"

class SignatureOutflow_Continue  {
public:
    uintptr_t baseAddr;

    SignatureOutflow_Continue() { baseAddr = 0; }
    SignatureOutflow_Continue(uintptr_t base) : baseAddr(base) {}

};

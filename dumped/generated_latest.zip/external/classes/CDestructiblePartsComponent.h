#pragma once
#include "../memory.h"
class C_BaseModelEntity;

class CDestructiblePartsComponent  {
public:
    uintptr_t baseAddr;

    CDestructiblePartsComponent() { baseAddr = 0; }
    CDestructiblePartsComponent(uintptr_t base) : baseAddr(base) {}

    uintptr_t __m_pChainEntity() { return read<uintptr_t>(baseAddr + offsets_instance.get("CDestructiblePartsComponent", "__m_pChainEntity")); }
    uint16_t m_vecDamageTakenByHitGroup() { return read<uint16_t>(baseAddr + offsets_instance.get("CDestructiblePartsComponent", "m_vecDamageTakenByHitGroup")); }
    C_BaseModelEntity* m_hOwner() { return read<C_BaseModelEntity*>(baseAddr + offsets_instance.get("CDestructiblePartsComponent", "m_hOwner")); }
};

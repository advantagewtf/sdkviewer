#pragma once
#include "../memory.h"
#include "../classes/CEntityIOOutput.h"
#include "../types/Vector3.h"

class C_DynamicProp  {
public:
    uintptr_t baseAddr;

    C_DynamicProp() { baseAddr = 0; }
    C_DynamicProp(uintptr_t base) : baseAddr(base) {}

    bool m_bUseHitboxesForRenderBox() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bUseHitboxesForRenderBox")); }
    bool m_bUseAnimGraph() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bUseAnimGraph")); }
    CEntityIOOutput m_pOutputAnimBegun() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_DynamicProp", "m_pOutputAnimBegun")); }
    CEntityIOOutput m_pOutputAnimOver() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_DynamicProp", "m_pOutputAnimOver")); }
    CEntityIOOutput m_pOutputAnimLoopCycleOver() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_DynamicProp", "m_pOutputAnimLoopCycleOver")); }
    CEntityIOOutput m_OnAnimReachedStart() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_DynamicProp", "m_OnAnimReachedStart")); }
    CEntityIOOutput m_OnAnimReachedEnd() { return read<CEntityIOOutput>(baseAddr + offsets_instance.get("C_DynamicProp", "m_OnAnimReachedEnd")); }
    uintptr_t m_iszIdleAnim() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_DynamicProp", "m_iszIdleAnim")); }
    uintptr_t m_nIdleAnimLoopMode() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_DynamicProp", "m_nIdleAnimLoopMode")); }
    bool m_bRandomizeCycle() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bRandomizeCycle")); }
    bool m_bStartDisabled() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bStartDisabled")); }
    bool m_bFiredStartEndOutput() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bFiredStartEndOutput")); }
    bool m_bForceNpcExclude() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bForceNpcExclude")); }
    bool m_bCreateNonSolid() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bCreateNonSolid")); }
    bool m_bIsOverrideProp() { return read<bool>(baseAddr + offsets_instance.get("C_DynamicProp", "m_bIsOverrideProp")); }
    int m_iInitialGlowState() { return read<int>(baseAddr + offsets_instance.get("C_DynamicProp", "m_iInitialGlowState")); }
    int m_nGlowRange() { return read<int>(baseAddr + offsets_instance.get("C_DynamicProp", "m_nGlowRange")); }
    int m_nGlowRangeMin() { return read<int>(baseAddr + offsets_instance.get("C_DynamicProp", "m_nGlowRangeMin")); }
    uintptr_t m_glowColor() { return read<uintptr_t>(baseAddr + offsets_instance.get("C_DynamicProp", "m_glowColor")); }
    int m_nGlowTeam() { return read<int>(baseAddr + offsets_instance.get("C_DynamicProp", "m_nGlowTeam")); }
    int m_iCachedFrameCount() { return read<int>(baseAddr + offsets_instance.get("C_DynamicProp", "m_iCachedFrameCount")); }
    Vector3 m_vecCachedRenderMins() { return read<Vector3>(baseAddr + offsets_instance.get("C_DynamicProp", "m_vecCachedRenderMins")); }
    Vector3 m_vecCachedRenderMaxs() { return read<Vector3>(baseAddr + offsets_instance.get("C_DynamicProp", "m_vecCachedRenderMaxs")); }
};
